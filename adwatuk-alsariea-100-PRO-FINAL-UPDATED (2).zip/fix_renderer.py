import re
with open('src/components/tools/ToolRenderer.tsx', 'r') as f:
    content = f.read()
    
pattern = re.compile(r"    case 'mega-converters-suite':.*?case 'fin-crypto-converter':\s+return <MegaConvertersSuite defaultTab=\"arabic-tafqeet\" />;", re.DOTALL)

replacement = """    case 'mega-converters-suite':
      return <MegaConvertersSuite defaultTab="text-cases" />;
    case 'media-converters-hub':
    case 'media-image-converter':
      return <UniversalImageConverter />;
    case 'media-audio-converter':
      return <AudioConverter />;
    case 'media-video-converter':
      return <VideoConverter />;
    case 'media-archive-converter':
      return <ArchiveConverter />;
    case 'documents-converters-hub':
    case 'doc-word-to-pdf':
    case 'doc-pdf-to-word':
    case 'doc-excel-to-pdf':
    case 'doc-pdf-to-excel':
    case 'doc-ocr-extractor':
      return <DocumentConverter />;
    case 'data-converters-hub':
    case 'data-json-to-csv':
    case 'data-csv-to-json':
    case 'data-json-to-yaml':
    case 'data-yaml-to-json':
    case 'data-sql-to-json':
      return <DataTableConverter />;
    case 'dev-converters-hub':
    case 'dev-code-converters':
      return <DevConverterSuite defaultMode="json-formatter" />;
    case 'dev-color-converters':
      return <DevConverterSuite defaultMode="color-converter" />;
    case 'dev-units-converters':
      return <UnitConverter />;
    case 'dev-timestamp-converters':
      return <TimeDateConverter />;
    case 'finance-converters-hub':
    case 'fin-gold-metals-calc':
    case 'fin-crypto-converter':
      return <FinancialCalculator />;
    case 'fin-currency-exchange':
      return <CurrencyCalculator />;"""

new_content = pattern.sub(replacement, content)
with open('src/components/tools/ToolRenderer.tsx', 'w') as f:
    f.write(new_content)
