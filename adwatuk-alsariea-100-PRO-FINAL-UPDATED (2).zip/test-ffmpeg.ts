import { FFmpeg } from '@ffmpeg/ffmpeg';
import coreURL from '@ffmpeg/core/dist/esm/ffmpeg-core.js?url';
console.log(coreURL);
