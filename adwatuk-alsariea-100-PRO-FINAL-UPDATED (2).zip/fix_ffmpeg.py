import re

for filename in ['src/components/tools/converters/VideoConverter.tsx', 'src/components/tools/converters/AudioConverter.tsx']:
    with open(filename, 'r') as f:
        content = f.read()

    # Ensure toBlobURL is imported
    if 'toBlobURL' not in content:
        content = content.replace("import { fetchFile } from '@ffmpeg/util';", "import { fetchFile, toBlobURL } from '@ffmpeg/util';")

    old_load = """const loadFFmpeg = async () => {
  if (ffmpegGlobal) return ffmpegGlobal;
  const f = new FFmpeg();
  const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.10/dist/umd';
  await f.load({
    coreURL: `${baseURL}/ffmpeg-core.js`,
    wasmURL: `${baseURL}/ffmpeg-core.wasm`,
  });
  ffmpegGlobal = f;
  return f;
};"""

    new_load = """const loadFFmpeg = async () => {
  if (ffmpegGlobal) return ffmpegGlobal;
  const f = new FFmpeg();
  const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.6/dist/umd';
  await f.load({
    coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
    wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
  });
  ffmpegGlobal = f;
  return f;
};"""

    content = content.replace(old_load, new_load)
    
    with open(filename, 'w') as f:
        f.write(content)

