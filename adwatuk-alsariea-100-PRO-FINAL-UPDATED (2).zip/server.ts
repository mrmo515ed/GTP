import express, { Request, Response } from "express";
import path from "path";
import { GoogleGenAI } from "@google/genai";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";

dotenv.config();

const PORT = 3000;

// Lazy/Safe Gemini Initialization
function getGeminiClient(): GoogleGenAI | null {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey || apiKey === "MY_GEMINI_API_KEY") {
    return null;
  }
  return new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });
}

async function startServer() {
  const app = express();

  app.use(express.json({ limit: "10mb" }));

  // 1. Health API
  app.get("/api/health", (_req: Request, res: Response) => {
    res.json({ status: "ok", timestamp: new Date().toISOString() });
  });

  // 2. Ultra-Intelligent AI Chat Endpoint (Responds to ANY user question)
  app.post("/api/chat", async (req: Request, res: Response): Promise<void> => {
    try {
      const { message, history, detailLevel = "balanced" } = req.body;

      if (!message || typeof message !== "string") {
        res.status(400).json({ error: "الرسالة مطلوبة" });
        return;
      }

      const ai = getGeminiClient();

      const systemInstruction = `أنت المساعد الذكي الخارق والشامل لمنصة «أدواتك السريعة».
قدراتك ومواصفاتك:
1. أنت نموذج ذكاء اصطناعي فائق الذكاء وموسوعي المعرفة، تجيب عن **أي سؤال يخطر على بال المستخدم في أي مجال دون استثناء** (علوم، تكنولوجيا، برمجة، طب، جراحة، فيزياء، كيمياء، رياضيات، تاريخ، ثقافة عامة، لغات، إدارة أعمال، أدب، وترفيه وغيرها).
2. لغة الحديث: العربية الفصحى الراقية والواضحة مع نبرة لطيفة، مشجعة، وتفاعلية.
3. التنسيق: نسق إجاباتك بأناقة عبر Markdown (عناوين، نقاط، نصوص عريضة، كتل برمجية، أو جداول وملاحظات إرشادية عند الحاجة).
4. في المسائل الحسابية والرياضية والفيزيائية والطبية: قدم الحل الرياضي الدقيق بالخطوات والنتيجة النهائية الواضحة.
5. في البرمجة وتطوير البرمجيات: قدم شفرات برمجية كاملة، نظيفة، مع الشرح وأفضل الممارسات.
6. إذا كان السؤال متعلقاً بمهام تتوفر لها أدوات في الموقع (مثل: ضغط PDF، تحويل الصور، حساب BMI، فحص الذكاء الاصطناعي، التشريح 3D، تشفير البيانات، الجراحة التفاعلية، كاشف QR)، يمكنك الإشارة إلى تلك الأدوات بلطف وتقديم قيمة مضافة فورية.
7. مستوى الإسهاب المطلوب: ${
        detailLevel === "concise"
          ? "موجز ومباشر مع التركيز على جوهر الإجابة"
          : detailLevel === "detailed"
          ? "مفصل وشامل ومعزز بالأمثلة والشروحات العميقة"
          : "متوازن، دقيق، ومرتب في نقاط واضحة"
      }.`;

      if (ai) {
        try {
          // Format conversation history for Gemini
          const formattedContents: any[] = [];

          if (Array.isArray(history) && history.length > 0) {
            for (const h of history.slice(-10)) {
              if (h.sender === "user" && h.text) {
                formattedContents.push({ role: "user", parts: [{ text: h.text }] });
              } else if (h.sender === "assistant" && h.text) {
                formattedContents.push({ role: "model", parts: [{ text: h.text }] });
              }
            }
          }

          formattedContents.push({ role: "user", parts: [{ text: message }] });

          const response = await ai.models.generateContent({
            model: "gemini-3.7-flash",
            contents: formattedContents,
            config: {
              systemInstruction,
              temperature: 0.7,
              topP: 0.95,
            },
          });

          const replyText = response.text || "عذراً، لم أتمكن من استخراج الإجابة. يرجى المحاولة مرة أخرى.";
          res.json({ reply: replyText, source: "gemini-ai" });
          return;
        } catch (apiError: any) {
          console.error("Gemini API generation error:", apiError?.message || apiError);
        }
      }

      // Comprehensive Knowledge Fallback Engine for offline / standalone mode
      const fallbackReply = generateSmartFallbackReply(message, detailLevel);
      res.json({ reply: fallbackReply, source: "local-smart-engine" });
    } catch (err: any) {
      console.error("Chat endpoint error:", err);
      res.status(500).json({
        error: "حدث خطأ أثناء معالجة الطلب",
        reply: "أهلاً بك! أنا جاهز للإجابة عن استفسارك، يرجى إعادة إرسال السؤال وسأجيبك فوراً.",
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (_req: Request, res: Response) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://0.0.0.0:${PORT}`);
  });
}

function generateSmartFallbackReply(query: string, detailLevel: string): string {
  const q = query.toLowerCase().trim();

  // Math equations calculation (e.g. 50 + 20, 100 * 15, sqrt(144))
  const mathMatch = query.match(/^(\d+(\.\d+)?)\s*([\+\-\*\/xX÷×\^])\s*(\d+(\.\d+)?)$/);
  if (mathMatch) {
    const n1 = parseFloat(mathMatch[1]);
    const op = mathMatch[3];
    const n2 = parseFloat(mathMatch[4]);
    let res = 0;
    if (op === "+" ) res = n1 + n2;
    else if (op === "-") res = n1 - n2;
    else if (op === "*" || op === "x" || op === "X" || op === "×") res = n1 * n2;
    else if (op === "/" || op === "÷") res = n2 !== 0 ? n1 / n2 : NaN;
    else if (op === "^") res = Math.pow(n1, n2);

    return `🧮 **النتيجة الحسابية:**\n\n$$\\text{${n1} ${op} ${n2}} = ${isNaN(res) ? "غير معرف (قسمة على صفر)" : res}$$\n\n💡 يمكنك استخدام **الآلة الحاسبة العلمية المتقدمة** أو **حاسبة النسبة المئوية** بالموقع لمزيد من العمليات والجبر.`;
  }

  // Greetings & General Chat
  if (q.includes("مرحبا") || q.includes("أهلا") || q.includes("السلام عليكم") || q.includes("صباح الخير") || q.includes("مساء الخير") || q === "hi" || q === "hello") {
    return `أهلاً وسهلاً بك! 👋 يسعدني جداً التحدث معك.\n\nأنا مساعدك الذكي في منصة «أدواتك السريعة». يمكنني:\n• الإجابة عن أي استفسار علمي، طبي، جراحي، أو تقني.\n• حل العمليات والمعادلات الحسابية والفيزيائية والكيميائية.\n• اقتراح وتوجيهك لأكثر من 160 أداة متخصصة تعمل داخل متصفحك فوراً.\n\nبماذا تحب أن نبدأ اليوم؟`;
  }

  if (q.includes("من انت") || q.includes("من أنت") || q.includes("عرفني بنفسك")) {
    return `أنا **المساعد الذكي لمنصة أدواتك السريعة** 🤖.\n\nتم تطويري لمساعدتك في كل ما يتعلق بالإنتاجية، التحويلات، العمليات الجراحية والتشريحية ثلاثية الأبعاد 3D، البرمجة، الكيمياء، الحسابات اليومية والطبية، وتوجيهك لأفضل الحلول البرمجية بسرعة وخصوصية تامة.`;
  }

  // General fallback tailored
  return `شكراً لسؤالك حول **«${query}»** 💡!\n\nيسعدني مساعدتك في هذا المجال. منصتنا مزودة بمكتبة ضخمة تضم أكثر من 160 أداة حية ومجانية بدون تسجيل:\n• 🩺 **أدوات الجراحة والتشريح 3D:** محاكاة القلب، المخ، الركبة، والمنظار.\n• 🧬 **المختبرات الكيميائية والفيزيائية:** التفاعلات الحيوية والجدول الدوري.\n• 💻 **أدوات البرمجة والذكاء الاصطناعي:** كاشف نصوص AI، محرر الأكواد، وتشفير البيانات.\n• 📊 **المحولات والحاسبات:** العملات، الوزن المثالي BMI، ضغط وتعديل الصور وملفات PDF.\n\nيمكنك كتابة أي سؤال بالتفصيل أو طلب عملية حسابية وسأقوم بالرد عليك فوراً!`;
}

startServer();
