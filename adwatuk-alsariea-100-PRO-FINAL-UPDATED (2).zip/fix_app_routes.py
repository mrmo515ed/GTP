import re

with open('src/App.tsx', 'r') as f:
    content = f.read()

if "import { ErrorBoundary }" not in content:
    content = content.replace("import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';", "import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';\nimport { ErrorBoundary } from './components/common/ErrorBoundary';")

replacement = """      <ErrorBoundary>
        <Routes>"""

content = content.replace("<Routes>", replacement)

replacement2 = """        </Routes>
      </ErrorBoundary>"""

content = content.replace("</Routes>", replacement2)

with open('src/App.tsx', 'w') as f:
    f.write(content)
