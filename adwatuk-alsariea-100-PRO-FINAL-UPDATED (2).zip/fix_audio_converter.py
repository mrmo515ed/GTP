import re

with open('src/components/tools/converters/AudioConverter.tsx', 'r') as f:
    content = f.read()

state_addition = r"""  const [isPlaying, setIsPlaying] = useState(false);
  const [convertedResultUrl, setConvertedResultUrl] = useState<string | null>(null);
  const [convertedResultName, setConvertedResultName] = useState<string>('');
"""
content = re.sub(r"  const \[isPlaying, setIsPlaying\] = useState\(false\);", state_addition, content)

new_handlers = r"""  const handleConvert = async () => {
    if (!selectedFile) {
      alert('الرجاء اختيار ملف صوتي أولاً');
      return;
    }

    setIsProcessing(true);
    setConvertedResultUrl(null);
    setConvertedResultName('');

    try {
      // Decode audio using AudioContext
      const arrayBuffer = await selectedFile.arrayBuffer();
      const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      const decodedBuffer = await audioCtx.decodeAudioData(arrayBuffer);

      // Encode to WAV
      const wavBlob = audioBufferToWav(decodedBuffer, channels === 'mono');
      const baseName = selectedFile.name.split('.')[0] || 'audio';
      const targetExt = AUDIO_MODES.find(m => m.id === currentMode)?.targetExt || 'wav';

      const downloadUrl = URL.createObjectURL(wavBlob);
      setConvertedResultUrl(downloadUrl);
      setConvertedResultName(`${baseName}_converted.${targetExt}`);

      confetti({ particleCount: 35, spread: 60, origin: { y: 0.8 } });
    } catch (err: any) {
      alert('خطأ في معالجة وتحويل الصوت: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (convertedResultUrl && convertedResultName) {
      const a = document.createElement('a');
      a.href = convertedResultUrl;
      a.download = convertedResultName;
      a.click();
    }
  };
"""

old_func_pattern = re.compile(r"  const handleConvertAndDownload = async \(\) => \{.*?(?=\n  // Convert AudioBuffer)", re.DOTALL)
content = old_func_pattern.sub(new_handlers, content)

buttons_replace = r"""        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
          <button
            onClick={handleConvert}
            disabled={!selectedFile || isProcessing}
            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-indigo-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5"
          >
            {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            <span>تحويل ومعالجة</span>
          </button>
          
          {convertedResultUrl && (
            <button
              onClick={handleDownload}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-emerald-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5 animate-in fade-in zoom-in"
            >
              <Download className="w-4 h-4" />
              <span>تحميل النتيجة</span>
            </button>
          )}
        </div>"""

content = re.sub(r"        \{\/\* Action Button \*\/}.*?<\/div>", buttons_replace, content, flags=re.DOTALL)

with open('src/components/tools/converters/AudioConverter.tsx', 'w') as f:
    f.write(content)
