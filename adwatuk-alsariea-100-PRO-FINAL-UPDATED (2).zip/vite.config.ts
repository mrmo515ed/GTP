import tailwindcss from '@tailwindcss/vite';
import react from '@vitejs/plugin-react';
import path from 'path';
import {defineConfig} from 'vite';

export default defineConfig(() => {
  return {
    plugins: [react(), tailwindcss()],
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      },
    },
    // FFmpeg ships its own module worker; pre-bundling rewrites its relative worker URL incorrectly.
    optimizeDeps: {
      exclude: ['@ffmpeg/ffmpeg', '@ffmpeg/util'],
    },
    build: {
      target: 'esnext',
      cssCodeSplit: true,
      minify: 'esbuild',
      sourcemap: true,
      modulePreload: {
        resolveDependencies(_filename, dependencies, context) {
          if (context.hostType !== 'html') return dependencies;
          return dependencies.filter(dependency =>
            !/vendor-(pdf|docs|3d|charts)/.test(dependency),
          );
        },
      },
      rollupOptions: {
        output: {
          manualChunks(id) {
            if (id.includes('node_modules')) {
              if (id.includes('three')) {
                return 'vendor-3d';
              }
              if (id.includes('pdf-lib') || id.includes('jspdf') || id.includes('pdfjs-dist') || id.includes('html2pdf')) {
                return 'vendor-pdf';
              }
              if (id.includes('xlsx') || id.includes('mammoth') || id.includes('docx') || id.includes('papaparse')) {
                return 'vendor-docs';
              }
              if (id.includes('recharts') || id.includes('canvas-confetti')) {
                return 'vendor-charts';
              }
              if (id.includes('lucide-react')) {
                return 'vendor-icons';
              }
              if (id.includes('react') || id.includes('react-dom') || id.includes('react-router-dom')) {
                return 'vendor-core';
              }
            }
          },
        },
      },
    },
    server: {
      host: '0.0.0.0',
      allowedHosts: true,
      // HMR is disabled in AI Studio via DISABLE_HMR env var.
      // Do not modifyâfile watching is disabled to prevent flickering during agent edits.
      hmr: process.env.DISABLE_HMR !== 'true',
      // Disable file watching when DISABLE_HMR is true to save CPU during agent edits.
      watch: process.env.DISABLE_HMR === 'true' ? null : {},
    },
  };
});
