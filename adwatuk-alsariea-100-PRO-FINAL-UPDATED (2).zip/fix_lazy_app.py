import re

with open('src/App.tsx', 'r') as f:
    content = f.read()

content = content.replace("import React, { useState, useEffect, useMemo, useCallback, lazy, Suspense } from 'react';", "import React, { useState, useEffect, useMemo, useCallback, lazy, Suspense } from 'react';\nimport { lazyWithRetry } from './utils/lazyWithRetry';")

content = content.replace("lazy(() =>", "lazyWithRetry(() =>")

with open('src/App.tsx', 'w') as f:
    f.write(content)
