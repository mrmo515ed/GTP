with open('src/components/tools/ToolRenderer.tsx', 'r') as f:
    content = f.read()

content = content.replace("""}: { toolId: string }) {
  return (
    <Suspense fallback={<LoadingFallback message="جاري تشغيل الأداة..." />}>
      {renderTool(toolId)}
    </Suspense>
  );
}""", "")

with open('src/components/tools/ToolRenderer.tsx', 'w') as f:
    f.write(content)
