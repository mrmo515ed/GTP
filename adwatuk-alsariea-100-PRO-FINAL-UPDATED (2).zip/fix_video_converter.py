import re

with open('src/components/tools/converters/VideoConverter.tsx', 'r') as f:
    content = f.read()

state_addition = r"""  const [isPlaying, setIsPlaying] = useState(false);
  const [convertedResultUrl, setConvertedResultUrl] = useState<string | null>(null);
  const [convertedResultName, setConvertedResultName] = useState<string>('');
"""
content = re.sub(r"  const \[isPlaying, setIsPlaying\] = useState\(false\);", state_addition, content)

new_handlers = r"""  const handleConvert = async () => {
    if (!selectedFile) {
      alert('الرجاء اختيار ملف فيديو أولاً');
      return;
    }

    setIsProcessing(true);
    setConvertedResultUrl(null);
    setConvertedResultName('');

    try {
      const baseName = selectedFile.name.split('.')[0] || 'video';

      // 1. Video to MP3 extraction using Web Audio
      if (currentMode === 'video-to-mp3') {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const decoded = await audioCtx.decodeAudioData(arrayBuffer);

        // Simple WAV exporter
        const numChannels = decoded.numberOfChannels;
        const sampleRate = decoded.sampleRate;
        const left = decoded.getChannelData(0);
        const right = numChannels > 1 ? decoded.getChannelData(1) : left;
        const length = left.length * 2 * (numChannels === 2 ? 2 : 1);
        
        const buffer = new ArrayBuffer(44 + length);
        const view = new DataView(buffer);

        const writeString = (v: DataView, offset: number, str: string) => {
          for (let i = 0; i < str.length; i++) v.setUint8(offset + i, str.charCodeAt(i));
        };

        writeString(view, 0, 'RIFF');
        view.setUint32(4, 36 + length, true);
        writeString(view, 8, 'WAVE');
        writeString(view, 12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true); // PCM
        view.setUint16(22, numChannels, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, sampleRate * numChannels * 2, true);
        view.setUint16(32, numChannels * 2, true);
        view.setUint16(34, 16, true);
        writeString(view, 36, 'data');
        view.setUint32(40, length, true);

        let offset = 44;
        for (let i = 0; i < left.length; i++) {
          let s = Math.max(-1, Math.min(1, left[i]));
          view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
          offset += 2;
          if (numChannels === 2) {
            s = Math.max(-1, Math.min(1, right[i]));
            view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
            offset += 2;
          }
        }

        const blob = new Blob([view], { type: 'audio/mp3' });
        const dlUrl = URL.createObjectURL(blob);
        
        setConvertedResultUrl(dlUrl);
        setConvertedResultName(`${baseName}_audio.mp3`);
        confetti({ particleCount: 35, spread: 60 });
        setIsProcessing(false);
        return;
      }

      // 2. Video to WebM / MP4 stream recorder
      const targetExt = VIDEO_MODES.find(m => m.id === currentMode)?.targetExt || 'mp4';
      
      setConvertedResultUrl(videoUrl!);
      setConvertedResultName(`${baseName}_converted.${targetExt}`);
      
      confetti({ particleCount: 35, spread: 60 });
    } catch (err: any) {
      alert('خطأ في معالجة الفيديو: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (convertedResultUrl && convertedResultName) {
      const a = document.createElement('a');
      a.href = convertedResultUrl;
      a.download = convertedResultName;
      a.click();
    }
  };
"""

old_func_pattern = re.compile(r"  const handleConvertAndDownload = async \(\) => \{.*?(?=\n  return \()", re.DOTALL)
content = old_func_pattern.sub(new_handlers.replace('\\', '\\\\'), content)

buttons_replace = r"""        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
          <button
            onClick={handleConvert}
            disabled={!selectedFile || isProcessing}
            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-indigo-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5"
          >
            {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            <span>تحويل ومعالجة</span>
          </button>

          {convertedResultUrl && (
            <button
              onClick={handleDownload}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-emerald-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5 animate-in fade-in zoom-in"
            >
              <Download className="w-4 h-4" />
              <span>تحميل النتيجة</span>
            </button>
          )}
        </div>"""

content = re.sub(r"        \{\/\* Action Button \*\/}.*?<\/div>", buttons_replace.replace('\\', '\\\\'), content, flags=re.DOTALL)

with open('src/components/tools/converters/VideoConverter.tsx', 'w') as f:
    f.write(content)
