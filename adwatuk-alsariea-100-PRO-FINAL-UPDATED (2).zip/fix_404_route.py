with open('src/App.tsx', 'r') as f:
    content = f.read()

replacement = """        <Route path="/ai-assistant" element={
          <main className="flex-1 w-full">
            <Suspense fallback={<LoadingFallback message="جاري تجهيز المساعد الذكي..." />}>
              <AssistantPage />
            </Suspense>
          </main>
        } />
        <Route path="*" element={
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-20 text-center">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">404 - الصفحة غير موجودة</h2>
            <p className="text-gray-500 mb-8">عذراً، لم نتمكن من العثور على الصفحة التي تبحث عنها.</p>
            <button onClick={() => window.location.href = '/'} className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold">العودة للرئيسية</button>
          </main>
        } />"""

content = content.replace("""        <Route path="/ai-assistant" element={
          <main className="flex-1 w-full">
            <Suspense fallback={<LoadingFallback message="جاري تجهيز المساعد الذكي..." />}>
              <AssistantPage />
            </Suspense>
          </main>
        } />""", replacement)

with open('src/App.tsx', 'w') as f:
    f.write(content)
