import re

with open('src/components/tools/converters/UniversalImageConverter.tsx', 'r') as f:
    content = f.read()

# Add states for converted result
state_addition = """  const [base64Output, setBase64Output] = useState<string>('');
  const [convertedResultUrl, setConvertedResultUrl] = useState<string | null>(null);
  const [convertedResultName, setConvertedResultName] = useState<string>('');
"""
content = re.sub(r"  const \[base64Output, setBase64Output\] = useState<string>\(''\);", state_addition, content)

# Replace handleConvertAndDownload with handleConvert and handleDownload
new_handlers = """  const handleConvert = async () => {
    if (!previewUrl && !base64Input) {
      alert('الرجاء اختيار صورة أو إدخال كود Base64 أولاً');
      return;
    }

    setIsProcessing(true);
    setConvertedResultUrl(null);
    setConvertedResultName('');

    try {
      if (currentMode === 'image-to-pdf') {
        const doc = new jsPDF({
          orientation: 'portrait',
          unit: 'px',
          format: [originalDimensions?.width || 800, originalDimensions?.height || 600]
        });

        doc.addImage(
          previewUrl!,
          'JPEG',
          0,
          0,
          originalDimensions?.width || 800,
          originalDimensions?.height || 600
        );
        const blob = doc.output('blob');
        const url = URL.createObjectURL(blob);
        setConvertedResultUrl(url);
        setConvertedResultName(`${selectedFile?.name.split('.')[0] || 'converted'}.pdf`);
        confetti({ particleCount: 30, spread: 50 });
        setIsProcessing(false);
        return;
      }

      if (currentMode === 'base64-to-image') {
        setConvertedResultUrl(base64Input);
        setConvertedResultName(`decoded_image.${targetFormat}`);
        confetti({ particleCount: 30, spread: 50 });
        setIsProcessing(false);
        return;
      }

      // Convert using Canvas
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        const canvas = canvasRef.current || document.createElement('canvas');
        const targetW = Number(resizeWidth) || img.naturalWidth;
        const targetH = Number(resizeHeight) || img.naturalHeight;
        
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        
        if (!ctx) {
          setIsProcessing(false);
          return;
        }

        // If target is JPEG, fill white background to avoid black transparency
        if (targetFormat === 'jpeg') {
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, targetW, targetH);
        }

        ctx.drawImage(img, 0, 0, targetW, targetH);
        
        const mime = targetFormat === 'jpeg' ? 'image/jpeg' : targetFormat === 'webp' ? 'image/webp' : 'image/png';
        const dataUrl = canvas.toDataURL(mime, quality);
        
        setConvertedResultUrl(dataUrl);
        const baseName = selectedFile?.name.split('.')[0] || 'converted_image';
        setConvertedResultName(`${baseName}.${targetFormat === 'jpeg' ? 'jpg' : targetFormat}`);
        
        confetti({ particleCount: 35, spread: 60, origin: { y: 0.8 } });
        setIsProcessing(false);
      };
      img.src = previewUrl!;
    } catch (err: any) {
      alert('حدث خطأ أثناء المعالجة: ' + err.message);
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (convertedResultUrl && convertedResultName) {
      const a = document.createElement('a');
      a.href = convertedResultUrl;
      a.download = convertedResultName;
      a.click();
    }
  };
"""

# Replace the function
old_func_pattern = re.compile(r"  const handleConvertAndDownload = async \(\) => \{.*?(?=\n  const handleWidthChange =)", re.DOTALL)
content = old_func_pattern.sub(new_handlers, content)

# Update the buttons
buttons_replace = """        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
          <button
            onClick={handleConvert}
            disabled={(!previewUrl && !base64Input) || isProcessing}
            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-indigo-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5"
          >
            {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            <span>تحويل ومعالجة</span>
          </button>
          
          {convertedResultUrl && currentMode !== 'image-to-base64' && (
            <button
              onClick={handleDownload}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-emerald-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5 animate-in fade-in zoom-in"
            >
              <Download className="w-4 h-4" />
              <span>تحميل النتيجة</span>
            </button>
          )}
        </div>"""

content = re.sub(r"        \{\/\* Action Button \*\/}.*?<\/div>", buttons_replace, content, flags=re.DOTALL)

with open('src/components/tools/converters/UniversalImageConverter.tsx', 'w') as f:
    f.write(content)
