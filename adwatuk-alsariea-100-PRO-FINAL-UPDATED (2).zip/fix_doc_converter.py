import re

with open('src/components/tools/converters/DocumentConverter.tsx', 'r') as f:
    content = f.read()

# Fix html2pdf output
content = content.replace("outputPdf('blob')", "output('blob')")

with open('src/components/tools/converters/DocumentConverter.tsx', 'w') as f:
    f.write(content)
