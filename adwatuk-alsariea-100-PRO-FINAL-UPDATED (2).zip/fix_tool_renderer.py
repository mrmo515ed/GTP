import re

with open('src/components/tools/ToolRenderer.tsx', 'r') as f:
    content = f.read()

if "import { ErrorBoundary }" not in content:
    content = content.replace("import React, { lazy, Suspense } from 'react';", "import React, { lazy, Suspense } from 'react';\nimport { ErrorBoundary } from '../common/ErrorBoundary';")

replacement = """export function ToolRenderer({ toolId }: { toolId: string }) {
  return (
    <ErrorBoundary>
      <Suspense fallback={<LoadingFallback message="جاري تشغيل الأداة..." />}>
        {renderTool(toolId)}
      </Suspense>
    </ErrorBoundary>
  );
}"""

content = re.sub(r"export function ToolRenderer.*?\{.*?\}", replacement, content, flags=re.DOTALL)

with open('src/components/tools/ToolRenderer.tsx', 'w') as f:
    f.write(content)
