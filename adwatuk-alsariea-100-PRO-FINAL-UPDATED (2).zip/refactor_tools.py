import re
import os

# We will just rewrite UniversalImageConverter, DocumentConverter, VideoConverter, and AudioConverter manually since each might be slightly different.
