export type ToolCategory = 
  | 'home'
  | 'all'
  | 'surgery-3d'
  | 'health'
  | 'text'
  | 'image'
  | 'documents'
  | 'data'
  | 'audio'
  | 'video'
  | 'archives'
  | 'calculators'
  | 'units'
  | 'currencies'
  | 'time-date'
  | 'dev'
  | 'student'
  | 'discovery'
  | 'engineering'
  | 'pdf'
  | 'design'
  | 'social'
  | 'converters'
  | 'encoding'
  | 'json'
  | 'xml'
  | 'svg'
  | 'misc'
  | 'favorites'
  | 'new'
  | 'popular';

export interface ToolDefinition {
  id: string;
  titleAr: string;
  titleEn: string;
  descriptionAr: string;
  category: ToolCategory;
  icon: string;
  tags: string[];
  keywords?: string[];
  badge?: 'شائع' | 'جديد' | 'مميز' | 'فوري' | string;
  isPopular?: boolean;
  isNew?: boolean;
  color?: string;
}

export interface CategoryInfo {
  id: ToolCategory;
  nameAr: string;
  nameEn: string;
  icon: string;
  descriptionAr: string;
  count?: number;
}

