import { useEffect } from 'react';

export interface SEOProps {
  title?: string;
  description?: string;
  keywords?: string[];
  canonicalUrl?: string;
  ogType?: 'website' | 'article';
  ogImage?: string;
  structuredData?: Record<string, any> | Record<string, any>[];
}

const DEFAULT_TITLE = 'أدواتك السريعة | منصة أدوات مجانية وسريعة 100% في المتصفح';
const DEFAULT_DESC = 'أكثر من 150 أداة احترافية مجانية وسريعة: جراحة وتشريح ثلاثي الأبعاد 3D، تحويل الصور، معالجة PDF، حاسبات مالية وطبية، روبوت ذكي والمزيد!';
const DEFAULT_URL = 'https://adwatuk-alsariea.netlify.app';
const DEFAULT_OG_IMAGE = 'https://adwatuk-alsariea.netlify.app/og-image.jpg';

export function useSEO(props?: SEOProps) {
  const safeProps = props || {};
  const {
    title,
    description = DEFAULT_DESC,
    keywords = [],
    canonicalUrl = DEFAULT_URL,
    ogType = 'website',
    ogImage = DEFAULT_OG_IMAGE,
    structuredData,
  } = safeProps;

  useEffect(() => {
    // 1. Update Title
    const fullTitle = title
      ? (title.includes('أدواتك السريعة') ? title : `${title} | أدواتك السريعة`)
      : DEFAULT_TITLE;
    document.title = fullTitle;

    // Helper to set or create meta tags
    const setMetaTag = (attrName: 'name' | 'property', attrValue: string, content: string) => {
      let element = document.querySelector(`meta[${attrName}="${attrValue}"]`) as HTMLMetaElement;
      if (!element) {
        element = document.createElement('meta');
        element.setAttribute(attrName, attrValue);
        document.head.appendChild(element);
      }
      element.setAttribute('content', content);
    };

    // 2. Set Basic Meta Tags
    setMetaTag('name', 'description', description);
    if (keywords.length > 0) {
      setMetaTag('name', 'keywords', keywords.join(', '));
    }

    // 3. Set Open Graph Tags
    setMetaTag('property', 'og:title', fullTitle);
    setMetaTag('property', 'og:description', description);
    setMetaTag('property', 'og:url', canonicalUrl);
    setMetaTag('property', 'og:type', ogType);
    setMetaTag('property', 'og:image', ogImage);
    setMetaTag('property', 'og:site_name', 'أدواتك السريعة');

    // 4. Set Twitter Card Tags
    setMetaTag('name', 'twitter:title', fullTitle);
    setMetaTag('name', 'twitter:description', description);
    setMetaTag('name', 'twitter:image', ogImage);

    // 5. Set Canonical Link
    let canonicalLink = document.querySelector('link[rel="canonical"]') as HTMLLinkElement;
    if (!canonicalLink) {
      canonicalLink = document.createElement('link');
      canonicalLink.setAttribute('rel', 'canonical');
      document.head.appendChild(canonicalLink);
    }
    canonicalLink.setAttribute('href', canonicalUrl);

    // 6. Set Structured Data (JSON-LD)
    const scriptId = 'seo-structured-data';
    let scriptTag = document.getElementById(scriptId) as HTMLScriptElement;
    
    if (structuredData) {
      if (!scriptTag) {
        scriptTag = document.createElement('script');
        scriptTag.id = scriptId;
        scriptTag.type = 'application/ld+json';
        document.head.appendChild(scriptTag);
      }
      scriptTag.textContent = JSON.stringify(structuredData);
    } else if (scriptTag) {
      scriptTag.remove();
    }

    return () => {
      // Optional cleanup on unmount: we leave canonical or default title for next transition
    };
  }, [title, description, keywords, canonicalUrl, ogType, ogImage, structuredData]);
}
