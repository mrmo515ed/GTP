import React, { useState, useEffect, useRef } from 'react';
import { X, ChevronDown, ChevronUp, Sparkles } from 'lucide-react';
import { getAdsterraBannerIframeHtml } from '../../utils/adsterraManager';

interface AdOverlayProps {
  slotId?: string;
  className?: string;
}

export function AdOverlay({ className = '' }: AdOverlayProps) {
  // Do NOT show initially when user opens page (prevents intrusive entry popups)
  const [isVisible, setIsVisible] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(1);

  // Listen for actual tool usage action events
  useEffect(() => {
    const handleToolAction = (e: Event) => {
      // Show ad banner only after user interacted/used a tool
      setIsVisible(true);
      setIsMinimized(false);
    };

    window.addEventListener('adwatuk_tool_action_executed', handleToolAction);
    return () => window.removeEventListener('adwatuk_tool_action_executed', handleToolAction);
  }, []);

  // Auto-close the in-site ad after a short view; the tool and its result stay mounted behind it.
  useEffect(() => {
    if (!isVisible || isMinimized) return;
    const timer = window.setTimeout(() => setIsVisible(false), 15000);
    return () => window.clearTimeout(timer);
  }, [isVisible, isMinimized]);

  // Responsive scaling for the 728px ad banner
  useEffect(() => {
    const handleResize = () => {
      if (containerRef.current) {
        const width = window.innerWidth;
        if (width < 760) {
          // Calculate scale to fit mobile screen with padding
          const targetWidth = Math.min(width - 32, 728);
          setScale(targetWidth / 728);
        } else {
          setScale(1);
        }
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  if (!isVisible) return null;

  const adIframeHtml = getAdsterraBannerIframeHtml();

  return (
    <div
      ref={containerRef}
      className={`fixed bottom-20 left-1/2 -translate-x-1/2 z-[60] w-[95%] max-w-[760px] transition-all duration-300 ${
        isMinimized ? 'translate-y-[calc(100%-28px)]' : 'translate-y-0'
      } ${className}`}
      id="ad-overlay-container"
    >
      <div className="bg-white/95 dark:bg-gray-900/95 backdrop-blur-md rounded-2xl border border-gray-200/90 dark:border-gray-700/80 shadow-2xl overflow-hidden p-2">
        {/* Header Bar */}
        <div className="flex items-center justify-between px-2 pb-1 text-[11px] text-gray-500 dark:text-gray-400 font-medium">
          <div className="flex items-center gap-1.5 font-bold text-gray-700 dark:text-gray-300">
            <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse" />
            <span>إعلان مميز • شكراً لاستخدامك الأداة (دعم استمرارية المنصة مجاناً)</span>
          </div>

          <div className="flex items-center gap-1">
            <button
              onClick={() => setIsMinimized(!isMinimized)}
              className="p-1 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-lg text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 transition"
              title={isMinimized ? 'إظهار الإعلان' : 'تصغير'}
            >
              {isMinimized ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
            <button
              onClick={() => setIsVisible(false)}
              className="p-1 hover:bg-rose-50 dark:hover:bg-rose-950/40 rounded-lg text-gray-400 hover:text-rose-600 transition"
              title="إغلاق"
            >
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Ad Body */}
        {!isMinimized && (
          <div
            className="w-full flex justify-center items-center overflow-hidden pt-1"
            style={{
              height: `${Math.round(90 * scale)}px`,
            }}
          >
            <div
              style={{
                transform: `scale(${scale})`,
                transformOrigin: 'top center',
                width: '728px',
                height: '90px',
              }}
            >
              <iframe
                srcDoc={adIframeHtml}
                width="728"
                height="90"
                frameBorder="0"
                scrolling="no"
                style={{ display: 'block', border: 'none', background: 'transparent' }}
                title="Floating Ad"
              />
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
