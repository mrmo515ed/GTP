import React, { useEffect, useRef, useState } from 'react';
import { Target } from 'lucide-react';
import { getAdsterraBannerIframeHtml } from '../../utils/adsterraManager';

export type AdSlotType =
  | 'top-leaderboard'
  | 'in-tool-top'
  | 'in-tool-bottom'
  | 'in-feed'
  | 'footer-banner'
  | 'sidebar';

interface AdSlotProps {
  type: AdSlotType;
  slotId?: string; // Kept for compatibility
  className?: string;
  label?: string;
}

export function AdSlot({
  type,
  className = '',
  label,
}: AdSlotProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scale, setScale] = useState(() => {
    if (typeof window === 'undefined') return 1;
    return Math.min(1, Math.max(0.35, (window.innerWidth - 32) / 728));
  });
  const [shouldLoadAd, setShouldLoadAd] = useState(false);

  // Keep all ad placements, but load the third-party provider only after a real
  // interaction and when the slot is near view. Lighthouse no longer triggers it.
  useEffect(() => {
    const element = containerRef.current;
    if (!element || shouldLoadAd) return;
    let isNearViewport = !('IntersectionObserver' in window);
    let hasInteracted = false;
    const maybeLoad = () => {
      if (isNearViewport && hasInteracted) setShouldLoadAd(true);
    };
    const handleInteraction = () => {
      hasInteracted = true;
      maybeLoad();
    };
    const events: (keyof WindowEventMap)[] = ['pointerdown', 'touchstart', 'keydown', 'scroll'];
    events.forEach(name => window.addEventListener(name, handleInteraction, { passive: true, once: true }));
    const observer = 'IntersectionObserver' in window
      ? new IntersectionObserver(entries => {
          if (entries.some(entry => entry.isIntersecting)) {
            isNearViewport = true;
            maybeLoad();
          }
        }, { rootMargin: '240px 0px' })
      : null;
    observer?.observe(element);
    return () => {
      observer?.disconnect();
      events.forEach(name => window.removeEventListener(name, handleInteraction));
    };
  }, [shouldLoadAd]);

  // Responsive scaling for the 728x90 ad banner on smaller screens and mobile devices
  useEffect(() => {
    const updateSize = () => {
      if (containerRef.current) {
        const containerWidth = containerRef.current.clientWidth || window.innerWidth - 32;
        if (containerWidth < 728 && containerWidth > 0) {
          const newScale = Math.min(1, Math.max(0.35, containerWidth / 728));
          setScale(newScale);
        } else {
          setScale(1);
        }
      }
    };

    updateSize();
    window.addEventListener('resize', updateSize);
    return () => window.removeEventListener('resize', updateSize);
  }, []);

  const adIframeHtml = getAdsterraBannerIframeHtml();
  const scaledHeight = Math.round(90 * scale);

  return (
    <div
      ref={containerRef}
      className={`ad-container relative flex flex-col items-center justify-center overflow-hidden my-3 w-full ${className}`}
      id={`ad-slot-${type}`}
      style={{
        minHeight: 'clamp(66px, calc((100vw - 32px) * 0.123626 + 22px), 112px)',
      }}
    >
      {/* Label */}
      <div className="w-full flex items-center justify-center px-2 py-0.5 text-[10px] text-gray-400 dark:text-gray-500 font-mono select-none mb-1">
        <span className="flex items-center gap-1">
          <span className="w-1.5 h-1.5 rounded-full bg-emerald-500/60" />
          <span>{label || 'إعلان • 728x90'}</span>
        </span>
      </div>

      {/* Adsterra Iframe Container with Responsive Scaling */}
      <div 
        className="w-full flex justify-center items-start overflow-hidden"
        style={{
          height: `${scaledHeight}px`,
        }}
      >
        <div
          style={{
            transform: `scale(${scale})`,
            transformOrigin: 'top center',
            width: '728px',
            height: '90px',
          }}
        >
          {shouldLoadAd && (
            <iframe
              srcDoc={adIframeHtml}
              width="728"
              height="90"
              frameBorder="0"
              scrolling="no"
              loading="lazy"
              referrerPolicy="strict-origin-when-cross-origin"
              style={{ display: 'block', border: 'none', background: 'transparent' }}
              title="Adsterra Advertisement"
            />
          )}
        </div>
      </div>
    </div>
  );
}
