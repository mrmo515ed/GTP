import React, { useMemo } from 'react';
import { motion } from 'motion/react';
import { 
  BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, Cell, 
  PieChart, Pie
} from 'recharts';
import { ALL_TOOLS } from '../../data/toolsData';
import { getToolIcon } from '../../utils/iconMap';
import { BarChart3, TrendingUp, Award, Activity, Play } from 'lucide-react';

interface UsageDashboardProps {
  toolUsage: Record<string, number>;
  onSelectTool: (toolId: string) => void;
}

const COLORS = ['#6366f1', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

export function UsageDashboard({ toolUsage, onSelectTool }: UsageDashboardProps) {
  // Compute top 5 tools from toolUsage
  const { top5Data, totalUsage, topTool, uniqueToolsCount } = useMemo(() => {
    const entries = Object.entries(toolUsage || {})
      .filter(([_, count]) => count > 0)
      .map(([id, count]) => {
        const tool = ALL_TOOLS.find(t => t.id === id);
        return {
          id,
          name: tool?.titleAr || id,
          shortName: (tool?.titleAr || id).length > 18 
            ? (tool?.titleAr || id).substring(0, 16) + '...' 
            : (tool?.titleAr || id),
          count,
          icon: tool?.icon || 'Sparkles',
          category: tool?.category || 'all',
          tool
        };
      })
      .sort((a, b) => b.count - a.count);

    const total = entries.reduce((acc, curr) => acc + curr.count, 0);
    const top5 = entries.slice(0, 5);
    const top = entries[0] || null;

    return {
      top5Data: top5,
      totalUsage: total,
      topTool: top,
      uniqueToolsCount: entries.length
    };
  }, [toolUsage]);

  if (top5Data.length === 0) {
    return null;
  }

  return (
    <motion.section 
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.4 }}
      className="my-8 bg-gradient-to-br from-slate-900 via-indigo-950 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-2xl border border-indigo-500/20 relative overflow-hidden"
    >
      {/* Background glow effects */}
      <div className="absolute -top-24 -left-24 w-72 h-72 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -right-24 w-72 h-72 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-6 border-b border-white/10 relative z-10">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-gradient-to-tr from-indigo-600 to-emerald-500 rounded-2xl shadow-lg shadow-indigo-500/30">
            <BarChart3 className="w-6 h-6 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white">
                لوحة إحصائيات الاستخدام
              </h2>
              <span className="flex items-center gap-1.5 px-2.5 py-0.5 rounded-full text-xs font-bold bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                تحديث مباشر
              </span>
            </div>
            <p className="text-xs sm:text-sm text-slate-300 mt-1">
              تحليل أدائك وأكثر 5 أدوات تكراراً واستخداماً في جهازك
            </p>
          </div>
        </div>
      </div>

      {/* Summary Stat Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-8 relative z-10">
        <div className="bg-white/5 backdrop-blur-md rounded-2xl p-4 border border-white/10 flex items-center gap-4">
          <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-xl">
            <Activity className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium block">إجمالي تشغيل الأدوات</span>
            <span className="text-2xl font-black text-white">{totalUsage} <span className="text-xs font-normal text-slate-300">مرة</span></span>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-md rounded-2xl p-4 border border-white/10 flex items-center gap-4">
          <div className="p-3 bg-emerald-500/20 text-emerald-400 rounded-xl">
            <Award className="w-6 h-6" />
          </div>
          <div className="overflow-hidden">
            <span className="text-xs text-slate-400 font-medium block">الأداة الأكثر استخداماً</span>
            <span className="text-base font-bold text-emerald-300 truncate block">
              {topTool ? topTool.name : '-'}
            </span>
          </div>
        </div>

        <div className="bg-white/5 backdrop-blur-md rounded-2xl p-4 border border-white/10 flex items-center gap-4">
          <div className="p-3 bg-amber-500/20 text-amber-400 rounded-xl">
            <TrendingUp className="w-6 h-6" />
          </div>
          <div>
            <span className="text-xs text-slate-400 font-medium block">عدد الأدوات النشطة</span>
            <span className="text-2xl font-black text-white">{uniqueToolsCount} <span className="text-xs font-normal text-slate-300">أداة</span></span>
          </div>
        </div>
      </div>

      {/* Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-stretch relative z-10">
        {/* Bar Chart - Top 5 */}
        <div className="lg:col-span-7 bg-white/5 backdrop-blur-md rounded-2xl p-5 border border-white/10 flex flex-col">
          <h3 className="text-sm font-bold text-slate-200 mb-4 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-indigo-400" />
            أكثر 5 أدوات استخداماً (رسم بياني)
          </h3>
          <div className="h-64 w-full mt-auto">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={top5Data} margin={{ top: 10, right: 10, left: -20, bottom: 25 }}>
                <XAxis 
                  dataKey="shortName" 
                  stroke="#94a3b8" 
                  fontSize={11}
                  tickLine={false}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis 
                  stroke="#94a3b8" 
                  fontSize={11}
                  tickLine={false}
                  allowDecimals={false}
                />
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      return (
                        <div className="bg-slate-900 border border-slate-700 text-white p-3 rounded-xl shadow-xl text-xs">
                          <p className="font-bold text-indigo-300 mb-1">{data.name}</p>
                          <p className="text-slate-300">عدد الاستخدامات: <span className="font-bold text-emerald-400">{data.count}</span></p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
                <Bar dataKey="count" radius={[8, 8, 0, 0]}>
                  {top5Data.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Pie Chart & Quick Action List */}
        <div className="lg:col-span-5 bg-white/5 backdrop-blur-md rounded-2xl p-5 border border-white/10 flex flex-col justify-between">
          <h3 className="text-sm font-bold text-slate-200 mb-3 flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            توزيع النسب والتشغيل السريع
          </h3>
          
          <div className="h-40 w-full flex items-center justify-center relative">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={top5Data}
                  cx="50%"
                  cy="50%"
                  innerRadius={35}
                  outerRadius={65}
                  paddingAngle={4}
                  dataKey="count"
                >
                  {top5Data.map((_, index) => (
                    <Cell key={`pie-cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip 
                  content={({ active, payload }) => {
                    if (active && payload && payload.length) {
                      const data = payload[0].payload;
                      const percentage = ((data.count / totalUsage) * 100).toFixed(1);
                      return (
                        <div className="bg-slate-900 border border-slate-700 text-white p-2.5 rounded-xl text-xs">
                          <p className="font-bold text-slate-200">{data.name}</p>
                          <p className="text-emerald-400">{data.count} مرة ({percentage}%)</p>
                        </div>
                      );
                    }
                    return null;
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          {/* Top Tools List */}
          <div className="space-y-2 mt-2">
            {top5Data.slice(0, 3).map((item, idx) => {
              const IconComp = getToolIcon(item.icon);
              return (
                <div 
                  key={item.id}
                  onClick={() => onSelectTool(item.id)}
                  className="flex items-center justify-between p-2 rounded-xl bg-white/5 hover:bg-white/15 transition cursor-pointer border border-white/5 group"
                >
                  <div className="flex items-center gap-2.5 min-w-0">
                    <span 
                      className="w-5 h-5 rounded-full text-[10px] font-bold flex items-center justify-center text-white shrink-0"
                      style={{ backgroundColor: COLORS[idx] }}
                    >
                      {idx + 1}
                    </span>
                    <IconComp className="w-4 h-4 text-slate-300 shrink-0" />
                    <span className="text-xs font-semibold text-slate-200 truncate group-hover:text-white transition">
                      {item.name}
                    </span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-xs font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded-md border border-emerald-500/20">
                      {item.count}
                    </span>
                    <Play className="w-3.5 h-3.5 text-slate-400 group-hover:text-white group-hover:translate-x-0.5 transition" />
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </motion.section>
  );
}
