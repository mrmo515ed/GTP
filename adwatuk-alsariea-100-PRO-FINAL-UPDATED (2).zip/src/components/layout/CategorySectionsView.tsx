import React from 'react';
import { CATEGORIES, ALL_TOOLS } from '../../data/toolsData';
import { ToolDefinition, ToolCategory } from '../../types';
import { ToolCard } from './ToolCard';
import {
  Type,
  Image as ImageIcon,
  Calculator,
  ArrowRightLeft,
  Code2,
  Stethoscope,
  HeartPulse,
  GraduationCap,
  Compass,
  FileText,
  Sparkles,
  Palette,
  Share2,
  ArrowLeft,
  ChevronLeft,
  Layers
} from 'lucide-react';

interface CategorySectionsViewProps {
  onSelectCategory: (category: ToolCategory) => void;
  onSelectTool: (tool: ToolDefinition) => void;
  favorites: string[];
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
}

export function CategorySectionsView({
  onSelectCategory,
  onSelectTool,
  favorites,
  onToggleFavorite,
}: CategorySectionsViewProps) {
  // Main display categories (excluding utility filters like all, favorites, new, popular)
  const displayCategories = CATEGORIES.filter(
    (c) => c.id !== 'all' && c.id !== 'favorites' && c.id !== 'new' && c.id !== 'popular'
  );

  const getCategoryIcon = (id: ToolCategory) => {
    switch (id) {
      case 'text':
        return Type;
      case 'image':
        return ImageIcon;
      case 'calculators':
        return Calculator;
      case 'units':
        return ArrowRightLeft;
      case 'dev':
        return Code2;
      case 'surgery-3d':
        return HeartPulse;
      case 'health':
        return Stethoscope;
      case 'student':
        return GraduationCap;
      case 'discovery':
        return Sparkles;
      case 'engineering':
        return Compass;
      case 'pdf':
        return FileText;
      case 'design':
        return Palette;
      case 'social':
        return Share2;
      default:
        return Compass;
    }
  };

  const getCategoryBadgeClass = (id: ToolCategory) => {
    switch (id) {
      case 'text':
        return 'bg-blue-50 dark:bg-blue-950/50 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800';
      case 'image':
        return 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800';
      case 'calculators':
        return 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800';
      case 'units':
        return 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800';
      case 'dev':
        return 'bg-purple-50 dark:bg-purple-950/50 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800';
      case 'health':
        return 'bg-red-50 dark:bg-red-950/50 text-red-700 dark:text-red-300 border-red-200 dark:border-red-800';
      case 'student':
        return 'bg-cyan-50 dark:bg-cyan-950/50 text-cyan-700 dark:text-cyan-300 border-cyan-200 dark:border-cyan-800';
      case 'discovery':
        return 'bg-fuchsia-50 dark:bg-fuchsia-950/50 text-fuchsia-700 dark:text-fuchsia-300 border-fuchsia-200 dark:border-fuchsia-800';
      case 'engineering':
        return 'bg-yellow-50 dark:bg-yellow-950/50 text-yellow-700 dark:text-yellow-300 border-yellow-200 dark:border-yellow-800';
      case 'pdf':
        return 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800';
      case 'design':
        return 'bg-amber-50 dark:bg-amber-950/50 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800';
      case 'social':
        return 'bg-pink-50 dark:bg-pink-950/50 text-pink-700 dark:text-pink-300 border-pink-200 dark:border-pink-800';
      default:
        return 'bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700';
    }
  };

  return (
    <div className="space-y-12 pt-4">
      {displayCategories.map((category) => {
        const categoryTools = ALL_TOOLS.filter((t) => t.category === category.id);
        if (categoryTools.length === 0) return null;

        const IconComponent = getCategoryIcon(category.id);
        const badgeColor = getCategoryBadgeClass(category.id);
        // Show up to 4 featured tools per section, with clean "View All" action
        const previewTools = categoryTools.slice(0, 4);
        const remainingCount = categoryTools.length - previewTools.length;

        return (
          <React.Fragment key={category.id}>
            <section
              id={`section-${category.id}`}
              className="space-y-4 rounded-3xl bg-white/70 dark:bg-gray-900/60 p-5 sm:p-7 border border-gray-200/70 dark:border-gray-800 shadow-2xs backdrop-blur-xs transition-all hover:border-gray-300 dark:hover:border-gray-700"
            >
              {/* Section Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-gray-100 dark:border-gray-800/80">
                <div className="flex items-center gap-3.5">
                  <div className={`w-11 h-11 rounded-2xl flex items-center justify-center border shadow-2xs ${badgeColor}`}>
                    <IconComponent className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h2 className="text-lg sm:text-xl font-heading font-extrabold text-gray-900 dark:text-white">
                        {category.nameAr}
                      </h2>
                      <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400">
                        {categoryTools.length} أداة
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                      {category.descriptionAr}
                    </p>
                  </div>
                </div>

                {/* View all category tools button */}
                <button
                  onClick={() => {
                    onSelectCategory(category.id);
                    window.scrollTo({ top: 400, behavior: 'smooth' });
                  }}
                  className="inline-flex items-center gap-2 self-start sm:self-auto px-4 py-2 rounded-xl text-xs font-bold text-emerald-700 dark:text-emerald-300 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200/80 dark:border-emerald-800/80 hover:bg-emerald-100 dark:hover:bg-emerald-900/60 transition shadow-2xs shrink-0"
                >
                  <span>استعراض كافة أدوات {category.nameAr} ({categoryTools.length})</span>
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </div>

              {/* Category Tools Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {previewTools.map((tool) => (
                  <ToolCard
                    key={tool.id}
                    tool={tool}
                    isFavorite={favorites.includes(tool.id)}
                    onToggleFavorite={onToggleFavorite}
                    onSelect={onSelectTool}
                  />
                ))}
              </div>

              {/* If there are more tools in this category, show footer expand button */}
              {remainingCount > 0 && (
                <div className="pt-2 text-center">
                  <button
                    onClick={() => {
                      onSelectCategory(category.id);
                      window.scrollTo({ top: 400, behavior: 'smooth' });
                    }}
                    className="inline-flex items-center gap-2 px-5 py-2 text-xs font-bold text-gray-700 dark:text-gray-300 bg-gray-50 dark:bg-gray-800/80 hover:bg-gray-100 dark:hover:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl transition"
                  >
                    <Layers className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                    <span>عرض المزيد من أدوات هذا القسم (+{remainingCount} أداة أخرى)</span>
                    <ArrowLeft className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                  </button>
                </div>
              )}
            </section>
          </React.Fragment>
        );
      })}
    </div>
  );
}
