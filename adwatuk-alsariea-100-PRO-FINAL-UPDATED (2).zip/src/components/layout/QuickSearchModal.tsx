import React, { useState, useEffect, useRef } from 'react';
import { Search, X, Star, ArrowLeft, Zap } from 'lucide-react';
import { ToolDefinition } from '../../types';
import { ALL_TOOLS } from '../../data/toolsData';

interface QuickSearchModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTool: (tool: ToolDefinition) => void;
}

export function QuickSearchModal({
  isOpen,
  onClose,
  onSelectTool,
}: QuickSearchModalProps) {
  const [query, setQuery] = useState('');
  const inputRef = useRef<HTMLInputElement>(null);
  
  // Recent searches state
  const [recentSearches, setRecentSearches] = useState<string[]>(() => {
    try {
      return JSON.parse(localStorage.getItem('adwatuk_recent_searches') || '[]');
    } catch {
      return [];
    }
  });

  useEffect(() => {
    if (isOpen) {
      setTimeout(() => inputRef.current?.focus(), 50);
      try {
        const history = JSON.parse(localStorage.getItem('adwatuk_recent_searches') || '[]');
        setRecentSearches(history);
      } catch {}
    } else {
      setQuery('');
    }
  }, [isOpen]);

  // Global keydown handler for Escape & Ctrl+K
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        if (isOpen) onClose();
      }
      if (e.key === 'Escape' && isOpen) {
        onClose();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  const filtered = ALL_TOOLS.filter((t) => {
    const q = query.toLowerCase().trim();
    if (!q) return t.isPopular || t.badge === 'شائع';
    return (
      t.titleAr.toLowerCase().includes(q) ||
      t.descriptionAr.toLowerCase().includes(q) ||
      (t.tags || []).some((k) => k.toLowerCase().includes(q)) ||
      (t.keywords || []).some((k) => k.toLowerCase().includes(q))
    );
  }).slice(0, query ? undefined : 6);

  return (
    <div
      className="fixed inset-0 z-50 overflow-y-auto bg-black/60 backdrop-blur-sm flex items-start justify-center p-4 pt-16 sm:pt-24"
      onClick={onClose}
      id="quick-search-spotlight-modal"
    >
      <div
        className="w-full max-w-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Search Input Bar */}
        <div className="p-4 border-b border-gray-100 dark:border-gray-800 flex items-center gap-3">
          <Search className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
          <input
            ref={inputRef}
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="اكتب اسم الأداة أو الكلمة الدلالية..."
            className="flex-1 bg-transparent text-sm sm:text-base text-gray-900 dark:text-gray-100 placeholder-gray-400 outline-none"
          />
          <button
            onClick={onClose}
            className="p-1.5 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-lg"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Results List or Recent */}
        <div className="max-h-96 overflow-y-auto p-2 divide-y divide-gray-100 dark:divide-gray-800/60">
          {!query && recentSearches.length > 0 && (
            <div className="p-2 mb-2 border-b border-gray-100 dark:border-gray-800/60 pb-3">
              <h4 className="text-[10px] font-bold text-gray-400 mb-2 px-1 uppercase">عمليات البحث الأخيرة</h4>
              <div className="flex flex-wrap gap-2">
                {recentSearches.map((s, idx) => (
                  <button
                    key={idx}
                    onClick={() => setQuery(s)}
                    className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 rounded-lg text-xs hover:bg-gray-200 dark:hover:bg-gray-700 transition"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {!query && (
            <div className="p-2">
              <h4 className="text-[10px] font-bold text-gray-400 mb-2 px-1 uppercase">الأدوات المقترحة</h4>
            </div>
          )}

          {query && filtered.length === 0 ? (
            <div className="py-12 text-center text-xs text-gray-500">
              لم يتم العثور على أداة مطابقة لكلمة البحث "{query}"
            </div>
          ) : (
            filtered.map((tool) => (
              <div
                key={tool.id}
                onClick={() => {
                  onSelectTool(tool);
                  onClose();
                }}
                className="p-3 hover:bg-emerald-50/70 dark:hover:bg-emerald-950/30 rounded-xl cursor-pointer transition flex items-center justify-between gap-3 group"
              >
                <div className="space-y-0.5 min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-gray-900 dark:text-gray-100 group-hover:text-emerald-600 dark:group-hover:text-emerald-400">
                      {tool.titleAr}
                    </span>
                    {tool.badge && (
                      <span className="px-1.5 py-0.2 text-[9px] font-bold rounded-md bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300">
                        {tool.badge}
                      </span>
                    )}
                  </div>
                  <p className="text-xs text-gray-500 dark:text-gray-400 truncate">
                    {tool.descriptionAr}
                  </p>
                </div>
                <ArrowLeft className="w-4 h-4 text-gray-400 group-hover:text-emerald-600 group-hover:-translate-x-1 transition-transform shrink-0" />
              </div>
            ))
          )}
        </div>

        {/* Footer Hint */}
        <div className="p-3 bg-gray-50 dark:bg-gray-800/60 border-t border-gray-100 dark:border-gray-800 text-[11px] text-gray-400 flex items-center justify-between">
          <span>اضغط على أي أداة لفتحها فوراً</span>
          <kbd className="px-1.5 py-0.5 font-mono text-[10px] bg-white dark:bg-gray-900 border rounded">
            ESC للإغلاق
          </kbd>
        </div>
      </div>
    </div>
  );
}
