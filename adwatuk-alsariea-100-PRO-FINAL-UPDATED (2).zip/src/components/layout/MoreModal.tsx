import React from 'react';
import { X, Moon, Sun, Heart, Info, Mail, ShieldCheck, FileText, ChevronLeft, BarChart3, Zap, LayoutGrid } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { ToolCategory } from '../../types';
import { UsageDashboard } from '../dashboard/UsageDashboard';

interface MoreModalProps {
  isOpen: boolean;
  onClose: () => void;
  darkMode: boolean;
  setDarkMode: (val: boolean) => void;
  onOpenAbout: () => void;
  onSelectCategory?: (category: ToolCategory) => void;
  toolUsage?: Record<string, number>;
  onSelectTool?: (toolId: string) => void;
}

export function MoreModal({ 
  isOpen, 
  onClose, 
  darkMode, 
  setDarkMode, 
  onOpenAbout, 
  onSelectCategory,
  toolUsage = {},
  onSelectTool
}: MoreModalProps) {
  const navigate = useNavigate();

  if (!isOpen) return null;

  const handleLinkClick = (action: () => void) => {
    action();
    onClose();
  };

  const handleToolClick = (toolId: string) => {
    if (onSelectTool) {
      onSelectTool(toolId);
    } else {
      navigate(`/tool/${toolId}`);
    }
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex justify-end bg-black/60 backdrop-blur-sm" onClick={onClose}>
      <div 
        className="w-full sm:w-11/12 max-w-lg bg-white dark:bg-gray-900 h-full flex flex-col shadow-2xl animate-in slide-in-from-right duration-300"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="flex flex-col h-full">
          {/* Header */}
          <div className="flex items-center justify-between p-4 border-b border-gray-100 dark:border-gray-800">
            <div className="flex items-center gap-2">
              <div className="p-2 rounded-xl bg-indigo-500/10 text-indigo-600 dark:text-indigo-400">
                <BarChart3 className="w-5 h-5" />
              </div>
              <h2 className="text-lg font-bold font-heading text-gray-900 dark:text-white">المزيد والإحصائيات</h2>
            </div>
            <button
              onClick={onClose}
              className="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="flex-1 overflow-y-auto p-4 space-y-6">
            
            {/* Usage Statistics Dashboard */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-2 flex items-center gap-2">
                <BarChart3 className="w-4 h-4 text-emerald-500" />
                إحصائيات الاستخدام الخاصة بك
              </h3>
              <div className="bg-gray-50 dark:bg-gray-800/40 rounded-2xl p-2 border border-gray-100 dark:border-gray-800">
                <UsageDashboard 
                  toolUsage={toolUsage}
                  onSelectTool={handleToolClick}
                />
              </div>
            </div>

            {/* Quick Settings */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">الإعدادات</h3>
              <button
                onClick={() => {
                  onClose();
                  window.dispatchEvent(new CustomEvent('adwatuk_trigger_install'));
                }}
                className="w-full flex items-center justify-between p-3 rounded-xl bg-emerald-50/70 dark:bg-emerald-950/30 hover:bg-emerald-100/70 dark:hover:bg-emerald-900/40 transition-colors border border-emerald-200/80 dark:border-emerald-800/60 text-emerald-800 dark:text-emerald-200"
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-600 text-white flex items-center justify-center shadow-xs">
                    <Zap className="w-4 h-4" />
                  </div>
                  <div className="text-right">
                    <span className="font-bold block text-sm">تثبيت التطبيق على جهازك</span>
                    <span className="text-[10px] text-emerald-600 dark:text-emerald-400">وصول سريع واستخدام بدون إنترنت</span>
                  </div>
                </div>
                <ChevronLeft className="w-4 h-4 text-emerald-600" />
              </button>

              <button
                onClick={() => setDarkMode(!darkMode)}
                className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors border border-gray-100 dark:border-gray-800/60"
              >
                <div className="flex items-center gap-3">
                  {darkMode ? <Moon className="w-5 h-5 text-indigo-400" /> : <Sun className="w-5 h-5 text-amber-500" />}
                  <span className="font-bold text-gray-700 dark:text-gray-200">
                    المظهر {darkMode ? 'الداكن' : 'الفاتح'}
                  </span>
                </div>
                <div className={`w-10 h-6 rounded-full transition-colors ${darkMode ? 'bg-indigo-600' : 'bg-gray-200'} relative`}>
                  <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-transform ${darkMode ? 'left-1 translate-x-4' : 'left-1'}`} />
                </div>
              </button>

              <button
                onClick={() => handleLinkClick(() => { 
                  navigate('/');
                  if (onSelectCategory) onSelectCategory('all');
                })}
                className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-emerald-50 dark:hover:bg-emerald-950/40 transition-colors border border-gray-100 dark:border-gray-800/60 text-emerald-700 dark:text-emerald-400 font-bold"
              >
                <div className="flex items-center gap-3">
                  <LayoutGrid className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
                  <span className="font-bold text-gray-800 dark:text-gray-100">كافة الأقسام والـ 145 أداة</span>
                </div>
                <ChevronLeft className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              </button>

              <button
                onClick={() => handleLinkClick(() => { 
                  navigate('/');
                  if (onSelectCategory) onSelectCategory('favorites');
                })}
                className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors border border-gray-100 dark:border-gray-800/60"
              >
                <div className="flex items-center gap-3">
                  <Heart className="w-5 h-5 text-rose-500" />
                  <span className="font-bold text-gray-700 dark:text-gray-200">الأدوات المفضلة</span>
                </div>
                <ChevronLeft className="w-4 h-4 text-gray-400" />
              </button>
            </div>

            {/* About & Contact */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">عن المنصة</h3>
              <button
                onClick={() => handleLinkClick(onOpenAbout)}
                className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors border border-gray-100 dark:border-gray-800/60"
              >
                <div className="flex items-center gap-3">
                  <Info className="w-5 h-5 text-blue-500" />
                  <span className="font-bold text-gray-700 dark:text-gray-200">عن منصة أدواتك</span>
                </div>
                <ChevronLeft className="w-4 h-4 text-gray-400" />
              </button>

              <a
                href="mailto:support@adwatuk.com"
                className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors border border-gray-100 dark:border-gray-800/60"
              >
                <div className="flex items-center gap-3">
                  <Mail className="w-5 h-5 text-emerald-500" />
                  <span className="font-bold text-gray-700 dark:text-gray-200">تواصل معنا</span>
                </div>
                <ChevronLeft className="w-4 h-4 text-gray-400" />
              </a>
            </div>

            {/* Legal */}
            <div className="space-y-2">
              <h3 className="text-xs font-bold text-gray-500 uppercase tracking-wider mb-3">القانونية</h3>
              <button className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors border border-gray-100 dark:border-gray-800/60">
                <div className="flex items-center gap-3">
                  <ShieldCheck className="w-5 h-5 text-gray-400" />
                  <span className="font-bold text-gray-700 dark:text-gray-200">سياسة الخصوصية</span>
                </div>
                <ChevronLeft className="w-4 h-4 text-gray-400" />
              </button>
              <button className="w-full flex items-center justify-between p-3 rounded-xl hover:bg-gray-50 dark:hover:bg-gray-800/50 transition-colors border border-gray-100 dark:border-gray-800/60">
                <div className="flex items-center gap-3">
                  <FileText className="w-5 h-5 text-gray-400" />
                  <span className="font-bold text-gray-700 dark:text-gray-200">شروط الاستخدام</span>
                </div>
                <ChevronLeft className="w-4 h-4 text-gray-400" />
              </button>
            </div>

          </div>
          
          <div className="p-4 border-t border-gray-100 dark:border-gray-800 text-center">
            <p className="text-xs text-gray-400 font-bold">منصة أدواتك - الإصدار 1.0.0</p>
          </div>
        </div>
      </div>
    </div>
  );
}

