import React, { useState } from 'react';
import { CATEGORIES, ALL_TOOLS } from '../../data/toolsData';
import { ToolDefinition, ToolCategory } from '../../types';
import { ToolCard } from './ToolCard';
import {
  Type,
  Image as ImageIcon,
  Calculator,
  ArrowRightLeft,
  Code2,
  Stethoscope,
  GraduationCap,
  Sparkles,
  Compass,
  FileText,
  Palette,
  Share2,
  Table,
  Music,
  Video,
  Archive,
  Coins,
  Clock,
  Layers,
  Search,
  CheckCircle2,
  ArrowRight,
  Filter,
} from 'lucide-react';

interface DiscoveryViewProps {
  onSelectCategory: (category: ToolCategory) => void;
  onSelectTool: (tool: ToolDefinition) => void;
  favorites: string[];
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
}

export function DiscoveryView({
  onSelectCategory,
  onSelectTool,
  favorites,
  onToggleFavorite,
}: DiscoveryViewProps) {
  const [activeFilter, setActiveFilter] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [expandedCategories, setExpandedCategories] = useState<Record<string, boolean>>({});

  const displayCategories = CATEGORIES.filter(
    (c) => c.id !== 'all' && c.id !== 'favorites' && c.id !== 'new' && c.id !== 'popular'
  );

  const getCategoryMeta = (id: ToolCategory) => {
    switch (id) {
      case 'text':
        return {
          icon: Type,
          accent: 'from-blue-600 to-indigo-600',
          badgeBg: 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800',
          borderAccent: 'hover:border-blue-400 dark:hover:border-blue-600',
          gradientBg: 'from-blue-500/10 via-indigo-500/5 to-transparent',
        };
      case 'image':
        return {
          icon: ImageIcon,
          accent: 'from-pink-600 to-rose-600',
          badgeBg: 'bg-pink-50 dark:bg-pink-950/60 text-pink-700 dark:text-pink-300 border-pink-200 dark:border-pink-800',
          borderAccent: 'hover:border-pink-400 dark:hover:border-pink-600',
          gradientBg: 'from-pink-500/10 via-rose-500/5 to-transparent',
        };
      case 'documents':
      case 'pdf':
        return {
          icon: FileText,
          accent: 'from-rose-600 to-red-600',
          badgeBg: 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800',
          borderAccent: 'hover:border-rose-400 dark:hover:border-rose-600',
          gradientBg: 'from-rose-500/10 via-red-500/5 to-transparent',
        };
      case 'data':
        return {
          icon: Table,
          accent: 'from-teal-600 to-emerald-600',
          badgeBg: 'bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border-teal-200 dark:border-teal-800',
          borderAccent: 'hover:border-teal-400 dark:hover:border-teal-600',
          gradientBg: 'from-teal-500/10 via-emerald-500/5 to-transparent',
        };
      case 'audio':
        return {
          icon: Music,
          accent: 'from-amber-600 to-yellow-600',
          badgeBg: 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800',
          borderAccent: 'hover:border-amber-400 dark:hover:border-amber-600',
          gradientBg: 'from-amber-500/10 via-yellow-500/5 to-transparent',
        };
      case 'video':
        return {
          icon: Video,
          accent: 'from-red-600 to-orange-600',
          badgeBg: 'bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300 border-red-200 dark:border-red-800',
          borderAccent: 'hover:border-red-400 dark:hover:border-red-600',
          gradientBg: 'from-red-500/10 via-orange-500/5 to-transparent',
        };
      case 'archives':
        return {
          icon: Archive,
          accent: 'from-slate-600 to-zinc-600',
          badgeBg: 'bg-slate-50 dark:bg-slate-950/60 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800',
          borderAccent: 'hover:border-slate-400 dark:hover:border-slate-600',
          gradientBg: 'from-slate-500/10 via-zinc-500/5 to-transparent',
        };
      case 'calculators':
        return {
          icon: Calculator,
          accent: 'from-emerald-600 to-teal-600',
          badgeBg: 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
          borderAccent: 'hover:border-emerald-400 dark:hover:border-emerald-600',
          gradientBg: 'from-emerald-500/10 via-teal-500/5 to-transparent',
        };
      case 'units':
        return {
          icon: ArrowRightLeft,
          accent: 'from-amber-600 to-orange-600',
          badgeBg: 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800',
          borderAccent: 'hover:border-amber-400 dark:hover:border-amber-600',
          gradientBg: 'from-amber-500/10 via-orange-500/5 to-transparent',
        };
      case 'currencies':
        return {
          icon: Coins,
          accent: 'from-emerald-600 to-green-600',
          badgeBg: 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
          borderAccent: 'hover:border-emerald-400 dark:hover:border-emerald-600',
          gradientBg: 'from-emerald-500/10 via-green-500/5 to-transparent',
        };
      case 'time-date':
        return {
          icon: Clock,
          accent: 'from-sky-600 to-blue-600',
          badgeBg: 'bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border-sky-200 dark:border-sky-800',
          borderAccent: 'hover:border-sky-400 dark:hover:border-sky-600',
          gradientBg: 'from-sky-500/10 via-blue-500/5 to-transparent',
        };
      case 'dev':
        return {
          icon: Code2,
          accent: 'from-purple-600 to-indigo-600',
          badgeBg: 'bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800',
          borderAccent: 'hover:border-purple-400 dark:hover:border-purple-600',
          gradientBg: 'from-purple-500/10 via-indigo-500/5 to-transparent',
        };
      case 'health':
        return {
          icon: Stethoscope,
          accent: 'from-rose-600 to-pink-600',
          badgeBg: 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800',
          borderAccent: 'hover:border-rose-400 dark:hover:border-rose-600',
          gradientBg: 'from-rose-500/10 via-pink-500/5 to-transparent',
        };
      case 'student':
        return {
          icon: GraduationCap,
          accent: 'from-cyan-600 to-teal-600',
          badgeBg: 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 border-cyan-200 dark:border-cyan-800',
          borderAccent: 'hover:border-cyan-400 dark:hover:border-cyan-600',
          gradientBg: 'from-cyan-500/10 via-teal-500/5 to-transparent',
        };
      case 'discovery':
        return {
          icon: Sparkles,
          accent: 'from-fuchsia-600 to-purple-600',
          badgeBg: 'bg-fuchsia-50 dark:bg-fuchsia-950/60 text-fuchsia-700 dark:text-fuchsia-300 border-fuchsia-200 dark:border-fuchsia-800',
          borderAccent: 'hover:border-fuchsia-400 dark:hover:border-fuchsia-600',
          gradientBg: 'from-fuchsia-500/10 via-purple-500/5 to-transparent',
        };
      case 'engineering':
        return {
          icon: Compass,
          accent: 'from-yellow-600 to-amber-600',
          badgeBg: 'bg-yellow-50 dark:bg-yellow-950/60 text-yellow-700 dark:text-yellow-300 border-yellow-200 dark:border-yellow-800',
          borderAccent: 'hover:border-yellow-400 dark:hover:border-yellow-600',
          gradientBg: 'from-yellow-500/10 via-amber-500/5 to-transparent',
        };
      case 'design':
        return {
          icon: Palette,
          accent: 'from-violet-600 to-fuchsia-600',
          badgeBg: 'bg-violet-50 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300 border-violet-200 dark:border-violet-800',
          borderAccent: 'hover:border-violet-400 dark:hover:border-violet-600',
          gradientBg: 'from-violet-500/10 via-fuchsia-500/5 to-transparent',
        };
      case 'social':
        return {
          icon: Share2,
          accent: 'from-pink-600 to-indigo-600',
          badgeBg: 'bg-pink-50 dark:bg-pink-950/60 text-pink-700 dark:text-pink-300 border-pink-200 dark:border-pink-800',
          borderAccent: 'hover:border-pink-400 dark:hover:border-pink-600',
          gradientBg: 'from-pink-500/10 via-indigo-500/5 to-transparent',
        };
      default:
        return {
          icon: Layers,
          accent: 'from-emerald-600 to-teal-600',
          badgeBg: 'bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700',
          borderAccent: 'hover:border-emerald-400',
          gradientBg: 'from-emerald-500/10 to-transparent',
        };
    }
  };

  const filteredCategories = displayCategories.filter((category) => {
    if (activeFilter !== 'all' && category.id !== activeFilter) {
      return false;
    }
    if (!searchQuery.trim()) return true;

    const query = searchQuery.toLowerCase();
    const matchesCategoryName =
      category.nameAr.toLowerCase().includes(query) ||
      category.nameEn.toLowerCase().includes(query) ||
      category.descriptionAr.toLowerCase().includes(query);

    const hasMatchingTools = ALL_TOOLS.some(
      (t) =>
        t.category === category.id &&
        (t.titleAr.toLowerCase().includes(query) ||
          t.titleEn.toLowerCase().includes(query) ||
          t.descriptionAr.toLowerCase().includes(query) ||
          t.tags.some((tag) => tag.toLowerCase().includes(query)))
    );

    return matchesCategoryName || hasMatchingTools;
  });

  return (
    <div className="space-y-8" id="discovery-view-container">
      {/* Header Banner */}
      <div className="relative overflow-hidden rounded-3xl bg-gradient-to-r from-emerald-600 via-teal-700 to-indigo-800 p-6 sm:p-8 text-white shadow-xl">
        <div className="relative z-10 max-w-3xl space-y-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-white/20 backdrop-blur-md text-xs font-bold">
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>استكشف كافة الأدوات المصنفة ({ALL_TOOLS.length} أداة)</span>
          </div>
          <h1 className="text-2xl sm:text-4xl font-heading font-black tracking-tight">
            دليل واستكشاف الأدوات الشامل
          </h1>
          <p className="text-xs sm:text-sm text-emerald-100 leading-relaxed">
            استعرض جميع الأدوات مقسمة بالتفصيل في أقسامها التخصصية الملونة مع إمكانية الفلترة السريعة
            والبحث المباشر.
          </p>
        </div>

        {/* Quick Filter Search in Explore Header */}
        <div className="relative z-10 mt-6 max-w-md">
          <div className="relative">
            <Search className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-emerald-200" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="ابحث في دليل الاستكشاف..."
              className="w-full pl-4 pr-10 py-2.5 bg-white/15 backdrop-blur-md border border-white/25 rounded-2xl text-xs sm:text-sm text-white placeholder-emerald-200/80 focus:outline-hidden focus:bg-white/25 focus:border-white transition"
            />
          </div>
        </div>

        <div className="absolute -left-12 -bottom-12 w-64 h-64 bg-white/10 rounded-full blur-2xl pointer-events-none" />
      </div>

      {/* Filter Tabs by Category */}
      <div className="flex items-center gap-2 overflow-x-auto py-2 scrollbar-none">
        <button
          onClick={() => setActiveFilter('all')}
          className={`px-4 py-2 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
            activeFilter === 'all'
              ? 'bg-emerald-600 text-white shadow-md'
              : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:bg-gray-50'
          }`}
        >
          <Filter className="w-3.5 h-3.5" />
          <span>كافة الأقسام ({displayCategories.length})</span>
        </button>

        {displayCategories.map((c) => {
          const meta = getCategoryMeta(c.id);
          const Icon = meta.icon;
          const isActive = activeFilter === c.id;
          return (
            <button
              key={c.id}
              onClick={() => setActiveFilter(c.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition-all shrink-0 flex items-center gap-1.5 ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:bg-gray-50'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{c.nameAr}</span>
            </button>
          );
        })}
      </div>

      {/* Category Sections */}
      <div className="space-y-8">
        {filteredCategories.map((category, index) => {
          const meta = getCategoryMeta(category.id);
          const Icon = meta.icon;
          const categoryTools = ALL_TOOLS.filter((t) => {
            if (t.category !== category.id) return false;
            if (!searchQuery.trim()) return true;
            const query = searchQuery.toLowerCase();
            return (
              t.titleAr.toLowerCase().includes(query) ||
              t.titleEn.toLowerCase().includes(query) ||
              t.descriptionAr.toLowerCase().includes(query) ||
              t.tags.some((tag) => tag.toLowerCase().includes(query))
            );
          });

          if (categoryTools.length === 0) return null;

          return (
            <React.Fragment key={category.id}>
              <section
                id={`explore-section-${category.id}`}
                className={`relative rounded-3xl bg-white dark:bg-gray-900 border border-gray-200/80 dark:border-gray-800 p-6 sm:p-7 shadow-xs overflow-hidden transition-all ${meta.borderAccent} bg-gradient-to-b ${meta.gradientBg}`}
              >
                {/* Header of the category section */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 mb-6 border-b border-gray-200/60 dark:border-gray-800">
                  <div className="flex items-center gap-4">
                    <div
                      className={`w-12 h-12 rounded-2xl bg-gradient-to-tr ${meta.accent} flex items-center justify-center text-white shadow-md`}
                    >
                      <Icon className="w-6 h-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-lg sm:text-xl font-heading font-black text-gray-900 dark:text-white">
                          {category.nameAr}
                        </h2>
                        <span className={`px-2.5 py-0.5 rounded-full text-xs font-bold border ${meta.badgeBg}`}>
                          {categoryTools.length} أداة
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                        {category.descriptionAr}
                      </p>
                    </div>
                  </div>

                  <button
                    onClick={() => {
                      onSelectCategory(category.id);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="inline-flex items-center gap-2 px-4 py-2 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:border-emerald-400 rounded-xl text-xs font-bold text-gray-800 dark:text-gray-200 transition shadow-2xs shrink-0 self-start sm:self-auto"
                  >
                    <span>فتح صفحة القسم المستقلة</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Tools Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
                  {(expandedCategories[category.id] || searchQuery.trim() ? categoryTools : categoryTools.slice(0, 4)).map((tool) => (
                    <ToolCard
                      key={tool.id}
                      tool={tool}
                      isFavorite={favorites.includes(tool.id)}
                      onToggleFavorite={onToggleFavorite}
                      onSelect={onSelectTool}
                    />
                  ))}
                </div>

                {!searchQuery.trim() && categoryTools.length > 4 && (
                  <div className="mt-6 flex justify-center">
                    <button
                      onClick={() => setExpandedCategories(prev => ({ ...prev, [category.id]: !prev[category.id] }))}
                      className="px-8 py-3 bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-200 font-bold rounded-xl border border-gray-200 dark:border-gray-700 hover:border-emerald-500 hover:text-emerald-600 dark:hover:text-emerald-400 transition shadow-sm"
                    >
                      {expandedCategories[category.id] ? 'طي الخريطة' : `عرض خريطة الأدوات بالكامل (${categoryTools.length - 4}+)`}
                    </button>
                  </div>
                )}
              </section>

              {/* Ad in feed every 3 sections */}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}
