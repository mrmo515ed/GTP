import React from 'react';
import { Bot, Sparkles } from 'lucide-react';

interface QuickToolsFloatingButtonProps {
  onClick: () => void;
}

export function QuickToolsFloatingButton({ onClick }: QuickToolsFloatingButtonProps) {
  return (
    <button
      onClick={onClick}
      className="fixed bottom-20 sm:bottom-6 left-6 z-40 group flex items-center gap-2.5 px-4 py-3 rounded-full bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 text-white shadow-xl shadow-emerald-600/30 hover:shadow-emerald-600/50 hover:scale-105 active:scale-95 transition-all duration-300 border border-white/20"
      aria-label="أدواتك السريعة - المساعد الذكي"
    >
      <div className="relative">
        <Bot className="w-5 h-5 transition-transform group-hover:rotate-12" />
        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-400 rounded-full animate-ping" />
        <span className="absolute -top-1 -right-1 w-2.5 h-2.5 bg-amber-400 rounded-full" />
      </div>
      <span className="text-xs sm:text-sm font-black hidden sm:inline">
        أدواتك السريعة 🤖
      </span>
    </button>
  );
}
