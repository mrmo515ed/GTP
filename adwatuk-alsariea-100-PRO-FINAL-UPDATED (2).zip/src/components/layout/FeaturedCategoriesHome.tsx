import React from 'react';
import { motion } from 'motion/react';
import { CATEGORIES, ALL_TOOLS } from '../../data/toolsData';
import { ToolCategory, ToolDefinition } from '../../types';
import { ToolCard } from './ToolCard';
import {
  HeartPulse,
  Stethoscope,
  Calculator,
  Type,
  Image as ImageIcon,
  FileText,
  Table,
  Code2,
  Clock,
  Sparkles,
  ArrowLeft,
  ChevronLeft,
  Flame,
  LayoutGrid,
  Zap,
} from 'lucide-react';

interface FeaturedCategoriesHomeProps {
  onSelectCategory: (categoryId: ToolCategory) => void;
  onSelectTool: (tool: ToolDefinition) => void;
  favorites: string[];
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onGoToAll: () => void;
}

// 8 Top Key Featured Categories to highlight cleanly on the Homepage
const FEATURED_CATEGORY_IDS: ToolCategory[] = [
  'surgery-3d',
  'health',
  'calculators',
  'pdf',
  'image',
  'text',
  'dev',
  'time-date',
];

export function FeaturedCategoriesHome({
  onSelectCategory,
  onSelectTool,
  favorites,
  onToggleFavorite,
  onGoToAll,
}: FeaturedCategoriesHomeProps) {
  const getCategoryIcon = (id: ToolCategory) => {
    switch (id) {
      case 'surgery-3d':
        return HeartPulse;
      case 'health':
        return Stethoscope;
      case 'calculators':
        return Calculator;
      case 'pdf':
        return FileText;
      case 'image':
        return ImageIcon;
      case 'text':
        return Type;
      case 'dev':
        return Code2;
      case 'time-date':
        return Clock;
      default:
        return Zap;
    }
  };

  const getCategoryMeta = (id: ToolCategory) => {
    switch (id) {
      case 'surgery-3d':
        return {
          gradient: 'from-rose-500/10 via-pink-500/5 to-transparent',
          border: 'border-rose-200/80 dark:border-rose-900/60 hover:border-rose-400',
          badge: 'bg-rose-100 dark:bg-rose-950 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800',
          iconBg: 'bg-gradient-to-tr from-rose-600 to-pink-600 text-white',
          tag: 'غرفة العمليات الذكية',
        };
      case 'health':
        return {
          gradient: 'from-emerald-500/10 via-teal-500/5 to-transparent',
          border: 'border-emerald-200/80 dark:border-emerald-900/60 hover:border-emerald-400',
          badge: 'bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
          iconBg: 'bg-gradient-to-tr from-emerald-600 to-teal-600 text-white',
          tag: 'طب وكيمياء حيوية',
        };
      case 'calculators':
        return {
          gradient: 'from-teal-500/10 via-emerald-500/5 to-transparent',
          border: 'border-teal-200/80 dark:border-teal-900/60 hover:border-teal-400',
          badge: 'bg-teal-100 dark:bg-teal-950 text-teal-700 dark:text-teal-300 border-teal-200 dark:border-teal-800',
          iconBg: 'bg-gradient-to-tr from-teal-600 to-emerald-600 text-white',
          tag: 'مالية وزكاة وقروض',
        };
      case 'pdf':
        return {
          gradient: 'from-red-500/10 via-rose-500/5 to-transparent',
          border: 'border-red-200/80 dark:border-red-900/60 hover:border-red-400',
          badge: 'bg-red-100 dark:bg-red-950 text-red-700 dark:text-red-300 border-red-200 dark:border-red-800',
          iconBg: 'bg-gradient-to-tr from-red-600 to-rose-600 text-white',
          tag: 'تحويل ومستندات',
        };
      case 'image':
        return {
          gradient: 'from-pink-500/10 via-fuchsia-500/5 to-transparent',
          border: 'border-pink-200/80 dark:border-pink-900/60 hover:border-pink-400',
          badge: 'bg-pink-100 dark:bg-pink-950 text-pink-700 dark:text-pink-300 border-pink-200 dark:border-pink-800',
          iconBg: 'bg-gradient-to-tr from-pink-600 to-rose-500 text-white',
          tag: 'ضغط وتحويل الصور',
        };
      case 'text':
        return {
          gradient: 'from-blue-500/10 via-indigo-500/5 to-transparent',
          border: 'border-blue-200/80 dark:border-blue-900/60 hover:border-blue-400',
          badge: 'bg-blue-100 dark:bg-blue-950 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800',
          iconBg: 'bg-gradient-to-tr from-blue-600 to-indigo-600 text-white',
          tag: 'تنسيق ومعالجة نصوص',
        };
      case 'dev':
        return {
          gradient: 'from-purple-500/10 via-violet-500/5 to-transparent',
          border: 'border-purple-200/80 dark:border-purple-900/60 hover:border-purple-400',
          badge: 'bg-purple-100 dark:bg-purple-950 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800',
          iconBg: 'bg-gradient-to-tr from-purple-600 to-violet-600 text-white',
          tag: 'أدوات المطورين',
        };
      default:
        return {
          gradient: 'from-sky-500/10 via-blue-500/5 to-transparent',
          border: 'border-sky-200/80 dark:border-sky-900/60 hover:border-sky-400',
          badge: 'bg-sky-100 dark:bg-sky-950 text-sky-700 dark:text-sky-300 border-sky-200 dark:border-sky-800',
          iconBg: 'bg-gradient-to-tr from-sky-600 to-blue-600 text-white',
          tag: 'وقت وتقويم',
        };
    }
  };

  const featuredCategories = CATEGORIES.filter((c) =>
    FEATURED_CATEGORY_IDS.includes(c.id as ToolCategory)
  );

  return (
    <div className="space-y-12" id="featured-categories-home">
      {/* Featured Header & Button to view all */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 p-5 rounded-3xl bg-gradient-to-r from-emerald-50 via-teal-50/50 to-emerald-50/20 dark:from-emerald-950/40 dark:via-teal-950/20 dark:to-gray-900 border border-emerald-200/80 dark:border-emerald-800/60 shadow-xs">
        <div className="space-y-1">
          <div className="inline-flex items-center gap-2 px-2.5 py-0.5 rounded-full bg-emerald-600 text-white text-[11px] font-black">
            <Flame className="w-3.5 h-3.5" />
            <span>أبرز الأقسام المختارة في الرئيسية</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-heading font-black text-gray-900 dark:text-white">
            الأقسام الأكثر طلباً واستخداماً
          </h2>
          <p className="text-xs text-gray-600 dark:text-gray-400 max-w-xl">
            استعرض عينة مميزة من أفضل الأدوات في كل قسم، أو انتقل لصفحة &quot;الكل&quot; لعرض كافة الـ 145 أداة وجميع الـ 24 قسماً بالكامل.
          </p>
        </div>

        <button
          onClick={onGoToAll}
          className="inline-flex items-center justify-center gap-2 px-5 py-3 rounded-2xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-black shadow-md hover:shadow-lg transition-all hover:scale-105 active:scale-95 shrink-0"
        >
          <LayoutGrid className="w-4 h-4" />
          <span>استعراض الكل (كافة الأقسام والـ 145 أداة)</span>
          <ChevronLeft className="w-4 h-4" />
        </button>
      </div>

      {/* Featured Sections Breakdown */}
      <div className="space-y-10">
        {featuredCategories.map((category) => {
          const categoryTools = ALL_TOOLS.filter((t) => t.category === category.id);
          if (categoryTools.length === 0) return null;

          const IconComp = getCategoryIcon(category.id as ToolCategory);
          const meta = getCategoryMeta(category.id as ToolCategory);
          // Show top 4 key tools for this featured section on home
          const previewTools = categoryTools.slice(0, 4);

          return (
            <section
              key={category.id}
              className={`p-5 sm:p-6 rounded-3xl bg-white dark:bg-gray-900 border ${meta.border} shadow-2xs space-y-4 transition-all bg-gradient-to-br ${meta.gradient}`}
            >
              {/* Header */}
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-gray-100 dark:border-gray-800">
                <div className="flex items-center gap-3">
                  <div
                    className={`w-11 h-11 rounded-2xl flex items-center justify-center shadow-md ${meta.iconBg}`}
                  >
                    <IconComp className="w-5 h-5" />
                  </div>
                  <div>
                    <div className="flex items-center gap-2">
                      <h3 className="text-base sm:text-lg font-heading font-black text-gray-900 dark:text-white">
                        {category.nameAr}
                      </h3>
                      <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-bold border ${meta.badge}`}>
                        {meta.tag}
                      </span>
                    </div>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 font-medium">
                      {category.descriptionAr}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => onSelectCategory(category.id as ToolCategory)}
                  className="inline-flex items-center gap-1.5 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:text-emerald-700 dark:hover:text-emerald-300 self-start sm:self-auto"
                >
                  <span>عرض جميع أدوات القسم ({categoryTools.length})</span>
                  <ChevronLeft className="w-4 h-4" />
                </button>
              </div>

              {/* Tools Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
                {previewTools.map((tool) => (
                  <ToolCard
                    key={tool.id}
                    tool={tool}
                    isFavorite={favorites.includes(tool.id)}
                    onToggleFavorite={onToggleFavorite}
                    onSelect={onSelectTool}
                  />
                ))}
              </div>
            </section>
          );
        })}
      </div>

      {/* Big Action Footer to Browse All */}
      <div className="p-8 rounded-3xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white text-center space-y-4 shadow-xl">
        <h3 className="text-xl sm:text-2xl font-heading font-black">
          هل تبحث عن أدوات إضافية أو أقسام أخرى؟
        </h3>
        <p className="text-xs sm:text-sm text-emerald-100 max-w-xl mx-auto">
          المنصة تضم أكثر من 145 أداة متخصصة ومصنفة تشمل السوشيال ميديا، العملات، الصوتيات، الأرشيف، الهندسة، وأدوات JSON و XML والمزيد!
        </p>
        <button
          onClick={onGoToAll}
          className="inline-flex items-center gap-2 px-8 py-3.5 rounded-2xl bg-white text-emerald-950 font-black text-sm shadow-lg hover:bg-emerald-50 transition-all hover:scale-105 active:scale-95"
        >
          <LayoutGrid className="w-5 h-5 text-emerald-600" />
          <span>فتح صفحة &quot;الكل&quot; (استعراض كامل الـ 145 أداة)</span>
        </button>
      </div>
    </div>
  );
}
