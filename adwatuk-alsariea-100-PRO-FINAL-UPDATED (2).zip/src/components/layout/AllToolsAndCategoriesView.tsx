import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CATEGORIES, ALL_TOOLS } from '../../data/toolsData';
import { ToolDefinition, ToolCategory } from '../../types';
import { ToolCard } from './ToolCard';
import { AdSlot } from '../ads/AdSlot';
import {
  LayoutGrid,
  Search,
  Flame,
  Star,
  Sparkles,
  Layers,
  ChevronLeft,
  ArrowDown,
  HeartPulse,
  Stethoscope,
  Calculator,
  Type,
  Image as ImageIcon,
  Palette,
  FileText,
  Table,
  Clock,
  GraduationCap,
  Share2,
  ArrowRightLeft,
  Coins,
  Music,
  Video,
  Archive,
  TerminalSquare,
  Shield,
  Braces,
  FileCode2,
  PenTool,
  Compass,
  Zap,
  Code2,
  SlidersHorizontal,
} from 'lucide-react';

interface AllToolsAndCategoriesViewProps {
  onSelectCategory: (categoryId: ToolCategory) => void;
  onSelectTool: (tool: ToolDefinition) => void;
  favorites: string[];
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
}

export function AllToolsAndCategoriesView({
  onSelectCategory,
  onSelectTool,
  favorites,
  onToggleFavorite,
}: AllToolsAndCategoriesViewProps) {
  const [filterQuery, setFilterQuery] = useState('');
  const [selectedQuickTag, setSelectedQuickTag] = useState<string>('all');

  // Real categories (excluding meta filters like 'all', 'favorites', 'new', 'popular', 'home')
  const displayCategories = CATEGORIES.filter(
    (c) => c.id !== 'all' && c.id !== 'favorites' && c.id !== 'new' && c.id !== 'popular' && c.id !== 'home'
  );

  const getCategoryIcon = (id: ToolCategory) => {
    switch (id) {
      case 'surgery-3d':
        return HeartPulse;
      case 'health':
        return Stethoscope;
      case 'calculators':
        return Calculator;
      case 'text':
        return Type;
      case 'image':
        return ImageIcon;
      case 'design':
        return Palette;
      case 'pdf':
      case 'documents':
        return FileText;
      case 'data':
        return Table;
      case 'time-date':
        return Clock;
      case 'student':
        return GraduationCap;
      case 'social':
        return Share2;
      case 'units':
      case 'converters':
        return ArrowRightLeft;
      case 'currencies':
        return Coins;
      case 'audio':
        return Music;
      case 'video':
        return Video;
      case 'archives':
        return Archive;
      case 'dev':
        return TerminalSquare;
      case 'encoding':
        return Shield;
      case 'json':
        return Braces;
      case 'xml':
        return FileCode2;
      case 'svg':
        return PenTool;
      case 'engineering':
        return Compass;
      case 'discovery':
        return Sparkles;
      default:
        return Layers;
    }
  };

  const getCategoryTheme = (id: ToolCategory) => {
    switch (id) {
      case 'surgery-3d':
        return {
          bg: 'bg-rose-50 dark:bg-rose-950/30',
          border: 'border-rose-200 dark:border-rose-900/50 hover:border-rose-400',
          iconBg: 'bg-rose-500 text-white',
          text: 'text-rose-700 dark:text-rose-300',
          badge: 'bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-200',
        };
      case 'health':
        return {
          bg: 'bg-emerald-50 dark:bg-emerald-950/30',
          border: 'border-emerald-200 dark:border-emerald-900/50 hover:border-emerald-400',
          iconBg: 'bg-emerald-600 text-white',
          text: 'text-emerald-700 dark:text-emerald-300',
          badge: 'bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200',
        };
      case 'calculators':
        return {
          bg: 'bg-teal-50 dark:bg-teal-950/30',
          border: 'border-teal-200 dark:border-teal-900/50 hover:border-teal-400',
          iconBg: 'bg-teal-600 text-white',
          text: 'text-teal-700 dark:text-teal-300',
          badge: 'bg-teal-100 dark:bg-teal-900/60 text-teal-800 dark:text-teal-200',
        };
      case 'text':
        return {
          bg: 'bg-blue-50 dark:bg-blue-950/30',
          border: 'border-blue-200 dark:border-blue-900/50 hover:border-blue-400',
          iconBg: 'bg-blue-600 text-white',
          text: 'text-blue-700 dark:text-blue-300',
          badge: 'bg-blue-100 dark:bg-blue-900/60 text-blue-800 dark:text-blue-200',
        };
      case 'image':
        return {
          bg: 'bg-pink-50 dark:bg-pink-950/30',
          border: 'border-pink-200 dark:border-pink-900/50 hover:border-pink-400',
          iconBg: 'bg-pink-600 text-white',
          text: 'text-pink-700 dark:text-pink-300',
          badge: 'bg-pink-100 dark:bg-pink-900/60 text-pink-800 dark:text-pink-200',
        };
      case 'design':
        return {
          bg: 'bg-amber-50 dark:bg-amber-950/30',
          border: 'border-amber-200 dark:border-amber-900/50 hover:border-amber-400',
          iconBg: 'bg-amber-600 text-white',
          text: 'text-amber-700 dark:text-amber-300',
          badge: 'bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-200',
        };
      case 'pdf':
        return {
          bg: 'bg-red-50 dark:bg-red-950/30',
          border: 'border-red-200 dark:border-red-900/50 hover:border-red-400',
          iconBg: 'bg-red-600 text-white',
          text: 'text-red-700 dark:text-red-300',
          badge: 'bg-red-100 dark:bg-red-900/60 text-red-800 dark:text-red-200',
        };
      case 'dev':
        return {
          bg: 'bg-purple-50 dark:bg-purple-950/30',
          border: 'border-purple-200 dark:border-purple-900/50 hover:border-purple-400',
          iconBg: 'bg-purple-600 text-white',
          text: 'text-purple-700 dark:text-purple-300',
          badge: 'bg-purple-100 dark:bg-purple-900/60 text-purple-800 dark:text-purple-200',
        };
      case 'encoding':
        return {
          bg: 'bg-orange-50 dark:bg-orange-950/30',
          border: 'border-orange-200 dark:border-orange-900/50 hover:border-orange-400',
          iconBg: 'bg-orange-600 text-white',
          text: 'text-orange-700 dark:text-orange-300',
          badge: 'bg-orange-100 dark:bg-orange-900/60 text-orange-800 dark:text-orange-200',
        };
      case 'json':
      case 'xml':
        return {
          bg: 'bg-indigo-50 dark:bg-indigo-950/30',
          border: 'border-indigo-200 dark:border-indigo-900/50 hover:border-indigo-400',
          iconBg: 'bg-indigo-600 text-white',
          text: 'text-indigo-700 dark:text-indigo-300',
          badge: 'bg-indigo-100 dark:bg-indigo-900/60 text-indigo-800 dark:text-indigo-200',
        };
      default:
        return {
          bg: 'bg-slate-50 dark:bg-slate-800/40',
          border: 'border-slate-200 dark:border-slate-700 hover:border-slate-400',
          iconBg: 'bg-emerald-600 text-white',
          text: 'text-slate-800 dark:text-slate-200',
          badge: 'bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200',
        };
    }
  };

  // Filter tools based on search filter input
  const filteredAllTools = ALL_TOOLS.filter((t) => {
    if (!filterQuery.trim()) return true;
    const q = filterQuery.toLowerCase();
    return (
      t.titleAr.toLowerCase().includes(q) ||
      t.titleEn.toLowerCase().includes(q) ||
      t.descriptionAr.toLowerCase().includes(q) ||
      t.tags.some((tag) => tag.toLowerCase().includes(q))
    );
  });

  const scrollToSection = (catId: string) => {
    const el = document.getElementById(`cat-sec-${catId}`);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="space-y-10" id="all-tools-page-container">
      {/* 1. Distinctive Top Category Directory Box (مربع فهرس كافة الأقسام العلوي المميز) */}
      <div className="rounded-3xl bg-white dark:bg-gray-900 border border-gray-200/80 dark:border-gray-800 shadow-xl overflow-hidden">
        {/* Top Header Strip */}
        <div className="px-6 py-6 sm:px-8 sm:py-7 bg-gradient-to-r from-gray-900 via-slate-900 to-gray-950 text-white border-b border-gray-800">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <div className="space-y-1.5">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-lg bg-emerald-500/20 border border-emerald-500/30 text-emerald-300 text-xs font-bold">
                <LayoutGrid className="w-3.5 h-3.5" />
                <span>دليل الأقسام الشامل</span>
              </div>
              <h1 className="text-xl sm:text-3xl font-heading font-black tracking-tight text-white">
                فهرس كافة الأقسام والـ {ALL_TOOLS.length} أداة
              </h1>
              <p className="text-xs sm:text-sm text-gray-300 font-medium max-w-2xl">
                انقر على أي قسم للانتقال المباشر إليه في نفس الصفحة، أو ابحث في شريط الفرز السريع أدناه.
              </p>
            </div>

            {/* Live Stats */}
            <div className="flex items-center gap-2.5 self-start md:self-auto shrink-0">
              <div className="px-4 py-2.5 rounded-2xl bg-white/10 border border-white/15 text-center">
                <span className="block text-lg sm:text-xl font-black text-emerald-400">{ALL_TOOLS.length}</span>
                <span className="text-[10px] text-gray-300 font-bold">أداة ومحاكي</span>
              </div>
              <div className="px-4 py-2.5 rounded-2xl bg-white/10 border border-white/15 text-center">
                <span className="block text-lg sm:text-xl font-black text-teal-300">{displayCategories.length}</span>
                <span className="text-[10px] text-gray-300 font-bold">قسماً تخصصياً</span>
              </div>
            </div>
          </div>

          {/* Quick Search Bar inside the Index */}
          <div className="mt-5 pt-5 border-t border-white/10">
            <div className="relative w-full">
              <input
                type="text"
                value={filterQuery}
                onChange={(e) => setFilterQuery(e.target.value)}
                placeholder="ابحث بالاسم أو الوظيفة بين كافة الـ 145 أداة..."
                className="w-full pl-4 pr-11 py-3 bg-white/10 hover:bg-white/15 focus:bg-white text-white focus:text-gray-900 rounded-2xl text-xs sm:text-sm font-bold border border-white/20 focus:border-emerald-500 shadow-inner focus:outline-none transition-all placeholder:text-gray-400"
              />
              <Search className="w-5 h-5 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2 pointer-events-none" />
              {filterQuery && (
                <button
                  onClick={() => setFilterQuery('')}
                  className="absolute left-3 top-1/2 -translate-y-1/2 px-2 py-1 bg-white/20 text-white rounded-lg text-xs font-bold hover:bg-white/30"
                >
                  مسح
                </button>
              )}
            </div>
          </div>
        </div>

        {/* Categories Directory Grid (المصفوفة الشاملة لجميع الأقسام) */}
        {!filterQuery && (
          <div className="p-5 sm:p-7 bg-gray-50/50 dark:bg-gray-900/50">
            <div className="flex items-center justify-between mb-4">
              <span className="text-xs font-black text-gray-700 dark:text-gray-300 flex items-center gap-1.5">
                <SlidersHorizontal className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>اختر قسماً للانتقال الفوري إليه ({displayCategories.length} قسم):</span>
              </span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-4 gap-2.5 sm:gap-3">
              {displayCategories.map((cat) => {
                const count = ALL_TOOLS.filter((t) => t.category === cat.id).length;
                const IconComp = getCategoryIcon(cat.id);
                const theme = getCategoryTheme(cat.id);

                return (
                  <button
                    key={cat.id}
                    onClick={() => scrollToSection(cat.id)}
                    className={`group flex items-center gap-2.5 p-2.5 sm:p-3 rounded-2xl border text-right transition-all duration-200 ${theme.bg} ${theme.border} hover:shadow-md hover:scale-[1.02] active:scale-[0.98]`}
                  >
                    <div className={`w-8 h-8 sm:w-9 sm:h-9 rounded-xl flex items-center justify-center shrink-0 shadow-xs ${theme.iconBg}`}>
                      <IconComp className="w-4 h-4 sm:w-4.5 sm:h-4.5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center justify-between gap-1">
                        <span className="text-[11px] sm:text-xs font-bold text-gray-800 dark:text-gray-100 truncate group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors">
                          {cat.nameAr}
                        </span>
                      </div>
                      <span className="text-[10px] text-gray-500 dark:text-gray-400 font-medium">
                        {count} أداة
                      </span>
                    </div>
                    <ArrowDown className="w-3.5 h-3.5 text-gray-400 group-hover:text-emerald-600 transition-colors shrink-0" />
                  </button>
                );
              })}
            </div>
          </div>
        )}
      </div>

      {/* Middle In-Feed Ad Banner */}
      <AdSlot type="in-feed" className="my-2" label="إعلان • استكشف خدمات وأدوات مقترحة" />

      {/* If Searching / Filtering */}
      {filterQuery ? (
        <div className="space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-gray-200 dark:border-gray-800">
            <h2 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
              <Search className="w-4 h-4 text-emerald-600" />
              <span>نتائج التصفية ({filteredAllTools.length} أداة)</span>
            </h2>
            <button
              onClick={() => setFilterQuery('')}
              className="text-xs font-bold text-emerald-600 hover:underline"
            >
              عرض كافة الأقسام
            </button>
          </div>

          {filteredAllTools.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
              {filteredAllTools.map((tool) => (
                <ToolCard
                  key={tool.id}
                  tool={tool}
                  isFavorite={favorites.includes(tool.id)}
                  onToggleFavorite={onToggleFavorite}
                  onSelect={onSelectTool}
                />
              ))}
            </div>
          ) : (
            <div className="py-16 text-center bg-white dark:bg-gray-900 rounded-3xl border border-gray-200 dark:border-gray-800 p-6 space-y-2">
              <p className="text-sm font-bold text-gray-700 dark:text-gray-300">
                لم يتم العثور على أي أداة مطابقة لـ &quot;{filterQuery}&quot;
              </p>
              <button
                onClick={() => setFilterQuery('')}
                className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold"
              >
                إلغاء التصفية
              </button>
            </div>
          )}
        </div>
      ) : (
        /* Full Sections View with All Tools */
        <div className="space-y-12">
          {displayCategories.map((category, idx) => {
            const categoryTools = ALL_TOOLS.filter((t) => t.category === category.id);
            if (categoryTools.length === 0) return null;

            const IconComp = getCategoryIcon(category.id);
            const theme = getCategoryTheme(category.id);

            return (
              <section
                key={category.id}
                id={`cat-sec-${category.id}`}
                className={`scroll-mt-24 p-5 sm:p-7 rounded-3xl bg-white dark:bg-gray-900 border ${theme.border} shadow-sm space-y-5 transition-all`}
              >
                {/* Section Header */}
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-gray-100 dark:border-gray-800">
                  <div className="flex items-center gap-3.5">
                    <div
                      className={`w-11 h-11 sm:w-12 sm:h-12 rounded-2xl flex items-center justify-center border shadow-xs ${theme.bg} ${theme.border} ${theme.text}`}
                    >
                      <IconComp className="w-5 h-5 sm:w-6 sm:h-6" />
                    </div>
                    <div>
                      <div className="flex items-center gap-2">
                        <h2 className="text-base sm:text-xl font-heading font-black text-gray-900 dark:text-white">
                          {category.nameAr}
                        </h2>
                        <span
                          className={`px-2.5 py-0.5 rounded-full text-xs font-black ${theme.badge}`}
                        >
                          {categoryTools.length} أداة
                        </span>
                      </div>
                      <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5 font-medium">
                        {category.descriptionAr}
                      </p>
                    </div>
                  </div>

                  {/* Direct Independent Category Page */}
                  <button
                    onClick={() => {
                      onSelectCategory(category.id);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-bold text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-600 transition self-start sm:self-auto"
                  >
                    <span>صفحة القسم</span>
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>

                {/* Section Tools Grid - Showing ALL tools of this category */}
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
                  {categoryTools.map((tool) => (
                    <ToolCard
                      key={tool.id}
                      tool={tool}
                      isFavorite={favorites.includes(tool.id)}
                      onToggleFavorite={onToggleFavorite}
                      onSelect={onSelectTool}
                    />
                  ))}
                </div>

                {/* Insert Ad Slot after every 4 categories for balanced monetization */}
                {(idx + 1) % 4 === 0 && (
                  <div className="pt-2">
                    <AdSlot type="in-feed" label="إعلان • خدمات وأدوات مقترحة" />
                  </div>
                )}
              </section>
            );
          })}
        </div>
      )}
    </div>
  );
}
