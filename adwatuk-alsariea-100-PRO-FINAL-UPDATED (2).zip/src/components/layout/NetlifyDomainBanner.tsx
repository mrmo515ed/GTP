import React, { useState, useEffect } from 'react';
import { Globe, X, ExternalLink, CheckCircle2, Sparkles, EyeOff } from 'lucide-react';

export function NetlifyDomainBanner() {
  const [isVisible, setIsVisible] = useState(false);
  const [isMinimized, setIsMinimized] = useState(false);

  useEffect(() => {
    // Check if user has permanently dismissed the banner
    const isDismissed = localStorage.getItem('adwatuk_netlify_banner_dismissed');
    if (!isDismissed) {
      // Show on first visit
      setIsVisible(true);
    }
  }, []);

  const handleDismissPermanently = () => {
    localStorage.setItem('adwatuk_netlify_banner_dismissed', 'true');
    setIsVisible(false);
  };

  if (!isVisible) return null;

  return (
    <div className="w-full bg-gradient-to-r from-emerald-600 via-teal-600 to-emerald-700 text-white shadow-md relative z-30 transition-all">
      <div className="max-w-7xl mx-auto px-4 py-2 sm:py-2.5 flex flex-wrap items-center justify-between gap-2 text-xs sm:text-sm">
        {/* Left / Info */}
        <div className="flex items-center gap-2 flex-1 min-w-[260px]">
          <div className="p-1 rounded-lg bg-white/15 backdrop-blur-xs flex items-center justify-center shrink-0">
            <Globe className="w-4 h-4 text-white" />
          </div>
          <div className="flex flex-wrap items-center gap-1.5 font-medium leading-tight">
            <span className="font-extrabold text-amber-200">الرابط الرسمي والمعتمد للموقع:</span>
            <a
              href="https://adwatuk-alsariea.netlify.app"
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono font-bold bg-black/20 hover:bg-black/35 px-2 py-0.5 rounded-md border border-white/20 inline-flex items-center gap-1 transition text-white"
            >
              <span>adwatuk-alsariea.netlify.app</span>
              <ExternalLink className="w-3 h-3 text-emerald-200" />
            </a>
            <span className="text-[11px] text-emerald-100 hidden md:inline">
              (احفظ الرابط في المفضلة للوصول السريع)
            </span>
          </div>
        </div>

        {/* Right / Actions */}
        <div className="flex items-center gap-2 shrink-0">
          <button
            onClick={handleDismissPermanently}
            className="px-2.5 py-1 bg-white/20 hover:bg-white/30 rounded-lg text-xs font-bold text-white transition flex items-center gap-1 cursor-pointer"
            title="إخفاء هذا الإشعار نهائياً"
          >
            <EyeOff className="w-3.5 h-3.5" />
            <span>إخفاء نهائياً</span>
          </button>
          
          <button
            onClick={() => setIsVisible(false)}
            className="p-1 text-white/80 hover:text-white hover:bg-white/10 rounded-lg transition"
            title="إغلاق مؤقت"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}
