import React from 'react';
import { motion } from 'motion/react';
import { ToolDefinition } from '../../types';
import { getToolIcon } from '../../utils/iconMap';

interface CompactRelatedToolCardProps {
  tool: ToolDefinition;
  onSelect: (tool: ToolDefinition) => void;
}

export function CompactRelatedToolCard({ tool, onSelect }: CompactRelatedToolCardProps) {
  const IconComponent = getToolIcon(tool.icon);

  return (
    <motion.button
      type="button"
      layout="position"
      whileHover={{ y: -3, scale: 1.02 }}
      whileTap={{ scale: 0.97 }}
      transition={{ duration: 0.2 }}
      onClick={() => onSelect(tool)}
      id={`related-mini-tool-${tool.id}`}
      className="group relative w-full bg-white dark:bg-gray-900/90 rounded-2xl p-3 border border-gray-200/80 dark:border-gray-800 hover:border-emerald-500 dark:hover:border-emerald-500 hover:shadow-md hover:shadow-emerald-500/5 transition-colors duration-200 cursor-pointer flex flex-col items-center justify-center text-center gap-2 min-h-[105px]"
    >
      {/* Icon in mini rounded pill */}
      <div className="w-9 h-9 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-400 group-hover:bg-emerald-600 group-hover:text-white transition-colors duration-200 flex items-center justify-center shrink-0 shadow-2xs">
        <IconComponent className="w-4 h-4" />
      </div>

      {/* Tool Title */}
      <div className="w-full">
        <h4 className="text-xs font-bold text-gray-800 dark:text-gray-200 group-hover:text-emerald-600 dark:group-hover:text-emerald-400 transition-colors line-clamp-2 leading-snug">
          {tool.titleAr}
        </h4>
      </div>

      {/* Mini badge if available */}
      {tool.badge && (
        <span className="text-[9px] px-1.5 py-0.5 rounded-md font-semibold bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-400 group-hover:bg-emerald-100 group-hover:text-emerald-700 dark:group-hover:bg-emerald-950 dark:group-hover:text-emerald-300 transition">
          {tool.badge}
        </span>
      )}
    </motion.button>
  );
}
