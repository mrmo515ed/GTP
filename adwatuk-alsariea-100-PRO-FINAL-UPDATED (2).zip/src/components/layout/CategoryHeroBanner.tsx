import React from 'react';
import { motion } from 'motion/react';
import { CATEGORIES } from '../../data/toolsData';
import { ToolCategory } from '../../types';
import {
  ArrowRight,
  Sparkles,
  Layers,
  HeartPulse,
  Stethoscope,
  Calculator,
  Type,
  Image as ImageIcon,
  Palette,
  FileText,
  Table,
  Clock,
  GraduationCap,
  Share2,
  ArrowRightLeft,
  Coins,
  Music,
  Video,
  Archive,
  TerminalSquare,
  Shield,
  Braces,
  FileCode2,
  PenTool,
  Compass,
  Star,
  Flame,
  LayoutGrid,
} from 'lucide-react';

interface CategoryHeroBannerProps {
  categoryId: ToolCategory;
  toolsCount: number;
  onBackToHome: () => void;
  onSelectAnotherCategory?: (cat: ToolCategory) => void;
}

export function CategoryHeroBanner({
  categoryId,
  toolsCount,
  onBackToHome,
  onSelectAnotherCategory,
}: CategoryHeroBannerProps) {
  const category = CATEGORIES.find((c) => c.id === categoryId);

  const getCategoryDetails = (id: ToolCategory) => {
    switch (id) {
      case 'surgery-3d':
        return {
          icon: HeartPulse,
          gradient: 'from-rose-950 via-rose-900 to-slate-950',
          accentBorder: 'border-rose-500/40',
          badgeBg: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
          iconBg: 'bg-gradient-to-tr from-rose-600 to-pink-600 shadow-rose-500/30',
          tagline: 'محاكاة طبية وجراحية ثلاثية الأبعاد تفاعلية',
        };
      case 'health':
        return {
          icon: Stethoscope,
          gradient: 'from-emerald-950 via-teal-900 to-slate-950',
          accentBorder: 'border-emerald-500/40',
          badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
          iconBg: 'bg-gradient-to-tr from-emerald-600 to-teal-600 shadow-emerald-500/30',
          tagline: 'حاسبات طبية ومختبر الكيمياء الحيوية وفصائل الدم',
        };
      case 'calculators':
        return {
          icon: Calculator,
          gradient: 'from-cyan-950 via-teal-900 to-slate-950',
          accentBorder: 'border-cyan-500/40',
          badgeBg: 'bg-cyan-500/20 text-cyan-300 border-cyan-500/30',
          iconBg: 'bg-gradient-to-tr from-cyan-600 to-teal-600 shadow-cyan-500/30',
          tagline: 'حاسبات ذكية للمال والضرائب والقروض والرياضيات',
        };
      case 'text':
        return {
          icon: Type,
          gradient: 'from-blue-950 via-indigo-900 to-slate-950',
          accentBorder: 'border-blue-500/40',
          badgeBg: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
          iconBg: 'bg-gradient-to-tr from-blue-600 to-indigo-600 shadow-blue-500/30',
          tagline: 'معالجة وتنسيق النصوص والتشكيل واستخراج الكلمات',
        };
      case 'image':
        return {
          icon: ImageIcon,
          gradient: 'from-pink-950 via-purple-900 to-slate-950',
          accentBorder: 'border-pink-500/40',
          badgeBg: 'bg-pink-500/20 text-pink-300 border-pink-500/30',
          iconBg: 'bg-gradient-to-tr from-pink-600 to-purple-600 shadow-pink-500/30',
          tagline: 'ضغط وتعديل واستخراج ألوان وتحويل الصور بجودة فائقة',
        };
      case 'design':
        return {
          icon: Palette,
          gradient: 'from-amber-950 via-orange-900 to-slate-950',
          accentBorder: 'border-amber-500/40',
          badgeBg: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
          iconBg: 'bg-gradient-to-tr from-amber-600 to-orange-600 shadow-amber-500/30',
          tagline: 'أدوات التصميم وأكواد الألوان والظلال والـ CSS',
        };
      case 'pdf':
      case 'documents':
        return {
          icon: FileText,
          gradient: 'from-red-950 via-rose-900 to-slate-950',
          accentBorder: 'border-red-500/40',
          badgeBg: 'bg-red-500/20 text-red-300 border-red-500/30',
          iconBg: 'bg-gradient-to-tr from-red-600 to-rose-600 shadow-red-500/30',
          tagline: 'دمج وتقسيم وتحويل واستخراج صفحات مستندات PDF',
        };
      case 'dev':
        return {
          icon: TerminalSquare,
          gradient: 'from-purple-950 via-slate-900 to-gray-950',
          accentBorder: 'border-purple-500/40',
          badgeBg: 'bg-purple-500/20 text-purple-300 border-purple-500/30',
          iconBg: 'bg-gradient-to-tr from-purple-600 to-indigo-600 shadow-purple-500/30',
          tagline: 'أدوات المطورين والبرمجة وفحص الشبكات و Regex و Cron',
        };
      case 'encoding':
        return {
          icon: Shield,
          gradient: 'from-orange-950 via-amber-900 to-slate-950',
          accentBorder: 'border-orange-500/40',
          badgeBg: 'bg-orange-500/20 text-orange-300 border-orange-500/30',
          iconBg: 'bg-gradient-to-tr from-orange-600 to-amber-600 shadow-orange-500/30',
          tagline: 'تشفير وحماية البيانات Base64, JWT, Hash وقوة كلمات المرور',
        };
      case 'json':
      case 'xml':
        return {
          icon: Braces,
          gradient: 'from-indigo-950 via-blue-900 to-slate-950',
          accentBorder: 'border-indigo-500/40',
          badgeBg: 'bg-indigo-500/20 text-indigo-300 border-indigo-500/30',
          iconBg: 'bg-gradient-to-tr from-indigo-600 to-blue-600 shadow-indigo-500/30',
          tagline: 'تحويل وتنسيق والتحقق من بنية وتراكيب ملفات البيانات',
        };
      case 'svg':
        return {
          icon: PenTool,
          gradient: 'from-violet-950 via-fuchsia-900 to-slate-950',
          accentBorder: 'border-violet-500/40',
          badgeBg: 'bg-violet-500/20 text-violet-300 border-violet-500/30',
          iconBg: 'bg-gradient-to-tr from-violet-600 to-fuchsia-600 shadow-violet-500/30',
          tagline: 'تحسين وضغط وتحويل الرسومات المتجهة SVG',
        };
      case 'student':
        return {
          icon: GraduationCap,
          gradient: 'from-sky-950 via-blue-900 to-slate-950',
          accentBorder: 'border-sky-500/40',
          badgeBg: 'bg-sky-500/20 text-sky-300 border-sky-500/30',
          iconBg: 'bg-gradient-to-tr from-sky-600 to-blue-600 shadow-sky-500/30',
          tagline: 'حساب المعدل التراكمي GPA والجدول الدراسي والامتحانات',
        };
      case 'favorites':
        return {
          icon: Star,
          gradient: 'from-amber-950 via-yellow-900 to-slate-950',
          accentBorder: 'border-yellow-500/40',
          badgeBg: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
          iconBg: 'bg-gradient-to-tr from-amber-500 to-yellow-500 shadow-yellow-500/30',
          tagline: 'مجموعتك المفضلة من الأدوات للوصول السريع',
        };
      default:
        return {
          icon: Layers,
          gradient: 'from-slate-950 via-gray-900 to-zinc-950',
          accentBorder: 'border-emerald-500/40',
          badgeBg: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
          iconBg: 'bg-gradient-to-tr from-emerald-600 to-teal-600 shadow-emerald-500/30',
          tagline: 'أدوات متخصصة وسريعة تعمل مباشرة في متصفحك',
        };
    }
  };

  const details = getCategoryDetails(categoryId);
  const IconComp = details.icon;
  const title = categoryId === 'favorites' ? 'الأدوات المفضلة' : category?.nameAr || 'القسم التخصصي';
  const desc = categoryId === 'favorites' ? 'جميع الأدوات التي قمت بحفظها في قائمتك المفضلة' : category?.descriptionAr;

  return (
    <div className={`relative overflow-hidden rounded-3xl bg-gradient-to-br ${details.gradient} text-white border ${details.accentBorder} shadow-2xl p-6 sm:p-8`}>
      {/* Ambient background glows */}
      <div className="absolute top-0 left-1/4 w-80 h-80 bg-white/5 rounded-full blur-3xl pointer-events-none" />
      <div className="absolute -bottom-10 -right-10 w-64 h-64 bg-emerald-500/10 rounded-full blur-2xl pointer-events-none" />

      <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-6">
        {/* Left Info Area */}
        <div className="flex items-start gap-4 sm:gap-5">
          <div className={`w-14 h-14 sm:w-16 sm:h-16 rounded-2xl flex items-center justify-center shrink-0 shadow-lg ${details.iconBg} border border-white/20`}>
            <IconComp className="w-7 h-7 sm:w-8 sm:h-8 text-white" />
          </div>

          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2">
              <span className={`inline-flex items-center gap-1.5 px-3 py-0.5 rounded-full text-xs font-black border ${details.badgeBg}`}>
                <Sparkles className="w-3 h-3" />
                <span>قسم تخصصي</span>
              </span>
              <span className="px-2.5 py-0.5 rounded-full bg-white/10 text-white/90 text-xs font-bold border border-white/10">
                {toolsCount} أداة ومحاكي جاهز
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-heading font-black text-white tracking-tight">
              {title}
            </h1>

            <p className="text-xs sm:text-sm text-gray-300 font-medium max-w-2xl leading-relaxed">
              {desc}
            </p>

            <div className="pt-1">
              <span className="text-[11px] text-emerald-400/90 font-bold bg-black/30 px-2.5 py-1 rounded-lg border border-white/5">
                ✦ {details.tagline}
              </span>
            </div>
          </div>
        </div>

        {/* Right Action Button: Back to Home */}
        <div className="flex items-center gap-3 self-start md:self-center shrink-0 pt-2 md:pt-0">
          <button
            onClick={onBackToHome}
            id="back-to-home-from-category-btn"
            className="inline-flex items-center justify-center gap-2 px-6 py-3.5 bg-white text-gray-900 hover:bg-emerald-50 rounded-2xl font-black text-xs sm:text-sm shadow-xl transition-all duration-200 hover:scale-105 active:scale-95 border border-white/80"
          >
            <ArrowRight className="w-4 h-4" />
            <span>الرجوع للرئيسية</span>
          </button>
        </div>
      </div>
    </div>
  );
}
