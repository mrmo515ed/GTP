import React, { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { ALL_TOOLS, CATEGORIES } from '../../data/toolsData';
import { ToolDefinition } from '../../types';
import {
  Bot,
  User,
  Sparkles,
  Send,
  X,
  RotateCcw,
  ArrowRight,
  ExternalLink,
  Sliders,
  Check,
  Search,
  Zap,
  HelpCircle,
  Clock,
  Heart,
  ChevronRight,
  MessageSquare,
  Wand2
} from 'lucide-react';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  matchedTools?: ToolDefinition[];
  quickActions?: { label: string; action: string }[];
  calculationResult?: string;
  timestamp: string;
}

interface QuickToolsAssistantModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelectTool?: (tool: ToolDefinition) => void;
}

export function QuickToolsAssistantModal({
  isOpen,
  onClose,
  onSelectTool
}: QuickToolsAssistantModalProps) {
  const navigate = useNavigate();
  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('adwatuk_quick_chat_history');
      if (saved) return JSON.parse(saved);
    } catch {}
    return [
      {
        id: 'msg-welcome',
        sender: 'assistant',
        text: 'أهلاً بك! أنا «أدواتك السريعة» 🤖، مساعدك الذكي للوصول إلى أدوات الموقع والإجابة عن استفساراتك المعرفية والحسابية.\n\nكيف يمكنني مساعدتك اليوم؟',
        quickActions: [
          { label: '🧬 ما هو ATP؟', action: 'ما هو ATP؟' },
          { label: '⚖️ حساب BMI لوزن 70 وطول 175', action: 'احسب لي BMI لوزن 70 وطول 175' },
          { label: '🤖 كاشف النصوص بالذكاء الاصطناعي', action: 'أريد أداة لكشف النصوص بالذكاء الاصطناعي' },
          { label: '🩺 أدوات الطب والمختبر', action: 'ما هي أدوات قسم الطب؟' }
        ],
        timestamp: 'الآن'
      }
    ];
  });

  const [inputVal, setInputVal] = useState<string>('');
  const [isTyping, setIsTyping] = useState<boolean>(false);
  const [responseDetailLevel, setResponseDetailLevel] = useState<'concise' | 'balanced' | 'detailed'>('balanced');
  const [showSettings, setShowSettings] = useState<boolean>(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Auto save messages
  useEffect(() => {
    try {
      localStorage.setItem('adwatuk_quick_chat_history', JSON.stringify(messages));
    } catch {}
  }, [messages]);

  // Scroll to bottom
  useEffect(() => {
    if (isOpen) {
      messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, isTyping]);

  if (!isOpen) return null;

  // Semantic Tool Matching Engine
  const findMatchingTools = (query: string): ToolDefinition[] => {
    const q = query.toLowerCase().trim();
    const matches: { tool: ToolDefinition; score: number }[] = [];

    ALL_TOOLS.forEach((tool) => {
      let score = 0;
      const title = tool.titleAr.toLowerCase();
      const titleEn = (tool.titleEn || '').toLowerCase();
      const desc = tool.descriptionAr.toLowerCase();
      const tags = (tool.tags || []).map((t) => t.toLowerCase());
      const keywords = (tool.keywords || []).map((k) => k.toLowerCase());

      if (title.includes(q)) score += 50;
      if (titleEn.includes(q)) score += 40;
      if (tags.some((t) => q.includes(t) || t.includes(q))) score += 30;
      if (keywords.some((k) => q.includes(k) || k.includes(q))) score += 25;
      if (desc.includes(q)) score += 15;

      // Specific semantic intent triggers
      if ((q.includes('ai') || q.includes('ذكاء') || q.includes('كشف') || q.includes('مكتوب')) && tool.id === 'ai-text-detector') score += 100;
      if ((q.includes('atp') || q.includes('كيمياء') || q.includes('تفاعل') || q.includes('حيوي') || q.includes('ميتوكوندريا')) && (tool.id === 'biochem-lab' || tool.id === 'human-body-reactions')) score += 100;
      if ((q.includes('وزن') || q.includes('طول') || q.includes('bmi') || q.includes('كتلة الجسم')) && tool.id === 'health-calculator') score += 100;
      if ((q.includes('صورة') || q.includes('ضغط') || q.includes('تصغير')) && tool.id === 'image-compressor') score += 80;
      if ((q.includes('عملة') || q.includes('دولار') || q.includes('ريال') || q.includes('تحويل')) && tool.id === 'currency-calculator') score += 80;
      if ((q.includes('pdf') || q.includes('بي دي اف')) && (tool.id === 'pdf-tools-suite' || tool.id === 'pdf-merger')) score += 80;
      if ((q.includes('تشريح') || q.includes('جراحة') || q.includes('3d')) && tool.id === 'surgical-anatomy-3d') score += 80;
      if ((q.includes('كود') || q.includes('برمجة') || q.includes('editor')) && tool.id === 'code-editor-suite') score += 80;

      if (score > 0) {
        matches.push({ tool, score });
      }
    });

    matches.sort((a, b) => b.score - a.score);
    return matches.slice(0, 3).map((m) => m.tool);
  };

  // Assistant Response Generation Engine
  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputVal).trim();
    if (!query) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: 'الآن'
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputVal('');
    setIsTyping(true);

    const matchedTools = findMatchingTools(query);

    try {
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages.slice(-4).map((m) => ({ sender: m.sender, text: m.text })),
          detailLevel: 'balanced'
        })
      });

      if (response.ok) {
        const data = await response.json();
        const replyText = data.reply || 'تم استلام طلبك.';
        const assistantMsg: ChatMessage = {
          id: `ast-${Date.now()}`,
          sender: 'assistant',
          text: replyText,
          matchedTools: matchedTools.length > 0 ? matchedTools : undefined,
          timestamp: 'الآن'
        };

        setMessages((prev) => [...prev, assistantMsg]);
        setIsTyping(false);
        return;
      }
    } catch (e) {
      console.warn('API chat fallback:', e);
    }

    setTimeout(() => {
      const qLower = query.toLowerCase();
      let responseText = '';
      let calcResult: string | undefined = undefined;

      // 1. Check for BMI calculation pattern (e.g., "وزن 70 وطول 175" or "70 كجم و175 سم")
      const weightMatch = query.match(/(\d+(\.\d+)?)\s*(كجم|كغ|كيلو|kg|وزن)/i) || query.match(/وزن\s*(\d+(\.\d+)?)/i);
      const heightMatch = query.match(/(\d+(\.\d+)?)\s*(سم|cm|طول)/i) || query.match(/طول\s*(\d+(\.\d+)?)/i);

      if (weightMatch && heightMatch) {
        const weight = parseFloat(weightMatch[1]);
        const height = parseFloat(heightMatch[1]);
        const heightM = height > 3 ? height / 100 : height; // in meters
        if (weight > 0 && heightM > 0) {
          const bmi = (weight / (heightM * heightM)).toFixed(1);
          let category = 'وزن طبيعي ومثالي';
          if (parseFloat(bmi) < 18.5) category = 'نقص في الوزن';
          else if (parseFloat(bmi) >= 25 && parseFloat(bmi) < 30) category = 'زيادة في الوزن';
          else if (parseFloat(bmi) >= 30) category = 'سمنة';

          calcResult = `مؤشر كتلة الجسم (BMI): ${bmi} — الحالة: ${category}`;
          responseText = `بناءً على الوزن (${weight} كجم) والطول (${height} سم)، مؤشر كتلة جسمك هو:\n\n✨ **BMI ≈ ${bmi}** (${category})\n\nيمكنك استخدام حاسبة الصحة والـ BMI لمزيد من التحليلات التفصيلية والسعرات:`;
        }
      } else if (qLower.includes('ai') || qLower.includes('ذكاء') || qLower.includes('كشف') || qLower.includes('مكتوب')) {
        responseText = 'وجدت لك الأداة المخصصة لذلك:\n\n🤖 **كاشف النص الذكي — AI Text Detector**\nتحليل احتمالي ولغوي متطور يكشف أنماط ونسب النصوص المولدة بالذكاء الاصطناعي مقارنة بالصياغة البشرية.';
      } else if (qLower.includes('atp') || qLower.includes('كيمياء') || qLower.includes('تفاعل') || qLower.includes('ميتوكوندريا')) {
        responseText = 'جزيء **ATP** (أدينوسين ثلاثي الفوسفات) هو عملة الطاقة الكيميائية العالمية في جميع خلايا الجسم البشري، ويتم إنتاجه بشكل رئيسي داخل الميتوكوندريا عبر أكسدة الجلوكوز وسلسلة نقل الإلكترون.\n\nتفضل بفتح مختبر الكيمياء الحيوية التفاعلي لاستكشاف المسارات والأعضاء:';
      } else {
        responseText = `أهلاً بك! أنا مساعدك الذكي في منصة أدواتك السريعة. سأساعدك في الإجابة عن أي استفسار وتوجيهك للأداة المناسبة فوراً!`;
      }

      const assistantMsg: ChatMessage = {
        id: `ast-${Date.now()}`,
        sender: 'assistant',
        text: responseText,
        matchedTools: matchedTools.length > 0 ? matchedTools : undefined,
        calculationResult: calcResult,
        timestamp: 'الآن'
      };

      setMessages((prev) => [...prev, assistantMsg]);
      setIsTyping(false);
    }, 450);
  };

  const handleOpenTool = (tool: ToolDefinition) => {
    onClose();
    if (onSelectTool) {
      onSelectTool(tool);
    } else {
      navigate(`/tool/${tool.id}`);
    }
  };

  const handleClearHistory = () => {
    localStorage.removeItem('adwatuk_quick_chat_history');
    setMessages([
      {
        id: 'msg-welcome-reset',
        sender: 'assistant',
        text: 'تم مسح السجل! مرحباً بك من جديد في «أدواتك السريعة» 🤖. كيف يمكنني خدمتك؟',
        timestamp: 'الآن'
      }
    ]);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 bg-black/70 backdrop-blur-md animate-in fade-in duration-200">
      <div className="bg-white dark:bg-gray-900 rounded-3xl w-full max-w-2xl h-[650px] max-h-[92vh] flex flex-col shadow-2xl border border-gray-200 dark:border-gray-800 overflow-hidden text-right">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-600 via-teal-600 to-indigo-600 text-white flex items-center justify-between shadow-md">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-2xl bg-white/20 backdrop-blur-sm border border-white/30 flex items-center justify-center text-white shadow-inner">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-base sm:text-lg">أدواتك السريعة 🤖</h3>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-white/20 border border-white/30">
                  مساعد ذكي فوري
                </span>
              </div>
              <p className="text-xs text-emerald-100/90">
                ابحث عن الأدوات، اسأل أي سؤال، واحصل على إجابات وأدوات فورية.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={() => setShowSettings(!showSettings)}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition text-xs"
              title="الإعدادات"
            >
              <Sliders className="w-4 h-4" />
            </button>
            <button
              onClick={handleClearHistory}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition text-xs"
              title="مسح المحادثة"
            >
              <RotateCcw className="w-4 h-4" />
            </button>
            <button
              onClick={onClose}
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 text-white transition text-xs"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* Settings Sub-panel */}
        {showSettings && (
          <div className="p-3.5 bg-gray-50 dark:bg-gray-950 border-b border-gray-200 dark:border-gray-800 flex items-center justify-between text-xs animate-in slide-in-from-top-2 duration-200">
            <span className="font-bold text-gray-700 dark:text-gray-300">مستوى تفصيل الإجابة:</span>
            <div className="flex items-center gap-1 bg-gray-200 dark:bg-gray-800 p-1 rounded-xl">
              {[
                { id: 'concise', label: 'مختصر' },
                { id: 'balanced', label: 'متوسط' },
                { id: 'detailed', label: 'مفصل' }
              ].map((lvl) => (
                <button
                  key={lvl.id}
                  onClick={() => setResponseDetailLevel(lvl.id as any)}
                  className={`px-2.5 py-1 rounded-lg font-bold transition ${
                    responseDetailLevel === lvl.id
                      ? 'bg-emerald-600 text-white'
                      : 'text-gray-600 dark:text-gray-400'
                  }`}
                >
                  {lvl.label}
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Chat Messages Area */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-5 space-y-4 bg-gray-50/50 dark:bg-gray-950/40 scrollbar-thin">
          {messages.map((msg) => {
            const isUser = msg.sender === 'user';
            return (
              <div
                key={msg.id}
                className={`flex gap-3 ${isUser ? 'flex-row-reverse' : 'flex-row'}`}
              >
                {/* Avatar */}
                <div
                  className={`w-8 h-8 rounded-xl shrink-0 flex items-center justify-center text-xs font-bold ${
                    isUser
                      ? 'bg-indigo-600 text-white'
                      : 'bg-emerald-600 text-white shadow-md'
                  }`}
                >
                  {isUser ? <User className="w-4 h-4" /> : <Bot className="w-4 h-4" />}
                </div>

                {/* Message Content */}
                <div className={`space-y-2 max-w-[82%] sm:max-w-[78%] ${isUser ? 'items-end' : 'items-start'}`}>
                  <div
                    className={`p-3.5 rounded-2xl text-xs sm:text-sm leading-relaxed whitespace-pre-wrap ${
                      isUser
                        ? 'bg-indigo-600 text-white rounded-tr-none'
                        : 'bg-white dark:bg-gray-800 text-gray-800 dark:text-gray-100 border border-gray-200 dark:border-gray-700 rounded-tl-none shadow-xs'
                    }`}
                  >
                    {msg.text}
                  </div>

                  {/* Calculation Highlight */}
                  {msg.calculationResult && (
                    <div className="p-3 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 font-bold text-xs">
                      {msg.calculationResult}
                    </div>
                  )}

                  {/* Matched Tool Cards */}
                  {msg.matchedTools && msg.matchedTools.length > 0 && (
                    <div className="space-y-2 pt-1 w-full">
                      {msg.matchedTools.map((tool) => (
                        <div
                          key={tool.id}
                          className="p-3.5 rounded-2xl bg-white dark:bg-gray-800 border border-emerald-300 dark:border-emerald-800/80 shadow-sm flex items-center justify-between gap-3 hover:border-emerald-500 transition-all"
                        >
                          <div className="space-y-0.5 flex-1 min-w-0">
                            <div className="flex items-center gap-1.5">
                              <span className="font-extrabold text-xs sm:text-sm text-gray-900 dark:text-white truncate">
                                {tool.titleAr}
                              </span>
                              {tool.badge && (
                                <span className="px-1.5 py-0.5 rounded text-[10px] font-bold bg-emerald-100 dark:bg-emerald-900/60 text-emerald-800 dark:text-emerald-200">
                                  {tool.badge}
                                </span>
                              )}
                            </div>
                            <p className="text-[11px] text-gray-500 dark:text-gray-400 line-clamp-1">
                              {tool.descriptionAr}
                            </p>
                          </div>

                          <button
                            onClick={() => handleOpenTool(tool)}
                            className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition flex items-center gap-1 shrink-0 shadow-sm shadow-emerald-500/20 active:scale-95"
                          >
                            <span>فتح الأداة</span>
                            <ArrowRight className="w-3.5 h-3.5 rotate-180" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}

                  {/* Quick Action Suggestion Pills */}
                  {msg.quickActions && msg.quickActions.length > 0 && (
                    <div className="flex flex-wrap gap-1.5 pt-1">
                      {msg.quickActions.map((qa, i) => (
                        <button
                          key={i}
                          onClick={() => handleSendMessage(qa.action)}
                          className="px-2.5 py-1 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 text-emerald-800 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 text-xs font-semibold transition"
                        >
                          {qa.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            );
          })}

          {isTyping && (
            <div className="flex gap-3">
              <div className="w-8 h-8 rounded-xl bg-emerald-600 text-white flex items-center justify-center">
                <Bot className="w-4 h-4" />
              </div>
              <div className="p-3 rounded-2xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-xs text-gray-400 flex items-center gap-1.5">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" />
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce delay-150" />
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce delay-300" />
                <span className="mr-1">«أدواتك السريعة» يكتب الآن...</span>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>

        {/* Input Footer */}
        <div className="p-3.5 sm:p-4 bg-white dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSendMessage();
            }}
            className="flex items-center gap-2"
          >
            <input
              type="text"
              value={inputVal}
              onChange={(e) => setInputVal(e.target.value)}
              placeholder="اكتب سؤالك أو اطلب أي أداة بالاسم (مثال: احسب BMI، تفاعلات الجسم، كاشف AI)..."
              className="flex-1 p-3 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-white text-xs sm:text-sm outline-none focus:ring-2 focus:ring-emerald-500"
            />
            <button
              type="submit"
              disabled={!inputVal.trim()}
              className="p-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 disabled:opacity-40 text-white transition shadow-md shadow-emerald-500/20"
            >
              <Send className="w-4 h-4 rotate-180" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}
