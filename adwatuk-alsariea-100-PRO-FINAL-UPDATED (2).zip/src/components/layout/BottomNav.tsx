import React from 'react';
import { Home, Compass, Flame, LayoutGrid, Menu, Sparkles } from 'lucide-react';
import { useLocation, useNavigate } from 'react-router-dom';
import { ToolCategory } from '../../types';

interface BottomNavProps {
  activeCategory: ToolCategory;
  onSelectCategory: (category: ToolCategory) => void;
  onOpenMore: () => void;
}

export function BottomNav({ activeCategory, onSelectCategory, onOpenMore }: BottomNavProps) {
  const location = useLocation();
  const navigate = useNavigate();

  const handleNavClick = (category: ToolCategory) => {
    if (location.pathname !== '/') {
      navigate('/');
    }
    onSelectCategory(category);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const isHome = location.pathname === '/' && (activeCategory === 'home' || activeCategory === 'all' && false);
  const isAll = location.pathname === '/' && activeCategory === 'all';
  const isPopular = location.pathname === '/' && activeCategory === 'popular';
  const isDiscovery = location.pathname === '/' && activeCategory === 'discovery';
  const isNew = location.pathname === '/' && activeCategory === 'new';

  return (
    <div className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 dark:bg-gray-900/95 backdrop-blur-xl border-t border-gray-200 dark:border-gray-800 shadow-[0_-4px_20px_-10px_rgba(0,0,0,0.1)] pb-safe">
      <div className="flex items-center justify-around h-16 px-1">
        {/* الرئيسية - أقسام مميزة وأدوات شائعة */}
        <button
          onClick={() => handleNavClick('home')}
          className={`flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors ${
            activeCategory === 'home' ? 'text-emerald-600 dark:text-emerald-400 font-extrabold' : 'text-gray-500 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          <Home className={`w-5 h-5 ${activeCategory === 'home' ? 'fill-emerald-600/20 stroke-[2.5]' : ''}`} />
          <span className="text-[9px] sm:text-[10px] font-bold">الرئيسية</span>
        </button>

        {/* الكل - كافة الأقسام والأدوات بالكامل */}
        <button
          onClick={() => handleNavClick('all')}
          className={`flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors ${
            activeCategory === 'all' ? 'text-emerald-600 dark:text-emerald-400 font-extrabold' : 'text-gray-500 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          <LayoutGrid className={`w-5 h-5 ${activeCategory === 'all' ? 'stroke-[2.5]' : ''}`} />
          <span className="text-[9px] sm:text-[10px] font-bold">الكل</span>
        </button>

        {/* الأكثر استخداماً */}
        <button
          onClick={() => handleNavClick('popular')}
          className={`flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors ${
            isPopular ? 'text-amber-500 dark:text-amber-400' : 'text-gray-500 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          <Flame className={`w-5 h-5 ${isPopular ? 'fill-amber-500/20' : ''}`} />
          <span className="text-[9px] sm:text-[10px] font-bold">شائعة</span>
        </button>

        {/* الاستكشاف */}
        <button
          onClick={() => handleNavClick('discovery')}
          className={`flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors ${
            isDiscovery ? 'text-emerald-600 dark:text-emerald-400' : 'text-gray-500 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          <Compass className={`w-5 h-5 ${isDiscovery ? 'fill-emerald-600/20' : ''}`} />
          <span className="text-[9px] sm:text-[10px] font-bold">الاستكشاف</span>
        </button>

        {/* المضاف مؤخراً */}
        <button
          onClick={() => handleNavClick('new')}
          className={`flex flex-col items-center justify-center w-full h-full space-y-1 transition-colors ${
            isNew ? 'text-teal-600 dark:text-teal-400' : 'text-gray-500 hover:text-gray-900 dark:hover:text-gray-300'
          }`}
        >
          <Sparkles className={`w-5 h-5 ${isNew ? 'fill-teal-600/20' : ''}`} />
          <span className="text-[9px] sm:text-[10px] font-bold">المضاف مؤخراً</span>
        </button>

        {/* المزيد */}
        <button
          onClick={onOpenMore}
          className="flex flex-col items-center justify-center w-full h-full space-y-1 text-gray-500 hover:text-gray-900 dark:hover:text-gray-300 transition-colors"
        >
          <Menu className="w-5 h-5" />
          <span className="text-[9px] sm:text-[10px] font-bold">المزيد</span>
        </button>
      </div>
    </div>
  );
}

