import React from 'react';
import { Search, Zap, ShieldCheck, Sparkles, Cpu, Clock } from 'lucide-react';

interface HeroSectionProps {
  searchQuery: string;
  setSearchQuery: (query: string) => void;
  totalToolsCount: number;
}

export function HeroSection({
  searchQuery,
  setSearchQuery,
  totalToolsCount,
}: HeroSectionProps) {
  return (
    <section className="relative overflow-hidden py-10 sm:py-14 bg-gradient-to-b from-emerald-500/10 via-emerald-500/5 to-transparent dark:from-emerald-950/20 dark:via-transparent border-b border-gray-200/50 dark:border-gray-800/50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 text-center space-y-6">
        {/* Official Site Logo Banner */}
        <div className="flex justify-center">
          <div className="w-16 h-16 sm:w-20 sm:h-20 rounded-2xl overflow-hidden border-2 border-emerald-500/40 shadow-xl shadow-emerald-500/20 transform hover:scale-105 transition-transform bg-gray-900 shrink-0">
            <img src="/logo-96.webp" alt="شعار منصة أدواتك السريعة" width="80" height="80" decoding="async" fetchPriority="high" className="w-full h-full object-cover" />
          </div>
        </div>

        {/* Privacy & Fast badge */}
        <div className="inline-flex items-center gap-2 px-3.5 py-1.5 rounded-full bg-emerald-100/80 dark:bg-emerald-950/60 border border-emerald-300/60 dark:border-emerald-800 text-emerald-800 dark:text-emerald-300 text-xs font-semibold shadow-2xs">
          <ShieldCheck className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>خصوصية كاملة 100% • تتم كافة المعالجات داخل متصفحك دون رفع ملفاتك</span>
        </div>

        {/* Title */}
        <div className="space-y-2">
          <h1 className="text-3xl sm:text-4xl md:text-5xl font-extrabold font-heading text-gray-900 dark:text-white tracking-tight">
            أدواتك اليومية، <span className="text-transparent bg-clip-text bg-gradient-to-l from-emerald-600 to-teal-500">بسرعة البرق</span>
          </h1>
          <p className="text-sm sm:text-base text-gray-600 dark:text-gray-300 max-w-2xl mx-auto leading-relaxed">
            منصة متكاملة تجمع أكثر من {totalToolsCount} أداة احترافية للتعامل مع النصوص، ضغط وتحويل الصور، الحاسبات الدقيقة، محولات القياس، ورموز QR بضغطة زر واحدة.
          </p>
        </div>

        {/* Big Search Input */}
        <div className="relative max-w-xl mx-auto">
          <div className="absolute inset-y-0 right-0 pr-4 flex items-center pointer-events-none text-gray-400">
            <Search className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="ابحث عن أداة (مثال: ضاغط الصور، حاسبة العمر، عداد الكلمات، QR، باركود)..."
            id="hero-search-input"
            className="w-full pr-11 pl-4 py-3.5 bg-white dark:bg-gray-900 border-2 border-gray-200 dark:border-gray-700 hover:border-emerald-400 focus:border-emerald-500 rounded-2xl text-sm sm:text-base text-gray-900 dark:text-white placeholder-gray-400 focus:ring-4 focus:ring-emerald-500/10 outline-none shadow-sm transition-all"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute inset-y-0 left-0 pl-4 flex items-center text-xs text-gray-400 hover:text-gray-600 dark:hover:text-gray-200"
            >
              مسح
            </button>
          )}
        </div>

        {/* Feature Pills */}
        <div className="flex flex-wrap items-center justify-center gap-4 text-xs font-medium text-gray-500 dark:text-gray-400 pt-2">
          <div className="flex items-center gap-1.5">
            <Zap className="w-4 h-4 text-emerald-500" />
            <span>معالجة فائقة السرعة</span>
          </div>
          <div className="w-1 h-1 rounded-full bg-gray-300 dark:bg-gray-700"></div>
          <div className="flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-teal-500" />
            <span>مجاني 100% بدون تسجيل</span>
          </div>
          <div className="w-1 h-1 rounded-full bg-gray-300 dark:bg-gray-700"></div>
          <div className="flex items-center gap-1.5">
            <Clock className="w-4 h-4 text-blue-500" />
            <span>يعمل بدون اتصال بالإنترنت</span>
          </div>
        </div>
      </div>
    </section>
  );
}
