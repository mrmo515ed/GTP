import React from 'react';
import { motion } from 'motion/react';
import { ToolDefinition, ToolCategory } from '../../types';
import { Star, Sparkles, ArrowLeft } from 'lucide-react';
import { getToolIcon } from '../../utils/iconMap';

interface ToolCardProps {
  key?: React.Key;
  tool: ToolDefinition;
  isFavorite: boolean;
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onSelect: (tool: ToolDefinition) => void;
}

interface CategoryStyleConfig {
  bg: string;
  cardBg: string;
  iconBg: string;
  iconText: string;
  borderHover: string;
  hoverText: string;
  glowColor: string;
  accentBar: string;
  badgeBg: string;
  tagBg: string;
}

const getCategoryStyles = (category: ToolCategory): CategoryStyleConfig => {
  const styles: Record<string, CategoryStyleConfig> = {
    text: {
      bg: 'from-indigo-500/10 via-blue-500/5 to-transparent dark:from-indigo-950/30 dark:via-blue-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-indigo-500 to-blue-600 text-white shadow-indigo-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-indigo-500/60 hover:shadow-indigo-500/15',
      hoverText: 'group-hover:text-indigo-600 dark:group-hover:text-indigo-400',
      glowColor: 'bg-indigo-500/10',
      accentBar: 'from-indigo-500 to-blue-500',
      badgeBg: 'bg-indigo-50 dark:bg-indigo-950/60 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
      tagBg: 'bg-indigo-50/70 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-300'
    },
    image: {
      bg: 'from-rose-500/10 via-pink-500/5 to-transparent dark:from-rose-950/30 dark:via-pink-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-rose-500 to-pink-600 text-white shadow-rose-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-rose-500/60 hover:shadow-rose-500/15',
      hoverText: 'group-hover:text-rose-600 dark:group-hover:text-rose-400',
      glowColor: 'bg-rose-500/10',
      accentBar: 'from-rose-500 to-pink-500',
      badgeBg: 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800',
      tagBg: 'bg-rose-50/70 dark:bg-rose-950/40 text-rose-600 dark:text-rose-300'
    },
    documents: {
      bg: 'from-red-500/10 via-orange-500/5 to-transparent dark:from-red-950/30 dark:via-orange-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-red-500 to-orange-600 text-white shadow-red-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-red-500/60 hover:shadow-red-500/15',
      hoverText: 'group-hover:text-red-600 dark:group-hover:text-red-400',
      glowColor: 'bg-red-500/10',
      accentBar: 'from-red-500 to-orange-500',
      badgeBg: 'bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300 border-red-200 dark:border-red-800',
      tagBg: 'bg-red-50/70 dark:bg-red-950/40 text-red-600 dark:text-red-300'
    },
    pdf: {
      bg: 'from-red-500/10 via-rose-500/5 to-transparent dark:from-red-950/30 dark:via-rose-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-red-600 to-rose-600 text-white shadow-red-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-red-500/60 hover:shadow-red-500/15',
      hoverText: 'group-hover:text-red-600 dark:group-hover:text-red-400',
      glowColor: 'bg-red-500/10',
      accentBar: 'from-red-600 to-rose-600',
      badgeBg: 'bg-red-50 dark:bg-red-950/60 text-red-700 dark:text-red-300 border-red-200 dark:border-red-800',
      tagBg: 'bg-red-50/70 dark:bg-red-950/40 text-red-600 dark:text-red-300'
    },
    dev: {
      bg: 'from-fuchsia-500/10 via-purple-500/5 to-transparent dark:from-fuchsia-950/30 dark:via-purple-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-fuchsia-500 to-purple-600 text-white shadow-fuchsia-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-fuchsia-500/60 hover:shadow-fuchsia-500/15',
      hoverText: 'group-hover:text-fuchsia-600 dark:group-hover:text-fuchsia-400',
      glowColor: 'bg-fuchsia-500/10',
      accentBar: 'from-fuchsia-500 to-purple-500',
      badgeBg: 'bg-fuchsia-50 dark:bg-fuchsia-950/60 text-fuchsia-700 dark:text-fuchsia-300 border-fuchsia-200 dark:border-fuchsia-800',
      tagBg: 'bg-fuchsia-50/70 dark:bg-fuchsia-950/40 text-fuchsia-600 dark:text-fuchsia-300'
    },
    health: {
      bg: 'from-emerald-500/10 via-teal-500/5 to-transparent dark:from-emerald-950/30 dark:via-teal-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-emerald-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-emerald-500/60 hover:shadow-emerald-500/15',
      hoverText: 'group-hover:text-emerald-600 dark:group-hover:text-emerald-400',
      glowColor: 'bg-emerald-500/10',
      accentBar: 'from-emerald-500 to-teal-500',
      badgeBg: 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
      tagBg: 'bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-300'
    },
    'surgery-3d': {
      bg: 'from-rose-500/10 via-emerald-500/5 to-transparent dark:from-rose-950/30 dark:via-emerald-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-rose-600 via-red-600 to-teal-600 text-white shadow-rose-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-rose-500/60 hover:shadow-rose-500/15',
      hoverText: 'group-hover:text-rose-600 dark:group-hover:text-rose-400',
      glowColor: 'bg-rose-500/10',
      accentBar: 'from-rose-600 to-teal-500',
      badgeBg: 'bg-rose-50 dark:bg-rose-950/60 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800',
      tagBg: 'bg-rose-50/70 dark:bg-rose-950/40 text-rose-600 dark:text-rose-300'
    },
    calculators: {
      bg: 'from-cyan-500/10 via-blue-500/5 to-transparent dark:from-cyan-950/30 dark:via-blue-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-cyan-500 to-blue-600 text-white shadow-cyan-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-cyan-500/60 hover:shadow-cyan-500/15',
      hoverText: 'group-hover:text-cyan-600 dark:group-hover:text-cyan-400',
      glowColor: 'bg-cyan-500/10',
      accentBar: 'from-cyan-500 to-blue-500',
      badgeBg: 'bg-cyan-50 dark:bg-cyan-950/60 text-cyan-700 dark:text-cyan-300 border-cyan-200 dark:border-cyan-800',
      tagBg: 'bg-cyan-50/70 dark:bg-cyan-950/40 text-cyan-600 dark:text-cyan-300'
    },
    units: {
      bg: 'from-amber-500/10 via-yellow-500/5 to-transparent dark:from-amber-950/30 dark:via-yellow-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-amber-500 to-yellow-600 text-white shadow-amber-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-amber-500/60 hover:shadow-amber-500/15',
      hoverText: 'group-hover:text-amber-600 dark:group-hover:text-amber-400',
      glowColor: 'bg-amber-500/10',
      accentBar: 'from-amber-500 to-yellow-500',
      badgeBg: 'bg-amber-50 dark:bg-amber-950/60 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800',
      tagBg: 'bg-amber-50/70 dark:bg-amber-950/40 text-amber-600 dark:text-amber-300'
    },
    currencies: {
      bg: 'from-emerald-500/10 via-amber-500/5 to-transparent dark:from-emerald-950/30 dark:via-amber-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-emerald-600 to-amber-500 text-white shadow-emerald-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-emerald-500/60 hover:shadow-emerald-500/15',
      hoverText: 'group-hover:text-emerald-600 dark:group-hover:text-emerald-400',
      glowColor: 'bg-emerald-500/10',
      accentBar: 'from-emerald-600 to-amber-500',
      badgeBg: 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
      tagBg: 'bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-300'
    },
    engineering: {
      bg: 'from-orange-500/10 via-amber-500/5 to-transparent dark:from-orange-950/30 dark:via-amber-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-orange-500 to-amber-600 text-white shadow-orange-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-orange-500/60 hover:shadow-orange-500/15',
      hoverText: 'group-hover:text-orange-600 dark:group-hover:text-orange-400',
      glowColor: 'bg-orange-500/10',
      accentBar: 'from-orange-500 to-amber-500',
      badgeBg: 'bg-orange-50 dark:bg-orange-950/60 text-orange-700 dark:text-orange-300 border-orange-200 dark:border-orange-800',
      tagBg: 'bg-orange-50/70 dark:bg-orange-950/40 text-orange-600 dark:text-orange-300'
    },
    data: {
      bg: 'from-blue-500/10 via-cyan-500/5 to-transparent dark:from-blue-950/30 dark:via-cyan-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-blue-500 to-cyan-600 text-white shadow-blue-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-blue-500/60 hover:shadow-blue-500/15',
      hoverText: 'group-hover:text-blue-600 dark:group-hover:text-blue-400',
      glowColor: 'bg-blue-500/10',
      accentBar: 'from-blue-500 to-cyan-500',
      badgeBg: 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800',
      tagBg: 'bg-blue-50/70 dark:bg-blue-950/40 text-blue-600 dark:text-blue-300'
    },
    audio: {
      bg: 'from-violet-500/10 via-purple-500/5 to-transparent dark:from-violet-950/30 dark:via-purple-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-violet-500 to-purple-600 text-white shadow-violet-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-violet-500/60 hover:shadow-violet-500/15',
      hoverText: 'group-hover:text-violet-600 dark:group-hover:text-violet-400',
      glowColor: 'bg-violet-500/10',
      accentBar: 'from-violet-500 to-purple-500',
      badgeBg: 'bg-violet-50 dark:bg-violet-950/60 text-violet-700 dark:text-violet-300 border-violet-200 dark:border-violet-800',
      tagBg: 'bg-violet-50/70 dark:bg-violet-950/40 text-violet-600 dark:text-violet-300'
    },
    video: {
      bg: 'from-pink-500/10 via-rose-500/5 to-transparent dark:from-pink-950/30 dark:via-rose-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-pink-500 to-rose-600 text-white shadow-pink-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-pink-500/60 hover:shadow-pink-500/15',
      hoverText: 'group-hover:text-pink-600 dark:group-hover:text-pink-400',
      glowColor: 'bg-pink-500/10',
      accentBar: 'from-pink-500 to-rose-500',
      badgeBg: 'bg-pink-50 dark:bg-pink-950/60 text-pink-700 dark:text-pink-300 border-pink-200 dark:border-pink-800',
      tagBg: 'bg-pink-50/70 dark:bg-pink-950/40 text-pink-600 dark:text-pink-300'
    },
    archives: {
      bg: 'from-teal-500/10 via-emerald-500/5 to-transparent dark:from-teal-950/30 dark:via-emerald-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-teal-500 to-emerald-600 text-white shadow-teal-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-teal-500/60 hover:shadow-teal-500/15',
      hoverText: 'group-hover:text-teal-600 dark:group-hover:text-teal-400',
      glowColor: 'bg-teal-500/10',
      accentBar: 'from-teal-500 to-emerald-500',
      badgeBg: 'bg-teal-50 dark:bg-teal-950/60 text-teal-700 dark:text-teal-300 border-teal-200 dark:border-teal-800',
      tagBg: 'bg-teal-50/70 dark:bg-teal-950/40 text-teal-600 dark:text-teal-300'
    },
    student: {
      bg: 'from-sky-500/10 via-indigo-500/5 to-transparent dark:from-sky-950/30 dark:via-indigo-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-sky-500 to-indigo-600 text-white shadow-sky-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-sky-500/60 hover:shadow-sky-500/15',
      hoverText: 'group-hover:text-sky-600 dark:group-hover:text-sky-400',
      glowColor: 'bg-sky-500/10',
      accentBar: 'from-sky-500 to-indigo-500',
      badgeBg: 'bg-sky-50 dark:bg-sky-950/60 text-sky-700 dark:text-sky-300 border-sky-200 dark:border-sky-800',
      tagBg: 'bg-sky-50/70 dark:bg-sky-950/40 text-sky-600 dark:text-sky-300'
    },
    discovery: {
      bg: 'from-purple-500/10 via-pink-500/5 to-transparent dark:from-purple-950/30 dark:via-pink-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-purple-500 to-pink-600 text-white shadow-purple-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-purple-500/60 hover:shadow-purple-500/15',
      hoverText: 'group-hover:text-purple-600 dark:group-hover:text-purple-400',
      glowColor: 'bg-purple-500/10',
      accentBar: 'from-purple-500 to-pink-500',
      badgeBg: 'bg-purple-50 dark:bg-purple-950/60 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800',
      tagBg: 'bg-purple-50/70 dark:bg-purple-950/40 text-purple-600 dark:text-purple-300'
    },
    design: {
      bg: 'from-pink-500/10 via-amber-500/5 to-transparent dark:from-pink-950/30 dark:via-amber-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-pink-500 to-amber-500 text-white shadow-pink-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-pink-500/60 hover:shadow-pink-500/15',
      hoverText: 'group-hover:text-pink-600 dark:group-hover:text-pink-400',
      glowColor: 'bg-pink-500/10',
      accentBar: 'from-pink-500 to-amber-500',
      badgeBg: 'bg-pink-50 dark:bg-pink-950/60 text-pink-700 dark:text-pink-300 border-pink-200 dark:border-pink-800',
      tagBg: 'bg-pink-50/70 dark:bg-pink-950/40 text-pink-600 dark:text-pink-300'
    },
    social: {
      bg: 'from-blue-500/10 via-rose-500/5 to-transparent dark:from-blue-950/30 dark:via-rose-950/15',
      cardBg: 'bg-white/90 dark:bg-slate-900/90',
      iconBg: 'bg-gradient-to-br from-blue-500 to-rose-500 text-white shadow-blue-500/25',
      iconText: 'text-white',
      borderHover: 'hover:border-blue-500/60 hover:shadow-blue-500/15',
      hoverText: 'group-hover:text-blue-600 dark:group-hover:text-blue-400',
      glowColor: 'bg-blue-500/10',
      accentBar: 'from-blue-500 to-rose-500',
      badgeBg: 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800',
      tagBg: 'bg-blue-50/70 dark:bg-blue-950/40 text-blue-600 dark:text-blue-300'
    }
  };

  const defaultStyle: CategoryStyleConfig = {
    bg: 'from-emerald-500/10 via-teal-500/5 to-transparent dark:from-emerald-950/30 dark:via-teal-950/15',
    cardBg: 'bg-white/90 dark:bg-slate-900/90',
    iconBg: 'bg-gradient-to-br from-emerald-500 to-teal-600 text-white shadow-emerald-500/25',
    iconText: 'text-white',
    borderHover: 'hover:border-emerald-500/60 hover:shadow-emerald-500/15',
    hoverText: 'group-hover:text-emerald-600 dark:group-hover:text-emerald-400',
    glowColor: 'bg-emerald-500/10',
    accentBar: 'from-emerald-500 to-teal-500',
    badgeBg: 'bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
    tagBg: 'bg-emerald-50/70 dark:bg-emerald-950/40 text-emerald-600 dark:text-emerald-300'
  };

  return styles[category] || defaultStyle;
};

export function ToolCard({
  tool,
  isFavorite,
  onToggleFavorite,
  onSelect,
}: ToolCardProps) {
  const IconComponent = getToolIcon(tool.icon);

  const getBadgeStyle = (badge?: string) => {
    switch (badge) {
      case 'شائع':
        return 'bg-gradient-to-r from-amber-500 to-orange-500 text-white border-transparent shadow-xs';
      case 'مميز':
        return 'bg-gradient-to-r from-purple-600 to-indigo-600 text-white border-transparent shadow-xs';
      case 'فوري':
        return 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white border-transparent shadow-xs';
      case 'جديد':
        return 'bg-gradient-to-r from-cyan-500 to-blue-600 text-white border-transparent shadow-xs animate-pulse';
      default:
        return 'bg-gray-100 text-gray-700 dark:bg-gray-800 dark:text-gray-300 border-gray-200 dark:border-gray-700';
    }
  };

  const style = getCategoryStyles(tool.category);

  return (
    <motion.div
      layout="position"
      initial={{ opacity: 0, y: 15, scale: 0.98 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      exit={{ opacity: 0, scale: 0.95 }}
      whileHover={{ y: -4, scale: 1.01 }}
      whileTap={{ scale: 0.98 }}
      transition={{ duration: 0.25, ease: 'easeOut' }}
      onClick={() => onSelect(tool)}
      id={`tool-card-${tool.id}`}
      className={`group relative ${style.cardBg} bg-gradient-to-br ${style.bg} rounded-2xl p-5 border border-slate-200/80 dark:border-slate-800/80 ${style.borderHover} hover:shadow-xl transition-colors duration-300 cursor-pointer flex flex-col justify-between overflow-hidden`}
    >
      {/* Top Accent Strip */}
      <div className={`absolute top-0 left-0 right-0 h-1 bg-gradient-to-r ${style.accentBar} opacity-0 group-hover:opacity-100 transition-opacity duration-300`} />

      {/* Ambient background glow circle */}
      <div className={`absolute -top-12 -right-12 w-28 h-28 rounded-full ${style.glowColor} blur-2xl pointer-events-none group-hover:scale-150 transition-transform duration-500`} />

      {/* Top Row: Icon, Favorite Button, and Status Badge */}
      <div className="flex items-start justify-between gap-3 mb-3.5 relative z-10">
        <div className={`p-3 rounded-2xl ${style.iconBg} shadow-md transition-all duration-300 group-hover:scale-110 group-hover:rotate-3`}>
          <IconComponent className="w-5 h-5" />
        </div>

        <div className="flex items-center gap-1.5">
          {tool.badge && (
            <span
              className={`px-2 py-0.5 text-[10px] font-black rounded-lg border tracking-wide ${getBadgeStyle(
                tool.badge
              )}`}
            >
              {tool.badge}
            </span>
          )}
          <button
            onClick={(e) => onToggleFavorite(tool.id, e)}
            id={`fav-btn-${tool.id}`}
            className="p-1.5 text-slate-400 hover:text-amber-500 rounded-xl hover:bg-white/80 dark:hover:bg-slate-800/80 transition-all duration-200 border border-transparent hover:border-slate-200 dark:hover:border-slate-700 shadow-xs"
            title={isFavorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
            aria-label={isFavorite ? 'إزالة من المفضلة' : 'إضافة إلى المفضلة'}
          >
            <Star
              className={`w-4 h-4 transition-transform active:scale-125 ${
                isFavorite ? 'text-amber-500 fill-amber-500' : ''
              }`}
            />
          </button>
        </div>
      </div>

      {/* Content: Title and Description */}
      <div className="space-y-2 flex-1 relative z-10">
        <h3 className={`font-heading font-black text-sm sm:text-base text-slate-900 dark:text-slate-100 ${style.hoverText} transition-colors leading-snug line-clamp-1`}>
          {tool.titleAr}
        </h3>
        <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed font-normal">
          {tool.descriptionAr}
        </p>
      </div>

      {/* Footer: Tags & Action Button */}
      <div className="pt-3 mt-3.5 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between relative z-10 gap-2">
        <div className="flex items-center gap-1 overflow-hidden">
          {tool.tags && tool.tags.length > 0 && (
            <span className={`text-[10px] font-bold px-2 py-0.5 rounded-md ${style.tagBg} truncate max-w-[110px]`}>
              #{tool.tags[0]}
            </span>
          )}
        </div>

        <button
          type="button"
          onClick={(e) => {
            e.stopPropagation();
            onSelect(tool);
          }}
          className={`px-3 py-1.5 rounded-xl text-xs font-black flex items-center gap-1.5 transition-all duration-300 shadow-xs bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 group-hover:bg-gradient-to-r ${style.accentBar} group-hover:text-white group-hover:shadow-md`}
        >
          <span>دخول للأداة</span>
          <ArrowLeft className="w-3.5 h-3.5 transform group-hover:-translate-x-1 transition-transform" />
        </button>
      </div>
    </motion.div>
  );
}

