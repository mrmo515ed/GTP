import React from 'react';
import { motion } from 'motion/react';
import { CATEGORIES } from '../../data/toolsData';
import { ToolCategory } from '../../types';
import {
  LayoutGrid,
  Home,
  Type,
  Image as ImageIcon,
  Calculator,
  ArrowRightLeft,
  Code2,
  Star,
  Stethoscope,
  HeartPulse,
  GraduationCap,
  Sparkles,
  Compass,
  FileText,
  Flame,
  Palette,
  Table,
  Clock,
  Share2,
  Coins,
  Music,
  Video,
  Archive,
  Shield,
  Braces,
  FileCode2,
  Layers,
} from 'lucide-react';

interface CategoryNavProps {
  activeCategory: ToolCategory;
  onSelectCategory: (cat: ToolCategory) => void;
  favoritesCount: number;
}

export function CategoryNav({
  activeCategory,
  onSelectCategory,
  favoritesCount,
}: CategoryNavProps) {
  const getIcon = (id: ToolCategory) => {
    switch (id) {
      case 'home':
        return Home;
      case 'all':
        return LayoutGrid;
      case 'popular':
        return Flame;
      case 'surgery-3d':
        return HeartPulse;
      case 'health':
        return Stethoscope;
      case 'calculators':
        return Calculator;
      case 'text':
        return Type;
      case 'image':
        return ImageIcon;
      case 'design':
        return Palette;
      case 'pdf':
      case 'documents':
        return FileText;
      case 'data':
        return Table;
      case 'time-date':
        return Clock;
      case 'student':
        return GraduationCap;
      case 'social':
        return Share2;
      case 'units':
      case 'converters':
        return ArrowRightLeft;
      case 'currencies':
        return Coins;
      case 'audio':
        return Music;
      case 'video':
        return Video;
      case 'archives':
        return Archive;
      case 'dev':
        return Code2;
      case 'encoding':
        return Shield;
      case 'json':
        return Braces;
      case 'xml':
        return FileCode2;
      case 'svg':
        return ImageIcon;
      case 'engineering':
        return Compass;
      case 'discovery':
        return Sparkles;
      case 'favorites':
        return Star;
      case 'new':
        return Sparkles;
      default:
        return Layers;
    }
  };

  return (
    <div className="w-full overflow-x-auto py-2 scrollbar-none" id="category-nav-bar">
      <div className="flex items-center gap-2 min-w-max pb-1">
        {CATEGORIES.map((cat) => {
          const Icon = getIcon(cat.id);
          const isActive = activeCategory === cat.id;
          return (
            <motion.button
              key={cat.id}
              whileTap={{ scale: 0.95 }}
              onClick={() => onSelectCategory(cat.id)}
              id={`cat-btn-${cat.id}`}
              className={`relative px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition-colors flex items-center gap-2 shrink-0 overflow-hidden ${
                isActive
                  ? 'text-white shadow-md shadow-emerald-600/20'
                  : 'bg-white dark:bg-gray-800/90 text-gray-700 dark:text-gray-300 border border-gray-200/80 dark:border-gray-700/80 hover:bg-emerald-50/60 dark:hover:bg-gray-700 hover:border-emerald-300'
              }`}
            >
              {isActive && (
                <motion.div
                  layoutId="activeCategoryPill"
                  className="absolute inset-0 bg-emerald-600 rounded-xl"
                  transition={{ type: 'spring', stiffness: 450, damping: 35 }}
                />
              )}
              <span className="relative z-10 flex items-center gap-2">
                <Icon
                  className={`w-4 h-4 ${
                    isActive
                      ? 'text-white'
                      : cat.id === 'favorites'
                      ? 'text-amber-500'
                      : 'text-emerald-600 dark:text-emerald-400'
                  }`}
                />
                <span>{cat.nameAr}</span>
                {cat.id === 'favorites' && favoritesCount > 0 && (
                  <span
                    className={`px-1.5 py-0.2 rounded-full text-[10px] font-extrabold ${
                      isActive ? 'bg-white text-emerald-700' : 'bg-amber-100 text-amber-800 dark:bg-amber-950 dark:text-amber-300'
                    }`}
                  >
                    {favoritesCount}
                  </span>
                )}
              </span>
            </motion.button>
          );
        })}
      </div>
    </div>
  );
}
