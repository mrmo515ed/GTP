import React, { useEffect, useState } from 'react';
import { X } from 'lucide-react';

export function TopCornerAdClose() {
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    try {
      const val = sessionStorage.getItem('ad_watched_direct');
      if (val === '1') setVisible(true);
    } catch (e) {}
  }, []);

  if (!visible) return null;

  const handleClose = () => {
    try { sessionStorage.removeItem('ad_watched_direct'); } catch (e) {}
    setVisible(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <button
      onClick={handleClose}
      className="fixed top-4 left-4 z-[60] w-10 h-10 rounded-full bg-amber-500 hover:bg-amber-600 text-white shadow-xl shadow-amber-500/40 flex items-center justify-center transition transform hover:scale-105 active:scale-95"
      title="إغلاق / العودة"
      aria-label="إغلاق"
    >
      <X className="w-5 h-5" />
    </button>
  );
}
