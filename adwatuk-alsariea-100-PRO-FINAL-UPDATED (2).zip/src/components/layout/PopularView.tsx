import React from 'react';
import { ToolDefinition } from '../../types';
import { ToolCard } from './ToolCard';
import { Flame, Trophy, TrendingUp, Sparkles, ArrowRight } from 'lucide-react';

interface PopularViewProps {
  onSelectTool: (tool: ToolDefinition) => void;
  favorites: string[];
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  tools: ToolDefinition[];
  onBack: () => void;
}

export function PopularView({
  onSelectTool,
  favorites,
  onToggleFavorite,
  tools,
  onBack
}: PopularViewProps) {
  // Take top 12 popular tools
  const topTools = tools.slice(0, 12);

  return (
    <div className="w-full space-y-10 animate-fade-in pb-16">
      
      {/* Popular Header */}
      <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-orange-500 via-rose-500 to-purple-600 p-8 sm:p-12 shadow-2xl flex flex-col items-center justify-center text-center">
        {/* Background Effects */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-30 mix-blend-overlay">
          <div className="absolute -top-24 -left-24 w-96 h-96 bg-white rounded-full blur-[100px]" />
          <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-yellow-300 rounded-full blur-[100px]" />
        </div>
        
        <button 
          onClick={onBack}
          className="absolute top-6 left-6 z-20 flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur-md px-4 py-2 rounded-xl text-white font-bold transition-all"
        >
          <ArrowRight className="w-4 h-4" />
          <span>الرجوع للرئيسية</span>
        </button>

        <div className="relative z-10 flex flex-col items-center">
          <div className="w-20 h-20 bg-white/20 backdrop-blur-xl border border-white/30 rounded-3xl flex items-center justify-center shadow-2xl mb-6">
            <Flame className="w-10 h-10 text-white drop-shadow-lg" />
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white mb-4 drop-shadow-md">
            الأدوات الأكثر استخداماً
          </h1>
          <p className="text-sm sm:text-lg text-white/90 max-w-2xl font-medium leading-relaxed drop-shadow">
            اكتشف الأدوات الأكثر شيوعاً وطلباً بين المستخدمين والمطورين والمصممين. هذه القائمة تعكس أحدث التريندات والمهام اليومية التي ينجزها مجتمعنا بكفاءة.
          </p>
        </div>
      </div>

      {/* Leaderboard Section */}
      <div className="space-y-6">
        <div className="flex items-center gap-3 border-b border-gray-200 dark:border-gray-800 pb-4 px-2">
          <Trophy className="w-6 h-6 text-amber-500" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">الترتيب الأسبوعي للأدوات</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {topTools.map((tool, index) => {
            let rankColor = 'bg-gray-100 dark:bg-gray-800 text-gray-500';
            if (index === 0) rankColor = 'bg-amber-100 text-amber-600 shadow-amber-500/20'; // Gold
            if (index === 1) rankColor = 'bg-slate-200 text-slate-600 shadow-slate-500/20'; // Silver
            if (index === 2) rankColor = 'bg-orange-100 text-orange-600 shadow-orange-500/20'; // Bronze

            return (
              <div key={tool.id} className="relative group">
                {/* Ranking Badge */}
                <div className={`absolute -top-3 -right-3 w-8 h-8 rounded-full flex items-center justify-center font-black text-sm shadow-lg z-10 border-2 border-white dark:border-gray-900 ${rankColor}`}>
                  {index + 1}
                </div>
                
                {/* Tool Card Wrapper */}
                <div className="h-full transition-transform transform hover:-translate-y-1">
                  <ToolCard
                    tool={tool}
                    isFavorite={favorites.includes(tool.id)}
                    onToggleFavorite={onToggleFavorite}
                    onSelect={onSelectTool}
                  />
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
