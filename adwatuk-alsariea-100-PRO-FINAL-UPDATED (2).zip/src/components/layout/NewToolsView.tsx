import React from 'react';
import { ToolDefinition } from '../../types';
import { ToolCard } from './ToolCard';
import { Sparkles, ArrowRight, Zap, Stars } from 'lucide-react';

interface NewToolsViewProps {
  onSelectTool: (tool: ToolDefinition) => void;
  favorites: string[];
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  tools: ToolDefinition[];
  onBack: () => void;
}

export function NewToolsView({
  onSelectTool,
  favorites,
  onToggleFavorite,
  tools,
  onBack
}: NewToolsViewProps) {
  // Only show new tools (badge === 'جديد')
  const newTools = tools.filter(t => t.badge === 'جديد' || t.isNew);

  return (
    <div className="w-full space-y-10 animate-fade-in pb-16">
      
      {/* New Tools Header */}
      <div className="relative overflow-hidden rounded-[2.5rem] bg-gradient-to-br from-teal-500 via-cyan-500 to-blue-600 p-8 sm:p-12 shadow-2xl flex flex-col items-center justify-center text-center">
        {/* Background Effects */}
        <div className="absolute top-0 left-0 w-full h-full overflow-hidden opacity-20 mix-blend-overlay pointer-events-none">
          <div className="absolute top-[-20%] left-[-10%] w-[50%] h-[150%] bg-white transform rotate-12 blur-3xl opacity-40 animate-pulse" />
          <div className="absolute -bottom-24 -right-24 w-96 h-96 bg-cyan-300 rounded-full blur-[100px]" />
        </div>
        
        <button 
          onClick={onBack}
          className="absolute top-6 left-6 z-20 flex items-center gap-2 bg-white/20 hover:bg-white/30 backdrop-blur-md px-4 py-2 rounded-xl text-white font-bold transition-all shadow-sm"
        >
          <ArrowRight className="w-4 h-4" />
          <span>الرجوع للرئيسية</span>
        </button>

        <div className="relative z-10 flex flex-col items-center mt-4 sm:mt-0">
          <div className="w-20 h-20 bg-white/20 backdrop-blur-xl border border-white/30 rounded-3xl flex items-center justify-center shadow-2xl mb-6 relative">
             <Stars className="absolute -top-3 -right-3 w-8 h-8 text-yellow-300 drop-shadow-md animate-bounce" />
            <Zap className="w-10 h-10 text-white drop-shadow-lg" />
          </div>
          <h1 className="text-3xl sm:text-5xl font-black text-white mb-4 drop-shadow-md">
            أحدث الأدوات المضافة
          </h1>
          <p className="text-sm sm:text-lg text-white/90 max-w-2xl font-medium leading-relaxed drop-shadow">
            اكتشف أحدث الأدوات والميزات التي قمنا بإضافتها للمنصة حديثاً. نحن نعمل باستمرار على تطوير أدوات جديدة لتسهيل مهامك اليومية وزيادة إنتاجيتك.
          </p>
        </div>
      </div>

      {/* Grid Section */}
      <div className="space-y-6">
        <div className="flex items-center gap-3 border-b border-gray-200 dark:border-gray-800 pb-4 px-2">
          <Sparkles className="w-6 h-6 text-blue-500" />
          <h2 className="text-2xl font-bold text-gray-900 dark:text-white">قائمة الإضافات الجديدة ({newTools.length})</h2>
        </div>

        {newTools.length > 0 ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
            {newTools.map((tool) => (
              <ToolCard
                key={tool.id}
                tool={tool}
                isFavorite={favorites.includes(tool.id)}
                onToggleFavorite={onToggleFavorite}
                onSelect={onSelectTool}
              />
            ))}
          </div>
        ) : (
           <div className="text-center py-16 text-gray-500 dark:text-gray-400 font-medium">
              لا توجد أدوات جديدة حالياً، تابعنا لمعرفة التحديثات القادمة!
           </div>
        )}
      </div>
    </div>
  );
}
