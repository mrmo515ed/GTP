import React from 'react';
import { Loader2 } from 'lucide-react';

interface LoadingFallbackProps {
  message?: string;
}

export function LoadingFallback({ message = 'جاري التحميل...' }: LoadingFallbackProps) {
  return (
    <div className="flex flex-col items-center justify-center min-h-[260px] py-12 px-4 space-y-4 w-full">
      <div className="relative">
        <div className="w-12 h-12 rounded-2xl bg-emerald-500/10 dark:bg-emerald-500/20 border border-emerald-500/30 flex items-center justify-center animate-pulse">
          <Loader2 className="w-6 h-6 text-emerald-600 dark:text-emerald-400 animate-spin" />
        </div>
      </div>
      <p className="text-xs sm:text-sm font-bold text-gray-500 dark:text-gray-400">
        {message}
      </p>
    </div>
  );
}
