import React from 'react';
import { motion } from 'motion/react';
import { CATEGORIES, ALL_TOOLS } from '../../data/toolsData';
import { ToolCategory } from '../../types';
import {
  Type,
  Image as ImageIcon,
  Calculator,
  ArrowRightLeft,
  Code2,
  Stethoscope,
  HeartPulse,
  GraduationCap,
  Sparkles,
  Compass,
  FileText,
  Palette,
  Share2,
  Table,
  Music,
  Video,
  Archive,
  Coins,
  Clock,
  ArrowLeft,
  Zap,
  Shield,
  Braces,
  FileCode2,
  PenTool,
  MoreHorizontal,
  Flame,
  LayoutGrid,
  Home,
} from 'lucide-react';

interface CategoryGridProps {
  onSelectCategory: (categoryId: ToolCategory) => void;
}

export function CategoryGrid({ onSelectCategory }: CategoryGridProps) {
  // Exclude 'all' and filter tabs from category directory cards
  const displayCategories = CATEGORIES.filter(
    (c) => c.id !== 'all' && c.id !== 'favorites' && c.id !== 'new' && c.id !== 'popular'
  );

  const getCategoryMeta = (id: ToolCategory) => {
    switch (id) {
      case 'text':
        return {
          icon: Type,
          gradient: 'from-blue-500/15 via-indigo-500/10 to-blue-600/5',
          border: 'border-blue-200/80 dark:border-blue-900/60 hover:border-blue-400 dark:hover:border-blue-500',
          iconBg: 'bg-gradient-to-tr from-blue-600 to-indigo-600 text-white shadow-blue-500/20',
          textColor: 'text-blue-700 dark:text-blue-400 group-hover:text-blue-600',
          badgeBg: 'bg-blue-50 dark:bg-blue-950/80 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800',
          tagBg: 'bg-blue-50/80 dark:bg-blue-950/40 text-blue-800 dark:text-blue-200 border-blue-100 dark:border-blue-900/40',
        };
      case 'image':
        return {
          icon: ImageIcon,
          gradient: 'from-pink-500/15 via-rose-500/10 to-pink-600/5',
          border: 'border-pink-200/80 dark:border-pink-900/60 hover:border-pink-400 dark:hover:border-pink-500',
          iconBg: 'bg-gradient-to-tr from-pink-600 to-rose-500 text-white shadow-pink-500/20',
          textColor: 'text-pink-700 dark:text-pink-400 group-hover:text-pink-600',
          badgeBg: 'bg-pink-50 dark:bg-pink-950/80 text-pink-700 dark:text-pink-300 border-pink-200 dark:border-pink-800',
          tagBg: 'bg-pink-50/80 dark:bg-pink-950/40 text-pink-800 dark:text-pink-200 border-pink-100 dark:border-pink-900/40',
        };
      case 'documents':
      case 'pdf':
        return {
          icon: FileText,
          gradient: 'from-rose-500/15 via-red-500/10 to-rose-600/5',
          border: 'border-rose-200/80 dark:border-rose-900/60 hover:border-rose-400 dark:hover:border-rose-500',
          iconBg: 'bg-gradient-to-tr from-rose-600 to-red-600 text-white shadow-rose-500/20',
          textColor: 'text-rose-700 dark:text-rose-400 group-hover:text-rose-600',
          badgeBg: 'bg-rose-50 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800',
          tagBg: 'bg-rose-50/80 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200 border-rose-100 dark:border-rose-900/40',
        };
      case 'data':
        return {
          icon: Table,
          gradient: 'from-teal-500/15 via-emerald-500/10 to-teal-600/5',
          border: 'border-teal-200/80 dark:border-teal-900/60 hover:border-teal-400 dark:hover:border-teal-500',
          iconBg: 'bg-gradient-to-tr from-teal-600 to-emerald-600 text-white shadow-teal-500/20',
          textColor: 'text-teal-700 dark:text-teal-400 group-hover:text-teal-600',
          badgeBg: 'bg-teal-50 dark:bg-teal-950/80 text-teal-700 dark:text-teal-300 border-teal-200 dark:border-teal-800',
          tagBg: 'bg-teal-50/80 dark:bg-teal-950/40 text-teal-800 dark:text-teal-200 border-teal-100 dark:border-teal-900/40',
        };
      case 'audio':
        return {
          icon: Music,
          gradient: 'from-amber-500/15 via-yellow-500/10 to-amber-600/5',
          border: 'border-amber-200/80 dark:border-amber-900/60 hover:border-amber-400 dark:hover:border-amber-500',
          iconBg: 'bg-gradient-to-tr from-amber-600 to-yellow-600 text-white shadow-amber-500/20',
          textColor: 'text-amber-700 dark:text-amber-400 group-hover:text-amber-600',
          badgeBg: 'bg-amber-50 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800',
          tagBg: 'bg-amber-50/80 dark:bg-amber-950/40 text-amber-800 dark:text-amber-200 border-amber-100 dark:border-amber-900/40',
        };
      case 'video':
        return {
          icon: Video,
          gradient: 'from-red-500/15 via-orange-500/10 to-red-600/5',
          border: 'border-red-200/80 dark:border-red-900/60 hover:border-red-400 dark:hover:border-red-500',
          iconBg: 'bg-gradient-to-tr from-red-600 to-orange-600 text-white shadow-red-500/20',
          textColor: 'text-red-700 dark:text-red-400 group-hover:text-red-600',
          badgeBg: 'bg-red-50 dark:bg-red-950/80 text-red-700 dark:text-red-300 border-red-200 dark:border-red-800',
          tagBg: 'bg-red-50/80 dark:bg-red-950/40 text-red-800 dark:text-red-200 border-red-100 dark:border-red-900/40',
        };
      case 'archives':
        return {
          icon: Archive,
          gradient: 'from-slate-500/15 via-zinc-500/10 to-slate-600/5',
          border: 'border-slate-200/80 dark:border-slate-800 hover:border-slate-400 dark:hover:border-slate-600',
          iconBg: 'bg-gradient-to-tr from-slate-700 to-zinc-700 text-white shadow-slate-500/20',
          textColor: 'text-slate-700 dark:text-slate-300 group-hover:text-slate-900',
          badgeBg: 'bg-slate-50 dark:bg-slate-950/80 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800',
          tagBg: 'bg-slate-100/80 dark:bg-slate-800/40 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700',
        };
      case 'units':
        return {
          icon: ArrowRightLeft,
          gradient: 'from-amber-500/15 via-orange-500/10 to-amber-600/5',
          border: 'border-amber-200/80 dark:border-amber-900/60 hover:border-amber-400 dark:hover:border-amber-500',
          iconBg: 'bg-gradient-to-tr from-amber-600 to-orange-600 text-white shadow-amber-500/20',
          textColor: 'text-amber-700 dark:text-amber-400 group-hover:text-amber-600',
          badgeBg: 'bg-amber-50 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800',
          tagBg: 'bg-amber-50/80 dark:bg-amber-950/40 text-amber-800 dark:text-amber-200 border-amber-100 dark:border-amber-900/40',
        };
      case 'currencies':
        return {
          icon: Coins,
          gradient: 'from-emerald-500/15 via-green-500/10 to-teal-600/5',
          border: 'border-emerald-200/80 dark:border-emerald-900/60 hover:border-emerald-400 dark:hover:border-emerald-500',
          iconBg: 'bg-gradient-to-tr from-emerald-600 to-green-600 text-white shadow-emerald-500/20',
          textColor: 'text-emerald-700 dark:text-emerald-400 group-hover:text-emerald-600',
          badgeBg: 'bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
          tagBg: 'bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 border-emerald-100 dark:border-emerald-900/40',
        };
      case 'time-date':
        return {
          icon: Clock,
          gradient: 'from-sky-500/15 via-blue-500/10 to-sky-600/5',
          border: 'border-sky-200/80 dark:border-sky-900/60 hover:border-sky-400 dark:hover:border-sky-500',
          iconBg: 'bg-gradient-to-tr from-sky-600 to-blue-600 text-white shadow-sky-500/20',
          textColor: 'text-sky-700 dark:text-sky-400 group-hover:text-sky-600',
          badgeBg: 'bg-sky-50 dark:bg-sky-950/80 text-sky-700 dark:text-sky-300 border-sky-200 dark:border-sky-800',
          tagBg: 'bg-sky-50/80 dark:bg-sky-950/40 text-sky-800 dark:text-sky-200 border-sky-100 dark:border-sky-900/40',
        };
      case 'dev':
        return {
          icon: Code2,
          gradient: 'from-purple-500/15 via-violet-500/10 to-indigo-600/5',
          border: 'border-purple-200/80 dark:border-purple-900/60 hover:border-purple-400 dark:hover:border-purple-500',
          iconBg: 'bg-gradient-to-tr from-purple-600 to-violet-600 text-white shadow-purple-500/20',
          textColor: 'text-purple-700 dark:text-purple-400 group-hover:text-purple-600',
          badgeBg: 'bg-purple-50 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800',
          tagBg: 'bg-purple-50/80 dark:bg-purple-950/40 text-purple-800 dark:text-purple-200 border-purple-100 dark:border-purple-900/40',
        };
      case 'calculators':
        return {
          icon: Calculator,
          gradient: 'from-emerald-500/15 via-teal-500/10 to-emerald-600/5',
          border: 'border-emerald-200/80 dark:border-emerald-900/60 hover:border-emerald-400 dark:hover:border-emerald-500',
          iconBg: 'bg-gradient-to-tr from-emerald-600 to-teal-600 text-white shadow-emerald-500/20',
          textColor: 'text-emerald-700 dark:text-emerald-400 group-hover:text-emerald-600',
          badgeBg: 'bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
          tagBg: 'bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 border-emerald-100 dark:border-emerald-900/40',
        };
      case 'surgery-3d':
        return {
          icon: HeartPulse,
          gradient: 'from-rose-600/20 via-red-600/15 to-indigo-600/10',
          border: 'border-rose-300/80 dark:border-rose-800/80 hover:border-rose-500 dark:hover:border-rose-400',
          iconBg: 'bg-gradient-to-tr from-rose-600 via-red-600 to-indigo-700 text-white shadow-rose-500/30 ring-2 ring-rose-400/20',
          textColor: 'text-rose-700 dark:text-rose-400 group-hover:text-rose-600',
          badgeBg: 'bg-rose-100 dark:bg-rose-950 text-rose-800 dark:text-rose-300 border-rose-300 dark:border-rose-800',
          tagBg: 'bg-rose-50/90 dark:bg-rose-950/60 text-rose-900 dark:text-rose-200 border-rose-200 dark:border-rose-900/60',
        };
      case 'health':
        return {
          icon: Stethoscope,
          gradient: 'from-rose-500/15 via-red-500/10 to-pink-600/5',
          border: 'border-rose-200/80 dark:border-rose-900/60 hover:border-rose-400 dark:hover:border-rose-500',
          iconBg: 'bg-gradient-to-tr from-rose-600 to-pink-600 text-white shadow-rose-500/20',
          textColor: 'text-rose-700 dark:text-rose-400 group-hover:text-rose-600',
          badgeBg: 'bg-rose-50 dark:bg-rose-950/80 text-rose-700 dark:text-rose-300 border-rose-200 dark:border-rose-800',
          tagBg: 'bg-rose-50/80 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200 border-rose-100 dark:border-rose-900/40',
        };
      case 'student':
        return {
          icon: GraduationCap,
          gradient: 'from-cyan-500/15 via-sky-500/10 to-teal-600/5',
          border: 'border-cyan-200/80 dark:border-cyan-900/60 hover:border-cyan-400 dark:hover:border-cyan-500',
          iconBg: 'bg-gradient-to-tr from-cyan-600 to-teal-600 text-white shadow-cyan-500/20',
          textColor: 'text-cyan-700 dark:text-cyan-400 group-hover:text-cyan-600',
          badgeBg: 'bg-cyan-50 dark:bg-cyan-950/80 text-cyan-700 dark:text-cyan-300 border-cyan-200 dark:border-cyan-800',
          tagBg: 'bg-cyan-50/80 dark:bg-cyan-950/40 text-cyan-800 dark:text-cyan-200 border-cyan-100 dark:border-cyan-900/40',
        };
      case 'discovery':
        return {
          icon: Sparkles,
          gradient: 'from-fuchsia-500/15 via-purple-500/10 to-pink-600/5',
          border: 'border-fuchsia-200/80 dark:border-fuchsia-900/60 hover:border-fuchsia-400 dark:hover:border-fuchsia-500',
          iconBg: 'bg-gradient-to-tr from-fuchsia-600 to-purple-600 text-white shadow-fuchsia-500/20',
          textColor: 'text-fuchsia-700 dark:text-fuchsia-400 group-hover:text-fuchsia-600',
          badgeBg: 'bg-fuchsia-50 dark:bg-fuchsia-950/80 text-fuchsia-700 dark:text-fuchsia-300 border-fuchsia-200 dark:border-fuchsia-800',
          tagBg: 'bg-fuchsia-50/80 dark:bg-fuchsia-950/40 text-fuchsia-800 dark:text-fuchsia-200 border-fuchsia-100 dark:border-fuchsia-900/40',
        };
      case 'engineering':
        return {
          icon: Compass,
          gradient: 'from-yellow-500/15 via-amber-500/10 to-orange-600/5',
          border: 'border-yellow-200/80 dark:border-yellow-900/60 hover:border-yellow-400 dark:hover:border-yellow-500',
          iconBg: 'bg-gradient-to-tr from-yellow-600 to-amber-600 text-white shadow-yellow-500/20',
          textColor: 'text-yellow-700 dark:text-yellow-400 group-hover:text-yellow-600',
          badgeBg: 'bg-yellow-50 dark:bg-yellow-950/80 text-yellow-700 dark:text-yellow-300 border-yellow-200 dark:border-yellow-800',
          tagBg: 'bg-yellow-50/80 dark:bg-yellow-950/40 text-yellow-800 dark:text-yellow-200 border-yellow-100 dark:border-yellow-900/40',
        };
      case 'design':
        return {
          icon: Palette,
          gradient: 'from-violet-500/15 via-fuchsia-500/10 to-pink-600/5',
          border: 'border-violet-200/80 dark:border-violet-900/60 hover:border-violet-400 dark:hover:border-violet-500',
          iconBg: 'bg-gradient-to-tr from-violet-600 to-fuchsia-600 text-white shadow-violet-500/20',
          textColor: 'text-violet-700 dark:text-violet-400 group-hover:text-violet-600',
          badgeBg: 'bg-violet-50 dark:bg-violet-950/80 text-violet-700 dark:text-violet-300 border-violet-200 dark:border-violet-800',
          tagBg: 'bg-violet-50/80 dark:bg-violet-950/40 text-violet-800 dark:text-violet-200 border-violet-100 dark:border-violet-900/40',
        };
      case 'social':
        return {
          icon: Share2,
          gradient: 'from-pink-500/15 via-indigo-500/10 to-purple-600/5',
          border: 'border-pink-200/80 dark:border-pink-900/60 hover:border-pink-400 dark:hover:border-pink-500',
          iconBg: 'bg-gradient-to-tr from-pink-600 to-indigo-600 text-white shadow-pink-500/20',
          textColor: 'text-pink-700 dark:text-pink-400 group-hover:text-pink-600',
          badgeBg: 'bg-pink-50 dark:bg-pink-950/80 text-pink-700 dark:text-pink-300 border-pink-200 dark:border-pink-800',
          tagBg: 'bg-pink-50/80 dark:bg-pink-950/40 text-pink-800 dark:text-pink-200 border-pink-100 dark:border-pink-900/40',
        };
      case 'encoding':
        return {
          icon: Shield,
          gradient: 'from-amber-500/15 via-orange-500/10 to-amber-600/5',
          border: 'border-amber-200/80 dark:border-amber-900/60 hover:border-amber-400 dark:hover:border-amber-500',
          iconBg: 'bg-gradient-to-tr from-amber-600 to-orange-600 text-white shadow-amber-500/20',
          textColor: 'text-amber-700 dark:text-amber-400 group-hover:text-amber-600',
          badgeBg: 'bg-amber-50 dark:bg-amber-950/80 text-amber-700 dark:text-amber-300 border-amber-200 dark:border-amber-800',
          tagBg: 'bg-amber-50/80 dark:bg-amber-950/40 text-amber-800 dark:text-amber-200 border-amber-100 dark:border-amber-900/40',
        };
      case 'json':
        return {
          icon: Braces,
          gradient: 'from-indigo-500/15 via-blue-500/10 to-indigo-600/5',
          border: 'border-indigo-200/80 dark:border-indigo-900/60 hover:border-indigo-400 dark:hover:border-indigo-500',
          iconBg: 'bg-gradient-to-tr from-indigo-600 to-blue-600 text-white shadow-indigo-500/20',
          textColor: 'text-indigo-700 dark:text-indigo-400 group-hover:text-indigo-600',
          badgeBg: 'bg-indigo-50 dark:bg-indigo-950/80 text-indigo-700 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
          tagBg: 'bg-indigo-50/80 dark:bg-indigo-950/40 text-indigo-800 dark:text-indigo-200 border-indigo-100 dark:border-indigo-900/40',
        };
      case 'xml':
        return {
          icon: FileCode2,
          gradient: 'from-emerald-500/15 via-teal-500/10 to-emerald-600/5',
          border: 'border-emerald-200/80 dark:border-emerald-900/60 hover:border-emerald-400 dark:hover:border-emerald-500',
          iconBg: 'bg-gradient-to-tr from-emerald-600 to-teal-600 text-white shadow-emerald-500/20',
          textColor: 'text-emerald-700 dark:text-emerald-400 group-hover:text-emerald-600',
          badgeBg: 'bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
          tagBg: 'bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200 border-emerald-100 dark:border-emerald-900/40',
        };
      case 'svg':
        return {
          icon: PenTool,
          gradient: 'from-purple-500/15 via-pink-500/10 to-purple-600/5',
          border: 'border-purple-200/80 dark:border-purple-900/60 hover:border-purple-400 dark:hover:border-purple-500',
          iconBg: 'bg-gradient-to-tr from-purple-600 to-pink-600 text-white shadow-purple-500/20',
          textColor: 'text-purple-700 dark:text-purple-400 group-hover:text-purple-600',
          badgeBg: 'bg-purple-50 dark:bg-purple-950/80 text-purple-700 dark:text-purple-300 border-purple-200 dark:border-purple-800',
          tagBg: 'bg-purple-50/80 dark:bg-purple-950/40 text-purple-800 dark:text-purple-200 border-purple-100 dark:border-purple-900/40',
        };
      case 'misc':
        return {
          icon: MoreHorizontal,
          gradient: 'from-slate-500/15 via-zinc-500/10 to-slate-600/5',
          border: 'border-slate-200/80 dark:border-slate-800 hover:border-slate-400 dark:hover:border-slate-600',
          iconBg: 'bg-gradient-to-tr from-slate-700 to-zinc-700 text-white shadow-slate-500/20',
          textColor: 'text-slate-700 dark:text-slate-300 group-hover:text-slate-900',
          badgeBg: 'bg-slate-50 dark:bg-slate-950/80 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800',
          tagBg: 'bg-slate-100/80 dark:bg-slate-800/40 text-slate-800 dark:text-slate-200 border-slate-200 dark:border-slate-700',
        };
      default:
        return {
          icon: Compass,
          gradient: 'from-emerald-500/15 via-teal-500/10 to-emerald-600/5',
          border: 'border-emerald-200/80 dark:border-emerald-900/60 hover:border-emerald-400',
          iconBg: 'bg-gradient-to-tr from-emerald-600 to-teal-600 text-white shadow-emerald-500/20',
          textColor: 'text-emerald-700 dark:text-emerald-400 group-hover:text-emerald-600',
          badgeBg: 'bg-emerald-50 dark:bg-emerald-950/80 text-emerald-700 dark:text-emerald-300 border-emerald-200',
          tagBg: 'bg-emerald-50/80 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200',
        };
    }
  };

  return (
    <div className="space-y-5 pt-2" id="category-grid-directory">
      <div className="flex items-center justify-between border-b border-gray-200/70 dark:border-gray-800 pb-3">
        <div>
          <h2 className="text-xl sm:text-2xl font-heading font-black text-gray-900 dark:text-white flex items-center gap-2.5">
            <span className="w-3 h-3 rounded-full bg-emerald-500 ring-4 ring-emerald-500/20" />
            <span>أقسام وتصنيفات الأدوات الرئيسية</span>
          </h2>
          <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">
            اختر القسم المخصص لاستعراض كافة الأدوات والمحولات المتاحة بداخله
          </p>
        </div>

        <span className="hidden sm:inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-xs font-extrabold bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800">
          <Zap className="w-3.5 h-3.5 fill-current" />
          <span>{displayCategories.length} قسم متخصص</span>
        </span>
      </div>

      {/* Modern Colorful Grid Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 sm:gap-5">
        {displayCategories.map((category, index) => {
          const meta = getCategoryMeta(category.id);
          const Icon = meta.icon;
          const toolCount = ALL_TOOLS.filter((t) => t.category === category.id).length;
          const sampleTools = ALL_TOOLS.filter((t) => t.category === category.id).slice(0, 3);

          return (
            <motion.div
              key={category.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: Math.min(index * 0.03, 0.3), ease: 'easeOut' }}
              whileHover={{ y: -5, scale: 1.015 }}
              whileTap={{ scale: 0.98 }}
              onClick={() => onSelectCategory(category.id)}
              id={`cat-card-${category.id}`}
              className={`group relative p-5 rounded-3xl bg-white dark:bg-gray-900 border transition-colors duration-300 hover:shadow-xl cursor-pointer flex flex-col justify-between overflow-hidden bg-gradient-to-br ${meta.gradient} ${meta.border}`}
            >
              {/* Top Row: Icon + Count */}
              <div>
                <div className="flex items-center justify-between mb-3.5">
                  <div
                    className={`w-13 h-13 rounded-2xl ${meta.iconBg} shadow-md flex items-center justify-center group-hover:scale-110 transition-transform duration-300`}
                  >
                    <Icon className="w-6 h-6" />
                  </div>
                  <span
                    className={`px-3 py-1 rounded-full text-xs font-black border backdrop-blur-xs shadow-2xs ${meta.badgeBg}`}
                  >
                    {toolCount} أداة
                  </span>
                </div>

                {/* Title & Description */}
                <h3
                  className={`text-base sm:text-lg font-heading font-black text-gray-900 dark:text-white transition-colors duration-200 ${meta.textColor}`}
                >
                  {category.nameAr}
                </h3>
                <p className="text-xs text-gray-600 dark:text-gray-400 line-clamp-2 mt-1.5 leading-relaxed font-medium">
                  {category.descriptionAr}
                </p>

                {/* Sample Tool Badges */}
                {sampleTools.length > 0 && (
                  <div className="flex flex-wrap gap-1.5 mt-3.5">
                    {sampleTools.map((t) => (
                      <span
                        key={t.id}
                        className={`text-[10px] font-bold px-2 py-0.5 rounded-lg border truncate max-w-[130px] ${meta.tagBg}`}
                      >
                        {t.titleAr}
                      </span>
                    ))}
                  </div>
                )}
              </div>

              {/* Bottom Card Action Footer */}
              <div className="pt-4 mt-3 border-t border-gray-200/50 dark:border-gray-800/80 flex items-center justify-between text-xs font-black">
                <span className={meta.textColor}>تصفح أدوات القسم</span>
                <div className="w-7 h-7 rounded-full bg-white/80 dark:bg-gray-800/80 border border-gray-200 dark:border-gray-700 flex items-center justify-center shadow-2xs group-hover:bg-emerald-600 group-hover:text-white group-hover:border-emerald-600 transition-all">
                  <ArrowLeft className="w-3.5 h-3.5 transform group-hover:-translate-x-0.5 transition-transform" />
                </div>
              </div>
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
