import React from 'react';
import { Loader2, CheckCircle2, Sparkles } from 'lucide-react';

interface ProcessingProgressBarProps {
  progress: number;
  statusText?: string;
  subText?: string;
  isCompleted?: boolean;
  color?: 'emerald' | 'blue' | 'indigo' | 'purple';
}

export function ProcessingProgressBar({
  progress,
  statusText = 'جاري المعالجة والتحويل...',
  subText,
  isCompleted = false,
  color = 'emerald'
}: ProcessingProgressBarProps) {
  const clampedProgress = Math.min(100, Math.max(0, Math.round(progress)));

  const colorMap = {
    emerald: {
      bar: 'bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600',
      badge: 'bg-emerald-100 dark:bg-emerald-900/50 text-emerald-800 dark:text-emerald-300 border-emerald-200 dark:border-emerald-800',
      icon: 'text-emerald-600 dark:text-emerald-400',
      border: 'border-emerald-200/80 dark:border-emerald-800/60',
      bg: 'bg-emerald-50/40 dark:bg-emerald-950/20'
    },
    blue: {
      bar: 'bg-gradient-to-r from-blue-500 via-cyan-500 to-blue-600',
      badge: 'bg-blue-100 dark:bg-blue-900/50 text-blue-800 dark:text-blue-300 border-blue-200 dark:border-blue-800',
      icon: 'text-blue-600 dark:text-blue-400',
      border: 'border-blue-200/80 dark:border-blue-800/60',
      bg: 'bg-blue-50/40 dark:bg-blue-950/20'
    },
    indigo: {
      bar: 'bg-gradient-to-r from-indigo-500 via-violet-500 to-indigo-600',
      badge: 'bg-indigo-100 dark:bg-indigo-900/50 text-indigo-800 dark:text-indigo-300 border-indigo-200 dark:border-indigo-800',
      icon: 'text-indigo-600 dark:text-indigo-400',
      border: 'border-indigo-200/80 dark:border-indigo-800/60',
      bg: 'bg-indigo-50/40 dark:bg-indigo-950/20'
    },
    purple: {
      bar: 'bg-gradient-to-r from-purple-500 via-pink-500 to-purple-600',
      badge: 'bg-purple-100 dark:bg-purple-900/50 text-purple-800 dark:text-purple-300 border-purple-200 dark:border-purple-800',
      icon: 'text-purple-600 dark:text-purple-400',
      border: 'border-purple-200/80 dark:border-purple-800/60',
      bg: 'bg-purple-50/40 dark:bg-purple-950/20'
    }
  };

  const scheme = colorMap[color] || colorMap.emerald;

  return (
    <div className={`p-4 sm:p-5 rounded-2xl border ${scheme.border} ${scheme.bg} space-y-3.5 transition-all shadow-xs`}>
      {/* Header with status and percentage badge */}
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          {clampedProgress >= 100 || isCompleted ? (
            <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 animate-in zoom-in duration-200" />
          ) : (
            <Loader2 className={`w-5 h-5 ${scheme.icon} animate-spin shrink-0`} />
          )}
          <div className="truncate">
            <span className="text-xs sm:text-sm font-extrabold text-gray-900 dark:text-white block truncate">
              {clampedProgress >= 100 || isCompleted ? 'اكتملت العملية بنجاح 100%!' : statusText}
            </span>
            {subText && (
              <span className="text-[11px] text-gray-500 dark:text-gray-400 block truncate">
                {subText}
              </span>
            )}
          </div>
        </div>

        {/* Percentage Counter */}
        <div className={`px-2.5 py-1 rounded-xl text-xs font-black border font-mono shrink-0 ${scheme.badge}`}>
          {clampedProgress}%
        </div>
      </div>

      {/* Progress Track */}
      <div className="w-full bg-gray-200/80 dark:bg-gray-700/60 rounded-full h-3 sm:h-3.5 overflow-hidden p-0.5 relative">
        <div
          className={`h-full rounded-full transition-all duration-300 ease-out relative ${scheme.bar}`}
          style={{ width: `${clampedProgress}%` }}
        >
          {/* Animated light effect */}
          <div className="absolute inset-0 bg-white/20 animate-pulse rounded-full" />
        </div>
      </div>

      {/* Stage Indicators */}
      <div className="flex justify-between text-[10px] text-gray-400 font-bold px-1">
        <span>البدء</span>
        <span>معالجة البيانات</span>
        <span>بناء المستند</span>
        <span>جاهز للتحميل</span>
      </div>
    </div>
  );
}
