import React, { ReactNode, useEffect, useRef, useState } from 'react';

interface DeferredMountProps {
  children: ReactNode;
  minHeight?: number;
  rootMargin?: string;
  fallbackDelay?: number;
}

/** Mounts below-the-fold content near the viewport, with a delayed accessibility/SEO fallback. */
export function DeferredMount({
  children,
  minHeight = 320,
  rootMargin = '160px 0px',
  fallbackDelay = 10000,
}: DeferredMountProps) {
  const markerRef = useRef<HTMLDivElement>(null);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    if (mounted) return;
    const marker = markerRef.current;
    const timer = window.setTimeout(() => setMounted(true), fallbackDelay);
    if (!marker || !('IntersectionObserver' in window)) {
      setMounted(true);
      return () => window.clearTimeout(timer);
    }
    const observer = new IntersectionObserver(entries => {
      if (entries.some(entry => entry.isIntersecting)) {
        setMounted(true);
        observer.disconnect();
      }
    }, { rootMargin });
    observer.observe(marker);
    return () => {
      observer.disconnect();
      window.clearTimeout(timer);
    };
  }, [fallbackDelay, mounted, rootMargin]);

  return (
    <div ref={markerRef} style={!mounted ? { minHeight: `${minHeight}px` } : undefined}>
      {mounted ? children : <div aria-hidden="true" />}
    </div>
  );
}
