import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface Props {
  children?: ReactNode;
  fallback?: ReactNode;
}

interface State {
  hasError: boolean;
  error?: Error;
}

export class ErrorBoundary extends Component<Props, State> {
  public state: State = {
    hasError: false
  };

  public static getDerivedStateFromError(error: Error): State {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Uncaught error:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: undefined });
    window.location.reload();
  };

  public render() {
    if (this.state.hasError) {
      if (this.props.fallback) {
        return this.props.fallback;
      }
      return (
        <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-gray-800 p-8 rounded-3xl shadow-xl max-w-lg w-full text-center space-y-6">
            <div className="w-20 h-20 bg-red-100 dark:bg-red-900/30 rounded-full flex items-center justify-center mx-auto">
              <AlertTriangle className="w-10 h-10 text-red-600 dark:text-red-500" />
            </div>
            <div className="space-y-2">
              <h2 className="text-2xl font-bold text-gray-900 dark:text-white">عذراً، حدث خطأ غير متوقع</h2>
              <p className="text-gray-500 dark:text-gray-400">
                واجهنا مشكلة أثناء تحميل هذه الصفحة. الرجاء المحاولة مرة أخرى.
              </p>
            </div>
            {this.state.error && (
              <div className="p-4 bg-gray-100 dark:bg-gray-900 rounded-xl text-left rtl:text-right overflow-auto max-h-40">
                <code className="text-xs text-gray-800 dark:text-gray-200 break-words whitespace-pre-wrap">
                  {this.state.error.message}
                </code>
              </div>
            )}
            <button
              onClick={this.handleReset}
              className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold w-full transition flex items-center justify-center gap-2"
            >
              <RefreshCw className="w-5 h-5" />
              <span>إعادة التحميل</span>
            </button>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}
