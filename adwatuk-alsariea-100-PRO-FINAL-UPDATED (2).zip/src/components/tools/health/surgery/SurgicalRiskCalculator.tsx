import React, { useState } from 'react';
import { Activity, Stethoscope, AlertTriangle, Shield, CheckCircle2, ChevronRight } from 'lucide-react';

export function SurgicalRiskCalculator() {
  const [asaClass, setAsaClass] = useState<number>(1);
  const [isEmergency, setIsEmergency] = useState<boolean>(false);
  const [mallampatiClass, setMallampatiClass] = useState<number>(1);
  const [age, setAge] = useState<number>(45);
  const [hasCardiacHistory, setHasCardiacHistory] = useState<boolean>(false);
  const [hasDiabetes, setHasDiabetes] = useState<boolean>(false);
  const [hasAnticoagulants, setHasAnticoagulants] = useState<boolean>(false);
  const [surgeryRiskLevel, setSurgeryRiskLevel] = useState<'low' | 'intermediate' | 'high'>('intermediate');

  // ASA Descriptions
  const ASA_DESCRIPTIONS = [
    { class: 1, titleAr: 'ASA I: مريض سليم صحياً', descAr: 'لا يعاني من أي أمراض جهازية عضوية، غير مدخن ولا يشرب الكحول.', mortalityRate: '< 0.1%' },
    { class: 2, titleAr: 'ASA II: مرض جهازي خفيف', descAr: 'ضغط دم مضبوط، سكري مضبوط، مدخن حالي، أو سمنة خفيفة (BMI 30-40).', mortalityRate: '0.2% - 0.4%' },
    { class: 3, titleAr: 'ASA III: مرض جهازي شديد يحد من النشاط', descAr: 'ذبحة صدرية مستقرة، سكري غير مضبوط، قصور كلوي مزمن، COPD، أو فشل قلبي مستقر.', mortalityRate: '1.2% - 2.5%' },
    { class: 4, titleAr: 'ASA IV: مرض جهازي شديد يهدد الحياة باستمرار', descAr: 'جلطة قلبية حديثة (<3 أشهر)، ذبحة غير مستقرة، قصور كلوي حاد بحاجة لغسيل إسعافي.', mortalityRate: '5.0% - 10.0%' },
    { class: 5, titleAr: 'ASA V: مريض مشرف على الوفاة', descAr: 'لا يتوقع بقاؤه حياً لأكثر من 24 ساعة بدون إجراء الجراحة الإسعافية (مثل تمزق الأبهر).', mortalityRate: '10.0% - 30.0%' }
  ];

  // Mallampati Classification
  const MALLAMPATI_DATA = [
    { class: 1, nameAr: 'الفئة 1: رؤية كاملة للحنك الرخو واللهاة والأعمدة اللوزية', airway: 'مجرى هواء سهل (Easy Intubation)' },
    { class: 2, nameAr: 'الفئة 2: رؤية الحنك الرخو واللهاة فقط', airway: 'مجرى هواء قياسي ميسر' },
    { class: 3, nameAr: 'الفئة 3: رؤية الحنك الرخو وقاعدة اللهاة فقط', airway: 'مجرى هواء محتمل الصعوبة (Difficult Airway Risk)' },
    { class: 4, nameAr: 'الفئة 4: رؤية الحنك الصلب فقط (لا تظهر اللهاة)', airway: 'صعوبة عالية - يستوجب منظار ألياف بصرية (Fiberoptic)' }
  ];

  // Compute Overall Perioperative Risk Score
  let score = 0;
  score += asaClass * 2;
  if (isEmergency) score += 3;
  if (age > 65) score += 2;
  if (hasCardiacHistory) score += 3;
  if (hasDiabetes) score += 1;
  if (hasAnticoagulants) score += 2;
  if (surgeryRiskLevel === 'high') score += 3;
  if (surgeryRiskLevel === 'intermediate') score += 1;

  let riskCategory = 'منخفض (Low Risk)';
  let riskColor = 'text-emerald-400';
  let riskBg = 'bg-emerald-950/40 border-emerald-500/50';

  if (score >= 12) {
    riskCategory = 'مرتفع وحرج للغاية (High / Critical Risk)';
    riskColor = 'text-rose-400';
    riskBg = 'bg-rose-950/40 border-rose-500/50';
  } else if (score >= 7) {
    riskCategory = 'متوسط (Intermediate Risk)';
    riskColor = 'text-amber-400';
    riskBg = 'bg-amber-950/40 border-amber-500/50';
  }

  return (
    <div className="bg-slate-900 rounded-3xl p-6 border border-slate-800 text-slate-100 space-y-6 shadow-2xl">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
        <div className="p-3 bg-indigo-500/20 text-indigo-400 rounded-2xl border border-indigo-500/30">
          <Stethoscope className="w-6 h-6" />
        </div>
        <div>
          <h3 className="text-lg font-black text-white">حاسبة وتقييم المخاطر والتخدير قبل الجراحة (Pre-Op Risk Suite)</h3>
          <p className="text-xs text-slate-400">تصنيف ASA الجمعية الأمريكية للتخدير، وتصنيف مالامباتي لصعوبة التنبيب، وتقييم النزيف القلبي</p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Inputs (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          {/* ASA Classification */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 block">
              1. تصنيف الحالة البدنية (ASA Physical Status Classification):
            </label>
            <div className="space-y-1.5">
              {ASA_DESCRIPTIONS.map((item) => (
                <button
                  key={item.class}
                  onClick={() => setAsaClass(item.class)}
                  className={`w-full p-3 rounded-2xl text-right transition border text-xs flex flex-col gap-1 ${
                    asaClass === item.class
                      ? 'bg-indigo-950/80 border-indigo-500 text-indigo-100 shadow-md'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center justify-between">
                    <span className="font-black text-slate-100">{item.titleAr}</span>
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded-md bg-slate-800 text-slate-300">
                      وفيات: {item.mortalityRate}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-400 leading-snug">{item.descAr}</p>
                </button>
              ))}
            </div>
          </div>

          {/* Mallampati Airway Assessment */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 block">
              2. تقييم مجرى الهواء وصعوبة التنبيب (Mallampati Score):
            </label>
            <div className="grid grid-cols-2 gap-2">
              {MALLAMPATI_DATA.map((mal) => (
                <button
                  key={mal.class}
                  onClick={() => setMallampatiClass(mal.class)}
                  className={`p-3 rounded-2xl text-right transition border text-xs flex flex-col justify-between gap-1.5 ${
                    mallampatiClass === mal.class
                      ? 'bg-teal-950 border-teal-500 text-teal-200 shadow-sm'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/40'
                  }`}
                >
                  <span className="font-bold text-slate-100">{mal.nameAr}</span>
                  <span className="text-[10px] font-mono text-teal-400">{mal.airway}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Clinical Risk Factors */}
          <div className="space-y-2">
            <label className="text-xs font-bold text-slate-300 block">3. عوامل الخطورة السريرية والجراحية:</label>
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              <label className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl text-xs flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={isEmergency}
                  onChange={(e) => setIsEmergency(e.target.checked)}
                  className="rounded accent-rose-500"
                />
                <span className="font-bold text-rose-400">جراحة طارئة (Emergency E)</span>
              </label>

              <label className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl text-xs flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasCardiacHistory}
                  onChange={(e) => setHasCardiacHistory(e.target.checked)}
                  className="rounded accent-indigo-500"
                />
                <span>تاريخ قلبي / جلطة</span>
              </label>

              <label className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl text-xs flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasDiabetes}
                  onChange={(e) => setHasDiabetes(e.target.checked)}
                  className="rounded accent-indigo-500"
                />
                <span>داء السكري</span>
              </label>

              <label className="p-3 bg-slate-950/60 border border-slate-800 rounded-2xl text-xs flex items-center gap-2 cursor-pointer">
                <input
                  type="checkbox"
                  checked={hasAnticoagulants}
                  onChange={(e) => setHasAnticoagulants(e.target.checked)}
                  className="rounded accent-indigo-500"
                />
                <span>مميعات دم / أسبرين</span>
              </label>
            </div>
          </div>
        </div>

        {/* Right Output & Summary (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className={`p-5 rounded-3xl border ${riskBg} space-y-4 shadow-xl`}>
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-slate-300">مستوى الخطورة الجراحية الكلية:</span>
              <span className={`text-xs font-mono font-black px-3 py-1 rounded-full bg-slate-900 border border-slate-700 ${riskColor}`}>
                الدرجة {score}
              </span>
            </div>

            <div>
              <div className={`text-lg font-black ${riskColor}`}>{riskCategory}</div>
              <div className="text-xs text-slate-300 mt-1">
                تصنيف التخدير: ASA {asaClass} {isEmergency ? '(E - طارئ)' : ''} | مالامباتي: الفئة {mallampatiClass}
              </div>
            </div>

            <div className="space-y-2 pt-3 border-t border-slate-800/80 text-xs">
              <span className="font-bold text-slate-200 block">التوصيات السريرية لفريق التخدير والجراحة:</span>
              <ul className="space-y-1.5 text-[11px] text-slate-300 list-disc pr-4 leading-relaxed">
                {mallampatiClass >= 3 && (
                  <li className="text-amber-300 font-bold">تجهيز منظار الحنجرة بالفيديو (Video Laryngoscope) وصندوق مجرى الهواء الصعب.</li>
                )}
                {hasAnticoagulants && (
                  <li className="text-rose-300 font-bold">مراجعة زمن التخثر (INR / PTT) وتوفير بلازما مجمدة أو مضادات الترياق إن لزم.</li>
                )}
                {isEmergency && (
                  <li className="text-rose-400 font-bold">المريض يعتبر بمعدة ممتلئة (Full Stomach) - تطبيق الحث السريع للتخدير (RSI).</li>
                )}
                <li>مراقبة تخطيط القلب المستمر (ECG)، وضغط الدم اللاتداخلي، وتوفير خط وريدي واسع (16G-18G).</li>
                <li>تطبيق تدابير الوقاية من تجلط الأوردة العميقة (DVT Prophylaxis) وجوارب الضغط الهوائي المتتابع.</li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
