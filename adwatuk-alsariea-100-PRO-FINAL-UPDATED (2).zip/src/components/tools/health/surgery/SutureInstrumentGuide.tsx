import React, { useState } from 'react';
import { Scissors, Layers, Shield, Sparkles, BookOpen } from 'lucide-react';

interface SutureData {
  name: string;
  type: 'absorbable' | 'non-absorbable';
  structure: 'monofilament' | 'braided';
  tensileStrength: string;
  absorptionTime: string;
  bestUses: string;
  color: string;
}

const SUTURES: SutureData[] = [
  {
    name: 'فيكريل (Vicryl - Polyglactin 910)',
    type: 'absorbable',
    structure: 'braided',
    tensileStrength: '50% بعد 3 أسابيع',
    absorptionTime: '56 - 70 يوماً بالتحلل المائي',
    bestUses: 'الأنسجة الرخوة، الصفاق، خياطة العضلات، وإغلاق الأمعاء والمثانة',
    color: '#8b5cf6'
  },
  {
    name: 'برولين (Prolene - Polypropylene)',
    type: 'non-absorbable',
    structure: 'monofilament',
    tensileStrength: 'دائم مدى الحياة',
    absorptionTime: 'غير ممتص (Non-absorbable)',
    bestUses: 'جراحة الأوعية الدموية، مفاغرة الشرايين، جراحة القلب، وإغلاق الجلد التجميلي',
    color: '#3b82f6'
  },
  {
    name: 'مونوكريل (Monocryl - Poliglecaprone 25)',
    type: 'absorbable',
    structure: 'monofilament',
    tensileStrength: '50% بعد 7-14 يوماً',
    absorptionTime: '90 - 120 يوماً',
    bestUses: 'الخياطة التجميلية تحت الجلد (Subcuticular closure) بدون أثر للغرز',
    color: '#ec4899'
  },
  {
    name: 'بي دي إس (PDS II - Polydioxanone)',
    type: 'absorbable',
    structure: 'monofilament',
    tensileStrength: '50% بعد 4-6 أسابيع (طويل الأمد)',
    absorptionTime: '180 - 210 يوماً',
    bestUses: 'إغلاق لفافة البطن (Abdominal Fascia) وعظام القفص الصدري والغضاريف',
    color: '#10b981'
  },
  {
    name: 'حرير جراحي (Silk Suture)',
    type: 'non-absorbable',
    structure: 'braided',
    tensileStrength: 'يتراجع تدريجياً خلال عام',
    absorptionTime: 'غير ممتص (مغلف بشمع النحل)',
    bestUses: 'تثبيت أنابيب التصريف والقساطر، جراحة الفم والأسنان والأنسجة الوعائية الدقيقة',
    color: '#64748b'
  }
];

const SCALPEL_BLADES = [
  { number: '#10', shape: 'منحنية عريضة (Curved)', useAr: 'شقوق الجلد الكبيرة الطولية في البطن والصدر وعمليات الجراحة العامة' },
  { number: '#11', shape: 'مثلثة حادة مستقيمة (Pointed)', useAr: 'شقوق البزل الإسعافية، شق الخراجات (I&D)، وفغر القصبة الهوائية وقسطرة الأوعية' },
  { number: '#15', shape: 'منحنية صغيرة دقيقة (Small Curved)', useAr: 'الجراحات التجميلية الدقيقة، جراحة اليد، جراحة العيون وقاع الجمجمة' },
  { number: '#20', shape: 'منحنية كبيرة جداً (Large Curved)', useAr: 'الجراحات الكبرى وشقوق العظام وجراحة الحوادث والكسور' }
];

export function SutureInstrumentGuide() {
  const [filterType, setFilterType] = useState<'all' | 'absorbable' | 'non-absorbable'>('all');

  const filteredSutures = filterType === 'all'
    ? SUTURES
    : SUTURES.filter(s => s.type === filterType);

  return (
    <div className="bg-slate-900 rounded-3xl p-6 border border-slate-800 text-slate-100 space-y-6 shadow-2xl">
      {/* Header */}
      <div className="flex items-center gap-3 border-b border-slate-800 pb-4">
        <div className="p-3 bg-teal-500/20 text-teal-400 rounded-2xl border border-teal-500/30">
          <Scissors className="w-6 h-6" />
        </div>
        <div>
          <h3 className="text-lg font-black text-white">دليل الخيوط والمشارط والأدوات الجراحية المتقدم (Surgical Atlas)</h3>
          <p className="text-xs text-slate-400">مرجع سريري شامل لأنواع الخيوط الممتصة وغير الممتصة ومقاسات الشفرات ومؤشرات الاستخدام</p>
        </div>
      </div>

      {/* Suture Filters */}
      <div className="flex items-center justify-between gap-3">
        <span className="text-xs font-bold text-slate-300">تصنيف خيوط الجراحة:</span>
        <div className="flex items-center gap-2">
          {[
            { id: 'all', label: 'الكل' },
            { id: 'absorbable', label: 'ممتصة (Absorbable)' },
            { id: 'non-absorbable', label: 'غير ممتصة (Non-absorbable)' }
          ].map(f => (
            <button
              key={f.id}
              onClick={() => setFilterType(f.id as any)}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition border ${
                filterType === f.id
                  ? 'bg-teal-950 border-teal-500 text-teal-200'
                  : 'bg-slate-950 border-slate-800 text-slate-400 hover:bg-slate-800'
              }`}
            >
              {f.label}
            </button>
          ))}
        </div>
      </div>

      {/* Suture Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {filteredSutures.map((sut, idx) => (
          <div key={idx} className="p-4 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-2.5">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <span className="w-3 h-3 rounded-full" style={{ backgroundColor: sut.color }} />
                <span className="text-xs font-black text-white">{sut.name}</span>
              </div>
              <span className={`text-[10px] px-2 py-0.5 rounded-md font-bold ${
                sut.type === 'absorbable' ? 'bg-emerald-500/20 text-emerald-300' : 'bg-blue-500/20 text-blue-300'
              }`}>
                {sut.type === 'absorbable' ? 'ممتص' : 'دائم'}
              </span>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[11px] text-slate-400 bg-slate-900/60 p-2.5 rounded-xl border border-slate-800/60">
              <div>
                <span className="text-slate-500 block">البنية:</span>
                <span className="text-slate-200 font-bold">{sut.structure === 'monofilament' ? 'أحادي الخيط (Monofilament)' : 'مجدول (Braided)'}</span>
              </div>
              <div>
                <span className="text-slate-500 block">الامتصاص:</span>
                <span className="text-slate-200 font-bold">{sut.absorptionTime}</span>
              </div>
            </div>

            <div className="text-xs text-slate-300">
              <span className="text-teal-400 font-bold block mb-0.5">أفضل مؤشرات الاستخدام:</span>
              <p className="text-[11px] leading-relaxed text-slate-300">{sut.bestUses}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Scalpel Blade Chart */}
      <div className="pt-4 border-t border-slate-800 space-y-3">
        <span className="text-xs font-bold text-slate-300 block">مقاسات واستخدامات شفرات المشرط الجراحي (Surgical Blades):</span>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
          {SCALPEL_BLADES.map((blade) => (
            <div key={blade.number} className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800 space-y-1 text-right">
              <div className="flex items-center justify-between">
                <span className="text-sm font-black text-teal-400">{blade.number}</span>
                <span className="text-[10px] text-slate-400 font-mono">{blade.shape}</span>
              </div>
              <p className="text-[11px] text-slate-300 leading-snug">{blade.useAr}</p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
