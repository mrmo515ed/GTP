import React, { useState } from 'react';
import { CheckSquare, ShieldCheck, AlertTriangle, UserCheck, Clock, Award, RotateCcw } from 'lucide-react';

interface ChecklistItem {
  id: string;
  phase: 'signin' | 'timeout' | 'signout';
  textAr: string;
  textEn: string;
  critical: boolean;
}

const CHECKLIST_ITEMS: ChecklistItem[] = [
  // 1. Sign In (قبل التخدير - Before Induction of Anesthesia)
  { id: 'si_1', phase: 'signin', textAr: 'تأكيد هوية المريض، مكان العملية الجراحية، والإجراء والموافقة الموقعة', textEn: 'Patient identity, site, procedure, and consent confirmed', critical: true },
  { id: 'si_2', phase: 'signin', textAr: 'تحديد موقع الجراحة بوضع علامة واضحة بقلم جراحي (Site Marked)', textEn: 'Surgical site marked by surgeon', critical: true },
  { id: 'si_3', phase: 'signin', textAr: 'اكتمال فحص جاهزية جهاز التخدير وأدوية الطوارئ (Anesthesia Safety Check)', textEn: 'Anesthesia machine and medication check complete', critical: true },
  { id: 'si_4', phase: 'signin', textAr: 'جهاز قياس الأكسجين (Pulse Oximeter) موصول ويعمل بدقة', textEn: 'Pulse oximeter on patient and functioning', critical: false },
  { id: 'si_5', phase: 'signin', textAr: 'تقييم الحساسية الدوائية ومخاطر صعوبة مجرى الهواء (Allergy & Airway Risk)', textEn: 'Known allergy and difficult airway / aspiration risk evaluated', critical: true },
  { id: 'si_6', phase: 'signin', textAr: 'تقييم مخاطر فقدان الدم (> 500 مل للبالغين) وتوفير وحدات دم مناسبة', textEn: 'Risk of >500ml blood loss evaluated with adequate IV lines/fluids', critical: false },

  // 2. Time Out (قبل شق الجلد - Before Skin Incision)
  { id: 'to_1', phase: 'timeout', textAr: 'تأكيد تقديم جميع أعضاء الفريق لأسمائهم وأدوارهم (Team Introduction)', textEn: 'All team members introduce themselves by name and role', critical: false },
  { id: 'to_2', phase: 'timeout', textAr: 'تأكيد شفهي بالاسم على المريض، الإجراء الجراحي، والموقع التشريحي الدقيق', textEn: 'Surgeon, anesthesia, and nurse verbally confirm patient, site, and procedure', critical: true },
  { id: 'to_3', phase: 'timeout', textAr: 'إعطاء المضاد الحيوي الوقائي خلال آخر 60 دقيقة قبل الشق الجراحي (Prophylactic Antibiotic)', textEn: 'Antibiotic prophylaxis given within past 60 minutes', critical: true },
  { id: 'to_4', phase: 'timeout', textAr: 'مراجعة الجراح: الخطوات الحرجة، مدة العملية المتوقعة، والنزيف المحتمل', textEn: 'Surgeon reviews critical/unexpected steps, operative duration, and blood loss', critical: true },
  { id: 'to_5', phase: 'timeout', textAr: 'مراجعة طبيب التخدير: مخاوف المريض المحددة واستقرار العلامات الحيوية', textEn: 'Anesthesia team reviews patient-specific concerns', critical: false },
  { id: 'to_6', phase: 'timeout', textAr: 'مراجعة فريق التمريض: التأكد من التعقيم، توفر كافة الأدوات والغرسات المطلوبة', textEn: 'Nursing team confirms sterility and equipment readiness/implants', critical: true },
  { id: 'to_7', phase: 'timeout', textAr: 'عرض الأشعة والصور التشخيصية الأساسية (Essential Imaging Displayed)', textEn: 'Essential imaging displayed in the OR', critical: false },

  // 3. Sign Out (قبل مغادرة غرفة العمليات - Before Patient Leaves OR)
  { id: 'so_1', phase: 'signout', textAr: 'التأكيد الشفهي على اسم الإجراء الجراحي المنفذ بالكامل', textEn: 'Nurse verbally confirms name of the procedure recorded', critical: true },
  { id: 'so_2', phase: 'signout', textAr: 'تطابق العد الجراحي الكامل للأدوات، الشاش، والإبر (Instrument, Sponge & Needle Counts)', textEn: 'Instrument, sponge, and needle counts are correct', critical: true },
  { id: 'so_3', phase: 'signout', textAr: 'وضع الملصقات الصحيحة على العينات التشريحية (بما فيها اسم المريض)', textEn: 'Specimen labeling confirmed (including patient name)', critical: true },
  { id: 'so_4', phase: 'signout', textAr: 'تسجيل أي أعطال أو مشاكل في الأدوات أو الأجهزة الجراحية لمعالجتها', textEn: 'Any equipment problems to be addressed identified', critical: false },
  { id: 'so_5', phase: 'signout', textAr: 'مراجعة خطة الرعاية والإفاقة والتحكم في الألم بعد العملية (Post-op Plan & Recovery)', textEn: 'Surgeon, anesthesia, and nurse review key recovery concerns', critical: true }
];

export function SurgicalChecklist() {
  const [checkedIds, setCheckedIds] = useState<Record<string, boolean>>({});
  const [activePhase, setActivePhase] = useState<'all' | 'signin' | 'timeout' | 'signout'>('all');

  const toggleItem = (id: string) => {
    setCheckedIds((prev) => ({
      ...prev,
      [id]: !prev[id]
    }));
  };

  const handleReset = () => {
    if (window.confirm('هل تريد إعادة تعيين قائمة التحقق الجراحية؟')) {
      setCheckedIds({});
    }
  };

  const filteredItems = activePhase === 'all'
    ? CHECKLIST_ITEMS
    : CHECKLIST_ITEMS.filter((item) => item.phase === activePhase);

  const completedCount = Object.values(checkedIds).filter(Boolean).length;
  const totalCount = CHECKLIST_ITEMS.length;
  const progressPercent = Math.round((completedCount / totalCount) * 100);

  return (
    <div className="bg-slate-900 rounded-3xl p-6 border border-slate-800 text-slate-100 space-y-6 shadow-2xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-5">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-teal-500/20 text-teal-400 rounded-2xl border border-teal-500/30">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white">قائمة التحقق الجراحية الآمنة (WHO Surgical Safety Checklist)</h3>
            <p className="text-xs text-slate-400">البروتوكول العالمي القياسي المعتمد لغرف العمليات للحد من الأخطاء الجراحية</p>
          </div>
        </div>

        <div className="flex items-center gap-3">
          <div className="text-left sm:text-right">
            <div className="text-xs text-slate-400">معدل الامتثال</div>
            <div className="text-base font-black text-teal-400">{progressPercent}% ({completedCount}/{totalCount})</div>
          </div>
          <button
            onClick={handleReset}
            className="p-2.5 bg-slate-800 hover:bg-slate-700 text-slate-300 rounded-xl transition border border-slate-700"
            title="إعادة التعيين"
          >
            <RotateCcw className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-slate-950 rounded-full h-2.5 overflow-hidden border border-slate-800">
        <div
          className="bg-gradient-to-r from-teal-500 to-emerald-400 h-full transition-all duration-300"
          style={{ width: `${progressPercent}%` }}
        />
      </div>

      {/* Phase Filters */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
        {[
          { id: 'all', label: 'كافة المراحل (18 خطوة)', icon: CheckSquare },
          { id: 'signin', label: '1. قبل التخدير (Sign In)', icon: UserCheck },
          { id: 'timeout', label: '2. قبل الشق (Time Out)', icon: Clock },
          { id: 'signout', label: '3. قبل الإفاقة (Sign Out)', icon: Award }
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activePhase === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActivePhase(tab.id as any)}
              className={`p-3 rounded-2xl text-xs font-bold transition flex items-center justify-center gap-2 border ${
                isActive
                  ? 'bg-teal-950 border-teal-500 text-teal-200 shadow-md'
                  : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/40'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Checklist Items */}
      <div className="space-y-2.5">
        {filteredItems.map((item) => {
          const isChecked = !!checkedIds[item.id];
          return (
            <div
              key={item.id}
              onClick={() => toggleItem(item.id)}
              className={`p-4 rounded-2xl border transition cursor-pointer flex items-start gap-3.5 ${
                isChecked
                  ? 'bg-teal-950/40 border-teal-500/50 text-slate-200 shadow-sm'
                  : 'bg-slate-950/80 border-slate-800/80 text-slate-300 hover:bg-slate-800/40'
              }`}
            >
              <input
                type="checkbox"
                checked={isChecked}
                onChange={() => toggleItem(item.id)}
                className="w-5 h-5 rounded-md mt-0.5 accent-teal-500 cursor-pointer shrink-0"
              />
              <div className="flex-1 text-right">
                <div className="flex items-center gap-2 mb-0.5">
                  <span className={`text-xs font-bold leading-relaxed ${isChecked ? 'line-through text-slate-400' : 'text-slate-100'}`}>
                    {item.textAr}
                  </span>
                  {item.critical && (
                    <span className="px-2 py-0.5 rounded-full bg-rose-500/20 text-rose-300 border border-rose-500/30 text-[10px] font-bold shrink-0">
                      إلزامي (Critical)
                    </span>
                  )}
                </div>
                <div className="text-[11px] text-slate-500 font-mono">{item.textEn}</div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
