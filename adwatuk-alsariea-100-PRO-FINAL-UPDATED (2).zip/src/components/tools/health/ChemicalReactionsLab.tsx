import React, { useState } from 'react';
import {
  FlaskConical,
  Atom,
  Flame,
  Droplets,
  Zap,
  Activity,
  Search,
  Sparkles,
  Info,
  Layers,
  AlertTriangle,
  Play,
  RotateCcw,
  CheckCircle2,
  Copy,
  Check,
  Brain,
  HeartPulse,
  Heart,
  Dna,
  Shield,
  Pill,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface ChemicalElement {
  number: number;
  symbol: string;
  nameAr: string;
  nameEn: string;
  mass: number;
  category: 'nonmetal' | 'noble' | 'alkali' | 'alkaline' | 'metalloid' | 'halogen' | 'transition' | 'post-transition';
  electrons: string;
  valence: number;
  descriptionAr: string;
  medicalUseAr: string;
  color: string;
}

const PERIODIC_TABLE_SAMPLE: ChemicalElement[] = [
  { number: 1, symbol: 'H', nameAr: 'هيدروجين', nameEn: 'Hydrogen', mass: 1.008, category: 'nonmetal', electrons: '1s¹', valence: 1, descriptionAr: 'أخف العناصر وأكثرها وفرة في الكون، أساس الماء والجزيئات الحيوية.', medicalUseAr: 'غاز الهيدروجين كمضاد أكسدة استنشاقي واعد، وأساس تكوين سوائل الجسم.', color: 'bg-sky-500' },
  { number: 2, symbol: 'He', nameAr: 'هيليوم', nameEn: 'Helium', mass: 4.0026, category: 'noble', electrons: '1s²', valence: 0, descriptionAr: 'غاز نبيل خامل جداً وغير قابل للاشتعال.', medicalUseAr: 'يستخدم مزيج الهيليوم والأكسجين (Heliox) لتقليل جهد التنفس في نوبات الربو الحادة وتبريد أجهزة الرنين المغناطيسي MRI.', color: 'bg-indigo-500' },
  { number: 3, symbol: 'Li', nameAr: 'ليثيوم', nameEn: 'Lithium', mass: 6.94, category: 'alkali', electrons: '[He] 2s¹', valence: 1, descriptionAr: 'فلز قلوي خفيف وفضي شديد التفاعل.', medicalUseAr: 'كربونات الليثيوم (Lithium Carbonate) العلاج المعياري لاضطراب ثنائي القطب وتقلبات المزاج.', color: 'bg-red-500' },
  { number: 6, symbol: 'C', nameAr: 'كربون', nameEn: 'Carbon', mass: 12.011, category: 'nonmetal', electrons: '[He] 2s² 2p²', valence: 4, descriptionAr: 'العمود الفقري للكيمياء العضوية وكل أشكال الحياة على الأرض.', medicalUseAr: 'الفحم النشط (Activated Charcoal) لامتصاص السموم والجرعات الزائدة في الطوارئ.', color: 'bg-emerald-500' },
  { number: 7, symbol: 'N', nameAr: 'نيتروجين', nameEn: 'Nitrogen', mass: 14.007, category: 'nonmetal', electrons: '[He] 2s² 2p³', valence: 3, descriptionAr: 'يشكل 78% من الغلاف الجوي، يدخل في تكوين البروتينات والأحماض النووية.', medicalUseAr: 'النيتروجين السائل لجراحة التبريد (Cryosurgery) وإزالة الثآليل، وغاز أكسيد النيتروز كمخدر.', color: 'bg-emerald-500' },
  { number: 8, symbol: 'O', nameAr: 'أكسجين', nameEn: 'Oxygen', mass: 15.999, category: 'nonmetal', electrons: '[He] 2s² 2p⁴', valence: 2, descriptionAr: 'عنصر التنفس الخلوي وأساس إنتاج الطاقة في الكائنات الحية.', medicalUseAr: 'العلاج بالأكسجين الطبي لإنقاذ حالات نقص الأكسجة وغرف الضغط العالي (Hyperbaric Oxygen).', color: 'bg-emerald-500' },
  { number: 9, symbol: 'F', nameAr: 'فلور', nameEn: 'Fluorine', mass: 18.998, category: 'halogen', electrons: '[He] 2s² 2p⁵', valence: 1, descriptionAr: 'أعلى العناصر كهروسلبية وهالوجين شديد الفعالية.', medicalUseAr: 'الفلورايد لحماية مينا الأسنان من التسوس، ونظير F-18 في التصوير المقطعي البوزيتروني PET.', color: 'bg-yellow-500' },
  { number: 11, symbol: 'Na', nameAr: 'صوديوم', nameEn: 'Sodium', mass: 22.990, category: 'alkali', electrons: '[Ne] 3s¹', valence: 1, descriptionAr: 'فلز قلوي لين، الأيون الرئيسي في السائل خارج الخلوي.', medicalUseAr: 'محلول ملحي معقم (Normal Saline 0.9%)، تنظيم الضغط الأسموزي وتوصيل السيالات العصبية.', color: 'bg-red-500' },
  { number: 12, symbol: 'Mg', nameAr: 'مغنيسيوم', nameEn: 'Magnesium', mass: 24.305, category: 'alkaline', electrons: '[Ne] 3s²', valence: 2, descriptionAr: 'عنصر حيوي يدخل في أكثر من 300 تفاعل إنزيمي.', medicalUseAr: 'سلفات المغنيسيوم لعلاج تسمم الحمل وتشنجاته ولتهدئة ضربات القلب غير المنتظمة.', color: 'bg-amber-500' },
  { number: 15, symbol: 'P', nameAr: 'فوسفور', nameEn: 'Phosphorus', mass: 30.974, category: 'nonmetal', electrons: '[Ne] 3s² 3p³', valence: 3, descriptionAr: 'مكون أساسي لأغشية الخلايا، DNA، ومركب الطاقة ATP.', medicalUseAr: 'فوسفات الصوديوم لمعالجة نقص الفوسفات وتنظيم حموضة الدم.', color: 'bg-emerald-500' },
  { number: 17, symbol: 'Cl', nameAr: 'كلور', nameEn: 'Chlorine', mass: 35.45, category: 'halogen', electrons: '[Ne] 3s² 3p⁵', valence: 1, descriptionAr: 'أيون الكلوريد الرئيسي السالب في الدم وسوائل الجسم.', medicalUseAr: 'تطهير الأدوات الطبية وتعقيم المياه، وحمض الهيدروكلوريك لهضم المعدة.', color: 'bg-yellow-500' },
  { number: 19, symbol: 'K', nameAr: 'بوتاسيوم', nameEn: 'Potassium', mass: 39.098, category: 'alkali', electrons: '[Ar] 4s¹', valence: 1, descriptionAr: 'الأيون الرئيسي الموجب داخل الخلايا، منظم كهربية القلب.', medicalUseAr: 'كلوريد البوتاسيوم الوريدي والفموي لعلاج نقص البوتاسيوم واضطراب النبض.', color: 'bg-red-500' },
  { number: 20, symbol: 'Ca', nameAr: 'كالسيوم', nameEn: 'Calcium', mass: 40.078, category: 'alkaline', electrons: '[Ar] 4s²', valence: 2, descriptionAr: 'المعدن الأكثر وفرة في الجسم، عماد العظام والأسنان.', medicalUseAr: 'جلوكونات الكالسيوم لإنعاش القلب واستقرار أغشية الخلايا عند ارتفاع البوتاسيوم.', color: 'bg-amber-500' },
  { number: 26, symbol: 'Fe', nameAr: 'حديد', nameEn: 'Iron', mass: 55.845, category: 'transition', electrons: '[Ar] 3d⁶ 4s²', valence: 2, descriptionAr: 'فلز انتقالي يشكل مركز جزيء الهيموجلوبين لنقل الأكسجين.', medicalUseAr: 'مركبات الحديد الوريدية والفموية لعلاج فقر الدم الناجم عن نقص الحديد.', color: 'bg-rose-500' },
  { number: 29, symbol: 'Cu', nameAr: 'نحاس', nameEn: 'Copper', mass: 63.546, category: 'transition', electrons: '[Ar] 3d¹⁰ 4s¹', valence: 2, descriptionAr: 'عنصر زهيد أساسي لوظائف الجهاز المناعي والأعصاب.', medicalUseAr: 'اللوالب الرحمية النحاسية كمانع حمل ومطهر موضعي.', color: 'bg-rose-500' },
  { number: 30, symbol: 'Zn', nameAr: 'زنك', nameEn: 'Zinc', mass: 65.38, category: 'transition', electrons: '[Ar] 3d¹⁰ 4s²', valence: 2, descriptionAr: 'عنصر حيوي لتجدد الخلايا، التئام الجروح، وحاسة التذوق.', medicalUseAr: 'مكملات الزنك لتقصير مدة نزلات البرد، علاج الإسهال الحاد، ومراهم التئام الحروق.', color: 'bg-rose-500' },
  { number: 53, symbol: 'I', nameAr: 'يود', nameEn: 'Iodine', mass: 126.90, category: 'halogen', electrons: '[Kr] 4d¹⁰ 5s² 5p⁵', valence: 1, descriptionAr: 'عنصر أساسي لهرمونات الغدة الدرقية (T3 و T4).', medicalUseAr: 'محلول بوفيدون اليود كمطهر جراحي واسع المدى، واليود المشع I-131 لعلاج أورام ونشاط الدرقية.', color: 'bg-yellow-500' },
];

interface ChemicalReaction {
  id: string;
  titleAr: string;
  categoryAr: string;
  organType?: 'brain' | 'heart' | 'liver' | 'stomach' | 'muscles' | 'lungs' | 'blood' | 'skin' | 'cell' | 'pharmacy';
  organNameAr?: string;
  reactants: string[];
  products: string[];
  equation: string;
  enzyme?: string;
  atpYield?: string;
  type: 'acid-base' | 'precipitation' | 'redox' | 'biochemical' | 'synthesis';
  colorBefore: string;
  colorAfter: string;
  observationsAr: string;
  medicalRelevanceAr: string;
  temperatureChange: 'exothermic' | 'endothermic' | 'neutral';
  gasReleased?: string;
  precipitateFormed?: string;
}

const REACTIONS_DATABASE: ChemicalReaction[] = [
  // 1. In-Body Reactions (تفاعلات تحدث داخل جسم الإنسان)
  {
    id: 'cellular-respiration-atp',
    titleAr: 'التنفس الخلوي وأكسدة الجلوكوز لإنتاج الطاقة ATP',
    categoryAr: 'كيمياء الطاقة الخلوية والميتوكوندريا',
    organType: 'cell',
    organNameAr: 'الميتوكوندريا وجميع خلايا الجسم',
    reactants: ['سكر الجلوكوز C₆H₁₂O₆', 'غاز الأكسجين 6O₂', '36-38 جزيء ADP + Pi'],
    products: ['ثاني أكسيد الكربون 6CO₂', 'ماء 6H₂O', '36 إلى 38 جزيء طاقة ATP'],
    equation: 'C₆H₁₂O₆ + 6O₂ + 38ADP + 38Pi → 6CO₂↑ + 6H₂O + 38ATP + حرارة',
    enzyme: 'سلسلة نقل الإلكترونات وATP Synthase',
    atpYield: '+38 ATP (إنتاج طاقة)',
    type: 'biochemical',
    colorBefore: '#38bdf8',
    colorAfter: '#fbbf24',
    observationsAr: 'تحرير هائل للطاقة الكيميائية وتخزينها في روابط فوسفات ATP الحيوية، وتصاعد غاز CO₂ الذي يخرجه هواء الزفير.',
    medicalRelevanceAr: 'العملية الحيوية الأساسية لبقاء الكائن الحي على قيد الحياة. في مرض السكري ينخفض دخول الجلوكوز للخلايا مما يضطر الجسم لحرق الدهون وتكون الأجسام الكيتونية.',
    temperatureChange: 'exothermic',
    gasReleased: 'ثاني أكسيد الكربون 6CO₂'
  },
  {
    id: 'lactic-acid-muscle',
    titleAr: 'التخمر اللاهوائي وحمض اللاكتيك في العضلات عند الإجهاد',
    categoryAr: 'كيمياء العضلات والجهد الرياضي',
    organType: 'muscles',
    organNameAr: 'العضلات الهيكلية وألياف الحركة',
    reactants: ['سكر الجلوكوز C₆H₁₂O₆', 'إنزيم لاكتات ديهيدروجيناز LDH', '2ADP'],
    products: ['حمض اللاكتيك C₃H₆O₃ (لاكتات)', '2 جزيء ATP', 'أيونات هيدروجين H⁺'],
    equation: 'C₆H₁₂O₆ + 2ADP + 2Pi —(LDH)→ 2 C₃H₆O₃ (Lactate) + 2ATP',
    enzyme: 'Lactate Dehydrogenase (LDH)',
    atpYield: '+2 ATP (طاقة سريعة طارئة)',
    type: 'biochemical',
    colorBefore: '#e2e8f0',
    colorAfter: '#f87171',
    observationsAr: 'تراكم حمض اللاكتيك وانخفاض موضعي في الرقم الهيدروجيني (pH) داخل الألياف العضلية، مصحوباً بإحساس الحرقان والتعب العضلي.',
    medicalRelevanceAr: 'يحدث عند نفاد الأكسجين أثناء الركض السريع أو التمارين الشاقة، وفي حالات الصدمة الإنتانية ونقص التروية الدموية كعلامة سريرية خطيرة على الحماض اللاكتيكي (Lactic Acidosis).',
    temperatureChange: 'exothermic'
  },
  {
    id: 'urea-cycle-liver',
    titleAr: 'دورة اليوريا ونزع سمية الأمونيا في الكبد',
    categoryAr: 'كيمياء الكبد وتصفية السموم الأيضية',
    organType: 'liver',
    organNameAr: 'خلايا الكبد (Hepatocytes)',
    reactants: ['أيونات الأمونيا السامة 2NH₄⁺', 'ثاني أكسيد الكربون CO₂', '3 جزيئات ATP'],
    products: ['اليوريا غير السامة CO(NH₂)₂', 'حمض الفوماريك', '2ADP + AMP + 4Pi'],
    equation: '2NH₃ + CO₂ + 3ATP + H₂O → NH₂-CO-NH₂ (اليوريا) + 2ADP + AMP + 4Pi',
    enzyme: 'Carbamoyl Phosphate Synthetase & Arginase',
    atpYield: '-3 ATP (استهلاك طاقة)',
    type: 'biochemical',
    colorBefore: '#a855f7',
    colorAfter: '#34d399',
    observationsAr: 'تحويل غاز الأمونيا عالي السمية والمدمر لخلايا الدماغ إلى مركب بولينا (اليوريا) آمن يذوب في بلازما الدم لترشحه الكلى في البول.',
    medicalRelevanceAr: 'في حالات تليف الكبد والفشل الكبدي تعجز الكبد عن إتمام هذا التفاعل، فترتفع الأمونيا في الدم وتخترق الحاجز الدموي الدماغي مسببة الغيبوبة الكبدية (Hepatic Encephalopathy).',
    temperatureChange: 'neutral'
  },
  {
    id: 'dopamine-synthesis',
    titleAr: 'تخليق الدوبامين (ناقل المكافأة والتحكم الحركي في الدماغ)',
    categoryAr: 'كيمياء النواقل العصبية والمخ',
    organType: 'brain',
    organNameAr: 'المادة السوداء والقشرة الدماغية (Substantia Nigra)',
    reactants: ['الحمض الأميني التيروزين L-Tyrosine', 'إنزيم التيروزين هيدروكسيلاز', 'L-DOPA'],
    products: ['الدوبامين C₈H₁₁NO₂ (Dopamine)', 'ثاني أكسيد الكربون CO₂'],
    equation: 'L-Tyrosine → L-DOPA —(DOPA Decarboxylase)→ Dopamine (C₈H₁₁NO₂) + CO₂↑',
    enzyme: 'Tyrosine Hydroxylase & DOPA Decarboxylase',
    type: 'biochemical',
    colorBefore: '#60a5fa',
    colorAfter: '#c084fc',
    observationsAr: 'تفاعل إنزيمي متسلسل ينتهي بإنتاج نواقل عصبية كيميائية تتحرك عبر الشقوق المشبكية لتنشيط مستقبلات الدوبامين D1 و D2.',
    medicalRelevanceAr: 'ضمور الخلايا المنتجة للدوبامين في المادة السوداء هو السبب الجذري لمرض باركنسون (الشلل الرعاش)، ويعالج بدواء ليفودوبا (L-DOPA) لتعويض النقص.',
    temperatureChange: 'neutral'
  },
  {
    id: 'serotonin-synthesis',
    titleAr: 'تخليق السيروتونين (هرمون تنظيم المزاج والنوم والسعادة)',
    categoryAr: 'كيمياء النواقل العصبية والطب النفسي',
    organType: 'brain',
    organNameAr: 'أنوية الرفاء في جذع الدماغ وبطانة الجهاز الهضمي',
    reactants: ['الحمض الأميني الأساسي L-Tryptophan', 'فيتامين B6', '5-HTP'],
    products: ['السيروتونين Serotonin (5-Hydroxytryptamine)', 'CO₂'],
    equation: 'L-Tryptophan —(TPH)→ 5-HTP —(AADC)→ 5-HT (Serotonin) + CO₂↑',
    enzyme: 'Tryptophan Hydroxylase (TPH) & AADC',
    type: 'biochemical',
    colorBefore: '#93c5fd',
    colorAfter: '#fb7185',
    observationsAr: 'تخليق جزيء كيميائي يتحكم في المشاعر، الشهية، وتنظيم دورة النوم والاستيقاظ عبر تحوله ليلاً إلى هرمون الميلاتونين.',
    medicalRelevanceAr: 'نقص السيروتونين المشبكي يرتبط بالاكتئاب والوسواس القهري، وتعمل مضادات الاكتئاب الحديثة (SSRIs مثل الفلوكسيتين) على منع إعادة امتصاصه لإبقائه نشطاً.',
    temperatureChange: 'neutral'
  },
  {
    id: 'nitric-oxide-vasodilation',
    titleAr: 'إنتاج غاز أكسيد النيتريك (NO) لتوسيع الشرايين وضغط الدم',
    categoryAr: 'كيمياء القلب والأوعية الدموية',
    organType: 'heart',
    organNameAr: 'بطانة الأوعية الدموية والشرايين التاجية (Endothelium)',
    reactants: ['الحمض الأميني L-Arginine', 'الأكسجين O₂', 'NADPH', 'أيونات Ca²⁺'],
    products: ['غاز أكسيد النيتريك NO (غاز ناقل)', 'L-Citrulline', 'NADP⁺'],
    equation: 'L-Arginine + O₂ + NADPH —(eNOS)→ NO↑ + L-Citrulline + NADP⁺',
    enzyme: 'Endothelial Nitric Oxide Synthase (eNOS)',
    type: 'redox',
    colorBefore: '#dc2626',
    colorAfter: '#ec4899',
    observationsAr: 'انطلاق جزيئات غاز NO النانوي التي تنتشر فوراً إلى الخلايا العضلية الملساء في جدار الشريان مسببة استرخاءً وتوسعاً وعائياً فوري.',
    medicalRelevanceAr: 'الآلية التي تعمل بها حبوب النيتروجليسرين تحت اللسان لإنقاذ مرضى الذبحة الصدرية، وكذلك أدوية توسيع الأوعية وعلاج ضعف الانتصاب (مكبحات PDE-5).',
    temperatureChange: 'neutral',
    gasReleased: 'أكسيد النيتريك NO'
  },
  {
    id: 'blood-clotting-fibrin',
    titleAr: 'شلال تخثر الدم وتحول الفيبرينوجين إلى شبكة فيبرين صلبة',
    categoryAr: 'كيمياء أمراض الدم والإرقاء ووقف النزيف',
    organType: 'blood',
    organNameAr: 'بلازما الدم والصفائح الدموية في موضع الجرح',
    reactants: ['بروتين الفيبرينوجين الذائب Fibrinogen', 'إنزيم الثرومبين النشط Thrombin', 'أيونات الكالسيوم Ca²⁺'],
    products: ['بوليمرات الفيبرين غير الذائبة (Fibrin Mesh)', 'ببتيدات الفبرين الصغيرة'],
    equation: 'Fibrinogen (Soluble) —(Thrombin + Ca²⁺ + FXIIIa)→ Insoluble Fibrin Clot (جلطة شبكية)',
    enzyme: 'Thrombin (Factor IIa) & Factor XIIIa',
    type: 'precipitation',
    colorBefore: '#ef4444',
    colorAfter: '#991b1b',
    observationsAr: 'تحول فوري لبلازما الدم السائلة إلى مادة هلامية وشبكة ليفية متماسكة تحبس خلايا الدم الحمراء والصفائح لسد التمزق الوعائي.',
    medicalRelevanceAr: 'أساس وقف النزيف وحماية الحياة من الجروح. فرط هذا التفاعل يسبب الجلطات الوريدية العميقة (DVT) والسكتات، بينما نقصه يسبب مرض الهيموفيليا (نزاف الدم).',
    temperatureChange: 'neutral',
    precipitateFormed: 'شبكة خيوط الفيبرين (Fibrin Polymer Mesh)'
  },
  {
    id: 'hemoglobin-oxygen-binding',
    titleAr: 'ارتباط وتفكك الأكسجين بالهيموجلوبين (كيمياء نقل الغازات)',
    categoryAr: 'كيمياء الجهاز التنفسي والدم',
    organType: 'lungs',
    organNameAr: 'الحويصلات الهوائية بالرئتين والشعيرات الدموية',
    reactants: ['الهيموجلوبين منزوع الأكسجين Deoxyhemoglobin (Hb)', '4 جزيئات أكسجين 4O₂'],
    products: ['الأوكسي هيموجلوبين الزاهي Oxyhemoglobin (Hb(O₂)₄)'],
    equation: 'Hb (أحمر قاتم) + 4O₂ ⇌ Hb(O₂)₄ (أحمر قاني ساطع)',
    type: 'biochemical',
    colorBefore: '#7f1d1d',
    colorAfter: '#ef4444',
    observationsAr: 'تغير لوني مذهل من اللون الأحمر القاتم المزرق (الدم الوريدي) إلى الأحمر القاني المشرق (الدم الشرياني المؤكسج) بتفاعل توازني معتمد على ضغط الغاز وتأثير بور (Bohr Effect).',
    medicalRelevanceAr: 'المسؤول عن نقل 98.5% من أكسجين الحياة لكل أنسجة الجسم. يرتبط غاز أول أكسيد الكربون CO بنفس الموقع بقوة تفوق 200 ضعف مسبباً التسمم الاختناقي الصامت.',
    temperatureChange: 'neutral'
  },
  {
    id: 'stomach-acid-secretion',
    titleAr: 'إنتاج حمض الهيدروكلوريك HCl وهضم البروتين بالببسين',
    categoryAr: 'كيمياء الجهاز الهضمي والمعدة',
    organType: 'stomach',
    organNameAr: 'الخلايا الجدارية في بطانة المعدة (Parietal Cells)',
    reactants: ['مضخة البروتون H⁺/K⁺ ATPase', 'أيونات الكلوريد Cl⁻', 'طاقة ATP', 'ببسينوجين غير نشط'],
    products: ['حمض الهيدروكلوريك المركز HCl (pH 1.5 - 2.0)', 'إنزيم الببسين النشط لهضم اللحوم'],
    equation: 'H⁺ + Cl⁻ → HCl (aq) ; Pepsinogen —(HCl, pH<2)→ Pepsin (Active)',
    enzyme: 'H⁺/K⁺ ATPase Proton Pump & Pepsin',
    atpYield: '-1 ATP (ضخ ضد تدرج التركيز)',
    type: 'acid-base',
    colorBefore: '#fbbf24',
    colorAfter: '#ef4444',
    observationsAr: 'إفراز بيئة حمضية قوية جداً (pH 1.5) كافية لإذابة المعادن وقتل معظم الميكروبات وتنشيط إنزيمات هضم البروتينات الغذائية.',
    medicalRelevanceAr: 'الأدوية الأكثر مبيعاً في العالم (مثل الأوميبرازول والبانتابرازول PPIs) تقوم بتثبيط هذا التفاعل الكيميائي لعلاج القرحة وحرقان المريء.',
    temperatureChange: 'exothermic'
  },
  {
    id: 'melanin-synthesis-skin',
    titleAr: 'تخليق صبغة الميلانين في الجلد للحماية من الأشعة فوق البنفسجية',
    categoryAr: 'كيمياء الجلد والأمراض الجلدية',
    organType: 'skin',
    organNameAr: 'الخلايا الصبغية في البشرة (Melanocytes)',
    reactants: ['الحمض الأميني التيروزين L-Tyrosine', 'إنزيم التيروزينيز Tyrosinase', 'الأكسجين O₂'],
    products: ['صبغة الميلانين البنية/السوداء Eumelanin', 'الدوپاكروم Dopachrome'],
    equation: 'L-Tyrosine + O₂ —(Tyrosinase / Cu²⁺)→ L-DOPA → Dopaquinone → Eumelanin',
    enzyme: 'Tyrosinase (معتمد على النحاس Cu²⁺)',
    type: 'redox',
    colorBefore: '#fef08a',
    colorAfter: '#78350f',
    observationsAr: 'تأكسد بطيء وتكثيف للبوليمرات الحيوية ليتكون لون بني داكن يحجب الأشعة فوق البنفسجية الضارة UV-B ويحمي الحمض النووي DNA.',
    medicalRelevanceAr: 'غياب جين إنزيم التيروزينيز يسبب مرض المهق (Albinism)، بينما فرط نشاطه يسبب الكلف والتصبغات والبقع الشمسية.',
    temperatureChange: 'neutral',
    precipitateFormed: 'صبغة الميلانين العضوية (Eumelanin Pigment)'
  },
  {
    id: 'respiratory-buffer',
    titleAr: 'توازن حمض الكربونيك والبيكربونات (منظومة pH الدم في الجسم)',
    categoryAr: 'كيمياء الفسيولوجيا والحماض / القلاء التنفسي',
    organType: 'blood',
    organNameAr: 'كريات الدم الحمراء والشعيرات الرئوية والكلية',
    reactants: ['ثاني أكسيد الكربون CO₂ من التنفس الخلوي', 'الماء H₂O'],
    products: ['حمض الكربونيك H₂CO₃', 'أيون البيكربونات HCO₃⁻', 'أيون الهيدروجين H⁺'],
    equation: 'CO₂ + H₂O ⇌ H₂CO₃ ⇌ H⁺ + HCO₃⁻ (بفعل الكاربونيك أنهيدراز)',
    enzyme: 'Carbonic Anhydrase (أسرع إنزيم في الجسم)',
    type: 'biochemical',
    colorBefore: '#3b82f6',
    colorAfter: '#10b981',
    observationsAr: 'تفاعل اتزان كيميائي ديناميكي دقيق يحافظ على درجة حموضة الدم (pH) بدقة متناهية بين 7.35 و 7.45.',
    medicalRelevanceAr: 'عند حبس النفس أو الفشل التنفسي يتراكم CO₂ مؤدياً لحماض تنفسي (Acidosis)، بينما عند فرط التنفس (Hyperventilation) يطرد الجسم CO₂ فيحدث قلاء تنفسي (Alkalosis).',
    temperatureChange: 'neutral'
  },
  {
    id: 'alcohol-metabolism-liver',
    titleAr: 'أكسدة الكحول ونزع سميته في الكبد بإنزيم ADH و ALDH',
    categoryAr: 'كيمياء السموم وأيض الكبد',
    organType: 'liver',
    organNameAr: 'خلايا الكبد (Hepatocytes) والميتوكوندريا',
    reactants: ['الإيثانول CH₃CH₂OH', 'إنزيم كحول ديهيدروجيناز ADH', 'مستقبل الإلكترونات NAD⁺'],
    products: ['الأسيتالدهيد السام CH₃CHO', 'حمض الخليك الآمن Acetate', 'NADH + H⁺'],
    equation: 'CH₃CH₂OH + NAD⁺ —(ADH)→ CH₃CHO (سام) + NAD⁺ —(ALDH)→ CH₃COOH (آمن)',
    enzyme: 'Alcohol Dehydrogenase (ADH) & ALDH',
    type: 'redox',
    colorBefore: '#f1f5f9',
    colorAfter: '#3b82f6',
    observationsAr: 'أكسدة متدرجة تحول الكحول إلى أسيتالدهيد (مادة مهيجة وسامة تسبب الصداع والغثيان)، ثم إلى خلات آمنة تدخل في دورة كريبس.',
    medicalRelevanceAr: 'دواء ديسلفرام (Antabuse) يثبط إنزيم ALDH فيتراكم الأسيتالدهيد بسرعة مسبباً نفوراً شديداً من الكحول كعلاج للإدمان.',
    temperatureChange: 'exothermic'
  },

  // 2. Clinical Lab & Pharmacology Reactions (تفاعلات مخبرية وصيدلانية)
  {
    id: 'antacid-stomach',
    titleAr: 'تفاعل مضاد الحموضة مع حمض المعدة (معادلة الحموضة)',
    categoryAr: 'كيمياء الجهاز الهضمي والطب الدوائي',
    organType: 'stomach',
    organNameAr: 'تجويف المعدة والاثني عشر',
    reactants: ['حمض الهيدروكلوريك HCl (حمض المعدة)', 'هيدروكسيد المغنيسيوم Mg(OH)₂ (حليب المغنيسيا)'],
    products: ['كلوريد المغنيسيوم MgCl₂', 'ماء H₂O'],
    equation: 'Mg(OH)₂ + 2HCl → MgCl₂ + 2H₂O',
    type: 'acid-base',
    colorBefore: '#f87171',
    colorAfter: '#60a5fa',
    observationsAr: 'اختفاء الحموضة فوراً، تحول المحلول إلى وسط متعادل، وانطلاق حرارة خفيفة.',
    medicalRelevanceAr: 'الآلية الأساسية لأدوية حرقان المعدة وقرحة الاثني عشر، حيث يعادل حليب المغنيسيا حمض المعدة الزائد ويخفف الألم.',
    temperatureChange: 'exothermic'
  },
  {
    id: 'effervescent-aspirin',
    titleAr: 'فوران الأسبرين الفوار وفوار فيتامين C',
    categoryAr: 'كيمياء الصيدلانيات وتوصيل الدواء',
    organType: 'pharmacy',
    organNameAr: 'المحلول الفموي وجدار المعدة',
    reactants: ['بيكربونات الصوديوم NaHCO₃', 'حمض الستريك C₆H₈O₇'],
    products: ['سترات الصوديوم Na₃C₆H₅O₇', 'ماء H₂O', 'غاز ثاني أكسيد الكربون CO₂'],
    equation: '3NaHCO₃ + C₆H₈O₇ → Na₃C₆H₅O₇ + 3H₂O + 3CO₂↑',
    type: 'acid-base',
    colorBefore: '#ffffff',
    colorAfter: '#e0f2fe',
    observationsAr: 'تصاعد فقاعات غازية كثيفة (فوران منعش)، ذوبان القرص بالكامل، وانخفاض طفيف في درجة الحرارة.',
    medicalRelevanceAr: 'يساعد الفوران على سرعة امتصاص الدواء عبر بطانة المعدة ويخفف من تهيج الغشاء المخاطي مقارنة بالأقراص الصلبة.',
    temperatureChange: 'endothermic',
    gasReleased: 'ثاني أكسيد الكربون CO₂'
  },
  {
    id: 'hydrogen-peroxide-wound',
    titleAr: 'تطهير الجروح بماء الأكسجين وتفاعل إنزيم الكاتاليز',
    categoryAr: 'كيمياء التعقيم والإسعافات الأولية',
    organType: 'blood',
    organNameAr: 'الأنسجة المصابة وخلايا الدم',
    reactants: ['بيروكسيد الهيدروجين H₂O₂ (3%)', 'إنزيم الكاتاليز في الدم Catalase'],
    products: ['ماء H₂O', 'غاز الأكسجين النشط O₂'],
    equation: '2H₂O₂ —(Catalase)→ 2H₂O + O₂↑',
    enzyme: 'Catalase (إنزيم الحماية من الأكسدة)',
    type: 'redox',
    colorBefore: '#f1f5f9',
    colorAfter: '#ffffff',
    observationsAr: 'فوران أبيض رغوي فوري عند ملامسة الدم أو الأنسجة مع تطاير فقاعات غاز الأكسجين.',
    medicalRelevanceAr: 'إنزيم الكاتاليز الموجود في خلايا الدم يكسر بيروكسيد الهيدروجين محرراً أكسجيناً نقياً يقتل البكتيريا اللاهوائية في الجروح وينظف الحطام الخلوي ميكانيكياً.',
    temperatureChange: 'exothermic',
    gasReleased: 'أكسجين O₂ نشط'
  },
  {
    id: 'blood-coagulation-calcium',
    titleAr: 'ترسيب أملاح الكالسيوم مع الأكسالات (منع تجلط عينات الدم)',
    categoryAr: 'كيمياء التحاليل المخبرية وأنابيب الفحص',
    organType: 'blood',
    organNameAr: 'أنابيب سحب الدم المخبرية (In Vitro)',
    reactants: ['أيونات الكالسيوم Ca²⁺ في بلازما الدم', 'أكسالات البوتاسيوم K₂C₂O₄'],
    products: ['أكسالات الكالسيوم غير الذائبة CaC₂O₄ (راسب)', 'أيونات البوتاسيوم K⁺'],
    equation: 'Ca²⁺ + C₂O₄²⁻ → CaC₂O₄↓ (راسب صلب)',
    type: 'precipitation',
    colorBefore: '#ef4444',
    colorAfter: '#fecaca',
    observationsAr: 'تكون راسب مجهري يحبس شوارد الكالسيوم ويمنع شلال التجلط تماماً.',
    medicalRelevanceAr: 'يستخدم في أنابيب سحب الدم المخبرية (مضادات التخثر مثل EDTA وأكسالات البوتاسيوم) لمنع تكون الجلطات قبل فحص الدم وسكر الجلوكوز.',
    temperatureChange: 'neutral',
    precipitateFormed: 'أكسالات الكالسيوم CaC₂O₄'
  },
  {
    id: 'benedict-glucose-test',
    titleAr: 'كشف السكر في البول (اختبار بندكت / فهلنج)',
    categoryAr: 'كيمياء التشخيص السريري والغدد الصماء',
    organType: 'pharmacy',
    organNameAr: 'مختبر التحاليل والبول (الكلى)',
    reactants: ['محلول بندكت النحاسي الأزرق Cu²⁺', 'جلوكوز البول C₆H₁₂O₆ (سكر مختزل)'],
    products: ['أكسيد النحاسوز الأحمر Cu₂O (راسب قرميدي)', 'حمض الجلوكونيك'],
    equation: 'R-CHO + 2Cu²⁺ + 5OH⁻ → R-COO⁻ + Cu₂O↓ (أحمر) + 3H₂O',
    type: 'redox',
    colorBefore: '#2563eb',
    colorAfter: '#dc2626',
    observationsAr: 'تحول لون المحلول من الأزرق السماوي الصافي إلى الأخضر ثم الأصفر ثم الراسب البرتقالي أو الأحمر الطوبي عند وجود السكر.',
    medicalRelevanceAr: 'الاختبار التاريخي الشهير لكشف داء السكري ووجود السكر في البول (Glucosuria) وتحديد تركيزه التقريبي.',
    temperatureChange: 'exothermic',
    precipitateFormed: 'أكسيد النحاسوز Cu₂O الأحمر'
  }
];

export function ChemicalReactionsLab() {
  const [activeSubTab, setActiveSubTab] = useState<'reactions' | 'periodic' | 'ph-calculator' | 'dilution' | 'molarity'>('reactions');
  const [selectedOrganFilter, setSelectedOrganFilter] = useState<string>('all');
  const [selectedReaction, setSelectedReaction] = useState<ChemicalReaction>(REACTIONS_DATABASE[0]);
  const [reactionStep, setReactionStep] = useState<number>(0); // 0: initial, 1: mixing/reacting, 2: complete
  const [isSimulating, setIsSimulating] = useState<boolean>(false);
  const [selectedElement, setSelectedElement] = useState<ChemicalElement>(PERIODIC_TABLE_SAMPLE[0]);
  const [searchElement, setSearchElement] = useState<string>('');

  // pH Calculator state
  const [phInputType, setPhInputType] = useState<'h' | 'oh' | 'ph' | 'poh'>('ph');
  const [phValue, setPhValue] = useState<number>(7.4); // Default blood pH

  // Solution Dilution (C1V1 = C2V2) state
  const [c1, setC1] = useState<string>('70'); // Initial conc (e.g. 70% alcohol)
  const [v1, setV1] = useState<string>('');
  const [c2, setC2] = useState<string>('50'); // Desired conc
  const [v2, setV2] = useState<string>('500'); // Desired volume (ml)

  // Molarity & Solution Prep Calculator (Mass = M * V * Mw)
  const [molMolarity, setMolMolarity] = useState<string>('0.154'); // 0.154 M for Saline
  const [molVolumeL, setMolVolumeL] = useState<string>('1.0'); // 1 Liter
  const [molWeight, setMolWeight] = useState<string>('58.44'); // NaCl Mw

  // Reaction Simulation Trigger
  const runSimulation = () => {
    setIsSimulating(true);
    setReactionStep(1);
    setTimeout(() => {
      setReactionStep(2);
      setIsSimulating(false);
      confetti({ particleCount: 35, spread: 60, origin: { y: 0.6 } });
    }, 2000);
  };

  const resetReaction = () => {
    setReactionStep(0);
    setIsSimulating(false);
  };

  // pH calculations
  const calculatePHMetrics = (type: string, val: number) => {
    let calculatedPh = 7;
    let calculatedPoh = 7;
    let hConcentration = 1e-7;
    let ohConcentration = 1e-7;

    try {
      if (type === 'ph') {
        calculatedPh = Math.max(0, Math.min(14, val));
        calculatedPoh = 14 - calculatedPh;
        hConcentration = Math.pow(10, -calculatedPh);
        ohConcentration = Math.pow(10, -calculatedPoh);
      } else if (type === 'poh') {
        calculatedPoh = Math.max(0, Math.min(14, val));
        calculatedPh = 14 - calculatedPoh;
        hConcentration = Math.pow(10, -calculatedPh);
        ohConcentration = Math.pow(10, -calculatedPoh);
      } else if (type === 'h') {
        hConcentration = Math.max(1e-14, val);
        calculatedPh = -Math.log10(hConcentration);
        calculatedPoh = 14 - calculatedPh;
        ohConcentration = Math.pow(10, -calculatedPoh);
      }
    } catch {
      // fallback
    }

    return {
      ph: calculatedPh,
      poh: calculatedPoh,
      h: hConcentration,
      oh: ohConcentration,
    };
  };

  const phData = calculatePHMetrics(phInputType, phValue);

  const getPhColor = (ph: number) => {
    if (ph < 3) return 'from-red-600 to-rose-500';
    if (ph < 6) return 'from-orange-500 to-amber-500';
    if (ph >= 6 && ph <= 8) return 'from-emerald-500 to-teal-500';
    if (ph < 11) return 'from-blue-500 to-indigo-500';
    return 'from-purple-600 to-fuchsia-600';
  };

  const getPhBiologicalContext = (ph: number) => {
    if (ph >= 7.35 && ph <= 7.45) {
      return { title: 'المدى الطبيعي لـ pH الدم البشري (7.35 - 7.45)', type: 'normal', desc: 'توازن حمضي قاعدي مثالي للحفاظ على نشاط الإنزيمات وكفاءة ارتباط الأكسجين بالهيموجلوبين.' };
    }
    if (ph < 7.35 && ph >= 6.8) {
      return { title: 'حماض دموي (Acidosis)', type: 'warning', desc: 'انخفاض خطير في قلوية الدم قد ينجم عن الحماض الكيتوني السكري DKA أو الصدمة أو الفشل التنفسي.' };
    }
    if (ph > 7.45 && ph <= 7.8) {
      return { title: 'قلاء دموي (Alkalosis)', type: 'warning', desc: 'ارتفاع في قلوية الدم قد ينجم عن القيء الشديد المستمر أو فرط التنفس (Hyperventilation).' };
    }
    if (ph < 2.5) {
      return { title: 'حمض الهيدروكلوريك المعدي (Stomach Acid ~ 1.5 - 2.0)', type: 'info', desc: 'بيئة حمضية قوية جداً لقتل الجراثيم وتنشيط إنزيم الببسين لهضم البروتينات.' };
    }
    if (ph >= 8.0 && ph <= 8.5) {
      return { title: 'إفرازات البنكرياس والمرارة القلوية', type: 'info', desc: 'إفرازات غنية بالبيكربونات لمعادلة حمض المعدة الواصل للاثني عشر وحماية الأمعاء.' };
    }
    return { title: ph < 7 ? 'محلول حمضي (Acidic)' : 'محلول قاعدي / قلوي (Basic)', type: 'info', desc: 'انحراف عن نقطة التعادل الكيميائي (pH = 7).' };
  };

  // Dilution calculation
  const calculateDilution = () => {
    const numC1 = parseFloat(c1);
    const numC2 = parseFloat(c2);
    const numV2 = parseFloat(v2);

    if (numC1 && numC2 && numV2 && numC1 > numC2) {
      const calculatedV1 = (numC2 * numV2) / numC1;
      const addedWater = numV2 - calculatedV1;
      return {
        v1: calculatedV1.toFixed(1),
        water: addedWater.toFixed(1),
        success: true
      };
    }
    return { v1: '0', water: '0', success: false };
  };

  const dilutionResult = calculateDilution();

  // Molarity calculation
  const calculateRequiredMass = () => {
    const m = parseFloat(molMolarity);
    const v = parseFloat(molVolumeL);
    const mw = parseFloat(molWeight);

    if (m && v && mw) {
      const grams = m * v * mw;
      return grams.toFixed(3);
    }
    return '0.000';
  };

  return (
    <div className="space-y-6" id="chemical-reactions-suite">
      {/* Header Banner */}
      <div className="p-5 sm:p-6 rounded-3xl bg-gradient-to-r from-teal-900 via-emerald-900 to-cyan-950 text-white shadow-xl relative overflow-hidden border border-teal-700/50">
        <div className="absolute -right-10 -bottom-10 w-48 h-48 bg-teal-500/20 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="space-y-1.5">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-teal-500/20 text-teal-300 text-xs font-bold border border-teal-400/30">
              <FlaskConical className="w-3.5 h-3.5" />
              <span>مختبر الكيمياء الطبية والصيدلانية التفاعلي</span>
            </div>
            <h2 className="text-xl sm:text-2xl font-black font-heading">
              محاكي التفاعلات الكيميائية والجدول الدوري الطبي
            </h2>
            <p className="text-xs sm:text-sm text-teal-100/80 max-w-2xl leading-relaxed">
              محاكاة بصرية لتفاعلات الأدوية وحموضة المعدة، كيمياء تحاليل الدم والبول، حاسبة pH والتحضير الصيدلاني، واستكشاف العناصر الحيوية في الطب.
            </p>
          </div>

          <div className="flex items-center gap-2 bg-white/10 backdrop-blur-md p-2 rounded-2xl border border-white/10 shrink-0">
            <Atom className="w-8 h-8 text-teal-300 animate-spin-slow" />
          </div>
        </div>
      </div>

      {/* Sub Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-none border-b border-gray-200 dark:border-gray-800">
        {[
          { id: 'reactions', label: 'محاكي التفاعلات الطبية الحية', icon: FlaskConical },
          { id: 'periodic', label: 'الجدول الدوري للعناصر الطبية', icon: Atom },
          { id: 'ph-calculator', label: 'حاسبة pH وحموضة الدم', icon: Droplets },
          { id: 'dilution', label: 'حاسبة التخفيف الصيدلاني (C₁V₁ = C₂V₂)', icon: RotateCcw },
          { id: 'molarity', label: 'حاسبة المولارية وتحضير المحاليل', icon: Layers },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeSubTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveSubTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-xl text-xs sm:text-sm font-bold transition flex items-center gap-2 shrink-0 ${
                isActive
                  ? 'bg-teal-600 text-white shadow-md'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* 1. REACTIONS SIMULATOR */}
      {activeSubTab === 'reactions' && (
        <div className="space-y-4">
          {/* Organ & System Filter Pills */}
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none">
            {[
              { id: 'all', label: 'الكل (15 تفاعل)', icon: FlaskConical },
              { id: 'in-body', label: 'تفاعلات جسم الإنسان الحيوية (Biochemical)', icon: Dna, highlight: true },
              { id: 'brain', label: 'الدماغ والأعصاب', icon: Brain },
              { id: 'heart', label: 'القلب والأوعية', icon: HeartPulse },
              { id: 'liver', label: 'الكبد ونزع السموم', icon: Shield },
              { id: 'muscles', label: 'العضلات والطاقة', icon: Zap },
              { id: 'stomach', label: 'المعدة والهضم', icon: Activity },
              { id: 'blood', label: 'الدم والمناعة', icon: Droplets },
              { id: 'lungs', label: 'الرئتان ونقل الغازات', icon: Atom },
              { id: 'skin', label: 'الجلد والميلانين', icon: Sparkles },
              { id: 'pharmacy', label: 'كيمياء التحاليل والصيدلة', icon: Pill },
            ].map((filt) => {
              const Icon = filt.icon;
              const isSelected = selectedOrganFilter === filt.id;
              return (
                <button
                  key={filt.id}
                  onClick={() => setSelectedOrganFilter(filt.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                    isSelected
                      ? filt.highlight
                        ? 'bg-gradient-to-r from-rose-600 to-indigo-600 text-white shadow-md'
                        : 'bg-teal-600 text-white shadow-md'
                      : filt.highlight
                      ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800'
                      : 'bg-white dark:bg-gray-900 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-800 hover:border-teal-400'
                  }`}
                >
                  <Icon className="w-3.5 h-3.5" />
                  <span>{filt.label}</span>
                </button>
              );
            })}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Reaction Selector (4 Cols) */}
            <div className="lg:col-span-4 space-y-3">
              <div className="flex items-center justify-between">
                <h3 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                  <FlaskConical className="w-4 h-4 text-teal-600" />
                  <span>اختر التفاعل الكيميائي / الحيوي:</span>
                </h3>
                <span className="text-[11px] font-mono text-gray-500">
                  {
                    REACTIONS_DATABASE.filter((rxn) => {
                      if (selectedOrganFilter === 'all') return true;
                      if (selectedOrganFilter === 'in-body') return rxn.organType && rxn.organType !== 'pharmacy';
                      return rxn.organType === selectedOrganFilter;
                    }).length
                  } تفاعل
                </span>
              </div>

              <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1 scrollbar-thin">
                {REACTIONS_DATABASE.filter((rxn) => {
                  if (selectedOrganFilter === 'all') return true;
                  if (selectedOrganFilter === 'in-body') return rxn.organType && rxn.organType !== 'pharmacy';
                  return rxn.organType === selectedOrganFilter;
                }).map((rxn) => {
                  const isSelected = selectedReaction.id === rxn.id;
                  const isInBody = rxn.organType && rxn.organType !== 'pharmacy';

                  return (
                    <button
                      key={rxn.id}
                      onClick={() => {
                        setSelectedReaction(rxn);
                        resetReaction();
                      }}
                      className={`w-full text-right p-3.5 rounded-2xl border transition-all text-xs flex flex-col gap-1.5 ${
                        isSelected
                          ? isInBody
                            ? 'bg-rose-50/70 dark:bg-rose-950/40 border-rose-500 dark:border-rose-500 shadow-sm ring-2 ring-rose-500/20'
                            : 'bg-teal-50 dark:bg-teal-950/40 border-teal-500 dark:border-teal-500 shadow-sm ring-2 ring-teal-500/20'
                          : 'bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 hover:border-teal-300 text-gray-700 dark:text-gray-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-gray-900 dark:text-white text-xs sm:text-sm">
                          {rxn.titleAr}
                        </span>
                        {isInBody && (
                          <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-rose-100 dark:bg-rose-900/60 text-rose-800 dark:text-rose-300 shrink-0">
                            داخل الجسم
                          </span>
                        )}
                      </div>

                      <div className="flex items-center gap-1.5 text-[11px] text-gray-500 dark:text-gray-400">
                        {rxn.organNameAr && (
                          <span className="font-bold text-indigo-600 dark:text-indigo-400 flex items-center gap-1">
                            <Dna className="w-3 h-3" />
                            <span>{rxn.organNameAr}</span>
                          </span>
                        )}
                        <span>•</span>
                        <span className="truncate">{rxn.categoryAr}</span>
                      </div>

                      <span className="font-mono text-[11px] text-teal-700 dark:text-teal-400 dir-ltr text-left">
                        {rxn.equation}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Interactive Beaker Simulation & Reaction Details (8 Cols) */}
            <div className="lg:col-span-8 space-y-5">
              {/* Visual Glass Beaker Simulator */}
              <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-gray-900 to-gray-950 text-white border border-gray-800 shadow-2xl relative overflow-hidden">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between border-b border-gray-800 pb-3 mb-6 gap-3">
                  <div>
                    <div className="flex items-center gap-2">
                      <h4 className="font-bold text-base sm:text-lg text-teal-400">
                        {selectedReaction.titleAr}
                      </h4>
                      {selectedReaction.organType && selectedReaction.organType !== 'pharmacy' && (
                        <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-rose-950 text-rose-300 border border-rose-700">
                          تفاعل حيوي داخل الجسم
                        </span>
                      )}
                    </div>
                    <div className="flex items-center gap-2 mt-1 text-xs text-gray-400">
                      {selectedReaction.organNameAr && (
                        <span className="text-amber-300 font-bold">
                          الموقع الحيوي: {selectedReaction.organNameAr}
                        </span>
                      )}
                      <span>•</span>
                      <span>{selectedReaction.categoryAr}</span>
                    </div>
                  </div>

                  <div className="flex items-center gap-2 shrink-0">
                    <button
                      onClick={resetReaction}
                      className="p-2 rounded-xl bg-gray-800 hover:bg-gray-700 text-gray-300 text-xs font-bold transition flex items-center gap-1.5"
                      title="إعادة ضبط المحلول"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span className="hidden sm:inline">إعادة ضبط</span>
                    </button>
                    <button
                      onClick={runSimulation}
                      disabled={isSimulating || reactionStep === 2}
                      className={`px-4 py-2 rounded-xl text-xs font-black transition flex items-center gap-2 ${
                        reactionStep === 2
                          ? 'bg-emerald-600 text-white cursor-default'
                          : isSimulating
                          ? 'bg-teal-500 text-white animate-pulse'
                          : 'bg-gradient-to-r from-teal-500 to-emerald-600 hover:from-teal-600 hover:to-emerald-700 text-white shadow-lg shadow-teal-500/20'
                      }`}
                    >
                      <Play className="w-3.5 h-3.5 fill-current" />
                      <span>
                        {reactionStep === 0 && 'بدء تفاعل المركبات'}
                        {reactionStep === 1 && 'جاري النشاط الكيميائي والإنزيمي...'}
                        {reactionStep === 2 && 'اكتمل التفاعل الحيوي'}
                      </span>
                    </button>
                  </div>
                </div>

                {/* Chemical Beaker & Biochemical Graphic */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-8 py-4">
                  {/* Left: Glass Beaker Canvas */}
                  <div className="relative w-48 h-64 flex flex-col items-center justify-end">
                    {/* Beaker Lip & Body */}
                    <div className="w-40 h-56 rounded-b-3xl border-4 border-t-0 border-teal-400/40 relative overflow-hidden bg-white/5 backdrop-blur-xs flex flex-col justify-end p-2 shadow-inner">
                      {/* Measurement marks */}
                      <div className="absolute left-2 top-4 bottom-4 flex flex-col justify-between text-[8px] font-mono text-gray-500 select-none">
                        <span>- 200ml</span>
                        <span>- 150ml</span>
                        <span>- 100ml</span>
                        <span>- 50ml</span>
                      </div>

                      {/* Bubbles & Vapor during reaction */}
                      {reactionStep === 1 && (
                        <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
                          <div className="w-4 h-4 rounded-full bg-white/60 animate-ping absolute top-10" />
                          <div className="w-3 h-3 rounded-full bg-white/50 animate-bounce absolute top-20 right-8" />
                          <div className="w-2 h-2 rounded-full bg-white/40 animate-pulse absolute top-14 left-10" />
                        </div>
                      )}

                      {/* Precipitate at bottom if any */}
                      {reactionStep === 2 && selectedReaction.precipitateFormed && (
                        <div className="w-full h-5 rounded-b-2xl bg-amber-200/90 text-[9px] text-amber-900 font-bold flex items-center justify-center shadow-md animate-pulse">
                          راسب: {selectedReaction.precipitateFormed}
                        </div>
                      )}

                      {/* Liquid Color */}
                      <div
                        className="w-full rounded-b-2xl transition-all duration-1000 flex items-center justify-center text-center p-2"
                        style={{
                          height: reactionStep === 0 ? '55%' : reactionStep === 1 ? '65%' : '60%',
                          backgroundColor:
                            reactionStep === 0
                              ? selectedReaction.colorBefore
                              : reactionStep === 1
                              ? '#a855f7'
                              : selectedReaction.colorAfter,
                          opacity: 0.85
                        }}
                      >
                        <span className="text-[11px] font-black text-gray-900 bg-white/80 px-2 py-0.5 rounded-md shadow-xs backdrop-blur-xs">
                          {reactionStep === 0 && 'المتفاعلات والركائز'}
                          {reactionStep === 1 && 'نشاط إنزيمي وتحول أيوني'}
                          {reactionStep === 2 && 'النواتج الحيوية النهائية'}
                        </span>
                      </div>
                    </div>
                  </div>

                  {/* Right: Live Chemical Status */}
                  <div className="flex-1 space-y-3 text-xs">
                    {/* Equation Box */}
                    <div className="p-3 rounded-2xl bg-gray-800/80 border border-gray-700">
                      <span className="text-gray-400 block mb-1 text-[11px]">المعادلة الكيميائية الموزونة:</span>
                      <div className="font-mono text-sm sm:text-base font-bold text-teal-300 dir-ltr text-left">
                        {selectedReaction.equation}
                      </div>
                    </div>

                    {/* Reactants vs Products */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                      <div className="p-3 rounded-xl bg-gray-800/40 border border-gray-700/60">
                        <span className="text-gray-400 font-bold block mb-1 text-[11px]">المواد المتفاعلة والركائز:</span>
                        <ul className="space-y-1 text-gray-200">
                          {selectedReaction.reactants.map((r, i) => (
                            <li key={i} className="flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-rose-400" />
                              <span>{r}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                      <div className="p-3 rounded-xl bg-gray-800/40 border border-gray-700/60">
                        <span className="text-gray-400 font-bold block mb-1 text-[11px]">النواتج الحيوية:</span>
                        <ul className="space-y-1 text-gray-200">
                          {selectedReaction.products.map((p, i) => (
                            <li key={i} className="flex items-center gap-1.5">
                              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400" />
                              <span>{p}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>

                    {/* Enzyme & ATP Badges */}
                    <div className="flex flex-wrap gap-2 pt-1">
                      {selectedReaction.enzyme && (
                        <span className="px-2.5 py-1 rounded-lg bg-indigo-950/80 text-indigo-300 border border-indigo-700/70 flex items-center gap-1">
                          <Dna className="w-3.5 h-3.5 text-indigo-400" />
                          <span>الإنزيم المحفز: {selectedReaction.enzyme}</span>
                        </span>
                      )}

                      {selectedReaction.atpYield && (
                        <span className="px-2.5 py-1 rounded-lg bg-amber-950/80 text-amber-300 border border-amber-700/70 flex items-center gap-1">
                          <Zap className="w-3.5 h-3.5 text-amber-400" />
                          <span>ميزان الطاقة: {selectedReaction.atpYield}</span>
                        </span>
                      )}

                      <span className="px-2.5 py-1 rounded-lg bg-gray-800 text-gray-300 border border-gray-700 flex items-center gap-1">
                        <Flame className="w-3.5 h-3.5 text-orange-400" />
                        <span>
                          {selectedReaction.temperatureChange === 'exothermic' && 'تفاعل طارد للحرارة (Exothermic)'}
                          {selectedReaction.temperatureChange === 'endothermic' && 'تفاعل ماص للحرارة (Endothermic)'}
                          {selectedReaction.temperatureChange === 'neutral' && 'تفاعل متعادل حرارياً'}
                        </span>
                      </span>

                      {selectedReaction.gasReleased && (
                        <span className="px-2.5 py-1 rounded-lg bg-gray-800 text-sky-300 border border-gray-700 flex items-center gap-1">
                          <Droplets className="w-3.5 h-3.5 text-sky-400" />
                          <span>انطلاق غاز: {selectedReaction.gasReleased}</span>
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>

              {/* Medical Context & Clinical Explanation */}
              <div className="p-5 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 space-y-3">
                <div className="flex items-center gap-2 text-emerald-600 dark:text-emerald-400 font-black text-sm">
                  <Sparkles className="w-4 h-4" />
                  <span>الأهمية الفسيولوجية والسريرية في جسم الإنسان:</span>
                </div>
                <p className="text-xs sm:text-sm text-gray-700 dark:text-gray-300 leading-relaxed font-medium">
                  {selectedReaction.medicalRelevanceAr}
                </p>
                <div className="p-3 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-xs text-teal-800 dark:text-teal-300">
                  <strong>الملاحظة المخبرية / الحيوية:</strong> {selectedReaction.observationsAr}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 2. PERIODIC TABLE & MEDICAL ELEMENTS */}
      {activeSubTab === 'periodic' && (
        <div className="space-y-5">
          {/* Element Search */}
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4 p-4 rounded-2xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
            <div className="relative w-full sm:w-80">
              <Search className="w-4 h-4 text-gray-400 absolute right-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                value={searchElement}
                onChange={(e) => setSearchElement(e.target.value)}
                placeholder="ابحث عن عنصر (صوديوم، كالسيوم، يود، Fe)..."
                className="w-full pr-10 pl-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs outline-none focus:border-teal-500"
              />
            </div>
            <span className="text-xs text-gray-500 dark:text-gray-400">
              انقر على أي عنصر كيميائي لاستعراض دوره الحيوي وتطبيقاته في الطب والأدوية
            </span>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Elements Grid (7 Cols) */}
            <div className="lg:col-span-7 grid grid-cols-3 sm:grid-cols-4 md:grid-cols-5 gap-2.5">
              {PERIODIC_TABLE_SAMPLE.filter(
                (el) =>
                  el.nameAr.includes(searchElement) ||
                  el.nameEn.toLowerCase().includes(searchElement.toLowerCase()) ||
                  el.symbol.toLowerCase().includes(searchElement.toLowerCase())
              ).map((el) => {
                const isSelected = selectedElement.symbol === el.symbol;
                return (
                  <button
                    key={el.symbol}
                    onClick={() => setSelectedElement(el)}
                    className={`p-3 rounded-2xl border transition-all text-center flex flex-col items-center justify-between gap-1 relative ${
                      isSelected
                        ? 'bg-teal-600 text-white border-teal-600 shadow-lg scale-105 z-10 ring-4 ring-teal-500/20'
                        : 'bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 hover:border-teal-400 text-gray-800 dark:text-gray-200'
                    }`}
                  >
                    <span className="text-[10px] font-mono text-gray-400 absolute top-1.5 left-2">
                      {el.number}
                    </span>
                    <span className="text-xl sm:text-2xl font-black font-mono tracking-tight mt-1">
                      {el.symbol}
                    </span>
                    <span className="text-xs font-bold truncate max-w-full">
                      {el.nameAr}
                    </span>
                    <span className="text-[10px] opacity-70 font-mono">
                      {el.mass.toFixed(2)}
                    </span>
                  </button>
                );
              })}
            </div>

            {/* Element Medical Card Details (5 Cols) */}
            <div className="lg:col-span-5 p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm space-y-4">
              <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-4">
                <div className="flex items-center gap-3">
                  <div className="w-14 h-14 rounded-2xl bg-teal-600 text-white font-black text-2xl flex items-center justify-center font-mono shadow-md">
                    {selectedElement.symbol}
                  </div>
                  <div>
                    <h4 className="text-lg font-black text-gray-900 dark:text-white">
                      {selectedElement.nameAr} ({selectedElement.nameEn})
                    </h4>
                    <span className="text-xs text-gray-500 dark:text-gray-400">
                      العدد الذري: {selectedElement.number} • الكتلة المولية: {selectedElement.mass} g/mol
                    </span>
                  </div>
                </div>
              </div>

              {/* Chemical Specs */}
              <div className="grid grid-cols-2 gap-2 text-xs">
                <div className="p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800/60 border border-gray-200/60 dark:border-gray-700/60">
                  <span className="text-gray-400 block text-[10px]">التوزيع الإلكتروني:</span>
                  <span className="font-mono font-bold text-teal-600 dark:text-teal-400">{selectedElement.electrons}</span>
                </div>
                <div className="p-2.5 rounded-xl bg-gray-50 dark:bg-gray-800/60 border border-gray-200/60 dark:border-gray-700/60">
                  <span className="text-gray-400 block text-[10px]">تكافؤ العنصر (Valence):</span>
                  <span className="font-mono font-bold text-teal-600 dark:text-teal-400">{selectedElement.valence}</span>
                </div>
              </div>

              {/* Description */}
              <div className="space-y-1">
                <span className="text-xs font-bold text-gray-500">الخصائص العامة:</span>
                <p className="text-xs text-gray-700 dark:text-gray-300 leading-relaxed">
                  {selectedElement.descriptionAr}
                </p>
              </div>

              {/* Medical & Pharmaceutical Role */}
              <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 space-y-2">
                <div className="flex items-center gap-2 text-teal-800 dark:text-teal-300 font-extrabold text-xs">
                  <Sparkles className="w-4 h-4 text-teal-600" />
                  <span>الاستخدام الطبي والصيدلاني والأهمية الحيوية:</span>
                </div>
                <p className="text-xs text-teal-900 dark:text-teal-200 leading-relaxed font-medium">
                  {selectedElement.medicalUseAr}
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 3. pH & BLOOD BUFFER CALCULATOR */}
      {activeSubTab === 'ph-calculator' && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          <div className="lg:col-span-5 p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 space-y-4">
            <h3 className="font-extrabold text-base text-gray-900 dark:text-white flex items-center gap-2">
              <Droplets className="w-5 h-5 text-teal-600" />
              <span>إدخال قيمة الرقم الهيدروجيني (pH):</span>
            </h3>

            {/* Quick Preset Buttons */}
            <div className="space-y-2">
              <label className="text-xs text-gray-500 font-bold block">قيم سريرية شائعة:</label>
              <div className="flex flex-wrap gap-1.5">
                {[
                  { label: 'دم طبيعي (7.40)', val: 7.4 },
                  { label: 'حماض دموي (7.25)', val: 7.25 },
                  { label: 'قلاء دموي (7.55)', val: 7.55 },
                  { label: 'حمض المعدة (1.8)', val: 1.8 },
                  { label: 'بول طبيعي (6.0)', val: 6.0 },
                  { label: 'ماء نقي (7.0)', val: 7.0 },
                  { label: 'عصارة بنكرياس (8.2)', val: 8.2 },
                ].map((preset) => (
                  <button
                    key={preset.label}
                    onClick={() => {
                      setPhInputType('ph');
                      setPhValue(preset.val);
                    }}
                    className="px-2.5 py-1 rounded-lg text-xs font-bold bg-gray-100 dark:bg-gray-800 hover:bg-teal-50 dark:hover:bg-teal-950 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 transition"
                  >
                    {preset.label}
                  </button>
                ))}
              </div>
            </div>

            {/* Slider / Direct Input */}
            <div className="space-y-3 pt-2">
              <div className="flex items-center justify-between text-xs font-bold">
                <span className="text-gray-600 dark:text-gray-400">قيمة pH المحددة:</span>
                <span className="text-xl font-black font-mono text-teal-600 dark:text-teal-400">{phValue.toFixed(2)}</span>
              </div>
              <input
                type="range"
                min="0"
                max="14"
                step="0.05"
                value={phValue}
                onChange={(e) => setPhValue(parseFloat(e.target.value))}
                className="w-full accent-teal-600 h-2 bg-gray-200 dark:bg-gray-700 rounded-lg cursor-pointer"
              />
              <div className="flex justify-between text-[10px] text-gray-400 font-mono">
                <span>0 (حمضي شديد)</span>
                <span>7 (متعادل)</span>
                <span>14 (قاعدي شديد)</span>
              </div>
            </div>

            {/* Calculated Constants */}
            <div className="grid grid-cols-2 gap-2 pt-2 text-xs">
              <div className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-800/60 border border-gray-200 dark:border-gray-700">
                <span className="text-gray-400 block text-[10px]">pOH:</span>
                <span className="font-mono font-black text-sm text-gray-900 dark:text-white">{phData.poh.toFixed(2)}</span>
              </div>
              <div className="p-3 rounded-2xl bg-gray-50 dark:bg-gray-800/60 border border-gray-200 dark:border-gray-700">
                <span className="text-gray-400 block text-[10px]">تركيز [H⁺]:</span>
                <span className="font-mono font-bold text-xs text-gray-900 dark:text-white dir-ltr">{phData.h.toExponential(2)} M</span>
              </div>
            </div>
          </div>

          {/* Clinical Interpretation */}
          <div className="lg:col-span-7 space-y-4">
            {/* Visual Color Meter */}
            <div className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-gray-500">التحليل السريري للـ pH:</span>
                <span className={`px-3 py-1 rounded-full text-xs font-black text-white bg-gradient-to-r ${getPhColor(phData.ph)}`}>
                  pH = {phData.ph.toFixed(2)}
                </span>
              </div>

              {/* Dynamic Context Card */}
              {(() => {
                const context = getPhBiologicalContext(phData.ph);
                return (
                  <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-800/70 border border-gray-200 dark:border-gray-700 space-y-2">
                    <h4 className="font-extrabold text-sm text-gray-900 dark:text-white flex items-center gap-2">
                      <Activity className="w-4 h-4 text-teal-600" />
                      <span>{context.title}</span>
                    </h4>
                    <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">
                      {context.desc}
                    </p>
                  </div>
                );
              })()}

              {/* Henderson-Hasselbalch Blood Buffer Formula */}
              <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 space-y-2 text-xs">
                <div className="font-bold text-teal-900 dark:text-teal-200">
                  معادلة هندرسون-هاسلبالخ لدرء وتوازن حموضة الدم:
                </div>
                <div className="font-mono text-sm font-bold text-teal-700 dark:text-teal-300 dir-ltr text-center py-1">
                  pH = 6.1 + log ( [HCO₃⁻] / (0.03 × PaCO₂) )
                </div>
                <p className="text-[11px] text-teal-800 dark:text-teal-300 leading-relaxed">
                  تعتمد كليتا الإنسان ورئتاه على هذا التوازن الدقيق لإبقاء الرقم الهيدروجيني في النطاق الآمن للحياة (7.35 - 7.45).
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* 4. DILUTION CALCULATOR (C1V1 = C2V2) */}
      {activeSubTab === 'dilution' && (
        <div className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 space-y-6">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-gray-100 dark:border-gray-800 pb-4">
            <div>
              <h3 className="text-base font-extrabold text-gray-900 dark:text-white flex items-center gap-2">
                <RotateCcw className="w-5 h-5 text-teal-600" />
                <span>حاسبة تخفيف المحاليل الصيدلانية (C₁V₁ = C₂V₂)</span>
              </h3>
              <p className="text-xs text-gray-500 mt-0.5">
                حساب كمية المحلول المركز وكمية الماء المقطر اللازم إضافتها للوصول للتركيز والحجم المطلوب.
              </p>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300">التركيز الابتدائي المركز (C₁):</label>
              <div className="relative">
                <input
                  type="number"
                  value={c1}
                  onChange={(e) => setC1(e.target.value)}
                  placeholder="مثال: 70"
                  className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-bold outline-none focus:border-teal-500"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">% أو M</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300">التركيز المخفف المطلوب (C₂):</label>
              <div className="relative">
                <input
                  type="number"
                  value={c2}
                  onChange={(e) => setC2(e.target.value)}
                  placeholder="مثال: 50"
                  className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-bold outline-none focus:border-teal-500"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">% أو M</span>
              </div>
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300">الحجم النهائي المطلوب (V₂):</label>
              <div className="relative">
                <input
                  type="number"
                  value={v2}
                  onChange={(e) => setV2(e.target.value)}
                  placeholder="مثال: 500"
                  className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-bold outline-none focus:border-teal-500"
                />
                <span className="absolute left-3 top-1/2 -translate-y-1/2 text-xs text-gray-400">مل (ml)</span>
              </div>
            </div>

            <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 flex flex-col justify-center text-center">
              <span className="text-[11px] text-teal-800 dark:text-teal-300 font-bold">الحجم المركز المطلوب (V₁):</span>
              <span className="text-xl font-black text-teal-700 dark:text-teal-300 font-mono">
                {dilutionResult.v1} <span className="text-xs">مل</span>
              </span>
            </div>
          </div>

          {/* Mixing Instructions */}
          {dilutionResult.success && (
            <div className="p-4 rounded-2xl bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800 space-y-1.5 text-xs text-emerald-900 dark:text-emerald-200">
              <div className="font-extrabold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                <span>خطوات التحضير الصيدلاني المخبري:</span>
              </div>
              <p>
                1. قس بدقة <strong>{dilutionResult.v1} مل</strong> من المحلول المركز (تركيز {c1}%).
              </p>
              <p>
                2. أضف إليه <strong>{dilutionResult.water} مل</strong> من الماء المقطر المعقم حتى يصل الحجم الكلي إلى <strong>{v2} مل</strong>.
              </p>
            </div>
          )}
        </div>
      )}

      {/* 5. MOLARITY & MASS PREPARATION */}
      {activeSubTab === 'molarity' && (
        <div className="p-6 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 space-y-6">
          <div>
            <h3 className="text-base font-extrabold text-gray-900 dark:text-white flex items-center gap-2">
              <Layers className="w-5 h-5 text-teal-600" />
              <span>حاسبة وزن المادة لتحضير محلول بتركيز مولاري معين</span>
            </h3>
            <p className="text-xs text-gray-500 mt-0.5">
              القانون: الكتلة بالجرام (Mass) = المولارية (M) × الحجم باللتر (V) × الكتلة المولية (Mw)
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300">المولارية المطلوبة (Molarity):</label>
              <input
                type="number"
                step="0.01"
                value={molMolarity}
                onChange={(e) => setMolMolarity(e.target.value)}
                placeholder="مثال: 0.154"
                className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-bold outline-none focus:border-teal-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300">الحجم باللتر (Volume in L):</label>
              <input
                type="number"
                step="0.1"
                value={molVolumeL}
                onChange={(e) => setMolVolumeL(e.target.value)}
                placeholder="مثال: 1.0"
                className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-bold outline-none focus:border-teal-500"
              />
            </div>

            <div className="space-y-1.5">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300">الوزن الجزيئي للمركب (g/mol):</label>
              <input
                type="number"
                step="0.01"
                value={molWeight}
                onChange={(e) => setMolWeight(e.target.value)}
                placeholder="مثال: 58.44 لـ NaCl"
                className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-xs font-bold outline-none focus:border-teal-500"
              />
            </div>
          </div>

          {/* Mass Result */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-teal-500 to-emerald-600 text-white flex flex-col sm:flex-row items-center justify-between gap-4 shadow-lg shadow-teal-500/20">
            <div>
              <span className="text-xs text-teal-100 font-bold block">الوزن المطلوب وزنه بدقة على الميزان الحساس:</span>
              <span className="text-2xl sm:text-3xl font-black font-mono">
                {calculateRequiredMass()} <span className="text-sm font-bold">جرام (g)</span>
              </span>
            </div>
            <p className="text-xs text-teal-100 max-w-xs text-center sm:text-right">
              قم بوزن هذه الكمية وإذابتها في كمية قليلة من المذيب ثم أكمل الحجم حتى {molVolumeL} لتر.
            </p>
          </div>
        </div>
      )}
    </div>
  );
}
