import React, { useState, useEffect, useMemo } from 'react';
import {
  Sparkles,
  Dna,
  Heart,
  HeartPulse,
  Brain,
  Zap,
  Activity,
  Flame,
  Droplets,
  Atom,
  FlaskConical,
  Pill,
  Shield,
  RotateCcw,
  Play,
  Pause,
  FastForward,
  CheckCircle2,
  HelpCircle,
  Award,
  Layers,
  ChevronRight,
  ChevronLeft,
  Search,
  Filter,
  BarChart2,
  Sliders,
  Compass,
  Maximize2,
  Eye
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface PathwayStep {
  stepNumber: number;
  titleAr: string;
  reactants: string[];
  products: string[];
  enzyme?: string;
  atpYield?: string;
  equation?: string;
  notesAr: string;
  difficultyExplanation: {
    beginner: string;
    intermediate: string;
    advanced: string;
  };
}

interface BiochemicalPathway {
  id: string;
  titleAr: string;
  categoryAr: string;
  organType: 'digestive' | 'respiratory' | 'energy' | 'blood' | 'brain' | 'muscle' | 'dna' | 'enzyme' | 'fluids' | 'adme';
  organNameAr: string;
  descriptionAr: string;
  totalAtpYield?: string;
  steps: PathwayStep[];
}

const BIOCHEM_PATHWAYS: BiochemicalPathway[] = [
  // 1. Cellular Respiration & Energy (Glycolysis to ATP)
  {
    id: 'cellular-respiration-complete',
    titleAr: 'مسار التنفس الخلوي وإنتاج الطاقة ATP (من الجلوكوز إلى الميتوكوندريا)',
    categoryAr: 'كيمياء الطاقة الخلوية والأيض الحيوي',
    organType: 'energy',
    organNameAr: 'السيتوبلازم والميتوكوندريا في جميع الخلايا',
    descriptionAr: 'المسار الأيضي الأهم في الحياة: تحويل سكر الجلوكوز C₆H₁₂O₆ عبر التحلل السكري ودورة كريبس وسلسلة نقل الإلكترون لإنتاج 36-38 جزيء ATP.',
    totalAtpYield: '+36 إلى +38 ATP صافي',
    steps: [
      {
        stepNumber: 1,
        titleAr: '1. فسفرة الجلوكوز واحتجازه داخل الخلية',
        reactants: ['جلوكوز C₆H₁₂O₆', '1 جزيء ATP'],
        products: ['جلوكوز-6-فوسفات (G6P)', 'ADP'],
        enzyme: 'Hexokinase / Glucokinase (في الكبد)',
        atpYield: '-1 ATP (استهلاك طاقة)',
        equation: 'Glucose + ATP —(Hexokinase + Mg²⁺)→ G6P + ADP',
        notesAr: 'إضافة مجموعة فوسفات تمنع الجلوكوز من الهروب عبر الغشاء الخلوي وتنشطه للدخول في التفاعلات التالية.',
        difficultyExplanation: {
          beginner: 'يتم حبس السكر داخل الخلية بإضافة شحنة فوسفات تمنعه من الخروج.',
          intermediate: 'إنزيم الهيكسوكيناز يستهلك 1 ATP لربط الفوسفات بذرة الكربون 6 في الجلوكوز لتكوين G6P.',
          advanced: 'تفاعل غير عكوس ذو ΔG° = -16.7 kJ/mol معتمد على المغنيسيوم Mg²⁺، يثبط بالتغذية الراجعة عبر ناتجه G6P.'
        }
      },
      {
        stepNumber: 2,
        titleAr: '2. شطر الفركتوز وإنتاج البيروفات (نهاية التحلل السكري)',
        reactants: ['فركتوز-1,6-ثنائي فوسفات', '4 ADP', '2 NAD⁺'],
        products: ['2 جزيء بيروفات (Pyruvate)', '4 ATP', '2 NADH'],
        enzyme: 'Phosphofructokinase (PFK-1) & Pyruvate Kinase',
        atpYield: '+4 ATP (صافي المرحلة +2 ATP)',
        equation: 'F-1,6-BP + 4ADP + 2NAD⁺ → 2 Pyruvate + 4ATP + 2NADH + 2H₂O',
        notesAr: 'مرحلة جني الطاقة في السيتوبلازم دون الحاجة إلى أكسجين، وإنتاج أول 2 ATP صافية و2 NADH.',
        difficultyExplanation: {
          beginner: 'ينشطر السكر إلى نصفين لإنتاج جزيئين من البيروفات مع توليد طاقة سريعة.',
          intermediate: 'إنزيم PFK-1 هو الصمام الرئيسي الحاكم لسرعة التحلل السكري بأكمله، وينتج بيروفات ينتقل للميتوكوندريا.',
          advanced: 'تحفيز خيفي للـ PFK-1 بواسطة F-2,6-BP وتثبيطه بمستويات ATP المرتفعة والسترات، مع فسفرة على مستوى الركيزة Substrate-Level Phosphorylation.'
        }
      },
      {
        stepNumber: 3,
        titleAr: '3. أكسدة البيروفات ودورة كريبس (دورة حمض الستريك)',
        reactants: ['2 بيروفات', '2 Coenzyme A', '6 NAD⁺', '2 FAD', '2 GDP'],
        products: ['6 CO₂ (يخرج بالزفير)', '2 Acetyl-CoA', '8 NADH', '2 FADH₂', '2 GTP (ATP)'],
        enzyme: 'Pyruvate Dehydrogenase Complex (PDH) & Citrate Synthase',
        atpYield: '+2 ATP / GTP مباشرة',
        equation: '2 Pyruvate + 8NAD⁺ + 2FAD + 2GDP → 6CO₂↑ + 8NADH + 2FADH₂ + 2GTP',
        notesAr: 'تحدث داخل حشوة الميتوكوندريا، وتنتزع ذرات الكربون على هيئة غاز CO₂ مع شحن النواقل الإلكترونية NADH و FADH₂ بأعلى طاقة.',
        difficultyExplanation: {
          beginner: 'تفكيك المركبات داخل الميتوكوندريا وإطلاق غاز ثاني أكسيد الكربون وشحن بطاريات الخلية.',
          intermediate: 'دورة دائرية تبدأ باتحاد أسيتيل كو-أ مع أوكسالوأسيتات لتكوين السترات وإنتاج كميات هائلة من النواقل الحاملة للإلكترونات.',
          advanced: 'تفاعلات نزع كربوكسيل تأكسدي Oxidative Decarboxylation متتالية، تنظمها إنزيمات Isocitrate Dehydrogenase و α-Ketoglutarate Dehydrogenase.'
        }
      },
      {
        stepNumber: 4,
        titleAr: '4. سلسلة نقل الإلكترونات وفسفرة التأكسد (ATP Synthase)',
        reactants: ['10 NADH', '2 FADH₂', '6 O₂ (من التنفس)', '34 ADP + Pi'],
        products: ['6 H₂O (ماء الأيض)', '32 إلى 34 جزيء طاقة ATP'],
        enzyme: 'Complexes I-IV & ATP Synthase (مضخة الطاقة الدورانية)',
        atpYield: '+34 ATP (التوليد الأعظم)',
        equation: '10NADH + 2FADH₂ + 6O₂ + 34ADP + 34Pi → 6H₂O + 34ATP + 10NAD⁺ + 2FAD',
        notesAr: 'تتدفق الإلكترونات إلى الأكسجين (المستقبل النهائي)، مما يضخ البروتونات عبر الغشاء لتشغيل محرك ATP Synthase الميكروي لإنتاج سيل هائل من الطاقة.',
        difficultyExplanation: {
          beginner: 'يصل الأكسجين الذي نتنفسه ليتحد مع الإلكترونات مشغلاً مصنع الطاقة الكبير لإنتاج معظم طاقة الجسم.',
          intermediate: 'تدرج كهروكيميائي للبروتونات H⁺ يدير الإنزيم الدوار ATP Synthase مثل التوربين لتخليق روابط ATP الفوسفاتية.',
          advanced: 'الاقتران الكيميائي الأسموزي Chemiosmosis لكلايس ميتشل: كل NADH ينتج حوالي 2.5 ATP وكل FADH₂ ينتج 1.5 ATP.'
        }
      }
    ]
  },

  // 2. Digestive System & Nutrient Breakdown
  {
    id: 'digestive-macronutrients',
    titleAr: 'هضم الكربوهيدرات والبروتينات والدهون وامتصاصها',
    categoryAr: 'كيمياء الجهاز الهضمي والإنزيمات الهاضمة',
    organType: 'digestive',
    organNameAr: 'الفم، المعدة، الاثني عشر، وبطانة الأمعاء الدقيقة',
    descriptionAr: 'تفكيك الجزيئات الغذائية الكبيرة المعقدة (النشا، اللحوم، الزيوت) بواسطة إنزيمات نوعية متدرجة لتسهيل امتصاصها عبر خملات الأمعاء إلى الدم.',
    steps: [
      {
        stepNumber: 1,
        titleAr: '1. هضم النشويات والكربوهيدرات (من الفم للأمعاء)',
        reactants: ['النشا والسكريات المعقدة', 'إنزيم الأميليز Amylase', 'ماء H₂O'],
        products: ['المالتوز والسكريات الثنائية', 'سكر الجلوكوز الأحادي C₆H₁₂O₆'],
        enzyme: 'Salivary & Pancreatic Amylase + Maltase',
        notesAr: 'يبدأ الهضم اللعابي بالفم عند pH 7، ثم يستكمل في الأمعاء بفعل أميليز البنكرياس لإنتاج الجلوكوز الجاهز للامتصاص بالناقل SGLT-1.',
        difficultyExplanation: {
          beginner: 'تفكك النشويات والخبز في اللعاب والأمعاء إلى سكر جلوكوز نقي يمتصه الدم.',
          intermediate: 'تكسير روابط ألفا (1→4) الجليكوسيدية بواسطة الأميليز ثم المالتيز في الحافة الفرجونية للأمعاء.',
          advanced: 'نقل نشط ثانوي للجلوكوز عبر SGLT1 بمصاحبة Na⁺ يعتمد على مضخة Na⁺/K⁺ ATPase ثم خروجه عبر GLUT2.'
        }
      },
      {
        stepNumber: 2,
        titleAr: '2. هضم البروتينات (حمض المعدة والببسين والتريبسين)',
        reactants: ['البروتينات المعقدة', 'حمض المعدة HCl', 'ببسينوجين Pepsinogen', 'تريبسين'],
        products: ['ببتيدات قصيرة', 'أحماض أمينية مفردة (Amino Acids)'],
        enzyme: 'Pepsin (في المعدة pH 1.5) و Trypsin/Chymotrypsin (في الأمعاء pH 8)',
        notesAr: 'يقوم حمض HCl بفرد السلاسل البروتينية وتنشيط الببسين، ثم تقوم إنزيمات البنكرياس في الاثني عشر بإنتاج أحماض أمينية تمتص لبناء عضلات وخلايا الجسم.',
        difficultyExplanation: {
          beginner: 'حمض المعدة والإنزيمات يفككون اللحوم والبيض إلى أحماض أمينية صغيرة لبناء الجسم.',
          intermediate: 'تكسير الروابط الببتيدية بواسطة الإندوببتيديز ثم الإكسوببتيديز لإنتاج أحماض أمينية حرة.',
          advanced: 'تنشيط متسلسل للزيموجينات Zymogens بإنزيم Enteropeptidase الذي يحول التريبسينوجين إلى تريبسين فعال.'
        }
      },
      {
        stepNumber: 3,
        titleAr: '3. استحلاب وهضم الدهون (أملاح المرارة وإنزيم الليباز)',
        reactants: ['ثلاثي الجليسريد (Triglycerides)', 'أملاح الصفراء Bile Salts', 'ليباز البنكرياس'],
        products: ['أحماض دهنية حرة (FFA)', 'أحادي الجليسريد 2-Monoglyceride', 'ميسيلات دهنية (Micelles)'],
        enzyme: 'Pancreatic Lipase & Colipase',
        notesAr: 'تفرز المرارة أملاح الصفراء لاستحلاب قطرات الدهن الكبيرة إلى مستحلب مجهري، فيعمل إنزيم الليباز على شطرها وامتصاصها للأوعية اللمفاوية (Lacteals).',
        difficultyExplanation: {
          beginner: 'الصفراء تذيب الدهون كالصابون لتمكين إنزيم الليباز من هضمها إلى زيوت دقيقة تدخل اللمف.',
          intermediate: 'تكوين ميسيلات دهنية مذيبة لتمكين امتصاص الفيتامينات الذائبة في الدهن (A, D, E, K).',
          advanced: 'إعادة أسترة الدهون داخل خلايا الأمعاء وتغليفها في كيلوميكرونات Chylomicrons لتنتقل عبر القناة الصدرية اللمفاوية.'
        }
      }
    ]
  },

  // 3. Respiratory & Blood Buffer
  {
    id: 'respiratory-hemoglobin-buffer',
    titleAr: 'كيمياء نقل الغازات (الهيموجلوبين ومنظومة درء pH الدم)',
    categoryAr: 'كيمياء الجهاز التنفسي والدم والأوعية',
    organType: 'respiratory',
    organNameAr: 'الحويصلات الهوائية بالرئتين والشعيرات الدموية بالأنسجة',
    descriptionAr: 'آلية تبادل الأكسجين وثاني أكسيد الكربون، وتأثير بوهر (Bohr Effect)، ومنظومة توازن حمض الكربونيك والبيكربونات للحفاظ على pH الدم بين 7.35 و 7.45.',
    steps: [
      {
        stepNumber: 1,
        titleAr: '1. ارتباط الأكسجين بالهيموجلوبين في الرئتين',
        reactants: ['Deoxyhemoglobin (Hb)', '4 جزيئات أكسجين 4O₂'],
        products: ['Oxyhemoglobin الزاهي (Hb(O₂)₄)'],
        equation: 'Hb (T-State) + 4O₂ ⇌ Hb(O₂)₄ (R-State أحمر قاني)',
        notesAr: 'في الرئة (ضغط O₂ عالي وpH قلوي)، يتحول الهيموجلوبين من الحالة المشدودة T إلى الحالة المرتخية R برباط تعاوني تآزري (Cooperativity).',
        difficultyExplanation: {
          beginner: 'كرات الدم الحمراء تلتقط 4 جزيئات أكسجين من الرئة ويصبح لون الدم أحمر فاتح.',
          intermediate: 'تأثير تعاوني: ارتباط أول جزيء O₂ يغير شكل الهيموجلوبين ويسهل ارتباط الجزيئات الثلاثة التالية.',
          advanced: 'تحول خيفي من الحالة Tense (T) منخفضة الألفة إلى Relaxed (R) عالية الألفة للأكسجين مع إزاحة 2,3-BPG.'
        }
      },
      {
        stepNumber: 2,
        titleAr: '2. تفكك الأكسجين في الأنسجة وتأثير بوهر (Bohr Effect)',
        reactants: ['Hb(O₂)₄', 'أيونات هيدروجين H⁺', 'غاز CO₂', '2,3-BPG'],
        products: ['Hb منزوع الأكسجين', '4 O₂ حرة تنتشر لخلايا الجسم'],
        notesAr: 'في الأنسجة المجهدة (تركيز CO₂ عالي وpH حامضي وحرارة أعلى)، تقل ألفة الهيموجلوبين للأكسجين فيتركه فوراً لتتغذى الخلايا.',
        difficultyExplanation: {
          beginner: 'عندما تبذل العضلات جهداً يطلق الهيموجلوبين الأكسجين إليها فوراً لتوليد الطاقة.',
          intermediate: 'تأثير بوهر: انخفاض pH وارتفاع CO₂ يرتبطان بالهيموجلوبين ويثبتان حالة T مما يجبره على تفريغ الأكسجين.',
          advanced: 'ارتباط بروتونات H⁺ ببقايا الهستيدين His-146 يكون جسوراً ملحية تثبت الحالة T وتحفز تفريغ O₂ بكفاءة.'
        }
      },
      {
        stepNumber: 3,
        titleAr: '3. منظومة درء حمض الكربونيك والبيكربونات (تنظيم pH الدم)',
        reactants: ['CO₂ (من الأنسجة)', 'ماء H₂O'],
        products: ['حمض الكربونيك H₂CO₃', 'أيون البيكربونات HCO₃⁻', 'بروتون H⁺'],
        enzyme: 'Carbonic Anhydrase (أسرع إنزيم في الجسم)',
        equation: 'CO₂ + H₂O ⇌ H₂CO₃ ⇌ H⁺ + HCO₃⁻',
        notesAr: 'التفاعل الحاكم لتوازن الحموضة والقلوية: ينقل 70% من CO₂ على هيئة بيكربونات ذائبة ويحافظ على حموضة الدم 7.40.',
        difficultyExplanation: {
          beginner: 'يحول الجسم غاز ثاني أكسيد الكربون إلى سائل غير ضار يحافظ على توازن حموضة الدم بدقة متناهية.',
          intermediate: 'إنزيم الكاربونيك أنهيدراز في كرات الدم الحمراء يحول CO₂ إلى بيكربونات، وتطرد الرئة CO₂ بالزفير لضبط الحموضة.',
          advanced: 'معادلة هندرسون-هاسلبالخ: pH = 6.1 + log([HCO₃⁻] / 0.03 × PaCO₂). التحكم الرئوي سريع والكلوي بطيء ودائم.'
        }
      }
    ]
  },

  // 4. Brain & Neurotransmitters
  {
    id: 'brain-neurotransmission',
    titleAr: 'كيمياء الدماغ وجهد الفعل والنواقل العصبية (Dopamine & Action Potential)',
    categoryAr: 'كيمياء الجهاز العصبي والمخ والمستقبلات',
    organType: 'brain',
    organNameAr: 'المشابك العصبية والمادة السوداء والقشرة المخية',
    descriptionAr: 'كيف تنتقل الرسائل العصبية والأفكار والمشاعر عبر قنوات الصوديوم والبوتاسيوم وتخليق الدوبامين والسيروتونين والأستيل كولين.',
    steps: [
      {
        stepNumber: 1,
        titleAr: '1. جهد الفعل العصبي وتدفق الأيونات (Na⁺ / K⁺ Pumps)',
        reactants: ['أيونات الصوديوم Na⁺ بالخارج', 'أيونات البوتاسيوم K⁺ بالداخل', 'طاقة ATP'],
        products: ['زوال الاستقطاب Depolarization (+30 mV)', 'انتقال السيال العصبي'],
        enzyme: 'Na⁺/K⁺ ATPase Pump & Voltage-Gated Channels',
        equation: '3 Na⁺(out) + 2 K⁺(in) + ATP → Resting Potential (-70 mV)',
        notesAr: 'تفتح قنوات الصوديوم ليدخل سيل من Na⁺ يغير الشحنة من -70 إلى +30 ملي فولت لنقل الإشارة العصبية بسرعة 100 متر/ثانية.',
        difficultyExplanation: {
          beginner: 'تدفق سريع لأيونات الصوديوم والبوتاسيوم يولد شحنة كهربائية تنقل الأوامر من الدماغ إلى الجسم.',
          intermediate: 'مضخة الصوديوم والبوتاسيوم تحافظ على جهد الراحة -70mV، وعند التحفيز تفتح قنوات الصوديوم لإزالة الاستقطاب.',
          advanced: 'دورة هودجكين: تدفق تضخيمي للـ Na⁺ يتبعه فتح قنوات K⁺ المتأخرة لإعادة الاستقطاب وفترة جموح Refractory Period.'
        }
      },
      {
        stepNumber: 2,
        titleAr: '2. تخليق وانطلاق الدوبامين (Dopamine Synapse)',
        reactants: ['الحمض الأميني L-Tyrosine', 'L-DOPA', 'تدفق أيونات Ca²⁺'],
        products: ['الدوبامين C₈H₁₁NO₂', 'تنشيط مستقبلات D1 و D2 في الشق المشبكي'],
        enzyme: 'Tyrosine Hydroxylase & DOPA Decarboxylase',
        equation: 'Tyrosine → L-DOPA → Dopamine (تخزين في الحويصلات المشبكية)',
        notesAr: 'المسؤول عن الشعور بالمكافأة، التحفيز، وتنسيق الحركة. موته في المادة السوداء يسبب مرض باركنسون.',
        difficultyExplanation: {
          beginner: 'ناقل المكافأة والسرور والتحكم بالحركة، يُصنع من حمض أميني ويفرز عند تحقيق إنجاز.',
          intermediate: 'عند وصول جهد الفعل تتدفق أيونات الكالسيوم لتفرغ حويصلات الدوبامين في الشق المشبكي.',
          advanced: 'الخطوة المحددة للسرعة هي هيدروكسيلاز التيروزين؛ يعاد امتصاصه عبر DAT أو يثبط بإنزيم MAO-B و COMT.'
        }
      }
    ]
  },

  // 5. Muscle Contraction
  {
    id: 'muscle-contraction-actin-myosin',
    titleAr: 'كيمياء الانقباض العضلي وانزلاق خيوط الأكتين والمايوسين',
    categoryAr: 'كيمياء العضلات والجهد الحركي',
    organType: 'muscle',
    organNameAr: 'الخلايا العضلية والشبكة الساركوبلازمية (Sarcomere)',
    descriptionAr: 'تحويل الطاقة الكيميائية ATP إلى حركة ميكانيكية حقيقية عبر تحرير أيونات الكالسيوم وارتباط رؤوس المايوسين بالأكتين.',
    steps: [
      {
        stepNumber: 1,
        titleAr: '1. انطلاق الكالسيوم وارتباطه بالتروبونين C',
        reactants: ['أيونات الكالسيوم Ca²⁺ من الشبكة الساركوبلازمية', 'معقد التروبونين والتروبومايوسين'],
        products: ['كشف مواقع الارتباط على خيوط الأكتين'],
        notesAr: 'تحرر Ca²⁺ يزيح خيوط التروبومايوسين الحارسة، كاشفاً النقاط النشطة على الأكتين لتلتصق بها رؤوس المايوسين.',
        difficultyExplanation: {
          beginner: 'تطلق الخلية العضلية الكالسيوم مثل المفتاح الذي يفتح قفل العضلة لتستعد للحركة.',
          intermediate: 'ارتباط الكالسيوم بالتروبونين-C يغير تشكيله الفراغي فيزيح التروبومايوسين عن رؤوس الأكتين.',
          advanced: 'تنشيط مستقبلات الريانودين RyR1 في الشبكة الساركوبلازمية عبر مستقبلات DHPR الأنبوبية T-Tubules.'
        }
      },
      {
        stepNumber: 2,
        titleAr: '2. ضربة القوة واستهلاك ATP (Cross-Bridge Power Stroke)',
        reactants: ['رؤوس المايوسين المشحونة', 'خيوط الأكتين', 'جزيئات ATP'],
        products: ['انزلاق الخيوط وقصر القطعة العضلية', 'انقباض وقوة ميكانيكية', 'ADP + Pi'],
        enzyme: 'Myosin ATPase',
        equation: 'Actin + Myosin-ATP → Actomyosin Crossbridge + ADP + Pi (ضربة القوة Power Stroke)',
        notesAr: 'تنحني رؤوس المايوسين ساحبة خيوط الأكتين نحو المنتصف، ويلزم ارتباط جزيء ATP جديد لفك الرابطة واسترخاء العضلة.',
        difficultyExplanation: {
          beginner: 'رؤوس المايوسين تشد خيوط الأكتين مثل التجديف في القارب مستهلكة ATP لقصر العضلة.',
          intermediate: 'انحناء رأس المايوسين بزاوية 45 درجة يولد ضربة القوة، وانعدام ATP بعد الوفاة يسبب التيبس الموتي Rigor Mortis.',
          advanced: 'دورة الجسور العرضية: حلمهة ATP إلى ADP+Pi تنشط الرأس؛ إطلاق Pi يولد ضربة القوة Power Stroke.'
        }
      }
    ]
  },

  // 6. Blood Clotting Cascade
  {
    id: 'blood-clotting-cascade',
    titleAr: 'شلال تخثر الدم وتحول الفيبرينوجين إلى شبكة فيبرين صلبة',
    categoryAr: 'كيمياء الدم وأمراض التخثر والإرقاء',
    organType: 'blood',
    organNameAr: 'بلازما الدم والصفائح الدموية في موضع الجرح الوعائي',
    descriptionAr: 'شلال تضخيمي كيميائي فوري يحول بلازما الدم السائلة إلى سدادة صلبة وشبكة فيبرين غير ذائبة لوقف النزيف وإنقاذ الحياة.',
    steps: [
      {
        stepNumber: 1,
        titleAr: '1. تنشيط العامل العاشر وتحول البروثرومبين إلى ثرومبين',
        reactants: ['عامل التخثر X النشط (Xa)', 'عامل التخثر V', 'البروثرومبين (Factor II)', 'أيونات Ca²⁺'],
        products: ['إنزيم الثرومبين النشط (Thrombin - Factor IIa)'],
        enzyme: 'Prothrombinase Complex',
        equation: 'Prothrombin (II) —(Factor Xa + Va + Ca²⁺)→ Thrombin (IIa)',
        notesAr: 'نقطة الالتقاء للمسارين الداخلي والخارجي، حيث ينتج إنزيم الثرومبين الفعال القادر على حلمهة مئات جزيئات الفيبرينوجين.',
        difficultyExplanation: {
          beginner: 'تتفاعل بروتينات التخثر عند حدوث جرح لتنشيط إنزيم الثرومبين القوي.',
          intermediate: 'معقد البروثرومبيناز يحول البروثرومبين غير النشط إلى ثرومبين نشط بوجود الكالسيوم والدهون الفوسفورية.',
          advanced: 'العامل Xa ينشط بالمسار الخارجي (Tissue Factor-VIIa) أو الداخلي (IXa-VIIIa)، ويعتمد إنتاج عوامل التخثر على فيتامين K.'
        }
      },
      {
        stepNumber: 2,
        titleAr: '2. بلمرة الفيبرين وتكوين الشبكة المتماسكة (Fibrin Mesh)',
        reactants: ['الفيبرينوجين الذائب Fibrinogen', 'إنزيم الثرومبين Thrombin', 'العامل XIIIa المثبت'],
        products: ['شبكة الفيبرين غير الذائبة الصلبة', 'جلطة دموية متماسكة تحبس الصفائح'],
        enzyme: 'Thrombin & Factor XIIIa (Fibrin Stabilizing Factor)',
        equation: 'Fibrinogen —(Thrombin)→ Fibrin Monomer → Fibrin Polymer Mesh (غير ذائب)',
        notesAr: 'يقص الثرومبين الأطراف السالبة للفيبرينوجين فتتجمع الخيوط وتترابط تساهمياً بفعل العامل XIII مكونة شبكة متينة.',
        difficultyExplanation: {
          beginner: 'يتحول السائل في الدم إلى شبكة خيوط متينة تسد الجرح وتوقف النزيف فوراً.',
          intermediate: 'الثرومبين يقص ببتيدات الفيبرينوجين لتتجمع مونومرات الفيبرين في ألياف غير ذائبة.',
          advanced: 'تكوين روابط ببتيدية متصالبة بين بقايا الجلوتامين واللايسين بواسطة الترانسجلوتاميناز (العامل XIIIa).'
        }
      }
    ]
  },

  // 7. Molecular Genetics: DNA to Protein
  {
    id: 'dna-transcription-translation',
    titleAr: 'تخليق البروتين: من الشفرة الوراثية DNA إلى النسخ mRNA والترجمة',
    categoryAr: 'كيمياء الوراثة الجزيئية والبيولوجيا الخلوية',
    organType: 'dna',
    organNameAr: 'نواة الخلية والريبوسومات في السيتوبلازم',
    descriptionAr: 'المسار المركزي في البيولوجيا الجزيئية (Central Dogma): نسخ الجين من DNA إلى شريط mRNA ثم ترجمته في الريبوسوم إلى بروتينات حية.',
    steps: [
      {
        stepNumber: 1,
        titleAr: '1. النسخ الجيني (Transcription in Nucleus)',
        reactants: ['شريط الحمض النووي DNA', 'إنزيم RNA Polymerase', 'نيوكليوتيدات ATP, UTP, CTP, GTP'],
        products: ['شريط الرنا الرسول الأولي (mRNA)', 'إعادة غلق شريط DNA'],
        enzyme: 'RNA Polymerase II',
        equation: 'DNA Gene —(RNA Polymerase II)→ pre-mRNA + PPi',
        notesAr: 'يقرأ الإنزيم شفرات القواعد النيتروجينية A-T-C-G ويصنع نسخة مكملة A-U-C-G تغادر النواة نحو السيتوبلازم.',
        difficultyExplanation: {
          beginner: 'يتم نسخ كتيب التعليمات الوراثية من النواة في ورقة رسول mRNA صغيرة.',
          intermediate: 'إنزيم بلمرة RNA ينسخ الشريط القالب Template من اتجاه 3′ إلى 5′ لبناء mRNA باتجاه 5′ إلى 3′.',
          advanced: 'ربط عوامل النسخ Transcription Factors بمنطقة المحفز Promoter TATA-box يتبعه معالجة بإضافة 5′-Cap وتذييل Poly-A والتضفير Splicing.'
        }
      },
      {
        stepNumber: 2,
        titleAr: '2. الترجمة في الريبوسوم وتكوين سلسلة البروتين (Translation)',
        reactants: ['شريط mRNA', 'ريبوسومات (Ribosomes)', 'جزيئات tRNA محملة بالأحماض الأمينية', 'طاقة GTP'],
        products: ['سلسلة ببتيدية متتالية (Functional Protein)'],
        enzyme: 'Peptidyl Transferase (ريبوزيم الريبوسوم)',
        equation: 'mRNA Codons + Aminoacyl-tRNAs —(Ribosome + GTP)→ Polypeptide Chain',
        notesAr: 'يقرأ الريبوسوم كودونات الثلاثيات (Codons)، ويجلب tRNA الحمض الأميني المناسب لربطه في سلسلة البروتين النامي.',
        difficultyExplanation: {
          beginner: 'يقرأ مصنع الريبوسوم الشفرات ويجمع الأحماض الأمينية مثل حبات العقد لتكوين البروتين.',
          intermediate: 'الترجمة تمر بثلاث مراحل: البدء (AUG للميثيونين)، الاستطالة بروابط ببتيدية، والإنهاء بكودون توقف (UAA, UAG, UGA).',
          advanced: 'نشاط إنزيمي في الموقع A و P و E للريبوسوم، يعتمد على حلمهة GTP في عوامل EF-Tu و EF-G لنقل السلسلة الببتيدية.'
        }
      }
    ]
  }
];

export function BiochemistryLabSuite() {
  const [activeTab, setActiveTab] = useState<'pathways' | 'workbench' | 'kinetics' | 'body3d' | 'quiz'>('pathways');
  const [selectedPathway, setSelectedPathway] = useState<BiochemicalPathway>(BIOCHEM_PATHWAYS[0]);
  const [currentStepIndex, setCurrentStepIndex] = useState<number>(0);
  const [explanationLevel, setExplanationLevel] = useState<'beginner' | 'intermediate' | 'advanced'>('intermediate');
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [playbackSpeed, setPlaybackSpeed] = useState<number>(1);
  const [selectedCategoryFilter, setSelectedCategoryFilter] = useState<string>('all');

  // Enzyme Kinetics State
  const [substrateConc, setSubstrateConc] = useState<number>(10); // mmol/L
  const [enzymeConc, setEnzymeConc] = useState<number>(1); // Relative
  const [temperature, setTemperature] = useState<number>(37); // Celsius
  const [phValue, setPhValue] = useState<number>(7.4);
  const [inhibitorType, setInhibitorType] = useState<'none' | 'competitive' | 'noncompetitive'>('none');

  // Quiz State
  const [quizIndex, setQuizIndex] = useState<number>(0);
  const [selectedQuizAnswer, setSelectedQuizAnswer] = useState<number | null>(null);
  const [quizScore, setQuizScore] = useState<number>(0);
  const [quizSubmitted, setQuizSubmitted] = useState<boolean>(false);

  // Workbench Custom Experiment State
  const [workbenchSubstrate, setWorkbenchSubstrate] = useState<string>('جلوكوز C₆H₁₂O₆');
  const [workbenchEnzyme, setWorkbenchEnzyme] = useState<string>('Hexokinase');
  const [workbenchTemp, setWorkbenchTemp] = useState<number>(37);
  const [workbenchPh, setWorkbenchPh] = useState<number>(7.4);
  const [experimentRunning, setExperimentRunning] = useState<boolean>(false);
  const [experimentResult, setExperimentResult] = useState<any>(null);

  // 3D Model view selected organ
  const [selected3DOrgan, setSelected3DOrgan] = useState<string>('mitochondria');

  // Time scrubber autoplay effect
  useEffect(() => {
    let timer: any;
    if (isPlaying) {
      const delay = Math.max(800, 3000 / playbackSpeed);
      timer = setTimeout(() => {
        if (currentStepIndex < selectedPathway.steps.length - 1) {
          setCurrentStepIndex(prev => prev + 1);
        } else {
          setIsPlaying(false);
          try {
            confetti({ particleCount: 40, spread: 50 });
          } catch {}
        }
      }, delay);
    }
    return () => clearTimeout(timer);
  }, [isPlaying, currentStepIndex, selectedPathway, playbackSpeed]);

  // Enzyme kinetics Michaelis-Menten calculation
  const kineticsData = useMemo(() => {
    let Km = 5; // mmol/L
    let Vmax = 100 * enzymeConc;

    if (inhibitorType === 'competitive') {
      Km = Km * 2.5; // Km increases
    } else if (inhibitorType === 'noncompetitive') {
      Vmax = Vmax * 0.5; // Vmax decreases
    }

    // Temperature factor (optimum at 37°C, denaturation at >55°C)
    let tempFactor = 1.0;
    if (temperature <= 37) {
      tempFactor = Math.pow(2, (temperature - 37) / 10);
    } else if (temperature <= 55) {
      tempFactor = 1.0 - (temperature - 37) * 0.03;
    } else {
      tempFactor = Math.max(0, 0.46 - (temperature - 55) * 0.05); // Rapid denaturation
    }

    // pH factor (bell-shaped around 7.4)
    const phDeviation = Math.abs(phValue - 7.4);
    const phFactor = Math.max(0.05, 1 - Math.pow(phDeviation / 3.5, 2));

    const finalVmax = Vmax * tempFactor * phFactor;
    const velocity = (finalVmax * substrateConc) / (Km + substrateConc);

    return {
      Km: Math.round(Km * 10) / 10,
      Vmax: Math.round(finalVmax * 10) / 10,
      velocity: Math.max(0, Math.round(velocity * 10) / 10),
      isDenatured: temperature > 58,
      isPhInactivated: phValue < 3.5 || phValue > 11.5
    };
  }, [substrateConc, enzymeConc, temperature, phValue, inhibitorType]);

  const BIOCHEM_QUIZZES = [
    {
      question: 'كم يبلغ صافي جزيئات الطاقة ATP الناتجة عن أكسدة جزيء جلوكوز كامل بالتنفس الخلوي الهوائي؟',
      options: ['2 إلى 4 ATP', '12 إلى 14 ATP', '36 إلى 38 ATP', '100 ATP'],
      correct: 2,
      explanation: 'ينتج التحلل السكري 2 ATP، ودورة كريبس 2 ATP، وسلسلة نقل الإلكترون 32-34 ATP ليصل المجموع الصافي إلى 36-38 ATP.'
    },
    {
      question: 'ما هو الإنزيم الرئيسي المسؤول عن تحويل الفيبرينوجين إلى شبكة فيبرين غير ذائبة في تخثر الدم؟',
      options: ['الأميليز (Amylase)', 'الثرومبين (Thrombin)', 'البيبسين (Pepsin)', 'اللاكتات ديهيدروجيناز (LDH)'],
      correct: 1,
      explanation: 'يقوم إنزيم الثرومبين (Factor IIa) بحلمهة الفيبرينوجين لإنتاج خيوط الفيبرين التي تكون الجلطة الدموية.'
    },
    {
      question: 'وفقاً لتأثير بوهر (Bohr Effect)، ماذا يحدث لألفة الهيموجلوبين للأكسجين عند انخفاض pH وارتفاع CO₂ في الأنسجة؟',
      options: [
        'تنخفض الألفة فيتحرر الأكسجين فوراً للخلايا',
        'ترتفع الألفة ويحبس الأكسجين بقوة',
        'يتحول الهيموجلوبين إلى جلوكوز',
        'لا يحدث أي تأثير'
      ],
      correct: 0,
      explanation: 'انخفاض pH وارتفاع حمض الكربونيك وCO₂ يقلل ألفة الهيموجلوبين للأكسجين مما يحفزه على تفريغه للأنسجة المجهدة.'
    },
    {
      question: 'في علم الوراثة الجزيئية، أي عضية خلوية مسؤولة عن ترجمة شريط mRNA وتخليق سلسلة الأحماض الأمينية؟',
      options: ['الريبوسوم (Ribosome)', 'الغشاء الخلوي', 'حويصلات جولجي', 'الليسوسوم'],
      correct: 0,
      explanation: 'الريبوسوم هو مصنع تخليق البروتين حيث يقرأ كودونات mRNA ويستقبل جزيئات tRNA المحملة بالأحماض الأمينية.'
    }
  ];

  const handleRunWorkbenchExperiment = () => {
    setExperimentRunning(true);
    setExperimentResult(null);

    setTimeout(() => {
      let isSuccess = true;
      let atpDelta = '+2 ATP';
      let speedRating = 'طبيعي ونشط';
      let statusText = 'تم تحفيز التفاعل الكيميائي بنجاح وإنتاج المركبات الأيضية المطلوبة.';

      if (workbenchTemp > 55) {
        isSuccess = false;
        speedRating = 'متوقف (تخثر حراري)';
        statusText = 'فشل التفاعل: حدث تمسخ وتخثر حراري (Denaturation) لبروتين الإنزيم بسبب الحرارة العالية.';
        atpDelta = '0 ATP';
      } else if (workbenchPh < 4 || workbenchPh > 10.5) {
        isSuccess = false;
        speedRating = 'متوقف (تأين شاذ)';
        statusText = 'فشل التفاعل: بيئة الـ pH خارج النطاق الفسيولوجي الملائم لعمل هذا الإنزيم.';
        atpDelta = '0 ATP';
      }

      setExperimentResult({
        isSuccess,
        substrate: workbenchSubstrate,
        enzyme: workbenchEnzyme,
        product: isSuccess ? 'جلوكوز-6-فوسفات (G6P) + ADP' : 'لا توجد نواتج (تفاعل معطل)',
        atpYield: atpDelta,
        speedRating,
        statusText,
        energyReleased: isSuccess ? '2870 kJ/mol' : '0 kJ/mol'
      });
      setExperimentRunning(false);

      if (isSuccess) {
        try {
          confetti({ particleCount: 35, spread: 45 });
        } catch {}
      }
    }, 600);
  };

  const currentStep = selectedPathway.steps[currentStepIndex] || selectedPathway.steps[0];

  return (
    <div className="w-full max-w-6xl mx-auto space-y-6">
      {/* Top Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-teal-900 via-slate-900 to-indigo-950 text-white border border-teal-800/50 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-80 h-80 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 rounded-2xl bg-teal-500/20 border border-teal-400/30 flex items-center justify-center text-teal-300 shadow-inner">
                <Dna className="w-6 h-6" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h1 className="text-xl sm:text-2xl font-black text-white">
                    🧬 BioChem Lab — مختبر الكيمياء الحيوية وتفاعلات جسم الإنسان
                  </h1>
                  <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-teal-500/30 text-teal-200 border border-teal-400/30">
                    مختبر تفاعلي ثلاثي الأبعاد
                  </span>
                </div>
                <p className="text-xs sm:text-sm text-teal-200/80 mt-0.5">
                  استكشف المسارات الكيميائية الحيوية والأيضية من مستوى الجسم والأعضاء إلى الخلية والإنزيمات والجزيئات.
                </p>
              </div>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start md:self-auto">
            <span className="px-3 py-1.5 rounded-xl bg-white/10 border border-white/15 text-xs font-bold text-teal-200 flex items-center gap-1.5">
              <Atom className="w-4 h-4 text-amber-400" />
              <span>محرك كيميائي نشط</span>
            </span>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex items-center gap-2 overflow-x-auto pt-6 border-t border-white/10 mt-6 scrollbar-none">
          {[
            { id: 'pathways', label: 'المسارات الحيوية (Pathways)', icon: Layers },
            { id: 'kinetics', label: 'حركية الإنزيمات (Enzyme Kinetics)', icon: Sliders },
            { id: 'workbench', label: 'مختبر جرب بنفسك (Workbench)', icon: FlaskConical },
            { id: 'body3d', label: 'مستكشف الأعضاء والخلايا 3D', icon: Maximize2 },
            { id: 'quiz', label: 'الاختبار والتحدي (Quiz)', icon: Award },
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`px-4 py-2 rounded-xl text-xs sm:text-sm font-black transition flex items-center gap-2 shrink-0 ${
                  isActive
                    ? 'bg-teal-500 text-gray-950 shadow-lg shadow-teal-500/30'
                    : 'bg-white/5 hover:bg-white/10 text-teal-100 border border-white/10'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{tab.label}</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* TAB 1: BIOCHEMICAL PATHWAYS EXPLORER */}
      {activeTab === 'pathways' && (
        <div className="space-y-6">
          {/* Organ Filter Pills */}
          <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-none">
            {[
              { id: 'all', label: 'جميع المسارات (All)' },
              { id: 'energy', label: '⚡ الطاقة و ATP' },
              { id: 'digestive', label: '🍽️ الجهاز الهضمي' },
              { id: 'respiratory', label: '🫁 التنفس والدم' },
              { id: 'brain', label: '🧠 الدماغ والنواقل' },
              { id: 'muscle', label: '💪 العضلات والانقباض' },
              { id: 'blood', label: '🩸 تخثر الدم' },
              { id: 'dna', label: '🧬 DNA والبروتين' },
            ].map((filt) => (
              <button
                key={filt.id}
                onClick={() => {
                  setSelectedCategoryFilter(filt.id);
                  const matched = BIOCHEM_PATHWAYS.find(p => filt.id === 'all' || p.organType === filt.id);
                  if (matched) {
                    setSelectedPathway(matched);
                    setCurrentStepIndex(0);
                    setIsPlaying(false);
                  }
                }}
                className={`px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
                  selectedCategoryFilter === filt.id
                    ? 'bg-teal-600 text-white shadow-md'
                    : 'bg-white dark:bg-gray-900 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-800 hover:border-teal-400'
                }`}
              >
                {filt.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Left: Pathways Selector (4 cols) */}
            <div className="lg:col-span-4 space-y-3">
              <h3 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
                <FlaskConical className="w-4 h-4 text-teal-600" />
                <span>اختر المسار الكيميائي الحيوي:</span>
              </h3>

              <div className="space-y-2 max-h-[600px] overflow-y-auto pr-1">
                {BIOCHEM_PATHWAYS.filter(p => selectedCategoryFilter === 'all' || p.organType === selectedCategoryFilter).map((pathway) => {
                  const isSelected = selectedPathway.id === pathway.id;
                  return (
                    <button
                      key={pathway.id}
                      onClick={() => {
                        setSelectedPathway(pathway);
                        setCurrentStepIndex(0);
                        setIsPlaying(false);
                      }}
                      className={`w-full text-right p-4 rounded-2xl border transition-all text-xs flex flex-col gap-2 ${
                        isSelected
                          ? 'bg-teal-50 dark:bg-teal-950/40 border-teal-500 shadow-md ring-2 ring-teal-500/20'
                          : 'bg-white dark:bg-gray-900 border-gray-200 dark:border-gray-800 hover:border-teal-300 text-gray-700 dark:text-gray-300'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-extrabold text-sm text-gray-900 dark:text-white">
                          {pathway.titleAr}
                        </span>
                        {pathway.totalAtpYield && (
                          <span className="px-2 py-0.5 rounded text-[10px] font-black bg-amber-100 dark:bg-amber-900/60 text-amber-800 dark:text-amber-300 shrink-0">
                            {pathway.totalAtpYield}
                          </span>
                        )}
                      </div>
                      <span className="text-[11px] text-gray-500 dark:text-gray-400">
                        📍 الموقع: {pathway.organNameAr}
                      </span>
                      <div className="flex items-center justify-between text-[10px] text-teal-700 dark:text-teal-400 font-bold">
                        <span>{pathway.steps.length} خطوات تفاعلية</span>
                        <span>{pathway.categoryAr}</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Right: Step-by-Step Interactive Pathway (8 cols) */}
            <div className="lg:col-span-8 space-y-5">
              {/* Pathway Header Card & Time Controller */}
              <div className="p-6 sm:p-7 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-gray-100 dark:border-gray-800 pb-4">
                  <div>
                    <h2 className="text-base sm:text-lg font-black text-gray-900 dark:text-white">
                      {selectedPathway.titleAr}
                    </h2>
                    <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
                      {selectedPathway.descriptionAr}
                    </p>
                  </div>

                  {/* Explanation Level Selector */}
                  <div className="flex items-center gap-1 bg-gray-100 dark:bg-gray-800 p-1 rounded-xl shrink-0 self-start sm:self-auto">
                    {[
                      { id: 'beginner', label: '🟢 مبسط' },
                      { id: 'intermediate', label: '🟡 متوسط' },
                      { id: 'advanced', label: '🔴 متقدم' },
                    ].map((lvl) => (
                      <button
                        key={lvl.id}
                        onClick={() => setExplanationLevel(lvl.id as any)}
                        className={`px-2.5 py-1 rounded-lg text-xs font-bold transition ${
                          explanationLevel === lvl.id
                            ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-xs'
                            : 'text-gray-600 dark:text-gray-400 hover:text-gray-900'
                        }`}
                      >
                        {lvl.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Timeline Scrubber & Step Pills */}
                <div className="space-y-3">
                  <div className="flex items-center justify-between text-xs font-bold text-gray-700 dark:text-gray-300">
                    <span>خطوات المسار ({currentStepIndex + 1} من {selectedPathway.steps.length})</span>
                    <span className="font-mono text-teal-600 dark:text-teal-400">{Math.round(((currentStepIndex + 1) / selectedPathway.steps.length) * 100)}% مكتمل</span>
                  </div>

                  {/* Progress Bar with Steps */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                    {selectedPathway.steps.map((step, idx) => {
                      const isCurrent = idx === currentStepIndex;
                      const isPassed = idx < currentStepIndex;
                      return (
                        <button
                          key={idx}
                          onClick={() => {
                            setCurrentStepIndex(idx);
                            setIsPlaying(false);
                          }}
                          className={`p-2.5 rounded-xl border text-right transition-all text-xs ${
                            isCurrent
                              ? 'bg-teal-600 text-white border-teal-600 shadow-md ring-2 ring-teal-500/20'
                              : isPassed
                              ? 'bg-teal-50 dark:bg-teal-950/30 border-teal-300 dark:border-teal-900 text-teal-800 dark:text-teal-300'
                              : 'bg-gray-50 dark:bg-gray-800/40 border-gray-200 dark:border-gray-800 text-gray-500'
                          }`}
                        >
                          <div className="font-black text-[11px]">خطوة {step.stepNumber}</div>
                          <div className="truncate text-[10px] opacity-90">{step.titleAr.replace(/^\d+\.\s*/, '')}</div>
                        </button>
                      );
                    })}
                  </div>

                  {/* Time Playback Controls */}
                  <div className="flex items-center justify-between bg-gray-50 dark:bg-gray-950/60 p-3 rounded-2xl border border-gray-200 dark:border-gray-800">
                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => setIsPlaying(!isPlaying)}
                        className="px-3.5 py-1.5 rounded-xl bg-teal-600 hover:bg-teal-700 text-white text-xs font-black transition flex items-center gap-1.5 shadow-sm"
                      >
                        {isPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5 fill-current" />}
                        <span>{isPlaying ? 'إيقاف مؤقت' : 'تشغيل المسار آلياً'}</span>
                      </button>

                      <button
                        onClick={() => {
                          setCurrentStepIndex(0);
                          setIsPlaying(false);
                        }}
                        className="p-2 rounded-xl bg-gray-200 dark:bg-gray-800 hover:bg-gray-300 text-gray-700 dark:text-gray-300 text-xs font-bold"
                        title="إعادة للبداية"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    {/* Speed Selector */}
                    <div className="flex items-center gap-1 text-xs">
                      <span className="text-gray-500 text-[11px] ml-1">السرعة:</span>
                      {[0.5, 1, 2].map((spd) => (
                        <button
                          key={spd}
                          onClick={() => setPlaybackSpeed(spd)}
                          className={`px-2 py-0.5 rounded-md font-mono text-[11px] font-bold ${
                            playbackSpeed === spd
                              ? 'bg-teal-600 text-white'
                              : 'bg-gray-200 dark:bg-gray-800 text-gray-600 dark:text-gray-400'
                          }`}
                        >
                          {spd}x
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              </div>

              {/* Active Step Detailed Showcase */}
              <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-gray-900 to-gray-950 text-white border border-gray-800 shadow-2xl space-y-6">
                <div className="flex items-center justify-between border-b border-gray-800 pb-3">
                  <div className="flex items-center gap-2">
                    <span className="w-8 h-8 rounded-full bg-teal-500 text-gray-950 font-black text-sm flex items-center justify-center">
                      {currentStep.stepNumber}
                    </span>
                    <h3 className="text-base sm:text-lg font-black text-teal-300">
                      {currentStep.titleAr}
                    </h3>
                  </div>

                  {currentStep.atpYield && (
                    <span className="px-3 py-1 rounded-xl text-xs font-black bg-amber-950 text-amber-300 border border-amber-800 flex items-center gap-1">
                      <Zap className="w-3.5 h-3.5 text-amber-400" />
                      <span>{currentStep.atpYield}</span>
                    </span>
                  )}
                </div>

                {/* Chemical Equation Box */}
                {currentStep.equation && (
                  <div className="p-4 rounded-2xl bg-gray-800/80 border border-gray-700 space-y-1">
                    <span className="text-[11px] text-gray-400 block font-semibold">المعادلة الكيميائية للمرحلة:</span>
                    <div className="font-mono text-sm sm:text-base font-bold text-teal-300 dir-ltr text-left">
                      {currentStep.equation}
                    </div>
                  </div>
                )}

                {/* Reactants vs Products Visual Grid */}
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="p-4 rounded-2xl bg-gray-800/50 border border-gray-700/60 space-y-2">
                    <span className="text-xs font-bold text-rose-400 block">المواد المتفاعلة والركائز (Reactants):</span>
                    <ul className="space-y-1.5 text-xs text-gray-200">
                      {currentStep.reactants.map((r, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-rose-500 shrink-0" />
                          <span>{r}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <div className="p-4 rounded-2xl bg-gray-800/50 border border-gray-700/60 space-y-2">
                    <span className="text-xs font-bold text-emerald-400 block">النواتج الحيوية المتكونة (Products):</span>
                    <ul className="space-y-1.5 text-xs text-gray-200">
                      {currentStep.products.map((p, i) => (
                        <li key={i} className="flex items-center gap-2">
                          <span className="w-2 h-2 rounded-full bg-emerald-500 shrink-0" />
                          <span>{p}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                {/* Enzyme Info */}
                {currentStep.enzyme && (
                  <div className="p-3.5 rounded-2xl bg-indigo-950/60 border border-indigo-800/60 flex items-center justify-between text-xs">
                    <span className="text-indigo-300 font-bold flex items-center gap-1.5">
                      <Dna className="w-4 h-4 text-indigo-400" />
                      <span>الإنزيم المحفز:</span>
                    </span>
                    <span className="font-mono text-white font-black bg-indigo-900/80 px-2.5 py-1 rounded-lg border border-indigo-700">
                      {currentStep.enzyme}
                    </span>
                  </div>
                )}

                {/* Multi-Level Explanation Box */}
                <div className="p-4 rounded-2xl bg-teal-950/40 border border-teal-800/60 text-xs sm:text-sm text-teal-100 leading-relaxed space-y-2">
                  <div className="font-bold flex items-center gap-2 text-teal-300">
                    <Sparkles className="w-4 h-4" />
                    <span>
                      الشرح العلمي ({explanationLevel === 'beginner' ? 'المبسط' : explanationLevel === 'intermediate' ? 'المتوسط' : 'المتقدم الجزيئي'}):
                    </span>
                  </div>
                  <p>{currentStep.difficultyExplanation[explanationLevel]}</p>
                </div>

                {/* Next / Previous Step Buttons */}
                <div className="flex items-center justify-between pt-2 border-t border-gray-800">
                  <button
                    disabled={currentStepIndex === 0}
                    onClick={() => setCurrentStepIndex(prev => Math.max(0, prev - 1))}
                    className="px-4 py-2 rounded-xl bg-gray-800 hover:bg-gray-700 disabled:opacity-30 text-xs font-bold transition flex items-center gap-1.5"
                  >
                    <ChevronRight className="w-4 h-4" />
                    <span>الخطوة السابقة</span>
                  </button>

                  <button
                    disabled={currentStepIndex === selectedPathway.steps.length - 1}
                    onClick={() => setCurrentStepIndex(prev => Math.min(selectedPathway.steps.length - 1, prev + 1))}
                    className="px-5 py-2 rounded-xl bg-teal-600 hover:bg-teal-700 disabled:opacity-30 text-xs font-black text-white transition flex items-center gap-1.5 shadow-lg shadow-teal-500/20"
                  >
                    <span>الخطوة التالية</span>
                    <ChevronLeft className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 2: ENZYME KINETICS SIMULATOR (Michaelis-Menten) */}
      {activeTab === 'kinetics' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm space-y-6">
          <div className="border-b border-gray-100 dark:border-gray-800 pb-4">
            <h2 className="text-lg sm:text-xl font-black text-gray-900 dark:text-white flex items-center gap-2">
              <Sliders className="w-5 h-5 text-teal-600" />
              <span>محاكي حركية الإنزيمات (Michaelis-Menten Kinetics)</span>
            </h2>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">
              تحكم بتركيز الركيزة، الإنزيم، درجة الحرارة، الـ pH، والمثبطات لمشاهدة تأثيرها الحيوي على سرعة التفاعل (Reaction Rate V).
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            {/* Left: Sliders Controls (6 cols) */}
            <div className="lg:col-span-6 space-y-5">
              {/* Substrate Concentration */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold text-gray-700 dark:text-gray-300">
                  <span>تركيز الركيزة [S] (Substrate Concentration):</span>
                  <span className="font-mono text-teal-600 dark:text-teal-400">{substrateConc} mmol/L</span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="50"
                  step="1"
                  value={substrateConc}
                  onChange={(e) => setSubstrateConc(Number(e.target.value))}
                  className="w-full accent-teal-600 cursor-pointer"
                />
              </div>

              {/* Enzyme Concentration */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold text-gray-700 dark:text-gray-300">
                  <span>تركيز الإنزيم [E] (Enzyme Concentration):</span>
                  <span className="font-mono text-teal-600 dark:text-teal-400">{enzymeConc}x</span>
                </div>
                <input
                  type="range"
                  min="0.2"
                  max="3"
                  step="0.2"
                  value={enzymeConc}
                  onChange={(e) => setEnzymeConc(Number(e.target.value))}
                  className="w-full accent-teal-600 cursor-pointer"
                />
              </div>

              {/* Temperature */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold text-gray-700 dark:text-gray-300">
                  <span>درجة الحرارة (°C):</span>
                  <span className={`font-mono font-black ${temperature > 50 ? 'text-rose-600' : 'text-teal-600 dark:text-teal-400'}`}>
                    {temperature}°C {temperature === 37 ? '(المثالية 37°)' : temperature > 55 ? '(تخثر حراري)' : ''}
                  </span>
                </div>
                <input
                  type="range"
                  min="0"
                  max="80"
                  step="1"
                  value={temperature}
                  onChange={(e) => setTemperature(Number(e.target.value))}
                  className="w-full accent-orange-500 cursor-pointer"
                />
              </div>

              {/* pH Level */}
              <div className="space-y-1.5">
                <div className="flex justify-between text-xs font-bold text-gray-700 dark:text-gray-300">
                  <span>درجة الحموضة (pH):</span>
                  <span className="font-mono text-teal-600 dark:text-teal-400">{phValue}</span>
                </div>
                <input
                  type="range"
                  min="1"
                  max="14"
                  step="0.1"
                  value={phValue}
                  onChange={(e) => setPhValue(Number(e.target.value))}
                  className="w-full accent-indigo-600 cursor-pointer"
                />
              </div>

              {/* Inhibitor Type */}
              <div className="space-y-2 pt-2">
                <span className="text-xs font-bold text-gray-700 dark:text-gray-300 block">
                  إضافة مثبط إنزيمي (Inhibitor):
                </span>
                <div className="grid grid-cols-3 gap-2">
                  {[
                    { id: 'none', label: 'بدون مثبط' },
                    { id: 'competitive', label: 'تنافسي (Km يرتفع)' },
                    { id: 'noncompetitive', label: 'غير تنافسي (Vmax ينخفض)' },
                  ].map((inh) => (
                    <button
                      key={inh.id}
                      onClick={() => setInhibitorType(inh.id as any)}
                      className={`p-2.5 rounded-xl border text-xs font-bold transition ${
                        inhibitorType === inh.id
                          ? 'bg-teal-600 text-white border-teal-600 shadow-sm'
                          : 'bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700'
                      }`}
                    >
                      {inh.label}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            {/* Right: Realtime Velocity Output & Visual Gauge (6 cols) */}
            <div className="lg:col-span-6 space-y-4">
              <div className="p-6 rounded-3xl bg-gradient-to-br from-gray-900 to-gray-950 text-white border border-gray-800 shadow-xl space-y-5">
                <div className="flex items-center justify-between border-b border-gray-800 pb-3">
                  <span className="text-xs text-gray-400 font-bold">سرعة التفاعل اللحظية (Reaction Velocity V):</span>
                  <span className="text-2xl font-black text-teal-400 font-mono">
                    {kineticsData.velocity} µmol/min
                  </span>
                </div>

                {/* Velocity Progress Bar */}
                <div className="space-y-1.5">
                  <div className="w-full bg-gray-800 h-4 rounded-full overflow-hidden p-0.5 border border-gray-700">
                    <div
                      className="h-full bg-gradient-to-r from-teal-500 to-emerald-400 rounded-full transition-all duration-300"
                      style={{ width: `${Math.min(100, (kineticsData.velocity / 150) * 100)}%` }}
                    />
                  </div>
                  <div className="flex justify-between text-[10px] text-gray-500 font-mono">
                    <span>0</span>
                    <span>50%</span>
                    <span>Vmax ({kineticsData.Vmax})</span>
                  </div>
                </div>

                {/* Metrics Table */}
                <div className="grid grid-cols-2 gap-3 pt-2 text-xs">
                  <div className="p-3 rounded-xl bg-gray-800/60 border border-gray-700">
                    <span className="text-gray-400 block mb-1">ثابت ميكائيليس (Km):</span>
                    <span className="font-mono font-bold text-white text-sm">{kineticsData.Km} mmol/L</span>
                  </div>
                  <div className="p-3 rounded-xl bg-gray-800/60 border border-gray-700">
                    <span className="text-gray-400 block mb-1">السرعة القصوى (Vmax):</span>
                    <span className="font-mono font-bold text-teal-300 text-sm">{kineticsData.Vmax} µmol/min</span>
                  </div>
                </div>

                {/* Warnings / State Badges */}
                {kineticsData.isDenatured && (
                  <div className="p-3 rounded-xl bg-rose-950/80 border border-rose-800 text-xs text-rose-300 font-bold flex items-center gap-2">
                    <Flame className="w-4 h-4 text-rose-400" />
                    <span>تنبيه: تمسخ حراري للإنزيم (Denaturation) بسبب الحرارة المرتفعة!</span>
                  </div>
                )}

                {kineticsData.isPhInactivated && (
                  <div className="p-3 rounded-xl bg-amber-950/80 border border-amber-800 text-xs text-amber-300 font-bold flex items-center gap-2">
                    <Activity className="w-4 h-4 text-amber-400" />
                    <span>تنبيه: الرقم الهيدروجيني pH متطرف ويعطل الموقع النشط للإنزيم!</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* TAB 3: TRY IT YOURSELF (Workbench) */}
      {activeTab === 'workbench' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm space-y-6">
          <div className="border-b border-gray-100 dark:border-gray-800 pb-4">
            <h2 className="text-lg sm:text-xl font-black text-gray-900 dark:text-white flex items-center gap-2">
              <FlaskConical className="w-5 h-5 text-teal-600" />
              <span>مختبر جرب بنفسك — طاولة التجارب الحيوية التفاعلية</span>
            </h2>
            <p className="text-xs sm:text-sm text-gray-500 dark:text-gray-400 mt-1">
              اختر المادة الكيميائية، الإنزيم، ودرجة الحرارة والـ pH وشاهد النتيجة الحيوية وميزان الطاقة.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {/* Input Controls */}
            <div className="space-y-4">
              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1.5">
                  اختر المادة المتفاعلة (Substrate):
                </label>
                <select
                  value={workbenchSubstrate}
                  onChange={(e) => setWorkbenchSubstrate(e.target.value)}
                  className="w-full p-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-950 text-xs sm:text-sm font-bold text-gray-900 dark:text-white outline-none"
                >
                  <option value="جلوكوز C₆H₁₂O₆">جلوكوز C₆H₁₂O₆ (سكر الدم)</option>
                  <option value="بيروفات Pyruvate">بيروفات Pyruvate (ناتج التحلل السكري)</option>
                  <option value="بروتين اللحم Peptides">بروتينات وببتيدات غذائية</option>
                  <option value="دهون ثلاثية Triglycerides">دهون ثلاثية Triglycerides</option>
                  <option value="حمض أميني L-Tyrosine">حمض أميني تيروزين L-Tyrosine</option>
                </select>
              </div>

              <div>
                <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1.5">
                  اختر الإنزيم المحفز (Enzyme):
                </label>
                <select
                  value={workbenchEnzyme}
                  onChange={(e) => setWorkbenchEnzyme(e.target.value)}
                  className="w-full p-3 rounded-xl border border-gray-300 dark:border-gray-700 bg-gray-50 dark:bg-gray-950 text-xs sm:text-sm font-bold text-gray-900 dark:text-white outline-none"
                >
                  <option value="Hexokinase">Hexokinase (إنزيم فسفرة الجلوكوز)</option>
                  <option value="Pyruvate Dehydrogenase">Pyruvate Dehydrogenase (أكسدة البيروفات)</option>
                  <option value="Pepsin">Pepsin (هضم البروتين في المعدة)</option>
                  <option value="Pancreatic Lipase">Pancreatic Lipase (ليباز البنكرياس للدهون)</option>
                  <option value="Tyrosine Hydroxylase">Tyrosine Hydroxylase (تخليق الدوبامين)</option>
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                    درجة الحرارة (°C): {workbenchTemp}°C
                  </label>
                  <input
                    type="range"
                    min="10"
                    max="70"
                    value={workbenchTemp}
                    onChange={(e) => setWorkbenchTemp(Number(e.target.value))}
                    className="w-full accent-teal-600 cursor-pointer"
                  />
                </div>

                <div>
                  <label className="text-xs font-bold text-gray-700 dark:text-gray-300 block mb-1">
                    درجة الحموضة pH: {workbenchPh}
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="14"
                    step="0.5"
                    value={workbenchPh}
                    onChange={(e) => setWorkbenchPh(Number(e.target.value))}
                    className="w-full accent-indigo-600 cursor-pointer"
                  />
                </div>
              </div>

              <button
                onClick={handleRunWorkbenchExperiment}
                disabled={experimentRunning}
                className="w-full py-3.5 rounded-2xl bg-gradient-to-r from-teal-600 to-emerald-600 hover:from-teal-700 hover:to-emerald-700 text-white font-black text-sm transition shadow-lg shadow-teal-500/20 flex items-center justify-center gap-2"
              >
                {experimentRunning ? (
                  <>
                    <Atom className="w-4 h-4 animate-spin" />
                    <span>جاري تحفيز التفاعل الكيميائي...</span>
                  </>
                ) : (
                  <>
                    <Play className="w-4 h-4 fill-current" />
                    <span>تشغيل التجربة المخبرية (Run Reaction)</span>
                  </>
                )}
              </button>
            </div>

            {/* Results Box */}
            <div className="p-6 rounded-3xl bg-gray-50 dark:bg-gray-950/60 border border-gray-200 dark:border-gray-800 space-y-4 flex flex-col justify-center">
              {experimentResult ? (
                <div className="space-y-4 animate-in fade-in duration-300 text-xs">
                  <div className={`p-4 rounded-2xl border ${
                    experimentResult.isSuccess
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200'
                      : 'bg-rose-50 dark:bg-rose-950/40 border-rose-300 dark:border-rose-800 text-rose-900 dark:text-rose-200'
                  }`}>
                    <div className="flex items-center gap-2 font-black text-sm mb-1">
                      {experimentResult.isSuccess ? <CheckCircle2 className="w-4 h-4 text-emerald-600" /> : <Shield className="w-4 h-4 text-rose-600" />}
                      <span>{experimentResult.isSuccess ? 'نجح التفاعل الكيميائي الحيوي' : 'توقف التفاعل الحيوي'}</span>
                    </div>
                    <p>{experimentResult.statusText}</p>
                  </div>

                  <div className="space-y-2">
                    <div className="flex justify-between p-2.5 rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
                      <span className="text-gray-500 font-medium">الناتج المتكون:</span>
                      <span className="font-bold text-teal-600 dark:text-teal-400">{experimentResult.product}</span>
                    </div>
                    <div className="flex justify-between p-2.5 rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
                      <span className="text-gray-500 font-medium">ميزان طاقة ATP:</span>
                      <span className="font-mono font-black text-amber-600 dark:text-amber-400">{experimentResult.atpYield}</span>
                    </div>
                    <div className="flex justify-between p-2.5 rounded-xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800">
                      <span className="text-gray-500 font-medium">معدل النشاط الإنزيمي:</span>
                      <span className="font-bold text-gray-900 dark:text-white">{experimentResult.speedRating}</span>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="text-center py-8 text-gray-400 text-xs space-y-2">
                  <FlaskConical className="w-10 h-10 mx-auto text-teal-500/50" />
                  <p>اضبط المتفاعلات والظروف ثم اضغط على "تشغيل التجربة" لرؤية النواتج الحيوية.</p>
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* TAB 4: 3D ORGAN & CELL EXPLORER */}
      {activeTab === 'body3d' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-b from-gray-900 to-gray-950 text-white border border-gray-800 shadow-2xl space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-800 pb-4">
            <div>
              <h2 className="text-lg sm:text-xl font-black text-teal-300 flex items-center gap-2">
                <Maximize2 className="w-5 h-5" />
                <span>مستكشف الأعضاء والخلايا التفاعلي (3D Cell & Organ Explorer)</span>
              </h2>
              <p className="text-xs text-gray-400 mt-1">
                انتقل بين أعضاء جسم الإنسان ومكونات الخلية لمشاهدة مواقع التفاعلات الحيوية.
              </p>
            </div>

            {/* Quick Organ Switcher */}
            <div className="flex items-center gap-1.5 overflow-x-auto scrollbar-none">
              {[
                { id: 'mitochondria', label: 'الميتوكوندريا (ATP)' },
                { id: 'nucleus', label: 'النواة و DNA' },
                { id: 'ribosome', label: 'الريبوسوم' },
                { id: 'membrane', label: 'الغشاء والمضخات' },
              ].map((org) => (
                <button
                  key={org.id}
                  onClick={() => setSelected3DOrgan(org.id)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                    selected3DOrgan === org.id
                      ? 'bg-teal-500 text-gray-950 shadow-md font-black'
                      : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                  }`}
                >
                  {org.label}
                </button>
              ))}
            </div>
          </div>

          {/* Visual 3D Representation Canvas */}
          <div className="p-8 rounded-3xl bg-gray-950 border border-teal-500/20 relative min-h-[320px] flex flex-col items-center justify-center text-center overflow-hidden">
            <div className="absolute inset-0 bg-radial from-teal-500/10 via-transparent to-transparent pointer-events-none" />

            {selected3DOrgan === 'mitochondria' && (
              <div className="space-y-4 max-w-md animate-in zoom-in-95 duration-500">
                <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-tr from-amber-600 via-orange-500 to-amber-300 flex items-center justify-center shadow-2xl shadow-orange-500/30 text-white">
                  <Zap className="w-12 h-12" />
                </div>
                <h3 className="text-lg font-black text-amber-300">الميتوكوندريا (محطة توليد الطاقة الخلوية)</h3>
                <p className="text-xs text-gray-300 leading-relaxed">
                  تحدث فيها دورة كريبس وسلسلة نقل الإلكترون ومضخة ATP Synthase لإنتاج 95% من طاقة الجسم البشري.
                </p>
              </div>
            )}

            {selected3DOrgan === 'nucleus' && (
              <div className="space-y-4 max-w-md animate-in zoom-in-95 duration-500">
                <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-tr from-indigo-600 via-purple-600 to-pink-500 flex items-center justify-center shadow-2xl shadow-purple-500/30 text-white">
                  <Dna className="w-12 h-12" />
                </div>
                <h3 className="text-lg font-black text-purple-300">نواة الخلية والشفرة الوراثية DNA</h3>
                <p className="text-xs text-gray-300 leading-relaxed">
                  تحتوي على 3 مليارات زوج من القواعد النيتروجينية، وتحدث فيها عملية النسخ Transcription لإنتاج mRNA.
                </p>
              </div>
            )}

            {selected3DOrgan === 'ribosome' && (
              <div className="space-y-4 max-w-md animate-in zoom-in-95 duration-500">
                <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-tr from-teal-600 via-emerald-600 to-cyan-400 flex items-center justify-center shadow-2xl shadow-teal-500/30 text-white">
                  <Atom className="w-12 h-12" />
                </div>
                <h3 className="text-lg font-black text-teal-300">الريبوسوم (مصنع البروتينات)</h3>
                <p className="text-xs text-gray-300 leading-relaxed">
                  يقرأ كودونات mRNA ويربط الأحماض الأمينية لبناء الإنزيمات والهرمونات وعضلات الجسم.
                </p>
              </div>
            )}

            {selected3DOrgan === 'membrane' && (
              <div className="space-y-4 max-w-md animate-in zoom-in-95 duration-500">
                <div className="w-24 h-24 mx-auto rounded-3xl bg-gradient-to-tr from-sky-600 via-blue-600 to-indigo-500 flex items-center justify-center shadow-2xl shadow-blue-500/30 text-white">
                  <Activity className="w-12 h-12" />
                </div>
                <h3 className="text-lg font-black text-sky-300">الغشاء الخلوي ومضخات الأيونات</h3>
                <p className="text-xs text-gray-300 leading-relaxed">
                  طبقة فوسفوليبيد ثنائية تحتوي على مضخات Na⁺/K⁺ وقنوات الكالسيوم ومستقبلات النواقل العصبية.
                </p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 5: BIOCHEM QUIZ */}
      {activeTab === 'quiz' && (
        <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm space-y-6">
          <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-4">
            <div>
              <h2 className="text-lg sm:text-xl font-black text-gray-900 dark:text-white flex items-center gap-2">
                <Award className="w-5 h-5 text-teal-600" />
                <span>اختبار وتحدي الكيمياء الحيوية (Biochemistry Quiz)</span>
              </h2>
              <p className="text-xs text-gray-500 dark:text-gray-400 mt-0.5">
                اختبر معلوماتك الأكاديمية والسريرية في التفاعلات الحيوية لجسم الإنسان.
              </p>
            </div>

            <div className="px-3.5 py-1.5 rounded-xl bg-teal-50 dark:bg-teal-950/40 text-teal-700 dark:text-teal-300 border border-teal-200 dark:border-teal-800 font-bold text-xs">
              النقاط: {quizScore} / {BIOCHEM_QUIZZES.length}
            </div>
          </div>

          {/* Current Quiz Card */}
          <div className="space-y-5">
            <div className="flex items-center gap-2 text-xs font-bold text-gray-500">
              <span>سؤال {quizIndex + 1} من {BIOCHEM_QUIZZES.length}</span>
            </div>

            <h3 className="text-base sm:text-lg font-extrabold text-gray-900 dark:text-white">
              {BIOCHEM_QUIZZES[quizIndex].question}
            </h3>

            {/* Options */}
            <div className="space-y-2.5">
              {BIOCHEM_QUIZZES[quizIndex].options.map((opt, oIdx) => {
                const isSelected = selectedQuizAnswer === oIdx;
                const isCorrect = oIdx === BIOCHEM_QUIZZES[quizIndex].correct;

                let btnStyle = 'bg-gray-50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 text-gray-800 dark:text-gray-200 hover:border-teal-400';
                if (quizSubmitted) {
                  if (isCorrect) {
                    btnStyle = 'bg-emerald-50 dark:bg-emerald-950/50 border-emerald-500 text-emerald-900 dark:text-emerald-200 font-bold';
                  } else if (isSelected) {
                    btnStyle = 'bg-rose-50 dark:bg-rose-950/50 border-rose-500 text-rose-900 dark:text-rose-200 font-bold';
                  }
                } else if (isSelected) {
                  btnStyle = 'bg-teal-50 dark:bg-teal-950/40 border-teal-500 text-teal-900 dark:text-teal-100 font-bold';
                }

                return (
                  <button
                    key={oIdx}
                    disabled={quizSubmitted}
                    onClick={() => setSelectedQuizAnswer(oIdx)}
                    className={`w-full text-right p-4 rounded-2xl border transition-all text-xs sm:text-sm flex items-center justify-between ${btnStyle}`}
                  >
                    <span>{opt}</span>
                    {quizSubmitted && isCorrect && <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />}
                  </button>
                );
              })}
            </div>

            {/* Explanation Note on Submit */}
            {quizSubmitted && (
              <div className="p-4 rounded-2xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 dark:border-teal-800 text-xs text-teal-800 dark:text-teal-200 leading-relaxed">
                <strong>التفسير العلمي:</strong> {BIOCHEM_QUIZZES[quizIndex].explanation}
              </div>
            )}

            {/* Submit / Next Button */}
            <div className="flex items-center justify-between pt-3">
              {!quizSubmitted ? (
                <button
                  disabled={selectedQuizAnswer === null}
                  onClick={() => {
                    if (selectedQuizAnswer === null) return;
                    setQuizSubmitted(true);
                    if (selectedQuizAnswer === BIOCHEM_QUIZZES[quizIndex].correct) {
                      setQuizScore(prev => prev + 1);
                      try {
                        confetti({ particleCount: 30, spread: 40 });
                      } catch {}
                    }
                  }}
                  className="px-6 py-2.5 rounded-xl bg-teal-600 hover:bg-teal-700 disabled:opacity-30 text-white font-black text-xs transition shadow-md"
                >
                  تحقق من الإجابة
                </button>
              ) : (
                <button
                  onClick={() => {
                    if (quizIndex < BIOCHEM_QUIZZES.length - 1) {
                      setQuizIndex(prev => prev + 1);
                      setSelectedQuizAnswer(null);
                      setQuizSubmitted(false);
                    } else {
                      // Reset
                      setQuizIndex(0);
                      setSelectedQuizAnswer(null);
                      setQuizSubmitted(false);
                      setQuizScore(0);
                    }
                  }}
                  className="px-6 py-2.5 rounded-xl bg-gradient-to-r from-teal-600 to-indigo-600 hover:from-teal-700 hover:to-indigo-700 text-white font-black text-xs transition shadow-md"
                >
                  {quizIndex < BIOCHEM_QUIZZES.length - 1 ? 'السؤال التالي' : 'إعادة الاختبار من البداية'}
                </button>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
