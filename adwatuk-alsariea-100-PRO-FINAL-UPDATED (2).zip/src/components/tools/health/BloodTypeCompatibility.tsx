import React, { useState } from 'react';
import { Droplet, Info } from 'lucide-react';

const BLOOD_COMPATIBILITY = {
  'O-': { donatesTo: ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'], receivesFrom: ['O-'] },
  'O+': { donatesTo: ['O+', 'A+', 'B+', 'AB+'], receivesFrom: ['O-', 'O+'] },
  'A-': { donatesTo: ['A-', 'A+', 'AB-', 'AB+'], receivesFrom: ['O-', 'A-'] },
  'A+': { donatesTo: ['A+', 'AB+'], receivesFrom: ['O-', 'O+', 'A-', 'A+'] },
  'B-': { donatesTo: ['B-', 'B+', 'AB-', 'AB+'], receivesFrom: ['O-', 'B-'] },
  'B+': { donatesTo: ['B+', 'AB+'], receivesFrom: ['O-', 'O+', 'B-', 'B+'] },
  'AB-': { donatesTo: ['AB-', 'AB+'], receivesFrom: ['O-', 'A-', 'B-', 'AB-'] },
  'AB+': { donatesTo: ['AB+'], receivesFrom: ['O-', 'O+', 'A-', 'A+', 'B-', 'B+', 'AB-', 'AB+'] },
};

type BloodType = keyof typeof BLOOD_COMPATIBILITY;

export function BloodTypeCompatibility() {
  const [selectedType, setSelectedType] = useState<BloodType>('O+');

  const { donatesTo, receivesFrom } = BLOOD_COMPATIBILITY[selectedType];

  return (
    <div className="space-y-6">
      <div className="bg-red-50 dark:bg-red-950/30 p-4 rounded-2xl flex gap-3 text-sm text-red-800 dark:text-red-300">
        <Info className="w-5 h-5 shrink-0 mt-0.5" />
        <p>اختر فصيلة الدم لمعرفة الفصائل التي يمكن التبرع لها، والفصائل التي يمكن استقبال الدم منها.</p>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {(Object.keys(BLOOD_COMPATIBILITY) as BloodType[]).map(type => (
          <button
            key={type}
            onClick={() => setSelectedType(type)}
            className={`p-4 rounded-2xl text-lg font-bold font-mono transition flex items-center justify-center gap-2 ${
              selectedType === type
                ? 'bg-red-600 text-white shadow-md'
                : 'bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-red-100 dark:hover:bg-red-900/50'
            }`}
          >
            <Droplet className={`w-5 h-5 ${selectedType === type ? 'text-white' : 'text-red-500'}`} />
            <span dir="ltr">{type}</span>
          </button>
        ))}
      </div>

      <div className="grid md:grid-cols-2 gap-6 mt-6">
        <div className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-3xl border border-gray-100 dark:border-gray-700 space-y-4">
          <h4 className="font-bold text-gray-800 dark:text-white flex items-center gap-2 border-b border-gray-200 dark:border-gray-700 pb-3">
            <span className="w-2 h-2 rounded-full bg-emerald-500"></span>
            يمكنه التبرع إلى:
          </h4>
          <div className="flex flex-wrap gap-2">
            {donatesTo.map(t => (
              <span key={t} className="px-4 py-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl font-mono font-bold text-gray-800 dark:text-gray-200" dir="ltr">
                {t}
              </span>
            ))}
          </div>
          {donatesTo.length === 8 && <p className="text-xs text-emerald-600 dark:text-emerald-400 font-bold">مُعطي عام (كريم)</p>}
        </div>

        <div className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-3xl border border-gray-100 dark:border-gray-700 space-y-4">
          <h4 className="font-bold text-gray-800 dark:text-white flex items-center gap-2 border-b border-gray-200 dark:border-gray-700 pb-3">
            <span className="w-2 h-2 rounded-full bg-blue-500"></span>
            يمكنه الاستقبال من:
          </h4>
          <div className="flex flex-wrap gap-2">
            {receivesFrom.map(t => (
              <span key={t} className="px-4 py-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl font-mono font-bold text-gray-800 dark:text-gray-200" dir="ltr">
                {t}
              </span>
            ))}
          </div>
          {receivesFrom.length === 8 && <p className="text-xs text-blue-600 dark:text-blue-400 font-bold">مُستقبل عام (بخيل)</p>}
        </div>
      </div>
    </div>
  );
}
