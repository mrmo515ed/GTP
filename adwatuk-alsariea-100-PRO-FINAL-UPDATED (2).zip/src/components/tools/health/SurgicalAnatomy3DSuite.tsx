import React, { useEffect, useRef, useState } from 'react';
import { SurgicalChecklist } from './surgery/SurgicalChecklist';
import { SurgicalRiskCalculator } from './surgery/SurgicalRiskCalculator';
import { SutureInstrumentGuide } from './surgery/SutureInstrumentGuide';
import { OperativeReportGenerator } from './surgery/OperativeReportGenerator';
import * as THREE from 'three';
import {
  Heart,
  Brain,
  Eye,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Play,
  Pause,
  Layers,
  Sparkles,
  Stethoscope,
  Activity,
  ShieldAlert,
  Info,
  ChevronLeft,
  ChevronRight,
  Maximize2,
  FileText,
  Scissors,
  Flame,
  Volume2,
  VolumeX,
  Lightbulb,
  Crosshair,
  CheckCircle2,
  AlertTriangle,
  Radio,
  Eye as EyeIcon,
  CircleDot
} from 'lucide-react';

export type OrganType = 'heart' | 'brain' | 'lungs' | 'eye' | 'knee' | 'laparoscopy' | 'spine';

interface OrganFeature {
  id: string;
  nameAr: string;
  nameEn: string;
  descAr: string;
  surgicalNoteAr: string;
  color: string;
  position: [number, number, number];
}

interface SurgicalProcedure {
  nameAr: string;
  nameEn: string;
  indicationAr: string;
  stepsAr: string[];
  riskAr: string;
  instrumentsUsed: string[];
  durationMinutes: number;
}

const ORGAN_DATA: Record<OrganType, {
  titleAr: string;
  titleEn: string;
  subtitle: string;
  icon: string;
  features: OrganFeature[];
  surgicalProcedures: SurgicalProcedure[];
}> = {
  heart: {
    titleAr: 'جراحة وتشريح القلب والأوعية الدموية 3D',
    titleEn: 'Cardiovascular Surgery & 3D Heart Anatomy',
    subtitle: 'مجسم ثلاثي الأبعاد تفاعلي ينبض حياً مع استعراض الأذينين، البطينين، الشريان الأورطي، والصمامات ومحاكاة عمليات القلب المفتوح والقسطرة.',
    icon: 'Heart',
    features: [
      {
        id: 'left_ventricle',
        nameAr: 'البطين الأيسر (Left Ventricle)',
        nameEn: 'Left Ventricle',
        descAr: 'الحجرة العضلية الأكثر سماكة وقوة، مسؤولة عن ضخ الدم المؤكسج إلى جميع أنحاء الجسم عبر الشريان الأورطي.',
        surgicalNoteAr: 'يتم فحصه بدقة في جراحات الصمام التاجي واستئصال تضخم عضلة القلب (Myectomy) وتركيب أجهزة المساعدة البطينية (LVAD).',
        color: '#dc2626',
        position: [0.8, -0.6, 0.4]
      },
      {
        id: 'right_ventricle',
        nameAr: 'البطين الأيمن (Right Ventricle)',
        nameEn: 'Right Ventricle',
        descAr: 'يستقبل الدم غير المؤكسج من الأذين الأيمن ويضخه عبر الشريان الرئوي إلى الرئتين للأكسجة.',
        surgicalNoteAr: 'موضع مهم لإصلاح عيوب الحاجز البطيني (VSD) وتصحيح رباعية فالوت (Tetralogy of Fallot).',
        color: '#991b1b',
        position: [-0.8, -0.5, 0.5]
      },
      {
        id: 'aorta',
        nameAr: 'الشريان الأبهر / الأورطي (Aorta)',
        nameEn: 'Aorta & Aortic Arch',
        descAr: 'الشريان الرئيسي الأكبر في جسم الإنسان الذي يخرج مباشرة من قمة القلب حاملاً الدم لكافة الأعضاء الحيوية.',
        surgicalNoteAr: 'موقع إجراء جراحة استبدال الصمام الأورطي (TAVR / SAVR) وإصلاح تمدد الشريان الأورطي (Aneurysm Repair).',
        color: '#ef4444',
        position: [0.1, 1.4, 0]
      },
      {
        id: 'superior_vena_cava',
        nameAr: 'الوريد الأجوف والشريان الرئوي',
        nameEn: 'Vena Cava & Pulmonary Artery',
        descAr: 'شبكة الأوعية العلوية المسؤولة عن نقل الدم المستهلك إلى القلب وإرساله للرئتين.',
        surgicalNoteAr: 'يتم عمل القسطرة الوريدية المركزية وتحويل المسار الشرياني الجراحي (CABG) واستخدام آلة القلب والرئة الصناعية.',
        color: '#2563eb',
        position: [-0.7, 1.2, -0.3]
      },
      {
        id: 'coronary_arteries',
        nameAr: 'الشرايين التاجية (Coronary Arteries)',
        nameEn: 'Coronary Vessels',
        descAr: 'شبكة الأوعية الدقيقة التي تغذي عضلة القلب نفسها بالأكسجين والغذاء الحيوي.',
        surgicalNoteAr: 'الهدف الرئيسي لعمليات القسطرة القلبية وتركيب الدعامات (Stents) أو ترقيع مجازة الشريان التاجي (CABG Bypass).',
        color: '#f59e0b',
        position: [0.1, -0.1, 1.1]
      }
    ],
    surgicalProcedures: [
      {
        nameAr: 'قسطرة الشرايين التاجية وتركيب الدعامة (PCI / Stent)',
        nameEn: 'Percutaneous Coronary Intervention',
        indicationAr: 'علاج انسداد أو تضيق الشرايين التاجية واحتشاء عضلة القلب الحاد (الجلطة القلبية).',
        stepsAr: [
          'إدخال سلك توجيه دقيق عبر الشريان الكعبري في الرسغ أو الفخذي.',
          'الوصول إلى الشريان التاجي المسدود تحت الأشعة السينية مع حقن الصبغة التباينية.',
          'نفخ بالون جراحي دقيق لتوسيع التضيق في جدار الوعاء الدموي.',
          'تثبيت دعامة شبكية دوائية (Drug-Eluting Stent) لإبقاء الشريان مفتوحاً وضمان تدفق الدم.'
        ],
        riskAr: 'إجراء قليل التوغل، نسبة النجاح تتجاوز 98% مع تعافٍ سريع خلال 24-48 ساعة.',
        instrumentsUsed: ['سلك توجيه كعبري', 'بالون تمديد', 'دعامة دوائية DES', 'قسطرة تشخيصية'],
        durationMinutes: 45
      },
      {
        nameAr: 'جراحة القلب المفتوح وتغيير مجرى الشرايين (CABG)',
        nameEn: 'Coronary Artery Bypass Grafting',
        indicationAr: 'انسداد متعدد في الشرايين التاجية الرئيسية غير القابلة للعلاج بالدعامة البسيطة.',
        stepsAr: [
          'شق القص المتوسط (Median Sternotomy) للوصول إلى التجويف الصدري.',
          'توصيل المريض بآلة القلب والرئة الصناعية وإيقاف النبض مؤقتاً بمحلول الكارديوبليجيا.',
          'أخذ طعم وريدي من الساق (Saphenous Vein) أو الشريان الثديي الداخلي (LIMA).',
          'مفاغرة وتوصيل الطعم بعد منطقة الانسداد لإعادة التروية الكاملة ثم إعادة نبض القلب.'
        ],
        riskAr: 'جراحة متقدمة وعالية الدقة تنقذ حياة المريض وتستغرق من 3 إلى 5 ساعات.',
        instrumentsUsed: ['منشار عظم القص', 'آلة القلب والرئة', 'خيوط Prolene 7-0', 'مشبك الأورطي'],
        durationMinutes: 240
      },
      {
        nameAr: 'استبدال الصمام الأورطي بالقسطرة (TAVR)',
        nameEn: 'Transcatheter Aortic Valve Replacement',
        indicationAr: 'تضيق الصمام الأورطي الشديد لكبار السن أو المرضى غير المؤهلين للقلب المفتوح.',
        stepsAr: [
          'تمرير الصمام الاصطناعي القابل للتمدد عبر قسطرة من الفخذ.',
          'توجيه الصمام بدقة داخل الصمام المتكلس الأصلي.',
          'فتح وتوسيع الصمام الجديد ليحل محل الصمام المتضرر دون شق الصدر.'
        ],
        riskAr: 'ثورة طبية حديثة تقلل فترة البقاء في المستشفى لأيام معدودة.',
        instrumentsUsed: ['صمام بالوني Edwards/CoreValve', 'سلك فخذي Lunderquist', 'جهاز تنظيم النبض السريع'],
        durationMinutes: 60
      }
    ]
  },
  brain: {
    titleAr: 'جراحة وتشريح المخ والأعصاب وقاع الجمجمة 3D',
    titleEn: 'Neurosurgery & 3D Brain Anatomy',
    subtitle: 'استكشاف ثلاثي الأبعاد متعمق لفصوص المخ، المخيخ، وجذع الدماغ ومحاكاة جراحات الأورام واستسقاء الدماغ والتحفيز العميق (DBS).',
    icon: 'Brain',
    features: [
      {
        id: 'frontal_lobe',
        nameAr: 'الفص الجبهي (Frontal Lobe)',
        nameEn: 'Frontal Lobe',
        descAr: 'مسؤول عن التفكير المنطقي، اتخاذ القرارات، الشخصية، والتحكم بالحركات الإرادية (الباحة الحركية الأولية ومنطقة بروكا للكلام).',
        surgicalNoteAr: 'منطقة شائعة لاستئصال الأورام الدبقية (Gliomas) مع مراعاة مناطق النطق والحركة واستخدام تخطيط الدماغ أثناء اليقظة (Awake Craniotomy).',
        color: '#ec4899',
        position: [0, 0.7, 1.0]
      },
      {
        id: 'parietal_lobe',
        nameAr: 'الفص الجداري (Parietal Lobe)',
        nameEn: 'Parietal Lobe',
        descAr: 'يعالج المعلومات الحسية مثل اللمس، الألم، الحرارة، والإدراك المكاني وتكامل الحواس.',
        surgicalNoteAr: 'تتطلب الجراحة فيه ملاحة عصبية دقيقة (Neuronavigation) لتجنب فقدان الإحساس أو متلازمة الإهمال المكاني.',
        color: '#8b5cf6',
        position: [0, 0.8, -0.4]
      },
      {
        id: 'temporal_lobe',
        nameAr: 'الفص الصدغي (Temporal Lobe)',
        nameEn: 'Temporal Lobe',
        descAr: 'يحوي مراكز الذاكرة (الحصين Hippocampus)، السمع، وفهم اللغة (منطقة فيرنيكه Wernicke).',
        surgicalNoteAr: 'موضع جراحات الصرع المقاوم للعلاج (Temporal Lobectomy) واستئصال أورام العصب السمعي.',
        color: '#06b6d4',
        position: [1.2, -0.1, 0.2]
      },
      {
        id: 'occipital_lobe',
        nameAr: 'الفص القذالي (Occipital Lobe)',
        nameEn: 'Occipital Lobe',
        descAr: 'المركز العصبي الأساسي لمعالجة الرؤية، تمييز الأشكال، الألوان، والحركة البصرية.',
        surgicalNoteAr: 'الحفاظ على الشريان الدماغي الخلفي (PCA) لتفادي العمى النصفي أو العشى الإبصاري.',
        color: '#10b981',
        position: [0, 0.2, -1.3]
      },
      {
        id: 'cerebellum_brainstem',
        nameAr: 'المخيخ وجذع الدماغ (Cerebellum & Brainstem)',
        nameEn: 'Cerebellum & Brainstem',
        descAr: 'المخيخ ينظم التوازن والتناسق الحركي الدقيق، بينما جذع الدماغ يتحكم في الوظائف الحيوية الأساسية (التنفس، نبض القلب، والوعي).',
        surgicalNoteAr: 'منطقة الحفرة الخلفية (Posterior Fossa Surgery) تتطلب أقصى درجات الحذر والتحكم بالمجهر الجراحي الدقيق (Microsurgery).',
        color: '#f97316',
        position: [0, -1.0, -0.7]
      }
    ],
    surgicalProcedures: [
      {
        nameAr: 'بضع القحف واستئصال الأورام (Craniotomy for Tumor)',
        nameEn: 'Image-Guided Brain Tumor Resection',
        indicationAr: 'أورام الدماغ السحائية أو الدبقية أو النقائل الضاغطة على نسيج المخ.',
        stepsAr: [
          'تثبيت رأس المريض بإطار Mayfield واستخدام نظام الملاحة العصبية ثلاثي الأبعاد.',
          'إحداث شق في فروة الرأس ورفع رفرف عظمي محدد من الجمجمة بمثقاب العظام الهوائي.',
          'فتح غشاء الأم الجافية تحت المجهر الجراحي المتقدم.',
          'استئصال الورم بمفتت الأورام بالموجات فوق الصوتية (CUSA) والمراقبة العصبية اللحظية (IONM).',
          'إعادة الرفرف العظمي وتثبيته بشرائح تيتانيوم مصغرة وخياطة الجافية بإحكام لمنع تسرب السائل النخاعي.'
        ],
        riskAr: 'تستخدم فيها أحدث تقنيات الليزر والملاحة المجهرية بدقة المليمتر.',
        instrumentsUsed: ['إطار Mayfield', 'مثقاب عظام هوائي', 'مسبار CUSA', 'مجهر Zeiss Kinevo'],
        durationMinutes: 180
      },
      {
        nameAr: 'التحفيز العميق للدماغ (Deep Brain Stimulation - DBS)',
        nameEn: 'DBS for Parkinson & Tremor',
        indicationAr: 'مرض باركنسون المتقدم، الرعاش الأساسي، أو خلل التوتر العضلي (Dystonia).',
        stepsAr: [
          'تحديد نواة تحت المهاد (STN) بدقة المليمتر بواسطة الرنين المغناطيسي الملاحي.',
          'إدخال أقطاب كهربائية دقيقة فائقة النعومة داخل الدماغ مع اختبار الاستجابة اللحظية.',
          'توصيل الأقطاب بمولد نبضات كهربائي يزرع تحت الجلد في منطقة الصدر.',
          'برمجة الجهاز لضبط الإشارات العصبية وإيقاف الرعاش الحركي.'
        ],
        riskAr: 'تقنية عالية التطور تعيد للمريض قدرته على الحركة الطبيعية بدون اهتزاز.',
        instrumentsUsed: ['إطار مجسم Leksell', 'أقطاب Medtronic DBS', 'جهاز تخطيط الخلايا الدقيقة Microelectrode'],
        durationMinutes: 210
      }
    ]
  },
  lungs: {
    titleAr: 'جراحة وتشريح الرئتين والجهاز التنفسي 3D',
    titleEn: 'Thoracic Surgery & 3D Lungs Anatomy',
    subtitle: 'مجسم ثلاثي الأبعاد تفاعلي حقيقي للرئتين وقصبة الهواء، والشعب الهوائية، والحجاب الحاجز مع محاكاة التناغم التنفسي وجراحات استئصال الورم والمنظار الصدري.',
    icon: 'Activity',
    features: [
      {
        id: 'trachea_bronchi',
        nameAr: 'القصبة الهوائية والشعبتان الهوائيتان (Trachea & Bronchi)',
        nameEn: 'Trachea & Main Bronchi',
        descAr: 'الأنبوب الشفاف المكون من 12-20 حلقة غضروفية ينقل الهواء من الحنجرة وينقسم إلى شعبيتين رئيسيتين للرئتين.',
        surgicalNoteAr: 'موقع إجراء مناظير الشعب الهوائية (Bronchoscopy) وتركيب دعامات القصبة واستئصال الأورام الحليمية.',
        color: '#38bdf8',
        position: [0, 1.3, 0]
      },
      {
        id: 'right_lung',
        nameAr: 'الرئة اليمنى (Right Lung - 3 Lobes)',
        nameEn: 'Right Lung (Superior, Middle, Inferior)',
        descAr: 'الرئة الأكبر حشواً، تتكون من 3 فصوص مستقلة تشريحياً (علوي، أوسط، وسفلي) مفصولة بالشق العرضي والشق المائل.',
        surgicalNoteAr: 'تجرى فيها عمليات استئصال الفص الرئوي (Right Lobectomy) لعلاج أورام الرئة أو التوسع الشعبي الشديد.',
        color: '#f43f5e',
        position: [0.9, 0.1, 0.2]
      },
      {
        id: 'left_lung',
        nameAr: 'الرئة اليسرى وثلمة القلب (Left Lung & Cardiac Notch)',
        nameEn: 'Left Lung (Superior & Inferior Lobes)',
        descAr: 'تتكون من فصين فقط (علوي وسفلي) مع وجود انحناء تجويفي يسمى ثلمة القلب (Cardiac Notch) ليستقر فيها القلب.',
        surgicalNoteAr: 'يتطلب التعامل معها حذراً شديداً لقربها المباشر من الشريان الأورطي والقلب أثناء جراحات الصدر.',
        color: '#fb7185',
        position: [-0.9, 0.1, 0.2]
      },
      {
        id: 'pulmonary_vessels',
        nameAr: 'الأوعية الدموية الرئوية (Pulmonary Vessels)',
        nameEn: 'Pulmonary Artery & Veins',
        descAr: 'شبكة الأوعية التي تنقل الدم غير المؤكسج من القلب إلى ملايين الحويصلات الهوائية وتبادل الأكسجين مع الكربون.',
        surgicalNoteAr: 'ربط وقص الشريان والوريد الرئوي بتقنية الخياطة والدباسات الذكية (Endo-GIA Staples).',
        color: '#818cf8',
        position: [0, -0.2, 0.6]
      },
      {
        id: 'diaphragm',
        nameAr: 'عضلة الحجاب الحاجز (Diaphragm Muscle)',
        nameEn: 'Diaphragm',
        descAr: 'العضلة الرئيسية للتنفس التي تفصل القفص الصدري عن البطن، تنقبض لأسفل لتوليد ضغط سلبي يسحب الهواء للداخل.',
        surgicalNoteAr: 'موضع جراحات إصلاح الفتق الحجابي (Diaphragmatic Hernia Repair) واستكشاف الإصابات الصدرية.',
        color: '#cbd5e1',
        position: [0, -1.5, 0]
      }
    ],
    surgicalProcedures: [
      {
        nameAr: 'استئصال فص رئوي بالمنظار الصدري (VATS Lobectomy)',
        nameEn: 'Video-Assisted Thoracoscopic Surgery',
        indicationAr: 'علاج أورام الرئة المبكرة أو الأكياس الرئوية الكبيرة بدون شق الصدر الكبير.',
        stepsAr: [
          'عمل 2-3 شقوق صغيرة جداً بين الأضلاع لإدخال كاميرا المنظار والأدوات الصدرية.',
          'عزل وفصل الشريان والوريد الرئوي والشعبة الهوائية للفص المتضرر.',
          'تدبيس وقص الأوعية والشعبة بدباسة أوعية آلية منظارية (Endo-GIA).',
          'وضع الفص المستأصل داخل كيس طبي خاص وإخراجه بعناية من الشق الصدري.'
        ],
        riskAr: 'جراحة متقدمة تقصر فترة التعافي وتخفف آلام ما بعد العملية مقارنة بفتح الصدر التقليدي.',
        instrumentsUsed: ['منظار صلب 30 درجة', 'دباسة أوعية Endo-GIA', 'مقص الكي الكهربائي harmonic', 'كيس عينات'],
        durationMinutes: 120
      },
      {
        nameAr: 'تنظير الشعب الهوائية وأخذ العينات (Diagnostic & Therapeutic Bronchoscopy)',
        nameEn: 'Flexible Bronchoscopy & Biopsy',
        indicationAr: 'تشخيص انسداد الشعب، أخذ عينات غسيل رئوي، أو إزالة الأجسام الغريبة المستنشقة.',
        stepsAr: [
          'إدخال المنظار المرن عبر الأنف أو الفم تحت التخدير الموضعي أو الخفيف.',
          'توجيه الكاميرا عبر القصبة الهوائية واستكشاف الفروع الهوائية الرئيسية والرئوية.',
          'حقن محلول معقم وشفطه (Bronchoalveolar Lavage) أو أخذ خزع نسيجية بالمشبك الدقيق.'
        ],
        riskAr: 'إجراء تشخيصي سريع وآمن جداً يستغرق 20-30 دقيقة فقط.',
        instrumentsUsed: ['منظار شعب مرن Olympus', 'ملاقط خزع Biopsy Forceps', 'أنبوب شفط مخاطي'],
        durationMinutes: 30
      }
    ]
  },
  eye: {
    titleAr: 'جراحة وتشريح العيون والبصريات الدقيقة 3D',
    titleEn: 'Ophthalmic Surgery & 3D Eye Anatomy',
    subtitle: 'مجسم ثلاثي الأبعاد متكامل لطبقات العين (القرنية، القزحية، العدسة، الشبكية، والعصب البصري) مع محاكاة جراحات الليزك والمياه البيضاء وانفصال الشبكية.',
    icon: 'Eye',
    features: [
      {
        id: 'cornea',
        nameAr: 'القرنية الشفافة (Cornea)',
        nameEn: 'Clear Cornea',
        descAr: 'النسيج الشفاف المحدب في مقدمة العين الذي يعمل كالنافذة الرئيسية والعدسة الانكسارية الأولى للضوء.',
        surgicalNoteAr: 'موضع جراحات تصحيح الإبصار بالليزر (Femto-LASIK / PRK / SMILE) وزراعة القرنية (Keratoplasty).',
        color: '#38bdf8',
        position: [0, 0, 1.45]
      },
      {
        id: 'crystalline_lens',
        nameAr: 'عدسة العين البلورية (Crystalline Lens)',
        nameEn: 'Natural Lens',
        descAr: 'عدسة شفافة ومرنة تقوم بتركيز الأشعة الضوئية بدقة متناهية على الشبكية للتكيف مع المسافات.',
        surgicalNoteAr: 'موقع حدوث المياه البيضاء (Cataract) حيث يتم تفتيتها بالموجات فوق الصوتية واستبدالها بعدسة صناعية IOL.',
        color: '#fef08a',
        position: [0, 0, 0.95]
      },
      {
        id: 'retina_optic_nerve',
        nameAr: 'الشبكية والعصب البصري (Retina & Optic Nerve)',
        nameEn: 'Retina & Optic Nerve',
        descAr: 'الشبكية تحوي المستقبلات الضوئية وتحول الضوء إلى نبضات عصبية ينقلها العصب البصري مباشرة إلى الدماغ.',
        surgicalNoteAr: 'علاج اعتلال الشبكية السكري بالليزر وحقن الأدوية داخل الجسم الزجاجي (Anti-VEGF) وإصلاح انفصال الشبكية.',
        color: '#f43f5e',
        position: [0, -0.1, -1.35]
      }
    ],
    surgicalProcedures: [
      {
        nameAr: 'إزالة المياه البيضاء وزراعة عدسة (Phacoemulsification + IOL)',
        nameEn: 'Phaco Cataract Extraction with IOL',
        indicationAr: 'عتمة العدسة الطبيعية (الساد) مما يسبب ضبابية شديدة في الرؤية وصعوبة القراءة والقيادة.',
        stepsAr: [
          'تخدير موضعي بقطرات للعين دون أي ألم.',
          'إحداث شق مجهري فائق الدقة (2.2 مليمتر) عند حافة القرنية.',
          'فتح المحفظة الأمامية للعدسة (Capsulorhexis) بالمسبار الدقيق.',
          'تفتيت وشفط العدسة المعتمة بمسبار الموجات فوق الصوتية (Phaco Probe).',
          'حقن وزراعة عدسة مطوية مرنة متطورة (Intraocular Lens - IOL) داخل المحفظة لتستعيد العين صفاء الرؤية فوراً.'
        ],
        riskAr: 'العملية الجراحية الأكثر شيوعاً ونجاحاً في العالم بنسبة نجاح تفوق 99% وتستغرق نحو 10 دقائق فقط.',
        instrumentsUsed: ['جهاز فاكو Alcon Centurion', 'مقص وملاقط Capsulorhexis', 'حاقن عدسة IOL', 'مادة لزجة Viscoelastic'],
        durationMinutes: 15
      },
      {
        nameAr: 'تصحيح الإبصار بالفيمتو ليزك (Femto-LASIK)',
        nameEn: 'Refractive Surgery (LASIK / PRK)',
        indicationAr: 'تصحيح قصر النظر، طول النظر، واللابؤرية (الاستجماتيزم) للاستغناء التام عن النظارات.',
        stepsAr: [
          'استخدام ليزر الفيمتو ثانية لإنشاء قشرة رقيقة ومثالية من القرنية (Flap).',
          'رفع القشرة القرنية بلطف لكشف طبقة السترومة.',
          'توجيه ليزر الإكزايمر البارد لإعادة تشكيل انحناء القرنية بدقة الميكرون.',
          'إعادة القشرة لمكانها لتلتئم ذاتياً خلال ثوانٍ بدون أي خياطة.'
        ],
        riskAr: 'إجراء فوري وعالي الأمان مع استعادة حدة البصر خلال ساعات قليلة.',
        instrumentsUsed: ['فيمتو ليزر VisuMax', 'إكزايمر ليزر Schwind', 'ملوق تسوية Flap Spatula'],
        durationMinutes: 10
      }
    ]
  },
  knee: {
    titleAr: 'جراحة واستبدال مفصل الركبة 3D (Orthopedics & Joint Replacement)',
    titleEn: 'Total Knee Arthroplasty (TKA) & Joint Surgery',
    subtitle: 'مجسم ثلاثي الأبعاد تفاعلي لعظام الفخذ والساق، الغضروف الهلالي، والأربطة الصليبية، ومحاكاة عملية استبدال المفصل بمفصل تيتانيوم وبوليثيلين متطور.',
    icon: 'Scissors',
    features: [
      {
        id: 'femur_condyles',
        nameAr: 'لقمتا عظم الفخذ (Femoral Condyles)',
        nameEn: 'Distal Femur',
        descAr: 'الطرف السفلي من عظم الفخذ، مغطى بغضروف زجاجي أملس ينزلق على سطح القصبة أثناء ثني وبسط الركبة.',
        surgicalNoteAr: 'يتم نشر وبرد الأسطح المتآكلة وتركيب غطاء الفخذ المعدني المصنوع من الكوبالت كروم أو التيتانيوم.',
        color: '#f8fafc',
        position: [0, 1.0, 0]
      },
      {
        id: 'tibia_plateau',
        nameAr: 'عظم الساق وهضبة القصبة (Tibial Plateau)',
        nameEn: 'Proximal Tibia',
        descAr: 'القاعدة الحاملة لوزن الجسم، تستقبل قوى الضغط المباشرة من الفخذ وتستند عليها الغضاريف الهلالية.',
        surgicalNoteAr: 'يتم قطع العظم بزاوية 90 درجة وتثبيت صينية الساق المعدنية مع قرص البوليثيلين عالي الكثافة (UHMWPE).',
        color: '#e2e8f0',
        position: [0, -1.0, 0]
      },
      {
        id: 'meniscus_ligaments',
        nameAr: 'الغضروف الهلالي والأربطة الصليبية (Meniscus & ACL/PCL)',
        nameEn: 'Cruciate Ligaments & Meniscus',
        descAr: 'ماصات الصدمات الطبيعية ومثبتات المفصل التي تمنع انزلاق الساق للأمام أو الخلف.',
        surgicalNoteAr: 'موضع جراحات المنظار (Arthroscopy) لترميم قطع الرباط الصليبي وخياطة أو تهذيب الغضروف الهلالي.',
        color: '#38bdf8',
        position: [0, 0, 0.6]
      }
    ],
    surgicalProcedures: [
      {
        nameAr: 'استبدال مفصل الركبة بالكامل (Total Knee Arthroplasty - TKA)',
        nameEn: 'Total Knee Replacement Surgery',
        indicationAr: 'خشونة وتآكل مفصل الركبة المتقدم من الدرجة الرابعة مع آلام شديدة وصعوبة المشي.',
        stepsAr: [
          'إحداث شق طولي في مقدمة الركبة وإزاحة صابونة الركبة (الرضفة) لكشف المفصل.',
          'استخدام قوالب التوجيه الدقيقة لقطع وإزالة أسطح العظام التالفة والمتهالكة بدقة المليمتر.',
          'تجربة وقياس المكونات التجريبية (Trial Implants) لضمان توازن الأربطة واستقامة الساق.',
          'تثبيت المفصل الصناعي النهائي باستخدام الأسمنت العظمي (Bone Cement) وتركيب بطانة البوليثيلين فائقة الانزلاق.',
          'غسل المفصل ووضع أنبوب تصريف وخياطة الأنسجة والجلد بطريقة تجميلية.'
        ],
        riskAr: 'عملية ناجحة للغاية تعيد للمريض قدرته على المشي بدون ألم لـ 20-25 سنة.',
        instrumentsUsed: ['منشار عظام متذبذب Stryker', 'قوالب قطع الفخذ والساق', 'أسمنت عظمي PMMA', 'مفصل تيتانيوم وبوليثيلين'],
        durationMinutes: 90
      },
      {
        nameAr: 'تنظير مفصل الركبة وترميم الرباط الصليبي (Knee Arthroscopy & ACL)',
        nameEn: 'ACL Reconstruction Arthroscopy',
        indicationAr: 'قطع الرباط الصليبي الأمامي أو تمزق الغضروف الهلالي أثناء ممارسة الرياضة.',
        stepsAr: [
          'عمل شقين صغيرين (0.5 سم) لإدخال كاميرا المنظار وأدوات العمل الدقيقة.',
          'فحص تجويف المفصل تحت ضخ المحلول الملحي المعقم وإزالة الأجزاء الممزقة من الغضروف.',
          'حفر نفق عظمي في الفخذ والساق لمرور الطعم الوتري الجديد (Hamstring Graft).',
          'تثبيت الرباط الجديد ببراغٍ حيوية قابلة للامتصاص (Bio-absorbable Screws).'
        ],
        riskAr: 'جراحة اليوم الواحد بالمنظار مع عودة لممارسة الرياضة تدريجياً.',
        instrumentsUsed: ['كاميرا منظار 4K Smith & Nephew', 'جهاز حت الغضروف Shaver', 'براغي تثبيت حيوية'],
        durationMinutes: 60
      }
    ]
  },
  laparoscopy: {
    titleAr: 'الجراحة المنظارية للبطن واستئصال المرارة 3D',
    titleEn: 'Laparoscopic Surgery & Cholecystectomy 3D',
    subtitle: 'مجسم ثلاثي الأبعاد تفاعلي لتشريح الكبد، المرارة، والقنوات الصفراوية مع محاكاة إدخال منافذ التروكار وكاميرا المنظار 4K ودبابيس الليغاكليب.',
    icon: 'Flame',
    features: [
      {
        id: 'gallbladder',
        nameAr: 'المرارة والقناة المرارية (Gallbladder & Cystic Duct)',
        nameEn: 'Gallbladder',
        descAr: 'كيس كمثري الشكل يقع أسفل الكبد يخزن العصارة الصفراوية لهضم الدهون.',
        surgicalNoteAr: 'تحديد مثلث كالوت (Calot Triangle) بدقة لوضع دبابيس التيتانيوم وقص القناة المرارية دون إيذاء القناة الجامعة.',
        color: '#10b981',
        position: [0.3, -0.2, 0.9]
      },
      {
        id: 'liver_lobes',
        nameAr: 'فصوص الكبد (Liver Lobes)',
        nameEn: 'Right & Left Hepatic Lobes',
        descAr: 'العضو الصلب الأكبر في البطن، مسؤول عن تنقية السموم، تصنيع عوامل التخثر والبروتينات، وإفراز العصارة الصفراوية.',
        surgicalNoteAr: 'يتم رفع الفص الأيمن بمباعد المنظار لكشف قاع وسرير المرارة أثناء الفصل بالكي الكهربائي.',
        color: '#b91c1c',
        position: [0, 0.4, 0]
      },
      {
        id: 'bile_ducts',
        nameAr: 'القناة الصفراوية الجامعة (Common Bile Duct)',
        nameEn: 'Common Bile Duct (CBD)',
        descAr: 'القناة الرئيسية الناقلة للصفراء من الكبد إلى الاثني عشر.',
        surgicalNoteAr: 'الحفاظ الصارم عليها هو الأولوية القصوى لتجنب التسرب الصفراوي أو الانسداد اليرقاني.',
        color: '#84cc16',
        position: [0.4, -0.8, 0.5]
      }
    ],
    surgicalProcedures: [
      {
        nameAr: 'استئصال المرارة بالمنظار (Laparoscopic Cholecystectomy)',
        nameEn: '4-Port Laparoscopic Cholecystectomy',
        indicationAr: 'حصوات المرارة المسببة للمغص المراري الحاد، التهاب المرارة، أو انسداد القنوات.',
        stepsAr: [
          'إحداث شق سري ونفخ البطن بغاز ثاني أكسيد الكربون ($CO_2$) لتوفير مساحة رؤية واسعة.',
          'إدخال 4 منافذ جراحية دقيقة (Trocars) وكاميرا المنظار عالية الدقة 4K.',
          'تشريح مثلث كالوت وعزل الشريان المراري والقناة المرارية (Critical View of Safety).',
          'وضع دبابيس تيتانيوم (Titanium Clips) وقص الشريان والقناة بالمقص الجراحي.',
          'فصل المرارة من سرير الكبد بالكي الكهربائي وإخراجها داخل كيس عينات جراحي خاص (Endo Catch).'
        ],
        riskAr: 'المعيار الذهبي عالمياً لعلاج حصوات المرارة بتعافٍ فائق خلال 24 ساعة.',
        instrumentsUsed: ['منافذ تروكار 5-10 ملم', 'كاميرا Karl Storz 4K', 'دباسة أوعية Ligaclip', 'خطاف الكي Hook'],
        durationMinutes: 40
      }
    ]
  },
  spine: {
    titleAr: 'جراحة العمود الفقري والانزلاق الغضروفي 3D',
    titleEn: 'Spine Neurosurgery & Disc Decompression 3D',
    subtitle: 'مجسم ثلاثي الأبعاد تفاعلي للفقرات القطنية L4-L5، الحبل الشوكي والجذور العصبية، والقرص الغضروفي المنزلق مع محاكاة إزالة الغضروف وتثبيت الفقرات بالمسامير والشرائح التيتانيوم.',
    icon: 'Activity',
    features: [
      {
        id: 'lumbar_vertebrae',
        nameAr: 'الفقرات القطنية L4-L5 (Lumbar Vertebrae)',
        nameEn: 'Lumbar Vertebrae',
        descAr: 'الفقرات الأكبر والأكثر تحملاً لثقل الجذع وحركات الانحناء في أسفل الظهر.',
        surgicalNoteAr: 'موقع إدخال مسامير التيتانيوم في عنيق الفقرة (Pedicle Screws) لتثبيت العمود الفقري.',
        color: '#f1f5f9',
        position: [0, 0.8, 0]
      },
      {
        id: 'herniated_disc',
        nameAr: 'القرص الغضروفي المنزلق (Herniated Intervertebral Disc)',
        nameEn: 'Herniated Disc & Nucleus Pulposus',
        descAr: 'الوسادة الغضروفية الممتصة للصدمات بين الفقرات، عند فتق الحلقة الليفية تبرز المادة الهلامية لتضغط على العصب.',
        surgicalNoteAr: 'الهدف الرئيسي لجراحة استئصال الغضروف المجهرية (Microdiscectomy) لتحرير العصب المضغوط.',
        color: '#ef4444',
        position: [0, 0, 0.7]
      },
      {
        id: 'spinal_cord_nerves',
        nameAr: 'الحبل الشوكي والجذور العصبية (Thecal Sac & Nerve Roots)',
        nameEn: 'Spinal Cord & Sciatic Nerve Root',
        descAr: 'حزمة الأعصاب النازلة من الدماغ المسؤولة عن إحساس وحركة الساقين وعرق النسا.',
        surgicalNoteAr: 'يتم إزاحتها بلطف بحامي الجذور العصبية (Nerve Root Retractor) لمنع أي إصابة عصبية.',
        color: '#fbbf24',
        position: [0, 0, -0.6]
      }
    ],
    surgicalProcedures: [
      {
        nameAr: 'استئصال الغضروف المجهري (Microscopic Lumbar Discectomy)',
        nameEn: 'Minimally Invasive Microdiscectomy',
        indicationAr: 'الانزلاق الغضروفي القطني الضاغط على عصب عرق النسا والمسبب لآلام مبرحة وضعف الساق.',
        stepsAr: [
          'شق جراحي صغير (2-3 سم) في أسفل الظهر تحت الأشعة التداخلية (C-Arm).',
          'استخدام المجهر الجراحي المكبر لكشف القوس الفقري وإزالة جزء بسيط من الصفيحة العظمية (Laminotomy).',
          'إبعاد الجذر العصبي المضغوط بلطف واستئصال الجزء الغضروفي البارز بملاقط الغضروف الميكروسكوبية.',
          'التأكد من حرية العصب التامة وتسكين موضعي طويل الأمد قبل إغلاق الجلد.'
        ],
        riskAr: 'جراحة دقيقة للغاية تزيل ألم عرق النسا فور إفاقة المريض.',
        instrumentsUsed: ['مجهر جراحي Zeiss', 'ملاقط غضروف Kerrison Rongeur', 'مسبار العصب العصبي Penfield', 'جهاز الأشعة C-Arm'],
        durationMinutes: 50
      },
      {
        nameAr: 'تثبيت الفقرات القطنية بالمسامير والقضبان (TLIF Spine Fusion)',
        nameEn: 'Transforaminal Lumbar Interbody Fusion',
        indicationAr: 'تزحزح الفقرات (Spondylolisthesis) أو عدم ثبات العمود الفقري مع تضيق القناة الشوكية.',
        stepsAr: [
          'إدخال 4 مسامير تيتانيوم عنيقية (Pedicle Screws) في الفقرات L4 و L5.',
          'استئصال القرص الغضروفي كاملاً وزراعة قفص كربوني أو تيتانيوم (Interbody Cage) محشو بفتات العظم.',
          'توصيل المسامير بقضيبين معدنيين متينين لدمج وتثبيت الفقرات بشكل دائم.',
          'إعادة بناء العضلات واللفافة وإغلاق الجرح.'
        ],
        riskAr: 'تعيد استقرار وقوة العمود الفقري وتنهي الآلام المزمنة.',
        instrumentsUsed: ['مسامير تيتانيوم ذاتية الثقب', 'قضبان تثبيت', 'قفص PEEK Cage', 'جهاز ملاحة ثلاثي الأبعاد StealthStation'],
        durationMinutes: 150
      }
    ]
  }
};

interface SurgicalAnatomy3DSuiteProps {
  defaultOrgan?: OrganType;
}

export function SurgicalAnatomy3DSuite({ defaultOrgan = 'heart' }: SurgicalAnatomy3DSuiteProps) {
  const [suiteTab, setSuiteTab] = useState<'simulator' | 'checklist' | 'risk' | 'sutures' | 'report'>('simulator');
  const [selectedOrgan, setSelectedOrgan] = useState<OrganType>(defaultOrgan);

  useEffect(() => {
    if (defaultOrgan) {
      setSelectedOrgan(defaultOrgan);
    }
  }, [defaultOrgan]);

  const [selectedFeature, setSelectedFeature] = useState<OrganFeature | null>(null);
  const [selectedProcedureIndex, setSelectedProcedureIndex] = useState<number>(0);
  const [isBeating, setIsBeating] = useState(true);
  const [isRotating, setIsRotating] = useState(true);
  const [isCrossSection, setIsCrossSection] = useState(false);
  const [viewMode, setViewMode] = useState<'solid' | 'wireframe' | 'xray'>('solid');

  // Operating Room Controls
  const [surgicalLightIntensity, setSurgicalLightIntensity] = useState<number>(100);
  const [isSurgicalLightOn, setIsSurgicalLightOn] = useState<boolean>(true);
  const [activeSurgicalPhase, setActiveSurgicalPhase] = useState<number>(0);
  const [isSoundMuted, setIsSoundMuted] = useState<boolean>(true);
  const [selectedInstrument, setSelectedInstrument] = useState<string>('scalpel');

  // Patient Vitals Simulation
  const [heartRate, setHeartRate] = useState<number>(72);
  const [spo2, setSpo2] = useState<number>(99);
  const [bloodPressure, setBloodPressure] = useState<{ sys: number, dia: number }>({ sys: 120, dia: 80 });

  const canvasContainerRef = useRef<HTMLDivElement>(null);
  const sceneRef = useRef<THREE.Scene | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const organGroupRef = useRef<THREE.Group | null>(null);
  const requestAnimationIdRef = useRef<number | null>(null);
  const surgicalSpotLight1Ref = useRef<THREE.SpotLight | null>(null);
  const surgicalSpotLight2Ref = useRef<THREE.SpotLight | null>(null);

  const organData = ORGAN_DATA[selectedOrgan];

  // Dynamic Patient Telemetry fluctuations
  useEffect(() => {
    const interval = setInterval(() => {
      setHeartRate((prev) => Math.min(85, Math.max(68, prev + Math.floor((Math.random() - 0.5) * 3))));
      setBloodPressure((prev) => ({
        sys: Math.min(125, Math.max(115, prev.sys + Math.floor((Math.random() - 0.5) * 2))),
        dia: Math.min(84, Math.max(76, prev.dia + Math.floor((Math.random() - 0.5) * 2)))
      }));
    }, 2500);
    return () => clearInterval(interval);
  }, []);

  // Initialize and update 3D Scene
  useEffect(() => {
    if (!canvasContainerRef.current) return;

    setSelectedFeature(organData.features[0]);
    setSelectedProcedureIndex(0);
    setActiveSurgicalPhase(0);

    const width = canvasContainerRef.current.clientWidth;
    const height = 480;

    // 1. Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x060d17); // Sterile deep OR slate

    // 2. Camera
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    camera.position.set(0, 0.4, 5.5);
    cameraRef.current = camera;

    let renderer: THREE.WebGLRenderer;
    try {
      renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
      renderer.setSize(width, height);
      renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
      renderer.shadowMap.enabled = true;
      renderer.shadowMap.type = THREE.PCFSoftShadowMap;
      rendererRef.current = renderer;

      canvasContainerRef.current.innerHTML = '';
      canvasContainerRef.current.appendChild(renderer.domElement);
    } catch (err) {
      console.warn('WebGL Renderer initialization error in SurgicalAnatomy3DSuite:', err);
      if (canvasContainerRef.current) {
        canvasContainerRef.current.innerHTML = `
          <div class="h-[480px] w-full flex flex-col items-center justify-center p-6 text-center bg-slate-900 text-slate-200 rounded-2xl border border-slate-800 space-y-3">
            <div class="p-3 bg-emerald-500/20 text-emerald-400 rounded-2xl">
              <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2v20"/><path d="M17 5H9.5a3.5 3.5 0 0 0 0 7h5a3.5 3.5 0 0 1 0 7H6"/></svg>
            </div>
            <h4 class="text-base font-bold text-white">العرض التفاعلي 2D النشط</h4>
            <p class="text-xs text-slate-400 max-w-sm">يمكنك استعراض الخصائص التشريحية والإجراءات الجراحية وحاسبة المخاطر وقوائم السلامة أدناه بنجاح.</p>
          </div>
        `;
      }
      return;
    }

    // 4. Operating Room Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.7);
    scene.add(ambientLight);

    // Dual Overhead Surgical Scialytic Spotlights
    const spot1 = new THREE.SpotLight(0xf0fdf4, (surgicalLightIntensity / 100) * 3.5, 20, Math.PI / 4, 0.3, 1);
    spot1.position.set(3, 6, 4);
    spot1.castShadow = true;
    scene.add(spot1);
    surgicalSpotLight1Ref.current = spot1;

    const spot2 = new THREE.SpotLight(0xe0f2fe, (surgicalLightIntensity / 100) * 3.0, 20, Math.PI / 4, 0.3, 1);
    spot2.position.set(-3, 6, 3);
    spot2.castShadow = true;
    scene.add(spot2);
    surgicalSpotLight2Ref.current = spot2;

    // OR Rim lighting
    const rimLight = new THREE.DirectionalLight(0x0284c7, 1.2);
    rimLight.position.set(0, -4, -3);
    scene.add(rimLight);

    // 5. Operating Theater Environment (Sterile Stage & Mayo Tray Grid)
    const organGroup = new THREE.Group();
    organGroupRef.current = organGroup;
    scene.add(organGroup);

    // Surgical Table Plane / Drapes
    const tableGeo = new THREE.CylinderGeometry(2.8, 2.8, 0.1, 32);
    const tableMat = new THREE.MeshStandardMaterial({
      color: 0x0f766e, // Sterile OR surgical green drape
      roughness: 0.8,
      metalness: 0.1
    });
    const tableMesh = new THREE.Mesh(tableGeo, tableMat);
    tableMesh.position.y = -2.1;
    tableMesh.receiveShadow = true;
    scene.add(tableMesh);

    // Grid Overlay on table
    const gridHelper = new THREE.GridHelper(5, 16, 0x14b8a6, 0x042f2e);
    gridHelper.position.y = -2.04;
    scene.add(gridHelper);

    // Material options helper
    const getMaterial = (color: string | number, opacity = 1, roughness = 0.35, metalness = 0.15) => {
      return new THREE.MeshStandardMaterial({
        color: new THREE.Color(color),
        roughness,
        metalness,
        wireframe: viewMode === 'wireframe',
        transparent: viewMode === 'xray' || opacity < 1,
        opacity: viewMode === 'xray' ? 0.35 : opacity,
        side: THREE.DoubleSide
      });
    };

    // 6. Build High-Fidelity 3D Anatomical Geometry
    if (selectedOrgan === 'heart') {
      // 3D Heart Model
      const heartBodyGeo = new THREE.SphereGeometry(1.2, 32, 32);
      heartBodyGeo.scale(1, 1.3, 0.9);
      const heartMat = getMaterial('#dc2626', 0.95, 0.35, 0.15);
      const heartMesh = new THREE.Mesh(heartBodyGeo, heartMat);
      heartMesh.position.set(0, -0.3, 0);
      organGroup.add(heartMesh);

      // Left & Right Ventricles
      const lvGeo = new THREE.SphereGeometry(0.75, 24, 24);
      lvGeo.scale(0.9, 1.2, 0.85);
      const lvMat = getMaterial('#b91c1c', 0.95);
      const lvMesh = new THREE.Mesh(lvGeo, lvMat);
      lvMesh.position.set(0.5, -0.6, 0.2);
      organGroup.add(lvMesh);

      const rvGeo = new THREE.SphereGeometry(0.7, 24, 24);
      rvGeo.scale(0.85, 1.1, 0.8);
      const rvMat = getMaterial('#991b1b', 0.95);
      const rvMesh = new THREE.Mesh(rvGeo, rvMat);
      rvMesh.position.set(-0.5, -0.6, 0.25);
      organGroup.add(rvMesh);

      // Aorta Arch (Curved Tube)
      const aortaCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0.1, 0.3, 0),
        new THREE.Vector3(0.2, 1.2, 0.1),
        new THREE.Vector3(-0.2, 1.5, 0),
        new THREE.Vector3(-0.6, 1.1, -0.2),
        new THREE.Vector3(-0.6, -0.2, -0.3)
      ]);
      const aortaGeo = new THREE.TubeGeometry(aortaCurve, 40, 0.28, 16, false);
      const aortaMat = getMaterial('#ef4444', 0.98, 0.2, 0.2);
      const aortaMesh = new THREE.Mesh(aortaGeo, aortaMat);
      organGroup.add(aortaMesh);

      // Aorta Branches
      for (let i = 0; i < 3; i++) {
        const branchGeo = new THREE.CylinderGeometry(0.08, 0.08, 0.5, 12);
        const branchMesh = new THREE.Mesh(branchGeo, aortaMat);
        branchMesh.position.set(-0.1 + i * 0.18, 1.55 + i * 0.05, 0.05);
        branchMesh.rotation.z = -0.2 + i * 0.1;
        organGroup.add(branchMesh);
      }

      // Superior Vena Cava
      const svcGeo = new THREE.CylinderGeometry(0.24, 0.24, 1.6, 16);
      const svcMat = getMaterial('#2563eb', 0.95);
      const svcMesh = new THREE.Mesh(svcGeo, svcMat);
      svcMesh.position.set(-0.7, 0.7, -0.1);
      organGroup.add(svcMesh);

      // Coronary Arteries
      for (let i = 0; i < 5; i++) {
        const curve = new THREE.CatmullRomCurve3([
          new THREE.Vector3(0, 0.3, 0.9),
          new THREE.Vector3(0.15 * (i % 2 === 0 ? 1 : -1) + (i * 0.1), -0.2 - (i * 0.2), 0.95 - (i * 0.05)),
          new THREE.Vector3(0.3 * (i % 2 === 0 ? 1 : -1), -0.5 - (i * 0.15), 0.8)
        ]);
        const vesselGeo = new THREE.TubeGeometry(curve, 20, 0.035, 8, false);
        const vesselMat = getMaterial(i % 2 === 0 ? '#f59e0b' : '#ef4444', 1);
        const vesselMesh = new THREE.Mesh(vesselGeo, vesselMat);
        organGroup.add(vesselMesh);
      }

    } else if (selectedOrgan === 'brain') {
      // 3D Brain Model
      const leftHemGeo = new THREE.SphereGeometry(1.2, 32, 28);
      leftHemGeo.scale(0.85, 1.0, 1.25);
      const leftMat = getMaterial('#ec4899', 0.92, 0.4, 0.1);
      const leftHemMesh = new THREE.Mesh(leftHemGeo, leftMat);
      leftHemMesh.position.set(0.65, 0.2, 0);
      organGroup.add(leftHemMesh);

      const rightHemGeo = new THREE.SphereGeometry(1.2, 32, 28);
      rightHemGeo.scale(0.85, 1.0, 1.25);
      const rightMat = getMaterial('#8b5cf6', 0.92, 0.4, 0.1);
      const rightHemMesh = new THREE.Mesh(rightHemGeo, rightMat);
      rightHemMesh.position.set(-0.65, 0.2, 0);
      organGroup.add(rightHemMesh);

      // Cerebellum & Brainstem
      const cerebGeo = new THREE.SphereGeometry(0.6, 24, 24);
      cerebGeo.scale(1.1, 0.7, 0.8);
      const cerebMat = getMaterial('#f97316', 0.95);
      const cerebLeft = new THREE.Mesh(cerebGeo, cerebMat);
      cerebLeft.position.set(0.45, -0.85, -0.65);
      organGroup.add(cerebLeft);

      const cerebRight = new THREE.Mesh(cerebGeo, cerebMat);
      cerebRight.position.set(-0.45, -0.85, -0.65);
      organGroup.add(cerebRight);

      const stemGeo = new THREE.CylinderGeometry(0.25, 0.18, 1.4, 20);
      const stemMat = getMaterial('#fbbf24', 0.95);
      const stemMesh = new THREE.Mesh(stemGeo, stemMat);
      stemMesh.position.set(0, -1.2, -0.2);
      organGroup.add(stemMesh);

    } else if (selectedOrgan === 'eye') {
      // 3D Eye Model
      const scleraGeo = new THREE.SphereGeometry(1.4, 36, 36);
      const scleraMat = getMaterial('#f8fafc', isCrossSection ? 0.6 : 0.98, 0.2, 0.05);
      const scleraMesh = new THREE.Mesh(scleraGeo, scleraMat);
      organGroup.add(scleraMesh);

      // Cornea
      const corneaGeo = new THREE.SphereGeometry(0.85, 28, 28, 0, Math.PI * 2, 0, Math.PI / 2.2);
      const corneaMat = getMaterial('#38bdf8', 0.45, 0.05, 0.2);
      const corneaMesh = new THREE.Mesh(corneaGeo, corneaMat);
      corneaMesh.position.set(0, 0, 0.95);
      corneaMesh.rotation.x = Math.PI / 2;
      organGroup.add(corneaMesh);

      // Iris & Pupil
      const irisGeo = new THREE.RingGeometry(0.25, 0.75, 32);
      const irisMat = getMaterial('#0284c7', 0.95, 0.3, 0.1);
      const irisMesh = new THREE.Mesh(irisGeo, irisMat);
      irisMesh.position.set(0, 0, 1.25);
      organGroup.add(irisMesh);

      const pupilGeo = new THREE.CircleGeometry(0.24, 32);
      const pupilMat = new THREE.MeshBasicMaterial({ color: 0x000000 });
      const pupilMesh = new THREE.Mesh(pupilGeo, pupilMat);
      pupilMesh.position.set(0, 0, 1.26);
      organGroup.add(pupilMesh);

      // Crystalline Lens
      const lensGeo = new THREE.SphereGeometry(0.55, 24, 24);
      lensGeo.scale(1, 1, 0.45);
      const lensMat = getMaterial('#fef08a', 0.75, 0.1, 0.3);
      const lensMesh = new THREE.Mesh(lensGeo, lensMat);
      lensMesh.position.set(0, 0, 0.95);
      organGroup.add(lensMesh);

      // Optic Nerve
      const nerveGeo = new THREE.CylinderGeometry(0.26, 0.28, 1.6, 20);
      const nerveMat = getMaterial('#fbbf24', 0.95);
      const nerveMesh = new THREE.Mesh(nerveGeo, nerveMat);
      nerveMesh.position.set(0, 0, -1.8);
      nerveMesh.rotation.x = Math.PI / 2;
      organGroup.add(nerveMesh);

    } else if (selectedOrgan === 'lungs') {
      // 3D Lungs Anatomy Model (Trachea, Cartilage Rings, Bronchi, Right 3 Lobes, Left 2 Lobes, Diaphragm)
      // 1. Trachea with Cartilage Rings
      const tracheaGeo = new THREE.CylinderGeometry(0.22, 0.22, 1.4, 20);
      const tracheaMat = getMaterial('#38bdf8', 0.9, 0.3, 0.1);
      const tracheaMesh = new THREE.Mesh(tracheaGeo, tracheaMat);
      tracheaMesh.position.set(0, 1.1, 0);
      organGroup.add(tracheaMesh);

      // Cartilage Rings on Trachea
      const ringMat = getMaterial('#e0f2fe', 0.95, 0.2, 0.1);
      for (let i = 0; i < 6; i++) {
        const ringGeo = new THREE.TorusGeometry(0.23, 0.035, 12, 24);
        const ringMesh = new THREE.Mesh(ringGeo, ringMat);
        ringMesh.rotation.x = Math.PI / 2;
        ringMesh.position.set(0, 0.6 + i * 0.16, 0);
        organGroup.add(ringMesh);
      }

      // Left & Right Main Bronchi
      const rightBronchusCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0, 0.4, 0),
        new THREE.Vector3(0.3, 0.1, 0.1),
        new THREE.Vector3(0.65, -0.1, 0.15)
      ]);
      const rightBronchusGeo = new THREE.TubeGeometry(rightBronchusCurve, 16, 0.12, 12, false);
      const bronchusMat = getMaterial('#38bdf8', 0.92, 0.3, 0.1);
      organGroup.add(new THREE.Mesh(rightBronchusGeo, bronchusMat));

      const leftBronchusCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0, 0.4, 0),
        new THREE.Vector3(-0.35, 0.08, 0.1),
        new THREE.Vector3(-0.7, -0.1, 0.15)
      ]);
      const leftBronchusGeo = new THREE.TubeGeometry(leftBronchusCurve, 16, 0.11, 12, false);
      organGroup.add(new THREE.Mesh(leftBronchusGeo, bronchusMat));

      // 2. Right Lung (3 Volumetric Lobes: Superior, Middle, Inferior)
      const lungMatRight = getMaterial('#f43f5e', 0.95, 0.4, 0.05);

      const rSupGeo = new THREE.SphereGeometry(0.7, 24, 24);
      rSupGeo.scale(0.85, 1.1, 0.9);
      const rSupMesh = new THREE.Mesh(rSupGeo, lungMatRight);
      rSupMesh.position.set(0.8, 0.55, 0.05);
      organGroup.add(rSupMesh);

      const rMidGeo = new THREE.SphereGeometry(0.55, 24, 24);
      rMidGeo.scale(0.85, 0.8, 0.85);
      const rMidMesh = new THREE.Mesh(rMidGeo, lungMatRight);
      rMidMesh.position.set(0.88, -0.05, 0.2);
      organGroup.add(rMidMesh);

      const rInfGeo = new THREE.SphereGeometry(0.75, 24, 24);
      rInfGeo.scale(0.9, 1.15, 0.95);
      const rInfMesh = new THREE.Mesh(rInfGeo, lungMatRight);
      rInfMesh.position.set(0.82, -0.65, 0);
      organGroup.add(rInfMesh);

      // 3. Left Lung (2 Volumetric Lobes with Cardiac Notch: Superior, Inferior)
      const lungMatLeft = getMaterial('#fb7185', 0.95, 0.4, 0.05);

      const lSupGeo = new THREE.SphereGeometry(0.72, 24, 24);
      lSupGeo.scale(0.8, 1.15, 0.85);
      const lSupMesh = new THREE.Mesh(lSupGeo, lungMatLeft);
      lSupMesh.position.set(-0.8, 0.45, 0.05);
      organGroup.add(lSupMesh);

      const lInfGeo = new THREE.SphereGeometry(0.72, 24, 24);
      lInfGeo.scale(0.85, 1.1, 0.9);
      const lInfMesh = new THREE.Mesh(lInfGeo, lungMatLeft);
      lInfMesh.position.set(-0.82, -0.6, 0);
      organGroup.add(lInfMesh);

      // Pulmonary Vessels Center Hub
      const paGeo = new THREE.SphereGeometry(0.35, 16, 16);
      paGeo.scale(1.2, 0.6, 0.8);
      const paMat = getMaterial('#2563eb', 0.95);
      const paMesh = new THREE.Mesh(paGeo, paMat);
      paMesh.position.set(0, -0.05, 0.25);
      organGroup.add(paMesh);

      // 4. Diaphragm Base
      const diaGeo = new THREE.CylinderGeometry(1.9, 2.2, 0.2, 32);
      const diaMat = getMaterial('#cbd5e1', 0.85, 0.6, 0.1);
      const diaMesh = new THREE.Mesh(diaGeo, diaMat);
      diaMesh.position.set(0, -1.45, 0);
      organGroup.add(diaMesh);

    } else if (selectedOrgan === 'knee') {
      // 3D Knee Joint (Femur, Tibia, Patella, Meniscus)
      // Distal Femur
      const femurGeo = new THREE.CylinderGeometry(0.55, 0.85, 2.0, 24);
      const boneMat = getMaterial('#f8fafc', 0.98, 0.3, 0.1);
      const femurMesh = new THREE.Mesh(femurGeo, boneMat);
      femurMesh.position.set(0, 1.2, 0);
      organGroup.add(femurMesh);

      // Femoral Condyles (Medial and Lateral bulbs)
      const condyleMat = getMaterial('#f1f5f9', 0.98, 0.25, 0.1);
      const leftCondyle = new THREE.Mesh(new THREE.SphereGeometry(0.45, 20, 20), condyleMat);
      leftCondyle.position.set(0.45, 0.25, 0);
      organGroup.add(leftCondyle);

      const rightCondyle = new THREE.Mesh(new THREE.SphereGeometry(0.45, 20, 20), condyleMat);
      rightCondyle.position.set(-0.45, 0.25, 0);
      organGroup.add(rightCondyle);

      // Proximal Tibia Plateau
      const tibiaGeo = new THREE.CylinderGeometry(0.75, 0.5, 2.0, 24);
      const tibiaMesh = new THREE.Mesh(tibiaGeo, boneMat);
      tibiaMesh.position.set(0, -1.3, 0);
      organGroup.add(tibiaMesh);

      // Meniscus Cushions (Blue cartillage discs)
      const menMat = getMaterial('#38bdf8', 0.85, 0.2, 0.2);
      const menMesh = new THREE.Mesh(new THREE.TorusGeometry(0.55, 0.12, 16, 32), menMat);
      menMesh.rotation.x = Math.PI / 2;
      menMesh.position.set(0, -0.2, 0);
      organGroup.add(menMesh);

      // Titanium Joint Prosthesis Replacement Preview (if active)
      const titaniumMat = getMaterial('#94a3b8', 0.95, 0.1, 0.9);
      const implantMesh = new THREE.Mesh(new THREE.BoxGeometry(1.2, 0.15, 1.0), titaniumMat);
      implantMesh.position.set(0, -0.15, 0);
      organGroup.add(implantMesh);

    } else if (selectedOrgan === 'laparoscopy') {
      // 3D Liver Lobes, Gallbladder, Bile Ducts & Laparoscopic Trocar
      // Liver Lobes
      const liverGeo = new THREE.SphereGeometry(1.5, 32, 28);
      liverGeo.scale(1.4, 0.8, 1.0);
      const liverMat = getMaterial('#991b1b', 0.95, 0.4, 0.1);
      const liverMesh = new THREE.Mesh(liverGeo, liverMat);
      liverMesh.position.set(-0.3, 0.5, 0);
      organGroup.add(liverMesh);

      // Gallbladder (Green pear)
      const gbGeo = new THREE.SphereGeometry(0.5, 24, 24);
      gbGeo.scale(0.7, 1.2, 0.7);
      const gbMat = getMaterial('#10b981', 0.95, 0.3, 0.2);
      const gbMesh = new THREE.Mesh(gbGeo, gbMat);
      gbMesh.position.set(0.4, -0.3, 0.8);
      gbMesh.rotation.z = -0.3;
      organGroup.add(gbMesh);

      // Cystic & Common Bile Duct (Green Tube)
      const ductCurve = new THREE.CatmullRomCurve3([
        new THREE.Vector3(0.4, -0.4, 0.8),
        new THREE.Vector3(0.3, -0.9, 0.5),
        new THREE.Vector3(0.1, -1.4, 0.2)
      ]);
      const ductGeo = new THREE.TubeGeometry(ductCurve, 20, 0.08, 12, false);
      const ductMat = getMaterial('#84cc16', 0.95);
      const ductMesh = new THREE.Mesh(ductGeo, ductMat);
      organGroup.add(ductMesh);

      // Laparoscopic 4K Scope Light Beam
      const scopeGeo = new THREE.CylinderGeometry(0.08, 0.08, 2.5, 16);
      const scopeMat = getMaterial('#64748b', 0.95, 0.1, 0.8);
      const scopeMesh = new THREE.Mesh(scopeGeo, scopeMat);
      scopeMesh.position.set(1.2, 0.8, 1.2);
      scopeMesh.rotation.z = 0.8;
      scopeMesh.rotation.x = -0.4;
      organGroup.add(scopeMesh);

    } else if (selectedOrgan === 'spine') {
      // 3D Lumbar Spine Vertebrae L4-L5 & Intervertebral Disc
      // Vertebra L4 (Upper)
      const vertGeo = new THREE.CylinderGeometry(0.9, 0.9, 0.7, 24);
      const vertMat = getMaterial('#f8fafc', 0.98, 0.3, 0.1);
      const vertL4 = new THREE.Mesh(vertGeo, vertMat);
      vertL4.position.set(0, 0.8, 0);
      organGroup.add(vertL4);

      // Vertebra L5 (Lower)
      const vertL5 = new THREE.Mesh(vertGeo, vertMat);
      vertL5.position.set(0, -0.8, 0);
      organGroup.add(vertL5);

      // Intervertebral Disc (Red Herniated Disc in between)
      const discGeo = new THREE.CylinderGeometry(0.85, 0.85, 0.45, 24);
      const discMat = getMaterial('#ef4444', 0.95, 0.2, 0.1);
      const discMesh = new THREE.Mesh(discGeo, discMat);
      discMesh.position.set(0, 0, 0.05);
      organGroup.add(discMesh);

      // Spinal Canal & Yellow Nerve Roots
      const nerveGeo = new THREE.CylinderGeometry(0.2, 0.2, 2.4, 16);
      const nerveMat = getMaterial('#fbbf24', 0.95);
      const nerveMesh = new THREE.Mesh(nerveGeo, nerveMat);
      nerveMesh.position.set(0, 0, -0.7);
      organGroup.add(nerveMesh);

      // Titanium Pedicle Screws & Fixation Rods
      const rodMat = getMaterial('#94a3b8', 0.95, 0.1, 0.9);
      const leftRod = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.0, 12), rodMat);
      leftRod.position.set(0.6, 0, -0.5);
      organGroup.add(leftRod);

      const rightRod = new THREE.Mesh(new THREE.CylinderGeometry(0.06, 0.06, 2.0, 12), rodMat);
      rightRod.position.set(-0.6, 0, -0.5);
      organGroup.add(rightRod);
    }

    // 7. Interactive 3D Marker Pins with Glow Rings
    organData.features.forEach((feat) => {
      const pinGroup = new THREE.Group();
      pinGroup.position.set(...feat.position);

      const sphereGeo = new THREE.SphereGeometry(0.12, 16, 16);
      const sphereMat = new THREE.MeshStandardMaterial({
        color: new THREE.Color(feat.color),
        emissive: new THREE.Color(feat.color),
        emissiveIntensity: 0.8,
        roughness: 0.2
      });
      const pinSphere = new THREE.Mesh(sphereGeo, sphereMat);
      pinGroup.add(pinSphere);

      const ringGeo = new THREE.RingGeometry(0.15, 0.22, 20);
      const ringMat = new THREE.MeshBasicMaterial({
        color: new THREE.Color(feat.color),
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.7
      });
      const pinRing = new THREE.Mesh(ringGeo, ringMat);
      pinRing.rotation.x = Math.PI / 2;
      pinGroup.add(pinRing);

      organGroup.add(pinGroup);
    });

    // 8. Animation Loop (Heartbeat / Respiration / Orbit)
    let clock = new THREE.Clock();

    const animate = () => {
      requestAnimationIdRef.current = requestAnimationFrame(animate);

      const elapsedTime = clock.getElapsedTime();

      // Rotation
      if (isRotating && organGroupRef.current) {
        organGroupRef.current.rotation.y += 0.005;
      }

      // Pulsation / Heartbeat / Respiration
      if (isBeating && organGroupRef.current) {
        if (selectedOrgan === 'lungs') {
          const breathe = 1 + Math.sin(elapsedTime * 2.2) * 0.06;
          organGroupRef.current.scale.set(breathe * 1.04, breathe, breathe * 1.02);
        } else {
          const pulse = 1 + Math.sin(elapsedTime * 4.5) * 0.04;
          organGroupRef.current.scale.set(pulse, pulse, pulse);
        }
      } else if (organGroupRef.current) {
        organGroupRef.current.scale.set(1, 1, 1);
      }

      if (rendererRef.current && sceneRef.current && cameraRef.current) {
        rendererRef.current.render(sceneRef.current, cameraRef.current);
      }
    };

    animate();

    // Resize handler
    const handleResize = () => {
      if (!canvasContainerRef.current || !rendererRef.current || !cameraRef.current) return;
      const newWidth = canvasContainerRef.current.clientWidth;
      cameraRef.current.aspect = newWidth / height;
      cameraRef.current.updateProjectionMatrix();
      rendererRef.current.setSize(newWidth, height);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (requestAnimationIdRef.current) {
        cancelAnimationFrame(requestAnimationIdRef.current);
      }
      if (rendererRef.current) {
        rendererRef.current.dispose();
      }
    };
  }, [selectedOrgan, viewMode, isCrossSection, isBeating, isRotating, surgicalLightIntensity]);

  // Adjust surgical spotlights
  useEffect(() => {
    const intensity = isSurgicalLightOn ? (surgicalLightIntensity / 100) * 3.5 : 0.2;
    if (surgicalSpotLight1Ref.current) surgicalSpotLight1Ref.current.intensity = intensity;
    if (surgicalSpotLight2Ref.current) surgicalSpotLight2Ref.current.intensity = intensity * 0.85;
  }, [surgicalLightIntensity, isSurgicalLightOn]);

  const handleZoom = (delta: number) => {
    if (!cameraRef.current) return;
    cameraRef.current.position.z = Math.max(3.0, Math.min(8.0, cameraRef.current.position.z + delta));
  };

  const handleResetCamera = () => {
    if (!cameraRef.current || !organGroupRef.current) return;
    cameraRef.current.position.set(0, 0.4, 5.5);
    organGroupRef.current.rotation.set(0, 0, 0);
  };

  const currentProcedure = organData.surgicalProcedures[selectedProcedureIndex] || organData.surgicalProcedures[0];

  return (
    <div className="space-y-6 max-w-7xl mx-auto" dir="rtl">
      {/* 1. Header Banner & Smart Operating Theater Badge */}
      <div className="bg-gradient-to-r from-slate-950 via-slate-900 to-teal-950 rounded-3xl p-6 sm:p-8 text-white border border-teal-500/20 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-teal-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 flex flex-col md:flex-row md:items-center justify-between gap-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2.5">
              <span className="px-3 py-1 bg-emerald-500/20 border border-emerald-500/40 text-emerald-400 text-xs font-black rounded-full flex items-center gap-1.5 animate-pulse">
                <span className="w-2 h-2 rounded-full bg-emerald-400" />
                غرفة العمليات الجراحية الذكية 3D (Smart OR Theater)
              </span>
              <span className="text-xs text-slate-400 font-mono hidden sm:inline">ISO Class 5 Sterile Field</span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-heading font-black text-slate-100 flex items-center gap-3">
              <span>{organData.titleAr}</span>
            </h1>
            <p className="text-sm text-slate-300 max-w-2xl leading-relaxed">
              {organData.subtitle}
            </p>
          </div>

          {/* Organ Selector Tabs (Real Surgical Models) */}
          <div className="flex flex-wrap items-center gap-1.5 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-800 backdrop-blur-md">
            {(['heart', 'brain', 'lungs', 'eye', 'knee', 'laparoscopy', 'spine'] as OrganType[]).map((org) => {
              const info = ORGAN_DATA[org];
              const isSelected = selectedOrgan === org;
              return (
                <button
                  key={org}
                  onClick={() => setSelectedOrgan(org)}
                  className={`px-3 py-2 rounded-xl text-xs font-black transition-all duration-200 flex items-center gap-1.5 ${
                    isSelected
                      ? 'bg-gradient-to-r from-emerald-600 to-teal-600 text-white shadow-lg shadow-emerald-900/40'
                      : 'text-slate-400 hover:text-white hover:bg-slate-800/60'
                  }`}
                >
                  <span>{info.titleAr.split(' ')[0]} {info.titleAr.split(' ')[1]}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>

      {/* Suite Master Navigation Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-thin">
        {[
          { id: 'simulator', label: 'مجسم العمليات والتشريح 3D', icon: 'Box' },
          { id: 'checklist', label: 'قائمة الأمان الجراحي (WHO Checklist)', icon: 'ShieldCheck' },
          { id: 'risk', label: 'تقييم مخاطر التخدير والجراحة (ASA Risk)', icon: 'Stethoscope' },
          { id: 'sutures', label: 'أطلس الخيوط والمشارط الجراحية', icon: 'Scissors' },
          { id: 'report', label: 'محرر ومولد تقارير العمليات (Report)', icon: 'FileText' }
        ].map((tab) => {
          const isActive = suiteTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setSuiteTab(tab.id as any)}
              className={`px-4 py-2.5 rounded-2xl text-xs font-black transition-all flex items-center gap-2 whitespace-nowrap border ${
                isActive
                  ? 'bg-teal-600 border-teal-500 text-white shadow-lg shadow-teal-900/30'
                  : 'bg-slate-900/90 border-slate-800 text-slate-300 hover:bg-slate-800'
              }`}
            >
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {suiteTab === 'checklist' && <SurgicalChecklist />}
      {suiteTab === 'risk' && <SurgicalRiskCalculator />}
      {suiteTab === 'sutures' && <SutureInstrumentGuide />}
      {suiteTab === 'report' && <OperativeReportGenerator />}

      {suiteTab === 'simulator' && (
        <div className="space-y-6">
            {/* 2. Patient Anesthesia Live Telemetry Monitor Bar */}
      <div className="bg-slate-950 rounded-2xl p-4 border border-slate-800 text-slate-100 shadow-xl flex flex-wrap items-center justify-between gap-4 font-mono text-xs">
        <div className="flex items-center gap-2">
          <Activity className="w-4 h-4 text-emerald-400 animate-pulse" />
          <span className="font-bold text-slate-300">مراقبة التخدير والمؤشرات الحيوية (Anesthesia Monitor):</span>
          <span className="px-2 py-0.5 rounded-md bg-emerald-950 text-emerald-300 border border-emerald-800 text-[10px]">
            المريض مستقر (BIS: 48)
          </span>
        </div>

        <div className="flex flex-wrap items-center gap-4 sm:gap-6">
          {/* Heart Rate */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 text-[11px]">HR (BPM):</span>
            <span className="text-emerald-400 font-black text-sm">{heartRate}</span>
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
          </div>

          {/* Blood Pressure */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 text-[11px]">NIBP (mmHg):</span>
            <span className="text-cyan-400 font-black text-sm">{bloodPressure.sys}/{bloodPressure.dia}</span>
          </div>

          {/* SpO2 */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 text-[11px]">SpO₂:</span>
            <span className="text-sky-400 font-black text-sm">{spo2}%</span>
          </div>

          {/* EtCO2 */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 text-[11px]">EtCO₂:</span>
            <span className="text-amber-400 font-black text-sm">38</span>
          </div>

          {/* Temp */}
          <div className="flex items-center gap-1.5">
            <span className="text-slate-400 text-[11px]">Temp:</span>
            <span className="text-purple-400 font-black text-sm">36.8°C</span>
          </div>

          {/* Sound Toggle */}
          <button
            onClick={() => setIsSoundMuted(!isSoundMuted)}
            className="p-1.5 text-slate-400 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
            title={isSoundMuted ? 'تشغيل صوت النبض والتنبيهات' : 'كتم الصوت'}
          >
            {isSoundMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
        </div>
      </div>

      {/* 3. Main 3D Operating Room Stage & Surgical Workspace */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: 3D Stage & Interactive OR Controls (8 Cols) */}
        <div className="lg:col-span-8 space-y-4">
          <div className="relative rounded-3xl overflow-hidden border border-slate-800 shadow-2xl bg-slate-950">
            {/* 3D WebGL Canvas Container */}
            <div ref={canvasContainerRef} className="w-full h-[480px] cursor-grab active:cursor-grabbing" />

            {/* Top-Right Floating Controls (OR Lighting, Modes, Beat, Rotate) */}
            <div className="absolute top-4 right-4 flex flex-col gap-2 z-20">
              {/* Surgical Lamp Toggle */}
              <button
                onClick={() => setIsSurgicalLightOn(!isSurgicalLightOn)}
                className={`p-2.5 rounded-xl border backdrop-blur-md transition-all shadow-lg ${
                  isSurgicalLightOn
                    ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                    : 'bg-slate-900/80 border-slate-700 text-slate-400'
                }`}
                title="كشاف غرفة العمليات المزدوج (Scialytic OR Lamps)"
              >
                <Lightbulb className="w-4 h-4" />
              </button>

              {/* Heartbeat / Pulsation */}
              <button
                onClick={() => setIsBeating(!isBeating)}
                className={`p-2.5 rounded-xl border backdrop-blur-md transition-all shadow-lg ${
                  isBeating
                    ? 'bg-rose-500/20 border-rose-500/50 text-rose-300'
                    : 'bg-slate-900/80 border-slate-700 text-slate-400'
                }`}
                title="الحركة والنبض الحيوي"
              >
                {isBeating ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
              </button>

              {/* 3D Rotation */}
              <button
                onClick={() => setIsRotating(!isRotating)}
                className={`p-2.5 rounded-xl border backdrop-blur-md transition-all shadow-lg ${
                  isRotating
                    ? 'bg-teal-500/20 border-teal-500/50 text-teal-300'
                    : 'bg-slate-900/80 border-slate-700 text-slate-400'
                }`}
                title="الدوران التلقائي 360 درجة"
              >
                <RotateCcw className={`w-4 h-4 ${isRotating ? 'animate-spin' : ''}`} />
              </button>
            </div>

            {/* Top-Left View Mode Toggles (Solid, X-Ray, Wireframe) */}
            <div className="absolute top-4 left-4 flex items-center gap-1.5 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-700/80 backdrop-blur-md z-20">
              <button
                onClick={() => setViewMode('solid')}
                className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all ${
                  viewMode === 'solid' ? 'bg-teal-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                مجسم حقيقي
              </button>
              <button
                onClick={() => setViewMode('xray')}
                className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all ${
                  viewMode === 'xray' ? 'bg-teal-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                أشعة X-Ray
              </button>
              <button
                onClick={() => setViewMode('wireframe')}
                className={`px-2.5 py-1 rounded-xl text-xs font-bold transition-all ${
                  viewMode === 'wireframe' ? 'bg-teal-600 text-white shadow-sm' : 'text-slate-400 hover:text-white'
                }`}
              >
                شبكة 3D
              </button>
            </div>

            {/* Bottom-Right Zoom & Reset Controls */}
            <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-slate-900/80 p-1.5 rounded-2xl border border-slate-700/80 backdrop-blur-md z-20">
              <button
                onClick={() => handleZoom(-0.5)}
                className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                title="تكبير"
              >
                <ZoomIn className="w-4 h-4" />
              </button>
              <button
                onClick={() => handleZoom(0.5)}
                className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                title="تصغير"
              >
                <ZoomOut className="w-4 h-4" />
              </button>
              <button
                onClick={handleResetCamera}
                className="p-1.5 text-slate-300 hover:text-white rounded-lg hover:bg-slate-800 transition-colors"
                title="إعادة ضبط زاوية الكاميرا"
              >
                <Maximize2 className="w-4 h-4" />
              </button>
            </div>

            {/* Bottom-Left Feature Focus Overlay */}
            {selectedFeature && (
              <div className="absolute bottom-4 left-4 max-w-xs sm:max-w-sm bg-slate-900/90 border border-slate-700/80 rounded-2xl p-3.5 backdrop-blur-md shadow-xl text-slate-100 z-20">
                <div className="flex items-center justify-between gap-2 mb-1">
                  <span className="text-xs font-bold text-teal-400 flex items-center gap-1.5">
                    <span className="w-2 h-2 rounded-full" style={{ backgroundColor: selectedFeature.color }} />
                    {selectedFeature.nameAr}
                  </span>
                </div>
                <p className="text-[11px] text-slate-300 leading-snug line-clamp-2">
                  {selectedFeature.surgicalNoteAr}
                </p>
              </div>
            )}
          </div>

          {/* Mayo Sterile Surgical Instrument Tray (طاولة الأدوات الجراحية المعقمة) */}
          <div className="bg-slate-900/90 rounded-2xl p-4 border border-slate-800 space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-slate-300 flex items-center gap-2">
                <Scissors className="w-4 h-4 text-teal-400" />
                صينية الأدوات الجراحية المعقمة (Sterile Mayo Stand Tray):
              </span>
              <span className="text-slate-400">انقر لتحديد الأداة الجراحية</span>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {[
                { id: 'scalpel', name: 'المشرط الجراحي #10', desc: 'لشق الجلد واللفافة' },
                { id: 'cautery', name: 'الكي الكهربائي Bipolar', desc: 'للسيطرة على النزيف' },
                { id: 'retractor', name: 'مباعد الجروح التلقائي', desc: 'لكشف العضو الداخلي' },
                { id: 'suture', name: 'خيوط البرولين والجراحة', desc: 'لإغلاق الطبقات والمفاغرة' }
              ].map((inst) => (
                <button
                  key={inst.id}
                  onClick={() => setSelectedInstrument(inst.id)}
                  className={`p-2.5 rounded-xl text-right transition-all border text-xs ${
                    selectedInstrument === inst.id
                      ? 'bg-teal-950/80 border-teal-500 text-teal-200 shadow-md shadow-teal-950'
                      : 'bg-slate-800/60 border-slate-700/60 text-slate-300 hover:bg-slate-800'
                  }`}
                >
                  <div className="font-black text-slate-100">{inst.name}</div>
                  <div className="text-[10px] text-slate-400">{inst.desc}</div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Right Column: Surgical Steps & Anatomical Exploration (4 Cols) */}
        <div className="lg:col-span-4 space-y-4">
          {/* Procedure Details Card */}
          <div className="bg-slate-900/90 rounded-3xl p-5 border border-slate-800 text-slate-100 shadow-xl space-y-4">
            <div className="flex items-center justify-between">
              <span className="px-2.5 py-1 rounded-lg bg-teal-500/20 text-teal-300 border border-teal-500/30 text-xs font-bold">
                محاكاة العملية الجراحية
              </span>
              <span className="text-xs text-slate-400 font-mono">
                ⏱️ {currentProcedure.durationMinutes} دقيقة
              </span>
            </div>

            <div>
              <h3 className="font-heading font-black text-base text-white">
                {currentProcedure.nameAr}
              </h3>
              <p className="text-xs text-slate-400 mt-1 font-mono">
                {currentProcedure.nameEn}
              </p>
            </div>

            <div className="p-3 bg-slate-950/80 rounded-2xl border border-slate-800/80 text-xs text-slate-300 space-y-1">
              <span className="font-bold text-amber-400 block">دواعي الإجراء الجراحي:</span>
              <p className="leading-relaxed">{currentProcedure.indicationAr}</p>
            </div>

            {/* 4 Surgical Phase Steps */}
            <div className="space-y-2">
              <span className="text-xs font-bold text-slate-300 block">خطوات ومراحل الجراحة:</span>
              <div className="space-y-2">
                {currentProcedure.stepsAr.map((step, idx) => {
                  const isActive = activeSurgicalPhase === idx;
                  return (
                    <div
                      key={idx}
                      onClick={() => setActiveSurgicalPhase(idx)}
                      className={`p-3 rounded-2xl border transition-all cursor-pointer text-xs ${
                        isActive
                          ? 'bg-gradient-to-r from-teal-950 to-slate-900 border-teal-500/80 text-teal-100 shadow-md'
                          : 'bg-slate-950/60 border-slate-800/60 text-slate-400 hover:bg-slate-800/40'
                      }`}
                    >
                      <div className="flex items-center gap-2 font-bold mb-1">
                        <span className={`w-5 h-5 rounded-full flex items-center justify-center text-[10px] font-black ${
                          isActive ? 'bg-teal-500 text-white' : 'bg-slate-800 text-slate-400'
                        }`}>
                          {idx + 1}
                        </span>
                        <span>المرحلة {idx + 1}</span>
                      </div>
                      <p className="text-[11px] leading-relaxed pr-7">{step}</p>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Instruments Used in Procedure */}
            <div className="pt-2 border-t border-slate-800">
              <span className="text-[11px] font-bold text-slate-400 block mb-1.5">الأدوات المستخدمة:</span>
              <div className="flex flex-wrap gap-1">
                {currentProcedure.instrumentsUsed.map((tool, i) => (
                  <span key={i} className="px-2 py-0.5 rounded-md bg-slate-800 text-slate-300 text-[10px] border border-slate-700">
                    {tool}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Anatomical Landmark Pinpoints */}
          <div className="bg-slate-900/90 rounded-3xl p-5 border border-slate-800 text-slate-100 shadow-xl space-y-3">
            <span className="font-bold text-xs text-slate-300 block">المعالم التشريحية في المجسم 3D:</span>
            <div className="space-y-1.5">
              {organData.features.map((feat) => (
                <button
                  key={feat.id}
                  onClick={() => setSelectedFeature(feat)}
                  className={`w-full p-2.5 rounded-xl border text-right transition-all flex items-center justify-between text-xs ${
                    selectedFeature?.id === feat.id
                      ? 'bg-teal-950 border-teal-500 text-teal-200 shadow-sm'
                      : 'bg-slate-950/60 border-slate-800 text-slate-400 hover:bg-slate-800/40'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full" style={{ backgroundColor: feat.color }} />
                    <span className="font-bold">{feat.nameAr.split('(')[0]}</span>
                  </div>
                  <ChevronLeft className="w-3.5 h-3.5 text-slate-500" />
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
        </div>
      )}
    </div>
  );
}
