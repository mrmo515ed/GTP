import React, { useState } from 'react';
import {
  Activity,
  Heart,
  Scale,
  Flame,
  Pill,
  Calendar,
  Baby,
  FileText,
  BookOpen,
  HelpCircle,
  Clock,
  Sparkles,
  Copy,
  Check,
  RotateCcw,
  Download,
  AlertCircle,
  Zap,
  Stethoscope,
  Brain,
  Eye,
  FlaskConical,
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { SurgicalAnatomy3DSuite } from './SurgicalAnatomy3DSuite';
import { ChemicalReactionsLab } from './ChemicalReactionsLab';

interface MedicalToolsSuiteProps {
  defaultTab?: string;
}

const VALID_TABS = [
  '3d-surgery',
  'chemical-lab',
  'bmi',
  'calories',
  'bmr-tdee',
  'body-fat',
  'blood-pressure',
  'heart-rate',
  'pregnancy',
  'pediatric-age',
  'dosage',
  'fluid-dosage',
  'lab-correction',
  'unit-converter',
  'abbreviations',
  'dictionary',
  'report-generator',
  'drug-card',
  'history-calc',
] as const;

function resolveTab(tab?: string): string {
  if (!tab) return '3d-surgery';
  if (VALID_TABS.includes(tab as any)) return tab;

  // Aliases mapping
  const map: Record<string, string> = {
    'medical-tools-suite': '3d-surgery',
    '3d-surgery-simulator': '3d-surgery',
    'surgery-3d-suite': '3d-surgery',
    'cardiac-bypass-surgery': '3d-surgery',
    'heart-surgery-3d': '3d-surgery',
    'brain-neurosurgery-3d': '3d-surgery',
    'lungs-surgery-3d': '3d-surgery',
    'eye-surgery-3d': '3d-surgery',
    'knee-replacement-3d': '3d-surgery',
    'laparoscopy-cholecystectomy-3d': '3d-surgery',
    'spine-disc-surgery-3d': '3d-surgery',
    'chemical-reactions-lab': 'chemical-lab',
    'human-body-reactions': 'chemical-lab',
    'biochem-lab': 'chemical-lab',
    'bmi-calc': 'bmi',
    'bmi-calculator': 'bmi',
    'calorie-calculator': 'calories',
    'bmr-calculator': 'bmr-tdee',
    'bmr-tdee-calculator': 'bmr-tdee',
    'body-fat-calculator': 'body-fat',
    'blood-pressure-log': 'blood-pressure',
    'blood-pressure-analyzer': 'blood-pressure',
    'target-heart-rate': 'heart-rate',
    'heart-rate-calc': 'heart-rate',
    'pregnancy-due-date': 'pregnancy',
    'pregnancy-calculator': 'pregnancy',
    'pediatric-age-calc': 'pediatric-age',
    'medical-dosage-calc': 'dosage',
    'dosage-calculator': 'dosage',
    'fluid-maintenance-calc': 'fluid-dosage',
    'fluid-calculator': 'fluid-dosage',
    'lab-correction-calc': 'lab-correction',
    'medical-unit-converter': 'unit-converter',
    'medical-abbreviations': 'abbreviations',
    'medical-dictionary': 'dictionary',
    'medical-report-gen': 'report-generator',
    'drug-info-card': 'drug-card',
    'medical-history-tracker': 'history-calc',
  };

  return map[tab] || '3d-surgery';
}

export function MedicalToolsSuite({ defaultTab = '3d-surgery' }: MedicalToolsSuiteProps) {
  const [activeTab, setActiveTab] = useState<string>(() => resolveTab(defaultTab));
  const [copied, setCopied] = useState(false);

  // Sync if defaultTab changes
  React.useEffect(() => {
    if (defaultTab) {
      setActiveTab(resolveTab(defaultTab));
    }
  }, [defaultTab]);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6" id="medical-tools-suite">
      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-gray-200 dark:border-gray-800">
        {[
          { id: '3d-surgery', label: 'الأطلس الجراحي 3D (قلب/دماغ/عيون)', icon: Stethoscope },
          { id: 'chemical-lab', label: 'مختبر التفاعلات الكيميائية والجدول الدوري', icon: FlaskConical },
          { id: 'bmi', label: 'حاسبة BMI', icon: Scale },
          { id: 'calories', label: 'حاسبة السعرات', icon: Flame },
          { id: 'bmr-tdee', label: 'حاسبة BMR / TDEE', icon: Activity },
          { id: 'body-fat', label: 'نسبة الدهون', icon: Sparkles },
          { id: 'blood-pressure', label: 'ضغط الدم', icon: Heart },
          { id: 'heart-rate', label: 'معدل النبض المستهدف', icon: Activity },
          { id: 'pregnancy', label: 'الحمل وموعد الولادة', icon: Baby },
          { id: 'pediatric-age', label: 'حاسبة العمر الطبي', icon: Calendar },
          { id: 'dosage', label: 'حاسبة الجرعات (تعليمي)', icon: Pill },
          { id: 'fluid-dosage', label: 'جرعة السوائل الوريدية', icon: Zap },
          { id: 'lab-correction', label: 'تصحيح التحاليل المخبرية', icon: Activity },
          { id: 'unit-converter', label: 'تحويل وحدات طبية', icon: RotateCcw },
          { id: 'abbreviations', label: 'الاختصارات الطبية', icon: HelpCircle },
          { id: 'dictionary', label: 'قاموس طبي', icon: BookOpen },
          { id: 'report-generator', label: 'مولد تقرير طبي', icon: FileText },
          { id: 'drug-card', label: 'بطاقة معلومات دواء', icon: Pill },
          { id: 'history-calc', label: 'التاريخ الطبي والمتابعة', icon: Clock },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                isActive
                  ? 'bg-rose-600 text-white shadow-md'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-5 sm:p-6 shadow-xs">
        {activeTab === '3d-surgery' && <SurgicalAnatomy3DSuite />}
        {activeTab === 'chemical-lab' && <ChemicalReactionsLab />}
        {activeTab === 'bmi' && <BMICalculator />}
        {activeTab === 'calories' && <CaloriesCalculator />}
        {activeTab === 'bmr-tdee' && <BMRTDEECalculator />}
        {activeTab === 'body-fat' && <BodyFatCalculator />}
        {activeTab === 'blood-pressure' && <BloodPressureAnalyzer />}
        {activeTab === 'heart-rate' && <TargetHeartRateCalculator />}
        {activeTab === 'pregnancy' && <PregnancyDueCalculator />}
        {activeTab === 'pediatric-age' && <PediatricAgeCalculator />}
        {activeTab === 'dosage' && <EducationalDosageCalculator />}
        {activeTab === 'fluid-dosage' && <FluidMaintenanceCalculator />}
        {activeTab === 'lab-correction' && <LabCorrectionCalculator />}
        {activeTab === 'unit-converter' && <MedicalUnitConverter />}
        {activeTab === 'abbreviations' && <MedicalAbbreviationsTool />}
        {activeTab === 'dictionary' && <MedicalDictionaryTool />}
        {activeTab === 'report-generator' && <MedicalReportGenerator />}
        {activeTab === 'drug-card' && <DrugCardGenerator />}
        {activeTab === 'history-calc' && <MedicalHistoryCalculator />}
      </div>
    </div>
  );
}

// 1. BMI Calculator
function BMICalculator() {
  const [weight, setWeight] = useState(70);
  const [height, setHeight] = useState(175);

  const bmi = weight > 0 && height > 0 ? (weight / Math.pow(height / 100, 2)).toFixed(1) : '0';
  const bmiNum = parseFloat(bmi);

  let status = { text: 'وزن مثالي', color: 'text-emerald-600', bg: 'bg-emerald-50 dark:bg-emerald-950/60 border-emerald-200' };
  if (bmiNum < 18.5) status = { text: 'نقص في الوزن (نحافة)', color: 'text-amber-600', bg: 'bg-amber-50 dark:bg-amber-950/60 border-amber-200' };
  else if (bmiNum >= 25 && bmiNum < 30) status = { text: 'وزن زائد', color: 'text-orange-600', bg: 'bg-orange-50 dark:bg-orange-950/60 border-orange-200' };
  else if (bmiNum >= 30) status = { text: 'سمنة', color: 'text-rose-600', bg: 'bg-rose-50 dark:bg-rose-950/60 border-rose-200' };

  const idealMin = (18.5 * Math.pow(height / 100, 2)).toFixed(1);
  const idealMax = (24.9 * Math.pow(height / 100, 2)).toFixed(1);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-3">
        <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <Scale className="w-5 h-5 text-rose-600" />
          <span>حاسبة مؤشر كتلة الجسم (BMI) والوزن المثالي</span>
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
              الوزن (كجم): {weight} كجم
            </label>
            <input
              type="range"
              min="30"
              max="200"
              value={weight}
              onChange={(e) => setWeight(Number(e.target.value))}
              className="w-full accent-rose-600"
            />
            <input
              type="number"
              value={weight}
              onChange={(e) => setWeight(Number(e.target.value))}
              className="mt-2 w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 dark:border-gray-700"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
              الطول (سم): {height} سم
            </label>
            <input
              type="range"
              min="100"
              max="220"
              value={height}
              onChange={(e) => setHeight(Number(e.target.value))}
              className="w-full accent-rose-600"
            />
            <input
              type="number"
              value={height}
              onChange={(e) => setHeight(Number(e.target.value))}
              className="mt-2 w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 dark:border-gray-700"
            />
          </div>
        </div>

        <div className="flex flex-col justify-center items-center p-6 rounded-2xl bg-gray-50 dark:bg-gray-800/60 border border-gray-200 dark:border-gray-700 text-center space-y-3">
          <span className="text-xs font-bold text-gray-500 dark:text-gray-400">مؤشر كتلة جسمك الحالي</span>
          <div className="text-5xl font-black text-gray-900 dark:text-white font-mono">{bmi}</div>
          <div className={`px-4 py-1.5 rounded-full text-xs font-black border ${status.bg} ${status.color}`}>
            {status.text}
          </div>
          <p className="text-xs text-gray-500 dark:text-gray-400 pt-2 border-t border-gray-200 dark:border-gray-700 w-full">
            الوزن المثالي لطولك ({height} سم) يتراوح بين <strong className="text-gray-900 dark:text-white">{idealMin} - {idealMax} كجم</strong>
          </p>
        </div>
      </div>
    </div>
  );
}

// 2. Calories Calculator
function CaloriesCalculator() {
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [age, setAge] = useState(25);
  const [weight, setWeight] = useState(70);
  const [height, setHeight] = useState(175);
  const [activity, setActivity] = useState(1.375); // Light activity

  // Mifflin-St Jeor Formula
  const bmr =
    gender === 'male'
      ? 10 * weight + 6.25 * height - 5 * age + 5
      : 10 * weight + 6.25 * height - 5 * age - 161;

  const tdee = Math.round(bmr * activity);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-3">
        <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <Flame className="w-5 h-5 text-amber-500" />
          <span>حاسبة الاحتياج اليومي من السعرات الحرارية (TDEE)</span>
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="space-y-3.5">
          <div className="flex gap-2">
            <button
              onClick={() => setGender('male')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl border transition ${
                gender === 'male'
                  ? 'bg-rose-600 text-white border-rose-600'
                  : 'bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
              }`}
            >
              ذكر
            </button>
            <button
              onClick={() => setGender('female')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl border transition ${
                gender === 'female'
                  ? 'bg-rose-600 text-white border-rose-600'
                  : 'bg-gray-50 dark:bg-gray-800 text-gray-700 dark:text-gray-300'
              }`}
            >
              أنثى
            </button>
          </div>

          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="block text-[11px] font-bold text-gray-600 dark:text-gray-400 mb-1">العمر</label>
              <input
                type="number"
                value={age}
                onChange={(e) => setAge(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 dark:border-gray-700"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-gray-600 dark:text-gray-400 mb-1">الوزن (كجم)</label>
              <input
                type="number"
                value={weight}
                onChange={(e) => setWeight(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 dark:border-gray-700"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-gray-600 dark:text-gray-400 mb-1">الطول (سم)</label>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 dark:border-gray-700"
              />
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-gray-600 dark:text-gray-400 mb-1">مستوى النشاط البدني</label>
            <select
              value={activity}
              onChange={(e) => setActivity(Number(e.target.value))}
              className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 dark:border-gray-700"
            >
              <option value={1.2}>خامل (قليل أو بدون تمرين)</option>
              <option value={1.375}>خفيف (تمرين 1-3 أيام أسبوعياً)</option>
              <option value={1.55}>متوسط (تمرين 3-5 أيام أسبوعياً)</option>
              <option value={1.725}>نشط جداً (تمرين 6-7 أيام أسبوعياً)</option>
              <option value={1.9}>نشط للغاية (تمارين شاقة يومياً)</option>
            </select>
          </div>
        </div>

        <div className="p-5 rounded-2xl bg-amber-50/50 dark:bg-amber-950/20 border border-amber-200 dark:border-amber-900/50 space-y-3 flex flex-col justify-center">
          <div className="text-center">
            <span className="text-xs font-bold text-amber-700 dark:text-amber-300">للحفاظ على الوزن الحالي</span>
            <div className="text-4xl font-black text-gray-900 dark:text-white mt-1">{tdee} سعرة / يوم</div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-3 border-t border-amber-200/80 dark:border-amber-900/60 text-center">
            <div className="p-2.5 rounded-xl bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
              <span className="text-[10px] text-gray-500 font-bold">لإنقاص الوزن (0.5 كجم/أسبوع)</span>
              <div className="text-sm font-black text-rose-600 mt-0.5">{Math.max(1200, tdee - 500)} سعرة</div>
            </div>
            <div className="p-2.5 rounded-xl bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700">
              <span className="text-[10px] text-gray-500 font-bold">لزيادة الوزن (عضلات/كتلة)</span>
              <div className="text-sm font-black text-emerald-600 mt-0.5">{tdee + 400} سعرة</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

// 3. BMR / TDEE Calculator
function BMRTDEECalculator() {
  return <CaloriesCalculator />;
}

// 4. Body Fat Calculator (U.S. Navy Method)
function BodyFatCalculator() {
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [height, setHeight] = useState(175);
  const [waist, setWaist] = useState(85);
  const [neck, setNeck] = useState(38);
  const [hip, setHip] = useState(95);

  let bodyFat = 0;
  if (gender === 'male') {
    bodyFat = 495 / (1.0324 - 0.19077 * Math.log10(waist - neck) + 0.15456 * Math.log10(height)) - 450;
  } else {
    bodyFat = 495 / (1.29579 - 0.35004 * Math.log10(waist + hip - neck) + 0.221 * Math.log10(height)) - 450;
  }
  const fatResult = isNaN(bodyFat) || bodyFat < 0 ? 0 : bodyFat.toFixed(1);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-3">
        <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <Sparkles className="w-5 h-5 text-indigo-500" />
          <span>حاسبة نسبة الدهون في الجسم (طريقة البحرية الأمريكية U.S. Navy)</span>
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="space-y-3">
          <div className="flex gap-2">
            <button
              onClick={() => setGender('male')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl border transition ${
                gender === 'male' ? 'bg-indigo-600 text-white' : 'bg-gray-50 dark:bg-gray-800'
              }`}
            >
              ذكر
            </button>
            <button
              onClick={() => setGender('female')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl border transition ${
                gender === 'female' ? 'bg-indigo-600 text-white' : 'bg-gray-50 dark:bg-gray-800'
              }`}
            >
              أنثى
            </button>
          </div>

          <div className="grid grid-cols-2 gap-2">
            <div>
              <label className="block text-[11px] font-bold text-gray-600 mb-1">الطول (سم)</label>
              <input
                type="number"
                value={height}
                onChange={(e) => setHeight(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-gray-600 mb-1">محيط الخصر (سم)</label>
              <input
                type="number"
                value={waist}
                onChange={(e) => setWaist(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
              />
            </div>
            <div>
              <label className="block text-[11px] font-bold text-gray-600 mb-1">محيط الرقبة (سم)</label>
              <input
                type="number"
                value={neck}
                onChange={(e) => setNeck(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
              />
            </div>
            {gender === 'female' && (
              <div>
                <label className="block text-[11px] font-bold text-gray-600 mb-1">محيط الأرداف (سم)</label>
                <input
                  type="number"
                  value={hip}
                  onChange={(e) => setHip(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
                />
              </div>
            )}
          </div>
        </div>

        <div className="p-6 rounded-2xl bg-indigo-50/50 dark:bg-indigo-950/20 border border-indigo-200 dark:border-indigo-900 text-center flex flex-col justify-center space-y-2">
          <span className="text-xs font-bold text-indigo-700 dark:text-indigo-300">نسبة الدهون المقدرة</span>
          <div className="text-5xl font-black text-gray-900 dark:text-white font-mono">{fatResult}%</div>
          <p className="text-xs text-gray-500">
            المعدل الصحي للرجال: 10-20% | للنساء: 18-28%
          </p>
        </div>
      </div>
    </div>
  );
}

// 5. Blood Pressure Analyzer
function BloodPressureAnalyzer() {
  const [systolic, setSystolic] = useState(120);
  const [diastolic, setDiastolic] = useState(80);

  let category = { title: 'طبيعي (Normal)', color: 'text-emerald-600', bg: 'bg-emerald-50 border-emerald-200' };
  if (systolic < 120 && diastolic < 80) {
    category = { title: 'طبيعي ومثالي', color: 'text-emerald-600', bg: 'bg-emerald-50 border-emerald-200' };
  } else if (systolic >= 120 && systolic <= 129 && diastolic < 80) {
    category = { title: 'مرتفع قليلاً (Elevated)', color: 'text-yellow-600', bg: 'bg-yellow-50 border-yellow-200' };
  } else if ((systolic >= 130 && systolic <= 139) || (diastolic >= 80 && diastolic <= 89)) {
    category = { title: 'ضغط دم مرتفع - مرحلة 1 (Stage 1)', color: 'text-orange-600', bg: 'bg-orange-50 border-orange-200' };
  } else if (systolic >= 140 || diastolic >= 90) {
    category = { title: 'ضغط دم مرتفع - مرحلة 2 (Stage 2)', color: 'text-rose-600', bg: 'bg-rose-50 border-rose-200' };
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between border-b border-gray-100 dark:border-gray-800 pb-3">
        <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <Heart className="w-5 h-5 text-rose-600" />
          <span>حاسبة ومحلل فئات ضغط الدم (وفق جمعية القلب الأمريكية AHA)</span>
        </h3>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
              الضغط الانقباضي Systolic (العلوي): {systolic} mmHg
            </label>
            <input
              type="range"
              min="80"
              max="200"
              value={systolic}
              onChange={(e) => setSystolic(Number(e.target.value))}
              className="w-full accent-rose-600"
            />
          </div>
          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
              الضغط الانبساطي Diastolic (السفلي): {diastolic} mmHg
            </label>
            <input
              type="range"
              min="50"
              max="130"
              value={diastolic}
              onChange={(e) => setDiastolic(Number(e.target.value))}
              className="w-full accent-rose-600"
            />
          </div>
        </div>

        <div className={`p-6 rounded-2xl border text-center flex flex-col justify-center space-y-3 ${category.bg}`}>
          <span className="text-xs font-bold text-gray-600 dark:text-gray-300">النتيجة والتشخيص التقريبي</span>
          <div className="text-4xl font-black text-gray-900 dark:text-white font-mono">
            {systolic} / {diastolic}
          </div>
          <div className={`text-sm font-black ${category.color}`}>{category.title}</div>
        </div>
      </div>
    </div>
  );
}

// 6. Target Heart Rate Calculator
function TargetHeartRateCalculator() {
  const [age, setAge] = useState(30);
  const [restingHR, setRestingHR] = useState(70);

  const maxHR = 220 - age;
  const fatBurnMin = Math.round(maxHR * 0.6);
  const fatBurnMax = Math.round(maxHR * 0.7);
  const cardioMin = Math.round(maxHR * 0.7);
  const cardioMax = Math.round(maxHR * 0.85);

  return (
    <div className="space-y-5">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Activity className="w-5 h-5 text-rose-500" />
        <span>حاسبة معدل ضربات القلب والنبض المستهدف للتمارين</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">العمر</label>
          <input
            type="number"
            value={age}
            onChange={(e) => setAge(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">نبض الراحة (اختياري)</label>
          <input
            type="number"
            value={restingHR}
            onChange={(e) => setRestingHR(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-xl bg-gray-50 dark:bg-gray-800 border text-center">
          <span className="text-[11px] text-gray-500 font-bold">أقصى معدل نبض (Max HR)</span>
          <div className="text-2xl font-black text-gray-900 dark:text-white mt-1">{maxHR} نبضة/دقيقة</div>
        </div>
        <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 text-center">
          <span className="text-[11px] text-amber-700 font-bold">نطاق حرق الدهون (60-70%)</span>
          <div className="text-2xl font-black text-amber-600 mt-1">{fatBurnMin} - {fatBurnMax} نبضة</div>
        </div>
        <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 text-center">
          <span className="text-[11px] text-rose-700 font-bold">نطاق الكارديو واللياقة (70-85%)</span>
          <div className="text-2xl font-black text-rose-600 mt-1">{cardioMin} - {cardioMax} نبضة</div>
        </div>
      </div>
    </div>
  );
}

// 7. Pregnancy & Due Date Calculator
function PregnancyDueCalculator() {
  const [lmpDate, setLmpDate] = useState(() => {
    const d = new Date();
    d.setDate(d.getDate() - 60);
    return d.toISOString().split('T')[0];
  });

  const lmp = new Date(lmpDate);
  const dueDate = new Date(lmp);
  dueDate.setDate(dueDate.getDate() + 280); // Naegele rule

  const now = new Date();
  const diffDays = Math.max(0, Math.floor((now.getTime() - lmp.getTime()) / (1000 * 60 * 60 * 24)));
  const weeks = Math.floor(diffDays / 7);
  const days = diffDays % 7;

  return (
    <div className="space-y-5">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Baby className="w-5 h-5 text-pink-500" />
        <span>حاسبة الحمل، عمر الجنين وتاريخ الولادة المتوقع</span>
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        <div>
          <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
            تاريخ أول يوم من آخر دورة شهرية (LMP)
          </label>
          <input
            type="date"
            value={lmpDate}
            onChange={(e) => setLmpDate(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>

        <div className="p-5 rounded-2xl bg-pink-50 dark:bg-pink-950/30 border border-pink-200 dark:border-pink-900/50 space-y-2 text-center">
          <span className="text-xs font-bold text-pink-700 dark:text-pink-300">الموعد المتوقع للولادة (EDD)</span>
          <div className="text-2xl font-black text-gray-900 dark:text-white">
            {dueDate.toLocaleDateString('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
          <div className="text-xs font-bold text-pink-600 pt-2 border-t border-pink-200">
            عمر الحمل الحالي: {weeks} أسبوع و {days} أيام
          </div>
        </div>
      </div>
    </div>
  );
}

// 8. Pediatric Age Calculator
function PediatricAgeCalculator() {
  const [birthDate, setBirthDate] = useState('2024-01-01');

  const b = new Date(birthDate);
  const now = new Date();
  const diffTime = Math.abs(now.getTime() - b.getTime());
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  const months = Math.floor(diffDays / 30.4375);
  const years = Math.floor(months / 12);
  const remMonths = months % 12;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Calendar className="w-5 h-5 text-teal-600" />
        <span>حاسبة العمر الطبي للأطفال والرضع بالتفصيل</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-bold mb-1">تاريخ الميلاد</label>
          <input
            type="date"
            value={birthDate}
            onChange={(e) => setBirthDate(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div className="p-4 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 text-center">
          <span className="text-xs font-bold text-teal-700">العمر الدقيق</span>
          <div className="text-xl font-black text-gray-900 dark:text-white mt-1">
            {years} سنة و {remMonths} شهر ({diffDays} يوم)
          </div>
        </div>
      </div>
    </div>
  );
}

// 9. Educational Dosage Calculator
function EducationalDosageCalculator() {
  const [weight, setWeight] = useState(15);
  const [doseMgKg, setDoseMgKg] = useState(15); // e.g. Paracetamol 15mg/kg
  const [concentration, setConcentration] = useState(120); // 120mg / 5ml
  const [perMl, setPerMl] = useState(5);

  const totalDoseMg = weight * doseMgKg;
  const liquidDoseMl = ((totalDoseMg * perMl) / concentration).toFixed(1);

  return (
    <div className="space-y-5">
      <div className="p-3 bg-amber-50 dark:bg-amber-950/50 border border-amber-200 dark:border-amber-800 rounded-xl flex items-center gap-2 text-xs text-amber-800 dark:text-amber-200">
        <AlertCircle className="w-4 h-4 shrink-0 text-amber-600" />
        <span>تنبيه هام: هذه الحاسبة للأغراض التعليمية والحسابية فقط. يجب مراجعة الطبيب والصيدلي لتحديد الجرعة العلاجية الدقيقة.</span>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">وزن الطفل (كجم)</label>
          <input
            type="number"
            value={weight}
            onChange={(e) => setWeight(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">الجرعة المقترحة (ملغ / كجم)</label>
          <input
            type="number"
            value={doseMgKg}
            onChange={(e) => setDoseMgKg(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">تركيز الشراب (ملغ / مل)</label>
          <div className="flex gap-1">
            <input
              type="number"
              placeholder="ملغ"
              value={concentration}
              onChange={(e) => setConcentration(Number(e.target.value))}
              className="w-2/3 px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
            />
            <input
              type="number"
              placeholder="مل"
              value={perMl}
              onChange={(e) => setPerMl(Number(e.target.value))}
              className="w-1/3 px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
            />
          </div>
        </div>
      </div>

      <div className="p-4 rounded-xl bg-gray-50 dark:bg-gray-800 border text-center">
        <span className="text-xs font-bold text-gray-500">الجرعة المحسوبة لكل نوبة</span>
        <div className="text-3xl font-black text-rose-600 mt-1">{liquidDoseMl} مل ({totalDoseMg} ملغ)</div>
      </div>
    </div>
  );
}

// 10. Fluid Maintenance Calculator (Holliday-Segar)
function FluidMaintenanceCalculator() {
  const [weight, setWeight] = useState(25);

  let dailyMl = 0;
  if (weight <= 10) {
    dailyMl = weight * 100;
  } else if (weight <= 20) {
    dailyMl = 1000 + (weight - 10) * 50;
  } else {
    dailyMl = 1500 + (weight - 20) * 20;
  }

  const hourlyMl = (dailyMl / 24).toFixed(1);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Zap className="w-5 h-5 text-blue-500" />
        <span>حاسبة السوائل الوريدية اليومية (قاعدة Holliday-Segar 4-2-1)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-bold mb-1">وزن المريض (كجم)</label>
          <input
            type="number"
            value={weight}
            onChange={(e) => setWeight(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 text-center">
          <span className="text-xs font-bold text-blue-700">معدل التنقيط المطلوب</span>
          <div className="text-2xl font-black text-blue-600 mt-1">{hourlyMl} مل / ساعة</div>
          <div className="text-xs text-gray-500 mt-0.5">إجمالي يومي: {dailyMl} مل/24 ساعة</div>
        </div>
      </div>
    </div>
  );
}

// 11. Lab Unit Correction (Corrected Calcium)
function LabCorrectionCalculator() {
  const [calcium, setCalcium] = useState(8.5);
  const [albumin, setAlbumin] = useState(3.0);

  // Corrected Calcium = Total Calcium + 0.8 * (4.0 - Albumin)
  const corrected = (calcium + 0.8 * (4.0 - albumin)).toFixed(2);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Activity className="w-5 h-5 text-purple-500" />
        <span>حاسبة تصحيح الكالسيوم مع الألبومين (Corrected Calcium)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-bold mb-1">الكالسيوم المقاس (mg/dL)</label>
          <input
            type="number"
            step="0.1"
            value={calcium}
            onChange={(e) => setCalcium(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">الألبومين المقاس (g/dL)</label>
          <input
            type="number"
            step="0.1"
            value={albumin}
            onChange={(e) => setAlbumin(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>

      <div className="p-4 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 text-center">
        <span className="text-xs font-bold text-purple-700">الكالسيوم المصحح</span>
        <div className="text-3xl font-black text-purple-600 mt-1">{corrected} mg/dL</div>
        <span className="text-[11px] text-gray-500">المعدل الطبيعي: 8.5 - 10.2 mg/dL</span>
      </div>
    </div>
  );
}

// 12. Medical Unit Converter
function MedicalUnitConverter() {
  const [val, setVal] = useState(100);
  const [type, setType] = useState<'glucose' | 'cholesterol' | 'creatinine'>('glucose');

  let result = '';
  if (type === 'glucose') {
    // mg/dL to mmol/L (/18)
    result = `${(val / 18).toFixed(2)} mmol/L أو ${(val * 18).toFixed(0)} mg/dL`;
  } else if (type === 'cholesterol') {
    // mg/dL to mmol/L (/38.67)
    result = `${(val / 38.67).toFixed(2)} mmol/L`;
  } else if (type === 'creatinine') {
    // mg/dL to umol/L (*88.4)
    result = `${(val * 88.4).toFixed(1)} µmol/L`;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <RotateCcw className="w-5 h-5 text-emerald-500" />
        <span>محول الوحدات المخبرية والطبية</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-bold mb-1">نوع التحليل</label>
          <select
            value={type}
            onChange={(e: any) => setType(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          >
            <option value="glucose">سكر الدم (Glucose: mg/dL ↔ mmol/L)</option>
            <option value="cholesterol">الكوليسترول (Cholesterol: mg/dL ↔ mmol/L)</option>
            <option value="creatinine">الكرياتينين (Creatinine: mg/dL ↔ µmol/L)</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">القيمة</label>
          <input
            type="number"
            value={val}
            onChange={(e) => setVal(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>

      <div className="p-4 rounded-xl bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 text-center">
        <span className="text-xs font-bold text-emerald-700">القيمة المحولة</span>
        <div className="text-2xl font-black text-emerald-600 mt-1">{result}</div>
      </div>
    </div>
  );
}

// 13. Medical Abbreviations Tool
function MedicalAbbreviationsTool() {
  const [search, setSearch] = useState('');

  const abbreviations = [
    { abbr: 'BP', ar: 'ضغط الدم (Blood Pressure)' },
    { abbr: 'HR', ar: 'معدل ضربات القلب (Heart Rate)' },
    { abbr: 'CBC', ar: 'تعداد الدم الكامل (Complete Blood Count)' },
    { abbr: 'ECG / EKG', ar: 'تخطيط كهربية القلب (Electrocardiogram)' },
    { abbr: 'MRI', ar: 'التصوير بالرنين المغناطيسي' },
    { abbr: 'CT', ar: 'التصوير المقطعي المحوسب' },
    { abbr: 'IV', ar: 'حقن وريدي (Intravenous)' },
    { abbr: 'IM', ar: 'حقن عضلي (Intramuscular)' },
    { abbr: 'PO', ar: 'عن طريق الفم (Per Os)' },
    { abbr: 'PRN', ar: 'عند اللزوم (Pro Re Nata)' },
    { abbr: 'BID', ar: 'مرتين يومياً (Bis in die)' },
    { abbr: 'TID', ar: 'ثلاث مرات يومياً (Ter in die)' },
    { abbr: 'QID', ar: 'أربع مرات يومياً (Quater in die)' },
    { abbr: 'NPO', ar: 'ممنوع الأكل والشرب (Nothing by mouth)' },
    { abbr: 'STAT', ar: 'فوراً وعاجل (Immediately)' },
    { abbr: 'Rx', ar: 'وصفة طبية / علاج (Prescription)' },
    { abbr: 'Dx', ar: 'التشخيص الطبي (Diagnosis)' },
    { abbr: 'Hx', ar: 'التاريخ المرضي (History)' },
  ];

  const filtered = abbreviations.filter(
    (a) => a.abbr.toLowerCase().includes(search.toLowerCase()) || a.ar.includes(search)
  );

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <HelpCircle className="w-5 h-5 text-indigo-500" />
        <span>دليل وتفسير الاختصارات الطبية والوصفات</span>
      </h3>

      <input
        type="text"
        placeholder="ابحث عن اختصار طبي مثل BID, CBC, Rx..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full px-3.5 py-2 text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-2.5 max-h-80 overflow-y-auto">
        {filtered.map((item) => (
          <div key={item.abbr} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
            <span className="font-black text-rose-600 font-mono text-sm">{item.abbr}</span>
            <p className="text-xs text-gray-700 dark:text-gray-300 mt-0.5">{item.ar}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// 14. Medical Dictionary Tool
function MedicalDictionaryTool() {
  const [search, setSearch] = useState('');

  const terms = [
    { en: 'Hypertension', ar: 'ارتفاع ضغط الدم المزمن' },
    { en: 'Hypotension', ar: 'انخفاض ضغط الدم' },
    { en: 'Tachycardia', ar: 'تسارع نبضات القلب (أكثر من 100 نبضة)' },
    { en: 'Bradycardia', ar: 'بطء نبضات القلب (أقل من 60 نبضة)' },
    { en: 'Hyperglycemia', ar: 'ارتفاع السكر في الدم' },
    { en: 'Hypoglycemia', ar: 'هبوط السكر في الدم' },
    { en: 'Analgesic', ar: 'مسكن للآلام' },
    { en: 'Antipyretic', ar: 'خافض للحرارة' },
    { en: 'Antibiotic', ar: 'مضاد حيوي للبكتيريا' },
    { en: 'Edema', ar: 'احتباس السوائل وتورم الأنسجة' },
    { en: 'Dyspnea', ar: 'صعوبة أو ضيق في التنفس' },
    { en: 'Cyanosis', ar: 'زرقة في الجلد لنقص الأكسجين' },
  ];

  const filtered = terms.filter(
    (t) => t.en.toLowerCase().includes(search.toLowerCase()) || t.ar.includes(search)
  );

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <BookOpen className="w-5 h-5 text-teal-600" />
        <span>القاموس الطبي للمصطلحات الشائعة (إنجليزي - عربي)</span>
      </h3>

      <input
        type="text"
        placeholder="ابحث عن مصطلح طبي بالعربي أو الإنجليزي..."
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        className="w-full px-3.5 py-2 text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-h-80 overflow-y-auto">
        {filtered.map((t) => (
          <div key={t.en} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
            <span className="font-bold text-teal-600 font-mono text-sm">{t.en}</span>
            <p className="text-xs text-gray-700 dark:text-gray-300 mt-1 font-medium">{t.ar}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

// 15. Medical Report Generator
function MedicalReportGenerator() {
  const [patientName, setPatientName] = useState('أحمد محمد');
  const [age, setAge] = useState('35');
  const [diagnosis, setDiagnosis] = useState('التهاب الحلق الحاد');
  const [notes, setNotes] = useState('الراحة التامة وتناول السوائل الدافئة والالتزام بالدواء');

  const reportText = `📋 التقرير الطبي المنظم
-------------------------------------
اسم المريض: ${patientName}
العمر: ${age} سنة
التاريخ: ${new Date().toLocaleDateString('ar-SA')}
التشخيص الطبي (Diagnosis):
- ${diagnosis}

الخطة العلاجية والتوصيات:
- ${notes}
-------------------------------------
* تم إنشاء هذا التقرير عبر المنصة الشاملة للأدوات الطبية`;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <FileText className="w-5 h-5 text-rose-600" />
        <span>مولد تقرير وملخص طبي منظم</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">اسم المريض</label>
          <input
            type="text"
            value={patientName}
            onChange={(e) => setPatientName(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">العمر</label>
          <input
            type="text"
            value={age}
            onChange={(e) => setAge(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>

      <div>
        <label className="block text-xs font-bold mb-1">التشخيص</label>
        <input
          type="text"
          value={diagnosis}
          onChange={(e) => setDiagnosis(e.target.value)}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
      </div>

      <div>
        <label className="block text-xs font-bold mb-1">التوصيات والعلاج</label>
        <textarea
          rows={3}
          value={notes}
          onChange={(e) => setNotes(e.target.value)}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
      </div>

      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <pre className="text-xs font-mono whitespace-pre-wrap text-gray-800 dark:text-gray-200">{reportText}</pre>
        <button
          onClick={() => {
            navigator.clipboard.writeText(reportText);
            confetti({ particleCount: 30, spread: 60 });
          }}
          className="mt-3 inline-flex items-center gap-1.5 px-4 py-2 bg-rose-600 text-white rounded-xl text-xs font-bold"
        >
          <Copy className="w-3.5 h-3.5" />
          <span>نسخ التقرير الطبي</span>
        </button>
      </div>
    </div>
  );
}

// 16. Drug Information Card Generator
function DrugCardGenerator() {
  const [drugName, setDrugName] = useState('Paracetamol (باراسيتامول)');
  const [dose, setDose] = useState('500 ملغ');
  const [frequency, setFrequency] = useState('كل 6 إلى 8 ساعات عند اللزوم');
  const [instructions, setInstructions] = useState('بعد الطعام مع كوب ماء، لا تتجاوز 4 غرام يومياً');

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Pill className="w-5 h-5 text-indigo-600" />
        <span>إنشاء بطاقة إرشادية للمريض عن الدواء</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">اسم الدواء</label>
          <input
            type="text"
            value={drugName}
            onChange={(e) => setDrugName(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">الجرعة المحددة</label>
          <input
            type="text"
            value={dose}
            onChange={(e) => setDose(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>

      <div className="p-5 rounded-2xl bg-gradient-to-br from-indigo-500 to-purple-600 text-white shadow-md space-y-2">
        <div className="flex items-center justify-between">
          <span className="text-xs bg-white/20 px-2.5 py-0.5 rounded-full font-bold">بطاقة إرشاد دوائي</span>
          <Pill className="w-5 h-5" />
        </div>
        <h4 className="text-lg font-black">{drugName}</h4>
        <div className="text-xs bg-black/15 p-3 rounded-xl space-y-1">
          <div>📌 <strong>الجرعة:</strong> {dose}</div>
          <div>⏰ <strong>التكرار:</strong> {frequency}</div>
          <div>💡 <strong>تعليمات:</strong> {instructions}</div>
        </div>
      </div>
    </div>
  );
}

// 17. Medical History Calculator
function MedicalHistoryCalculator() {
  const [lastVisit, setLastVisit] = useState('2024-01-15');
  const [followUpDays, setFollowUpDays] = useState(90);

  const nextDate = new Date(lastVisit);
  nextDate.setDate(nextDate.getDate() + Number(followUpDays));

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Clock className="w-5 h-5 text-amber-500" />
        <span>حاسبة التاريخ الطبي ومواعيد المراجعة الدورية</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-bold mb-1">تاريخ آخر زيارة / فحص</label>
          <input
            type="date"
            value={lastVisit}
            onChange={(e) => setLastVisit(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">فترة المتابعة (بالأيام)</label>
          <input
            type="number"
            value={followUpDays}
            onChange={(e) => setFollowUpDays(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>

      <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 text-center">
        <span className="text-xs font-bold text-amber-700">موعد الفحص القادم المقترح</span>
        <div className="text-2xl font-black text-gray-900 dark:text-white mt-1">
          {nextDate.toLocaleDateString('ar-SA', { year: 'numeric', month: 'long', day: 'numeric' })}
        </div>
      </div>
    </div>
  );
}
