import React, { useState } from 'react';
import { Calendar, Baby, Info } from 'lucide-react';

export function PregnancyCalculator() {
  const [lmpDate, setLmpDate] = useState<string>('');
  const [cycleLength, setCycleLength] = useState<number>(28);

  const calculateDates = () => {
    if (!lmpDate) return null;
    const lmp = new Date(lmpDate);
    if (isNaN(lmp.getTime())) return null;

    // Standard calculation: EDD = LMP + 280 days (for 28 day cycle)
    // Adjust for cycle length: + (cycleLength - 28)
    const cycleAdjustment = cycleLength - 28;
    
    const edd = new Date(lmp);
    edd.setDate(edd.getDate() + 280 + cycleAdjustment);

    const conceptionDate = new Date(lmp);
    conceptionDate.setDate(conceptionDate.getDate() + 14 + cycleAdjustment);

    const endOfFirstTrimester = new Date(lmp);
    endOfFirstTrimester.setDate(endOfFirstTrimester.getDate() + 84); // 12 weeks

    const endOfSecondTrimester = new Date(lmp);
    endOfSecondTrimester.setDate(endOfSecondTrimester.getDate() + 189); // 27 weeks

    const today = new Date();
    const diffTime = Math.abs(today.getTime() - lmp.getTime());
    let currentWeek = Math.floor(diffTime / (1000 * 60 * 60 * 24 * 7));
    if (currentWeek < 0) currentWeek = 0;
    if (currentWeek > 42) currentWeek = 42;

    return {
      edd: edd.toLocaleDateString('ar-EG', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' }),
      conceptionDate: conceptionDate.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' }),
      endOfFirstTrimester: endOfFirstTrimester.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' }),
      endOfSecondTrimester: endOfSecondTrimester.toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' }),
      currentWeek,
    };
  };

  const results = calculateDates();

  return (
    <div className="space-y-6">
      <div className="bg-rose-50 dark:bg-rose-950/30 p-4 rounded-2xl flex gap-3 text-sm text-rose-800 dark:text-rose-300">
        <Info className="w-5 h-5 shrink-0 mt-0.5" />
        <p>تعتمد حاسبة موعد الولادة على تاريخ أول يوم من آخر دورة شهرية (LMP). هذه النتائج تقريبية، ويرجى استشارة الطبيب المختص.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <div className="space-y-1.5">
            <label className="text-sm font-bold text-gray-700 dark:text-gray-300">تاريخ أول يوم لآخر دورة شهرية</label>
            <input
              type="date"
              value={lmpDate}
              onChange={(e) => setLmpDate(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none"
            />
          </div>
          <div className="space-y-1.5">
            <label className="text-sm font-bold text-gray-700 dark:text-gray-300">متوسط طول الدورة الشهرية (بالأيام)</label>
            <input
              type="number"
              value={cycleLength}
              onChange={(e) => setCycleLength(Number(e.target.value))}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-left"
              dir="ltr"
            />
          </div>
        </div>

        {results && (
          <div className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-3xl border border-gray-100 dark:border-gray-700 space-y-6">
            <div className="text-center space-y-2 border-b border-gray-200 dark:border-gray-700 pb-4">
              <Baby className="w-10 h-10 mx-auto text-rose-500" />
              <h4 className="text-gray-500 dark:text-gray-400 font-bold">موعد الولادة المتوقع</h4>
              <div className="text-xl sm:text-2xl font-extrabold text-rose-600 dark:text-rose-400">
                {results.edd}
              </div>
            </div>
            
            <div className="space-y-3">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">أسبوع الحمل الحالي:</span>
                <span className="font-bold text-gray-900 dark:text-white">الأسبوع {results.currentWeek}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">تاريخ الإخصاب المتوقع:</span>
                <span className="font-bold text-gray-900 dark:text-white">{results.conceptionDate}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">نهاية الثلث الأول (12 أسبوع):</span>
                <span className="font-bold text-gray-900 dark:text-white">{results.endOfFirstTrimester}</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">نهاية الثلث الثاني (27 أسبوع):</span>
                <span className="font-bold text-gray-900 dark:text-white">{results.endOfSecondTrimester}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
