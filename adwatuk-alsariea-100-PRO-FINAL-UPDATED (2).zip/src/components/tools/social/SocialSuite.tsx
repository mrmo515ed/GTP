import React, { useState, useRef } from 'react';
import {
  Smartphone,
  QrCode,
  Sparkles,
  Hash,
  Instagram,
  Crop,
  User,
  MessageCircle,
  Copy,
  Check,
  Download,
  Upload,
  RefreshCw,
  Share2
} from 'lucide-react';
import QRCode from 'qrcode';

interface Props {
  defaultTab?:
    | 'social-qr'
    | 'bio-generator'
    | 'username-generator'
    | 'hashtag-generator'
    | 'social-resizer'
    | 'whatsapp-compress'
    | 'avatar-cropper';
}

export function SocialSuite({ defaultTab = 'social-qr' }: Props) {
  const [activeTab, setActiveTab] = useState<string>(defaultTab);
  const [copied, setCopied] = useState<boolean>(false);

  // Social QR state
  const [socialPlatform, setSocialPlatform] = useState<string>('instagram');
  const [socialHandle, setSocialHandle] = useState<string>('adwatuk_app');
  const [generatedQr, setGeneratedQr] = useState<string>('');

  // Bio generator state
  const [bioNiche, setBioNiche] = useState<string>('tech');
  const [bioRole, setBioRole] = useState<string>('مطور برمجيات وصانع محتوى تقني');
  const [bioKeywords, setBioKeywords] = useState<string>('تطوير الويب، الذكاء الاصطناعي، إنتاجية');
  const [generatedBios, setGeneratedBios] = useState<string[]>([]);

  // Username generator state
  const [seedKeyword, setSeedKeyword] = useState<string>('sami');
  const [userNiche, setUserNiche] = useState<string>('dev');
  const [generatedUsernames, setGeneratedUsernames] = useState<string[]>([]);

  // Hashtag generator state
  const [hashtagTopic, setHashtagTopic] = useState<string>('تصميم وتطوير');
  const [generatedHashtags, setGeneratedHashtags] = useState<string[]>([]);

  // Social resizer / Avatar state
  const [imageSrc, setImageSrc] = useState<string>('');
  const [imageName, setImageName] = useState<string>('avatar.png');
  const [selectedSocialPreset, setSelectedSocialPreset] = useState<{ name: string; w: number; h: number }>({
    name: 'Instagram Post (1:1)',
    w: 1080,
    h: 1080
  });

  const fileInputRef = useRef<HTMLInputElement>(null);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Generate Social QR
  const handleGenerateSocialQr = async () => {
    let url = '';
    if (socialPlatform === 'instagram') url = `https://instagram.com/${socialHandle.replace('@', '')}`;
    else if (socialPlatform === 'twitter') url = `https://x.com/${socialHandle.replace('@', '')}`;
    else if (socialPlatform === 'tiktok') url = `https://tiktok.com/@${socialHandle.replace('@', '')}`;
    else if (socialPlatform === 'youtube') url = `https://youtube.com/@${socialHandle.replace('@', '')}`;
    else if (socialPlatform === 'snapchat') url = `https://snapchat.com/add/${socialHandle.replace('@', '')}`;
    else if (socialPlatform === 'whatsapp') url = `https://wa.me/${socialHandle.replace('+', '').replace(/\s+/g, '')}`;
    else url = socialHandle;

    try {
      const dataUrl = await QRCode.toDataURL(url, {
        width: 300,
        margin: 2,
        color: { dark: '#000000', light: '#ffffff' }
      });
      setGeneratedQr(dataUrl);
    } catch {}
  };

  // Bio generator logic
  const handleGenerateBios = () => {
    const bios = [
      `🚀 ${bioRole} | 💡 شغوف بـ ${bioKeywords}\n👇 تابع للمزيد من الإلهام والحلول التقنية`,
      `✨ مهتم بمستقبل ${bioKeywords}\n📌 أشارك رحلتي وخبرتي اليومية\n✉️ للتواصل والتعاون عبر الخاص`,
      `🎯 نبني أفكاراً ذكية بأسلوب حديث\n💻 ${bioRole}\n🔗 رابط الموقع بالأسفل 👇`,
      `🌱 أصنع أثراً في عالم ${bioKeywords}\n👨‍💻 ${bioRole}\n⚡ لا تتردد في الانضمام إلى مجتمعنا!`
    ];
    setGeneratedBios(bios);
  };

  // Username generator logic
  const handleGenerateUsernames = () => {
    const prefixes = ['the', 'real', 'iam', 'official', 'hey', 'get', 'mr', 'dev'];
    const suffixes = ['hq', 'pro', 'tech', 'hub', 'lab', 'zone', 'app', 'online', '99', 'x'];
    const clean = seedKeyword.trim().toLowerCase().replace(/\s+/g, '_');
    const results = [
      `${clean}_${userNiche}`,
      `${clean}.official`,
      `iam_${clean}`,
      `${clean}pro`,
      `the.${clean}`,
      `${clean}hq`,
      `real${clean}`,
      `${clean}_lab`,
      `dev.${clean}`
    ];
    setGeneratedUsernames(results);
  };

  // Hashtags generator
  const handleGenerateHashtags = () => {
    const topic = hashtagTopic.trim();
    const commonTags = [
      `#${topic.replace(/\s+/g, '_')}`,
      `#اكسبلور`,
      `#تقنية`,
      `#تصميم`,
      `#برمجة`,
      `#تطوير_الويب`,
      `#أدوات_رقمية`,
      `#ريادة_أعمال`,
      `#تسويق_إلكتروني`,
      `#انستقرام`,
      `#ترند_اليوم`,
      `#فكرة_جديدة`
    ];
    setGeneratedHashtags(commonTags);
  };

  // Circular Avatar Crop
  const getCircularCropDataUrl = (): string => {
    if (!imageSrc) return '';
    const img = new Image();
    img.src = imageSrc;
    const canvas = document.createElement('canvas');
    const size = Math.min(img.naturalWidth || 400, img.naturalHeight || 400);
    canvas.width = size;
    canvas.height = size;
    const ctx = canvas.getContext('2d');
    if (!ctx) return imageSrc;

    ctx.beginPath();
    ctx.arc(size / 2, size / 2, size / 2, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();

    ctx.drawImage(
      img,
      (img.naturalWidth - size) / 2,
      (img.naturalHeight - size) / 2,
      size,
      size,
      0,
      0,
      size,
      size
    );
    return canvas.toDataURL('image/png');
  };

  // Preset Resizer
  const getSocialResizedDataUrl = (): string => {
    if (!imageSrc) return '';
    const img = new Image();
    img.src = imageSrc;
    const canvas = document.createElement('canvas');
    canvas.width = selectedSocialPreset.w;
    canvas.height = selectedSocialPreset.h;
    const ctx = canvas.getContext('2d');
    if (!ctx) return imageSrc;

    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL('image/jpeg', 0.9);
  };

  const tabs = [
    { id: 'social-qr', label: 'QR حسابات السوشيال', icon: QrCode },
    { id: 'bio-generator', label: 'صانع البايو (Bio)', icon: Sparkles },
    { id: 'username-generator', label: 'توليد أسماء الحسابات', icon: User },
    { id: 'hashtag-generator', label: 'مولد الهاشتاقات', icon: Hash },
    { id: 'social-resizer', label: 'مقاسات منصات السوشيال', icon: Instagram },
    { id: 'avatar-cropper', label: 'قص دائري لصور البروفايل', icon: Crop }
  ];

  return (
    <div className="space-y-6" id="social-suite">
      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-200 dark:scrollbar-thumb-gray-800">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/60 border border-gray-200/80 dark:border-gray-700/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Social QR */}
      {activeTab === 'social-qr' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold block mb-1">اختر المنصة:</label>
              <select
                value={socialPlatform}
                onChange={e => setSocialPlatform(e.target.value)}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-bold border border-gray-200 dark:border-gray-700"
              >
                <option value="instagram">Instagram انستقرام</option>
                <option value="twitter">X / Twitter تويتر</option>
                <option value="tiktok">TikTok تيك توك</option>
                <option value="youtube">YouTube يوتيوب</option>
                <option value="snapchat">Snapchat سناب شات</option>
                <option value="whatsapp">WhatsApp واتساب (رقم الهاتف مع الرمز)</option>
              </select>
            </div>
            <div>
              <label className="text-xs font-bold block mb-1">اسم المستخدم أو الرقم:</label>
              <input
                type="text"
                value={socialHandle}
                onChange={e => setSocialHandle(e.target.value)}
                placeholder="مثال: adwatuk_app أو 966500000000"
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border border-gray-200 dark:border-gray-700 outline-none"
              />
            </div>
          </div>

          <button
            onClick={handleGenerateSocialQr}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
          >
            <QrCode className="w-4 h-4" />
            <span>توليد كود QR لحسابك</span>
          </button>

          {generatedQr && (
            <div className="p-6 bg-gray-50 dark:bg-gray-900 rounded-2xl text-center space-y-3">
              <img src={generatedQr} alt="Social QR" className="w-48 h-48 mx-auto rounded-xl shadow-md border" />
              <a
                href={generatedQr}
                download={`qr-${socialPlatform}-${socialHandle}.png`}
                className="inline-flex items-center gap-2 px-6 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold"
              >
                <Download className="w-4 h-4" />
                <span>تنزيل رمز QR بدقة عالية</span>
              </a>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Bio Generator */}
      {activeTab === 'bio-generator' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
            <h4 className="text-xs font-black text-gray-700 dark:text-gray-200">صياغة بايو احترافي لحساباتك</h4>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold block mb-1">صفتك أو دورك الأساسي</label>
                <input type="text" value={bioRole} onChange={e => setBioRole(e.target.value)} className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs border" />
              </div>
              <div>
                <label className="text-xs font-bold block mb-1">الكلمات المفتاحية والاهتمامات</label>
                <input type="text" value={bioKeywords} onChange={e => setBioKeywords(e.target.value)} className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs border" />
              </div>
            </div>
            <button
              onClick={handleGenerateBios}
              className="py-2.5 px-6 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4" />
              <span>توليد خيارات البايو الآن</span>
            </button>
          </div>

          {generatedBios.length > 0 && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {generatedBios.map((bio, i) => (
                <div key={i} className="p-4 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 flex flex-col justify-between space-y-3">
                  <p className="text-xs text-gray-800 dark:text-gray-200 whitespace-pre-line leading-relaxed font-sans">{bio}</p>
                  <button
                    onClick={() => copyToClipboard(bio)}
                    className="self-end px-3 py-1.5 bg-gray-100 dark:bg-gray-700 hover:bg-emerald-50 text-emerald-600 rounded-xl text-xs font-bold flex items-center gap-1.5"
                  >
                    <Copy className="w-3.5 h-3.5" /> نسخ البايو
                  </button>
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Username Generator */}
      {activeTab === 'username-generator' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="text-xs font-bold block mb-1">الاسم أو الكلمة الأساسية:</label>
              <input type="text" value={seedKeyword} onChange={e => setSeedKeyword(e.target.value)} className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border" />
            </div>
            <div>
              <label className="text-xs font-bold block mb-1">التصنيف أو المجال:</label>
              <input type="text" value={userNiche} onChange={e => setUserNiche(e.target.value)} className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border" />
            </div>
          </div>

          <button
            onClick={handleGenerateUsernames}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-4 h-4" />
            <span>توليد أسماء يوزرات مقترحة</span>
          </button>

          {generatedUsernames.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {generatedUsernames.map((u, i) => (
                <div
                  key={i}
                  onClick={() => copyToClipboard(`@${u}`)}
                  className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 cursor-pointer hover:border-emerald-500 transition-all flex items-center justify-between text-xs font-mono"
                >
                  <span className="text-emerald-600 font-bold truncate">@{u}</span>
                  <Copy className="w-3.5 h-3.5 text-gray-400" />
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Hashtags */}
      {activeTab === 'hashtag-generator' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold block">موضوع المنشور أو الفيديو:</label>
            <input
              type="text"
              value={hashtagTopic}
              onChange={e => setHashtagTopic(e.target.value)}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-sans border border-gray-200 dark:border-gray-700 outline-none"
            />
          </div>

          <button
            onClick={handleGenerateHashtags}
            className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
          >
            <Hash className="w-4 h-4" />
            <span>توليد أقوى الهاشتاقات المتفاعلة</span>
          </button>

          {generatedHashtags.length > 0 && (
            <div className="space-y-3">
              <div className="flex justify-between items-center">
                <span className="text-xs font-bold text-gray-500">انقر على أي هاشتاق للنسخ، أو انسخها جميعاً:</span>
                <button
                  onClick={() => copyToClipboard(generatedHashtags.join(' '))}
                  className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 rounded-lg text-xs font-bold flex items-center gap-1"
                >
                  <Copy className="w-3.5 h-3.5" /> نسخ الكل
                </button>
              </div>
              <div className="flex flex-wrap gap-2">
                {generatedHashtags.map((tag, i) => (
                  <span
                    key={i}
                    onClick={() => copyToClipboard(tag)}
                    className="px-3 py-1.5 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 hover:border-emerald-500 cursor-pointer rounded-xl text-xs font-bold text-emerald-600"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          )}
        </div>
      )}

      {/* Upload image for Resizer & Avatar Cropper */}
      {(activeTab === 'social-resizer' || activeTab === 'avatar-cropper') && (
        <div className="space-y-6">
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={e => {
              const file = e.target.files?.[0];
              if (!file) return;
              setImageName(file.name);
              const reader = new FileReader();
              reader.onload = () => setImageSrc(reader.result as string);
              reader.readAsDataURL(file);
            }}
            className="hidden"
          />

          {!imageSrc ? (
            <div
              onClick={() => fileInputRef.current?.click()}
              className="p-10 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-3xl cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/20 transition-all text-center space-y-3"
            >
              <Upload className="w-10 h-10 text-emerald-600 mx-auto" />
              <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200">اختر صورة لتكييف مقاسها أو قصها دائرياً</h4>
            </div>
          ) : (
            <div>
              {/* Tab 5: Social Resizer */}
              {activeTab === 'social-resizer' && (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
                    <h4 className="text-xs font-black text-gray-700 dark:text-gray-200">اختر مقاس المنصة المطلوب:</h4>
                    <div className="space-y-2">
                      {[
                        { name: 'Instagram Post (1:1 مربع)', w: 1080, h: 1080 },
                        { name: 'Instagram Story / Reel / TikTok (9:16 رأسي)', w: 1080, h: 1920 },
                        { name: 'YouTube Thumbnail (16:9 مصغرة)', w: 1280, h: 720 },
                        { name: 'X / Twitter Post (16:9)', w: 1200, h: 675 },
                        { name: 'Facebook Cover (غلاف فيسبوك)', w: 820, h: 312 }
                      ].map((preset, idx) => (
                        <div
                          key={idx}
                          onClick={() => setSelectedSocialPreset(preset)}
                          className={`p-3 rounded-xl text-xs font-bold cursor-pointer border transition-all flex items-center justify-between ${
                            selectedSocialPreset.name === preset.name
                              ? 'border-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300'
                              : 'border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-900'
                          }`}
                        >
                          <span>{preset.name}</span>
                          <span className="font-mono text-[11px] text-gray-400">{preset.w}x{preset.h} px</span>
                        </div>
                      ))}
                    </div>

                    <a
                      href={getSocialResizedDataUrl()}
                      download={`social-${selectedSocialPreset.w}x${selectedSocialPreset.h}-${imageName}`}
                      className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
                    >
                      <Download className="w-4 h-4" />
                      <span>تنزيل بالمقاس المضبوط</span>
                    </a>
                  </div>

                  <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 flex items-center justify-center">
                    <img src={imageSrc} alt="Preview" className="max-h-64 object-contain rounded-xl shadow-sm" />
                  </div>
                </div>
              )}

              {/* Tab 6: Avatar Cropper */}
              {activeTab === 'avatar-cropper' && (
                <div className="max-w-xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 text-center space-y-6">
                  <div className="w-48 h-48 mx-auto rounded-full overflow-hidden border-4 border-emerald-500 shadow-xl bg-gray-100">
                    <img src={getCircularCropDataUrl()} alt="Circular Avatar" className="w-full h-full object-cover" />
                  </div>

                  <a
                    href={getCircularCropDataUrl()}
                    download={`avatar-circle-${imageName}`}
                    className="inline-flex items-center gap-2 py-3 px-8 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold"
                  >
                    <Download className="w-4 h-4" />
                    <span>تنزيل صورة البروفايل الدائرية الشفافة (PNG)</span>
                  </a>
                </div>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
}
