import React, { useEffect, useState, useRef } from 'react';
import { Files, Upload, Trash2, Download, GripVertical, AlertCircle, CheckCircle2 } from 'lucide-react';
import { PDFDocument } from 'pdf-lib';
import { ProcessingProgressBar } from '../../common/ProcessingProgressBar';
import { triggerToolActionAd } from '../../../utils/adsterraManager';

export function PdfMerger() {
  const [files, setFiles] = useState<File[]>([]);
  const [isMerging, setIsMerging] = useState(false);
  const [progress, setProgress] = useState(0);
  const [statusStep, setStatusStep] = useState('');
  const [mergedUrl, setMergedUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (mergedUrl) triggerToolActionAd('pdf_merge_result');
    return () => {
      if (mergedUrl?.startsWith('blob:')) URL.revokeObjectURL(mergedUrl);
    };
  }, [mergedUrl]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files) {
      const selectedFiles = Array.from(e.target.files).filter((f: File) => f.type === 'application/pdf');
      setFiles(prev => [...prev, ...selectedFiles]);
      setMergedUrl(null);
      setError(null);
      setProgress(0);
    }
  };

  const handleRemoveFile = (index: number) => {
    setFiles(files.filter((_, i) => i !== index));
    setMergedUrl(null);
  };

  const handleMoveFile = (index: number, direction: 'up' | 'down') => {
    if (direction === 'up' && index === 0) return;
    if (direction === 'down' && index === files.length - 1) return;
    
    const newFiles = [...files];
    const swapIndex = direction === 'up' ? index - 1 : index + 1;
    const temp = newFiles[index];
    newFiles[index] = newFiles[swapIndex];
    newFiles[swapIndex] = temp;
    setFiles(newFiles);
    setMergedUrl(null);
  };

  const handleMerge = async () => {
    if (files.length < 2) {
      setError('يرجى اختيار ملفين PDF على الأقل للدمج.');
      return;
    }
    
    setIsMerging(true);
    setError(null);
    setMergedUrl(null);
    setProgress(10);
    setStatusStep('جاري إنشاء مستند الدمج الجديد...');

    try {
      const mergedPdf = await PDFDocument.create();
      const total = files.length;

      for (let i = 0; i < total; i++) {
        const file = files[i];
        const arrayBuffer = await file.arrayBuffer();
        const pdf = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
        const copiedPages = await mergedPdf.copyPages(pdf, pdf.getPageIndices());
        copiedPages.forEach((page) => mergedPdf.addPage(page));

        const pct = 15 + Math.round(((i + 1) / total) * 70);
        setProgress(pct);
        setStatusStep(`جاري دمج ملف ${i + 1} من ${total}: ${file.name}`);
      }

      setProgress(90);
      setStatusStep('جاري تشفير وتجهيز ملف PDF المدمج...');

      const mergedPdfBytes = await mergedPdf.save();
      const blob = new Blob([mergedPdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);
      
      setProgress(100);
      setStatusStep('اكتمل دمج جميع الملفات بنجاح!');
      setMergedUrl(url);
    } catch (err: any) {
      setError('حدث خطأ أثناء دمج الملفات: ' + (err.message || 'Unknown error'));
    } finally {
      setIsMerging(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-2xl flex items-start gap-3 border border-blue-100 dark:border-blue-800/30">
        <Files className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 shrink-0" />
        <p className="text-sm text-blue-800 dark:text-blue-200 leading-relaxed">
          أداة دمج ملفات PDF تتيح لك دمج ملفين أو أكثر في ملف واحد بسهولة وسرعة. معالجة الملفات تتم 100% داخل المتصفح لضمان خصوصيتك بدون رفع أي ملفات للسيرفر.
        </p>
      </div>

      <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-2xl p-8 text-center hover:bg-gray-50 dark:hover:bg-gray-800/50 transition">
        <input
          type="file"
          accept="application/pdf"
          multiple
          className="hidden"
          ref={fileInputRef}
          onChange={handleFileChange}
        />
        <Upload className="w-10 h-10 text-gray-400 mx-auto mb-3" />
        <p className="text-sm text-gray-600 dark:text-gray-400 mb-4 font-bold">
          اسحب وأفلت ملفات PDF هنا، أو اضغط للاختيار
        </p>
        <button
          onClick={() => fileInputRef.current?.click()}
          className="px-6 py-2.5 bg-blue-600 text-white rounded-xl text-sm font-bold shadow-xs hover:bg-blue-700 transition"
        >
          اختر الملفات
        </button>
      </div>

      {files.length > 0 && (
        <div className="space-y-4">
          <h3 className="font-bold text-gray-800 dark:text-gray-200 text-sm">الملفات المحددة ({files.length}):</h3>
          <div className="space-y-2">
            {files.map((f, index) => (
              <div key={`${f.name}-${f.size}-${f.lastModified}-${index}`} className="flex items-center gap-3 p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl shadow-xs">
                <GripVertical className="w-5 h-5 text-gray-400 shrink-0" />
                <span className="flex-1 truncate text-sm text-gray-700 dark:text-gray-300 font-bold" dir="ltr">{f.name}</span>
                <span className="text-xs text-gray-500 shrink-0" dir="ltr">{(f.size / 1024 / 1024).toFixed(2)} MB</span>
                
                <div className="flex items-center gap-1 shrink-0">
                  <button
                    onClick={() => handleMoveFile(index, 'up')}
                    disabled={index === 0}
                    className="p-1.5 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded disabled:opacity-30"
                  >
                    ↑
                  </button>
                  <button
                    onClick={() => handleMoveFile(index, 'down')}
                    disabled={index === files.length - 1}
                    className="p-1.5 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded disabled:opacity-30"
                  >
                    ↓
                  </button>
                  <button
                    onClick={() => handleRemoveFile(index)}
                    className="p-1.5 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))}
          </div>

          {/* Progress Bar */}
          {(isMerging || progress > 0) && (
            <ProcessingProgressBar
              progress={progress}
              statusText={statusStep}
              subText={`${files.length} ملفات قيد المعالجة والدمج`}
              isCompleted={!isMerging && progress === 100}
              color="blue"
            />
          )}

          <div className="pt-4 flex flex-col sm:flex-row gap-4 items-center">
            <button
              onClick={handleMerge}
              disabled={isMerging || files.length < 2}
              className="w-full sm:w-auto px-8 py-3 bg-blue-600 hover:bg-blue-700 disabled:bg-gray-400 text-white rounded-xl font-bold transition shadow-xs flex items-center justify-center gap-2"
            >
              {isMerging ? 'جاري الدمج...' : 'دمج الملفات الآن'}
            </button>
            {files.length < 2 && (
              <span className="text-xs text-amber-600">اختر ملفين على الأقل للدمج</span>
            )}
          </div>
        </div>
      )}

      {error && (
        <div className="flex items-center gap-2 text-rose-600 bg-rose-50 dark:bg-rose-900/20 p-4 rounded-xl border border-rose-100 dark:border-rose-800/30">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span className="text-sm font-medium">{error}</span>
        </div>
      )}

      {mergedUrl && (
        <div className="bg-emerald-50 dark:bg-emerald-900/20 p-6 rounded-2xl border border-emerald-100 dark:border-emerald-800/30 flex items-center justify-between gap-4 flex-col sm:flex-row text-center sm:text-right">
          <div>
            <h4 className="text-emerald-800 dark:text-emerald-300 font-bold mb-1">تم دمج الملفات بنجاح!</h4>
            <p className="text-xs text-emerald-600 dark:text-emerald-400">ملفك جاهز للتحميل الآن.</p>
          </div>
          <a
            href={mergedUrl}
            download="merged-document.pdf"
            className="px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl font-bold transition shadow-xs flex items-center gap-2 shrink-0"
          >
            <Download className="w-5 h-5" />
            تحميل الملف المدمج
          </a>
        </div>
      )}
    </div>
  );
}
