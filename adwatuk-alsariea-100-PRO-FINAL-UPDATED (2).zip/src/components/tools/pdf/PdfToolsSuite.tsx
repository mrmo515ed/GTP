import React, { useEffect, useState, useRef } from 'react';
import {
  FileText,
  Merge,
  Split,
  RotateCw,
  Trash2,
  Lock,
  Unlock,
  Stamp,
  Upload,
  Download,
  Check,
  AlertCircle,
  FileImage,
  Layers,
  ArrowUpDown,
  CheckCircle2
} from 'lucide-react';
import { PDFDocument, degrees } from 'pdf-lib';
import { jsPDF } from 'jspdf';
import { ProcessingProgressBar } from '../../common/ProcessingProgressBar';
import { triggerToolActionAd } from '../../../utils/adsterraManager';

interface Props {
  defaultTab?:
    | 'merge'
    | 'split'
    | 'organize'
    | 'pdf-to-jpg'
    | 'jpg-to-pdf'
    | 'compress'
    | 'watermark'
    | 'protect'
    | 'unlock';
}

export function PdfToolsSuite({ defaultTab = 'merge' }: Props) {
  const [activeTab, setActiveTab] = useState<string>(defaultTab);
  const [loading, setLoading] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [statusStep, setStatusStep] = useState<string>('');
  const [readyResult, setReadyResult] = useState<{ url: string; name: string; info?: string } | null>(null);
  const [statusMessage, setStatusMessage] = useState<{ text: string; type: 'success' | 'error' } | null>(null);

  // Files state
  const [pdfFiles, setPdfFiles] = useState<{ file: File; name: string; size: number }[]>([]);
  const [singlePdfBytes, setSinglePdfBytes] = useState<ArrayBuffer | null>(null);
  const [singlePdfName, setSinglePdfName] = useState<string>('');
  const [pdfPageCount, setPdfPageCount] = useState<number>(0);

  // Split state
  const [splitRange, setSplitRange] = useState<string>('1-2');

  // Watermark state
  const [watermarkText, setWatermarkText] = useState<string>('سري للغاية - CONFIDENTIAL');
  const [watermarkOpacity, setWatermarkOpacity] = useState<number>(0.35);
  const [watermarkSize, setWatermarkSize] = useState<number>(40);

  // Password protect
  const [pdfPassword, setPdfPassword] = useState<string>('');

  // JPG to PDF state
  const [imageFiles, setImageFiles] = useState<{ file: File; dataUrl: string; name: string }[]>([]);

  const pdfInputRef = useRef<HTMLInputElement>(null);
  const imageInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (readyResult) triggerToolActionAd('pdf_tool_result');
    return () => {
      if (readyResult?.url.startsWith('blob:')) URL.revokeObjectURL(readyResult.url);
    };
  }, [readyResult]);

  const handlePdfUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    if (files.length === 0) return;
    setStatusMessage(null);
    setProgress(0);

    if (activeTab === 'merge') {
      const newItems = files.map(f => ({ file: f, name: f.name, size: f.size }));
      setPdfFiles(prev => [...prev, ...newItems]);
    } else {
      const file = files[0];
      setSinglePdfName(file.name);
      const arrayBuffer = await file.arrayBuffer();
      setSinglePdfBytes(arrayBuffer);
      try {
        const doc = await PDFDocument.load(arrayBuffer, { ignoreEncryption: true });
        setPdfPageCount(doc.getPageCount());
      } catch {
        setPdfPageCount(1);
      }
    }
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files || []) as File[];
    if (files.length === 0) return;
    setProgress(0);
    files.forEach(file => {
      const reader = new FileReader();
      reader.onload = () => {
        setImageFiles(prev => [...prev, { file, dataUrl: reader.result as string, name: file.name }]);
      };
      reader.readAsDataURL(file);
    });
  };

  // Helper to generate watermark PNG supporting full Arabic typography
  const createWatermarkPngUrl = (text: string, size: number, opacity: number): string => {
    const canvas = document.createElement('canvas');
    canvas.width = 800;
    canvas.height = 800;
    const ctx = canvas.getContext('2d');
    if (!ctx) return '';

    ctx.clearRect(0, 0, 800, 800);
    ctx.save();
    ctx.translate(400, 400);
    ctx.rotate(-Math.PI / 4); // -45 deg
    ctx.font = `bold ${size * 1.5}px 'Alexandria', 'Cairo', Tahoma, Arial, sans-serif`;
    ctx.fillStyle = `rgba(220, 38, 38, ${opacity})`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.direction = 'rtl';
    ctx.fillText(text, 0, 0);
    ctx.restore();

    return canvas.toDataURL('image/png');
  };

  // 1. Merge PDFs
  const handleMergePdfs = async () => {
    if (pdfFiles.length < 2) {
      setStatusMessage({ text: 'يرجى اختيار ملفين PDF على الأقل للدمج.', type: 'error' });
      return;
    }
    setLoading(true);
    setProgress(10);
    setStatusStep('جاري إنشاء مستند PDF المدمج الجديد...');

    try {
      const mergedPdf = await PDFDocument.create();
      const total = pdfFiles.length;

      for (let i = 0; i < total; i++) {
        const item = pdfFiles[i];
        const bytes = await item.file.arrayBuffer();
        const srcDoc = await PDFDocument.load(bytes, { ignoreEncryption: true });
        const copiedPages = await mergedPdf.copyPages(srcDoc, srcDoc.getPageIndices());
        copiedPages.forEach(p => mergedPdf.addPage(p));

        const pct = 15 + Math.round(((i + 1) / total) * 70);
        setProgress(pct);
        setStatusStep(`جاري دمج ملف ${i + 1} من ${total}: ${item.name}`);
      }

      setProgress(90);
      setStatusStep('جاري حفظ وتجهيز الملف النهائي...');
      const pdfBytes = await mergedPdf.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);

      setProgress(100);
      setStatusStep('تم دمج جميع الملفات بنجاح!');
      setReadyResult({ url, name: 'merged-document.pdf', info: `تم دمج ${pdfFiles.length} ملفات بنجاح في ملف واحد` });
      setStatusMessage({ text: 'تم دمج الملفات بنجاح! يمكنك الآن تحميل الملف.', type: 'success' });
    } catch (err: any) {
      setStatusMessage({ text: `فشل دمج الملفات: ${err.message}`, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  // 2. Split PDF
  const handleSplitPdf = async () => {
    if (!singlePdfBytes) {
      setStatusMessage({ text: 'يرجى رفع ملف PDF أولاً.', type: 'error' });
      return;
    }
    setLoading(true);
    setProgress(15);
    setStatusStep('جاري قراءة بنية ملف PDF...');

    try {
      const srcDoc = await PDFDocument.load(singlePdfBytes, { ignoreEncryption: true });
      const newDoc = await PDFDocument.create();

      const pagesToInclude: number[] = [];
      const parts = splitRange.split(',').map(s => s.trim());
      for (const part of parts) {
        if (part.includes('-')) {
          const [start, end] = part.split('-').map(Number);
          for (let p = start; p <= end; p++) {
            if (p >= 1 && p <= srcDoc.getPageCount()) pagesToInclude.push(p - 1);
          }
        } else {
          const p = Number(part);
          if (p >= 1 && p <= srcDoc.getPageCount()) pagesToInclude.push(p - 1);
        }
      }

      if (pagesToInclude.length === 0) {
        setStatusMessage({ text: 'نطاق الصفحات غير صالح، يرجى كتابة أرقام صفحات موجودة.', type: 'error' });
        setLoading(false);
        return;
      }

      setProgress(50);
      setStatusStep(`جاري نسخ ${pagesToInclude.length} صفحة محددة...`);

      const copiedPages = await newDoc.copyPages(srcDoc, pagesToInclude);
      copiedPages.forEach(p => newDoc.addPage(p));
      
      setProgress(85);
      setStatusStep('جاري توليد ملف PDF الجديد...');

      const pdfBytes = await newDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);

      setProgress(100);
      setStatusStep('اكتمل تقسيم الملف بنجاح!');
      setReadyResult({ url, name: `split-${singlePdfName}`, info: `تم استخراج ${pagesToInclude.length} صفحة بنجاح` });
      setStatusMessage({ text: 'تم استخراج وتجهيز الصفحات المحددة بنجاح!', type: 'success' });
    } catch (err: any) {
      setStatusMessage({ text: `خطأ في تقسيم الملف: ${err.message}`, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  // 3. Add Watermark with 100% Arabic Typography Support
  const handleAddWatermark = async () => {
    if (!singlePdfBytes) {
      setStatusMessage({ text: 'يرجى رفع ملف PDF أولاً.', type: 'error' });
      return;
    }
    setLoading(true);
    setProgress(15);
    setStatusStep('جاري إنشاء شارة العلامة المائية بالخط العربي...');

    try {
      const pdfDoc = await PDFDocument.load(singlePdfBytes, { ignoreEncryption: true });
      const pages = pdfDoc.getPages();
      const total = pages.length;

      // Create high-res PNG watermark
      const pngUrl = createWatermarkPngUrl(watermarkText, watermarkSize, watermarkOpacity);
      const pngBytes = await fetch(pngUrl).then(res => res.arrayBuffer());
      const watermarkImg = await pdfDoc.embedPng(pngBytes);

      setProgress(40);
      setStatusStep('جاري تطبيق العلامة المائية على كافة الصفحات...');

      for (let i = 0; i < total; i++) {
        const page = pages[i];
        const { width, height } = page.getSize();
        const imgDim = Math.min(width, height) * 0.85;

        page.drawImage(watermarkImg, {
          x: (width - imgDim) / 2,
          y: (height - imgDim) / 2,
          width: imgDim,
          height: imgDim,
        });

        const pct = 40 + Math.round(((i + 1) / total) * 45);
        setProgress(pct);
        setStatusStep(`تم تطبيق العلامة على صفحة ${i + 1} من ${total}...`);
      }

      setProgress(90);
      setStatusStep('جاري تصدير الملف النهائي...');

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);

      setProgress(100);
      setStatusStep('تمت إضافة العلامة المائية بنجاح!');
      setReadyResult({ url, name: `watermarked-${singlePdfName}`, info: `تمت إضافة العلامة المائية (${watermarkText}) لجميع الصفحات` });
      setStatusMessage({ text: 'تمت إضافة العلامة المائية بنجاح!', type: 'success' });
    } catch (err: any) {
      setStatusMessage({ text: `فشل تطبيق العلامة المائية: ${err.message}`, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  // 4. JPG to PDF with proper aspect ratio
  const handleJpgToPdf = async () => {
    if (imageFiles.length === 0) {
      setStatusMessage({ text: 'يرجى اختيار صورة واحدة على الأقل.', type: 'error' });
      return;
    }
    setLoading(true);
    setProgress(15);
    setStatusStep('جاري تهيئة صفحات مستند PDF...');

    try {
      const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' });
      const total = imageFiles.length;
      const pageWidth = 210;
      const pageHeight = 297;
      const margin = 10;
      const maxW = pageWidth - margin * 2;
      const maxH = pageHeight - margin * 2;

      for (let i = 0; i < total; i++) {
        if (i > 0) doc.addPage();
        const imgItem = imageFiles[i];
        
        // Preserve the original aspect ratio and center the image on the A4 page.
        const properties = doc.getImageProperties(imgItem.dataUrl);
        const ratio = Math.min(maxW / properties.width, maxH / properties.height);
        const drawWidth = properties.width * ratio;
        const drawHeight = properties.height * ratio;
        const x = (pageWidth - drawWidth) / 2;
        const y = (pageHeight - drawHeight) / 2;
        const format = imgItem.dataUrl.startsWith('data:image/png') ? 'PNG' : 'JPEG';
        doc.addImage(imgItem.dataUrl, format, x, y, drawWidth, drawHeight, undefined, 'FAST');
        
        const pct = 20 + Math.round(((i + 1) / total) * 65);
        setProgress(pct);
        setStatusStep(`جاري إدراج صورة ${i + 1} من ${total}...`);
      }

      setProgress(90);
      setStatusStep('جاري استخراج ملف PDF النهائي...');

      const blob = doc.output('blob');
      const url = URL.createObjectURL(blob);

      setProgress(100);
      setStatusStep('تم تحويل جميع الصور إلى PDF بنجاح!');
      setReadyResult({ url, name: 'converted-images.pdf', info: `تم تجميع ${imageFiles.length} صورة في ملف PDF بدقة عالية` });
      setStatusMessage({ text: 'تم تحويل الصور إلى مستند PDF بنجاح!', type: 'success' });
    } catch (err: any) {
      setStatusMessage({ text: `خطأ أثناء التحويل: ${err.message}`, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  // 5. Rotate All Pages
  const handleRotatePdfPages = async () => {
    if (!singlePdfBytes) return;
    setLoading(true);
    setProgress(20);
    setStatusStep('جاري تدوير صفحات الـ PDF...');

    try {
      const pdfDoc = await PDFDocument.load(singlePdfBytes, { ignoreEncryption: true });
      const pages = pdfDoc.getPages();
      pages.forEach(p => {
        const currentRot = p.getRotation().angle;
        p.setRotation(degrees((currentRot + 90) % 360));
      });

      setProgress(75);
      setStatusStep('جاري حفظ التدوير...');

      const pdfBytes = await pdfDoc.save();
      const blob = new Blob([pdfBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);

      setProgress(100);
      setStatusStep('اكتمل التدوير بنجاح!');
      setReadyResult({ url, name: `rotated-${singlePdfName}`, info: 'تم تدوير جميع صفحات الملف 90 درجة' });
      setStatusMessage({ text: 'تم تدوير صفحات الملف بنجاح!', type: 'success' });
    } catch (err: any) {
      setStatusMessage({ text: `فشل تدوير الصفحات: ${err.message}`, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  // 6. Compress PDF
  const handleCompressPdf = async () => {
    if (!singlePdfBytes) return;
    setLoading(true);
    setProgress(20);
    setStatusStep('جاري تحليل وهيكلة كائنات مستند الـ PDF...');

    try {
      const originalSize = singlePdfBytes.byteLength;
      const pdfDoc = await PDFDocument.load(singlePdfBytes, { ignoreEncryption: true });
      
      setProgress(60);
      setStatusStep('جاري ضغط تدفقات البيانات وإزالة البيانات المكررة...');

      const compressedBytes = await pdfDoc.save({ useObjectStreams: true });
      const newSize = compressedBytes.byteLength;
      if (newSize >= originalSize) {
        setProgress(100);
        setStatusStep('الملف محسن مسبقًا ولا يمكن تقليل حجمه محليًا دون خفض جودة الصور.');
        setReadyResult(null);
        setStatusMessage({ text: 'لم يتم إنشاء نسخة وهمية: حجم الملف لن يصغر بهذه المعالجة.', type: 'error' });
        return;
      }

      const blob = new Blob([compressedBytes], { type: 'application/pdf' });
      const url = URL.createObjectURL(blob);

      setProgress(100);
      setStatusStep('تم تحسين وضغط الملف بنجاح!');
      setReadyResult({
        url,
        name: `compressed-${singlePdfName}`,
        info: `الحجم الأصلي: ${(originalSize / 1024).toFixed(1)} KB | الحجم الجديد: ${(newSize / 1024).toFixed(1)} KB`
      });
      setStatusMessage({ text: 'تم ضغط وتحسين مستند PDF بنجاح!', type: 'success' });
    } catch (e: any) {
      setStatusMessage({ text: `فشل الضغط: ${e.message}`, type: 'error' });
    } finally {
      setLoading(false);
    }
  };

  const tabs = [
    { id: 'merge', label: 'دمج ملفات PDF', icon: Merge },
    { id: 'split', label: 'تقسيم PDF', icon: Split },
    { id: 'organize', label: 'تدوير وترتيب الصفحات', icon: RotateCw },
    { id: 'watermark', label: 'إضافة علامة مائية (Watermark)', icon: Stamp },
    { id: 'jpg-to-pdf', label: 'تحويل صور JPG إلى PDF', icon: FileImage },
    { id: 'compress', label: 'ضغط ملف PDF', icon: Layers }
  ];

  return (
    <div className="space-y-6" id="pdf-tools-suite">
      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-200 dark:scrollbar-thumb-gray-800">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => {
                setActiveTab(tab.id);
                setStatusMessage(null);
                setReadyResult(null);
                setProgress(0);
              }}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/60 border border-gray-200/80 dark:border-gray-700/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Real Progress Bar */}
      {(loading || progress > 0) && (
        <ProcessingProgressBar
          progress={progress}
          statusText={statusStep}
          subText={singlePdfName || (pdfFiles.length ? `${pdfFiles.length} ملفات` : undefined)}
          isCompleted={!loading && progress === 100}
          color="emerald"
        />
      )}

      {/* Ready Result Download Box */}
      {readyResult && (
        <div className="p-4 bg-gradient-to-r from-emerald-50 to-teal-50 dark:from-emerald-950/40 dark:to-teal-950/40 rounded-2xl border-2 border-emerald-500/40 flex flex-col sm:flex-row items-center justify-between gap-4 animate-in fade-in zoom-in shadow-lg">
          <div className="flex items-center gap-3 text-right">
            <div className="w-10 h-10 rounded-xl bg-emerald-600 text-white flex items-center justify-center shrink-0 shadow-md">
              <Check className="w-5 h-5" />
            </div>
            <div>
              <div className="text-xs font-black text-emerald-900 dark:text-emerald-200">النتيجة جاهزة للتحميل: {readyResult.name}</div>
              {readyResult.info && <div className="text-[11px] text-emerald-700 dark:text-emerald-400">{readyResult.info}</div>}
            </div>
          </div>
          <a
            href={readyResult.url}
            download={readyResult.name}
            className="w-full sm:w-auto px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 active:scale-95 text-white font-black text-xs rounded-xl shadow-md flex items-center justify-center gap-2 transition"
          >
            <Download className="w-4 h-4" />
            <span>تحميل المستند المطلوب الآن</span>
          </a>
        </div>
      )}

      {statusMessage && (
        <div
          className={`p-4 rounded-xl text-xs font-bold flex items-center gap-2 ${
            statusMessage.type === 'success'
              ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200'
              : 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200'
          }`}
        >
          {statusMessage.type === 'success' ? <Check className="w-4 h-4" /> : <AlertCircle className="w-4 h-4" />}
          <span>{statusMessage.text}</span>
        </div>
      )}

      {/* Hidden inputs */}
      <input ref={pdfInputRef} type="file" accept="application/pdf" multiple={activeTab === 'merge'} onChange={handlePdfUpload} className="hidden" />
      <input ref={imageInputRef} type="file" accept="image/*" multiple onChange={handleImageUpload} className="hidden" />

      {/* Tab 1: Merge PDFs */}
      {activeTab === 'merge' && (
        <div className="space-y-6">
          <div
            onClick={() => pdfInputRef.current?.click()}
            className="p-10 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-3xl cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/20 transition-all text-center space-y-3"
          >
            <Merge className="w-10 h-10 text-emerald-600 mx-auto" />
            <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200">اختر ملفات PDF المراد دمجها بالترتيب</h4>
            <p className="text-xs text-gray-500">يمكنك رفع ملفين أو أكثر للدمج في ملف واحد مباشر</p>
          </div>

          {pdfFiles.length > 0 && (
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-200 block">الملفات المحددة للدمج ({pdfFiles.length}):</span>
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {pdfFiles.map((f, i) => (
                  <div key={i} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs">
                    <div className="flex items-center gap-2 truncate">
                      <span className="font-bold text-emerald-600">#{i + 1}</span>
                      <span className="truncate">{f.name}</span>
                    </div>
                    <button
                      onClick={() => setPdfFiles(prev => prev.filter((_, idx) => idx !== i))}
                      className="p-1 text-gray-400 hover:text-rose-500"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>

              <button
                disabled={loading}
                onClick={handleMergePdfs}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>{loading ? 'جارٍ الدمج والتصدير...' : 'دمج ومعالجة الملفات'}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 2: Split PDF */}
      {activeTab === 'split' && (
        <div className="space-y-6">
          {!singlePdfBytes ? (
            <div
              onClick={() => pdfInputRef.current?.click()}
              className="p-10 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-3xl cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/20 transition-all text-center space-y-3"
            >
              <Split className="w-10 h-10 text-emerald-600 mx-auto" />
              <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200">اختر ملف PDF المراد تقسيمه</h4>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-5">
              <div className="flex items-center justify-between">
                <div>
                  <span className="text-xs font-bold text-gray-800 dark:text-gray-200 block">{singlePdfName}</span>
                  <span className="text-[11px] text-emerald-600 font-bold">إجمالي الصفحات: {pdfPageCount} صفحة</span>
                </div>
                <button onClick={() => setSinglePdfBytes(null)} className="text-xs text-rose-500 font-bold">تغيير الملف</button>
              </div>

              <div className="space-y-2">
                <label className="text-xs font-bold block">أدخل أرقام الصفحات المراد استخراجها (مثال: 1-3 أو 1, 4, 5):</label>
                <input
                  type="text"
                  value={splitRange}
                  onChange={e => setSplitRange(e.target.value)}
                  className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border border-gray-200 dark:border-gray-700 outline-none"
                />
              </div>

              <button
                disabled={loading}
                onClick={handleSplitPdf}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>{loading ? 'جارٍ التقسيم...' : 'استخراج الصفحات المحددة'}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 3: Organize / Rotate */}
      {activeTab === 'organize' && (
        <div className="space-y-6">
          {!singlePdfBytes ? (
            <div
              onClick={() => pdfInputRef.current?.click()}
              className="p-10 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-3xl cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/20 transition-all text-center space-y-3"
            >
              <RotateCw className="w-10 h-10 text-emerald-600 mx-auto" />
              <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200">اختر ملف PDF لتدوير صفحاته</h4>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-5 text-center">
              <span className="text-sm font-bold text-gray-800 dark:text-gray-200 block">{singlePdfName} ({pdfPageCount} صفحة)</span>
              <button
                disabled={loading}
                onClick={handleRotatePdfPages}
                className="py-3 px-8 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold inline-flex items-center gap-2"
              >
                <RotateCw className="w-4 h-4" />
                <span>{loading ? 'جارٍ التدوير...' : 'تدوير جميع الصفحات 90°'}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Watermark */}
      {activeTab === 'watermark' && (
        <div className="space-y-6">
          {!singlePdfBytes ? (
            <div
              onClick={() => pdfInputRef.current?.click()}
              className="p-10 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-3xl cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/20 transition-all text-center space-y-3"
            >
              <Stamp className="w-10 h-10 text-emerald-600 mx-auto" />
              <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200">اختر ملف PDF لإضافة علامة مائية</h4>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-5">
              <div className="space-y-2">
                <label className="text-xs font-bold block">نص العلامة المائية:</label>
                <input
                  type="text"
                  value={watermarkText}
                  onChange={e => setWatermarkText(e.target.value)}
                  className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-sans border border-gray-200 dark:border-gray-700 outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-xs font-bold block mb-1">الشفافية: {Math.round(watermarkOpacity * 100)}%</label>
                  <input
                    type="range"
                    min="0.1"
                    max="1.0"
                    step="0.05"
                    value={watermarkOpacity}
                    onChange={e => setWatermarkOpacity(Number(e.target.value))}
                    className="w-full accent-emerald-600"
                  />
                </div>
                <div>
                  <label className="text-xs font-bold block mb-1">حجم الخط: {watermarkSize}px</label>
                  <input
                    type="range"
                    min="18"
                    max="72"
                    value={watermarkSize}
                    onChange={e => setWatermarkSize(Number(e.target.value))}
                    className="w-full accent-emerald-600"
                  />
                </div>
              </div>

              <button
                disabled={loading}
                onClick={handleAddWatermark}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <Stamp className="w-4 h-4" />
                <span>{loading ? 'جارٍ التطبيق...' : 'تطبيق العلامة المائية'}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 5: JPG to PDF */}
      {activeTab === 'jpg-to-pdf' && (
        <div className="space-y-6">
          <div
            onClick={() => imageInputRef.current?.click()}
            className="p-10 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-3xl cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/20 transition-all text-center space-y-3"
          >
            <FileImage className="w-10 h-10 text-emerald-600 mx-auto" />
            <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200">اختر صور JPG / PNG لتحويلها إلى ملف PDF</h4>
          </div>

          {imageFiles.length > 0 && (
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
              <span className="text-xs font-bold block">الصور المحددة ({imageFiles.length}):</span>
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                {imageFiles.map((img, i) => (
                  <div key={i} className="p-2 bg-gray-50 dark:bg-gray-900 rounded-xl relative group">
                    <img src={img.dataUrl} alt={img.name} className="h-24 w-full object-cover rounded-lg" />
                    <button
                      onClick={() => setImageFiles(prev => prev.filter((_, idx) => idx !== i))}
                      className="absolute top-3 right-3 p-1 bg-rose-600 text-white rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                    >
                      <Trash2 className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>

              <button
                disabled={loading}
                onClick={handleJpgToPdf}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>{loading ? 'جارٍ التحويل...' : 'تحويل الصور إلى مستند PDF واحد'}</span>
              </button>
            </div>
          )}
        </div>
      )}

      {/* Tab 6: Compress PDF */}
      {activeTab === 'compress' && (
        <div className="space-y-6">
          {!singlePdfBytes ? (
            <div
              onClick={() => pdfInputRef.current?.click()}
              className="p-10 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-3xl cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/20 transition-all text-center space-y-3"
            >
              <Layers className="w-10 h-10 text-emerald-600 mx-auto" />
              <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200">اختر ملف PDF لضغطه وتقليل حجمه</h4>
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-4 text-center">
              <span className="text-sm font-bold text-gray-800 dark:text-gray-200 block">{singlePdfName}</span>
              <p className="text-xs text-gray-500">يقوم المحرك بإعادة ترميز بنية الكائنات والخطوط لتخفيف حجم الملف دون التأثير على جودة النصوص.</p>
              <button
                disabled={loading}
                onClick={handleCompressPdf}
                className="py-3 px-8 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white rounded-xl text-xs font-bold inline-flex items-center gap-2"
              >
                <Layers className="w-4 h-4" />
                <span>{loading ? 'جارٍ الضغط...' : 'ضغط وتحسين ملف PDF'}</span>
              </button>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

