import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';

interface ToolErrorBoundaryProps {
  children: ReactNode;
  toolName?: string;
}

interface ToolErrorBoundaryState {
  hasError: boolean;
  error: Error | null;
}

export class ToolErrorBoundary extends Component<ToolErrorBoundaryProps, ToolErrorBoundaryState> {
  constructor(props: ToolErrorBoundaryProps) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
    };
  }

  public static getDerivedStateFromError(error: Error): ToolErrorBoundaryState {
    return { hasError: true, error };
  }

  public componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    console.error('Tool rendering error:', error, errorInfo);
  }

  private handleReset = () => {
    this.setState({ hasError: false, error: null });
  };

  public render() {
    if (this.state.hasError) {
      return (
        <div className="p-8 text-center bg-red-50/50 dark:bg-red-950/20 border border-red-200 dark:border-red-900/50 rounded-2xl space-y-4 my-4">
          <div className="w-12 h-12 rounded-full bg-red-100 dark:bg-red-900/50 text-red-600 dark:text-red-400 flex items-center justify-center mx-auto">
            <AlertTriangle className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-base font-bold text-red-900 dark:text-red-200">
              حدث خطأ أثناء تشغيل {this.props.toolName ? `أداة ${this.props.toolName}` : 'الأداة'}
            </h3>
            <p className="text-xs text-red-600 dark:text-red-400 mt-1 max-w-md mx-auto">
              قد يكون سبب ذلك إدخال غير صالح أو ملف غير متوافق. يمكنك إعادة تعيين الأداة والمحاولة مجدداً.
            </p>
          </div>
          <button
            onClick={this.handleReset}
            className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white text-xs font-bold rounded-xl transition shadow-xs cursor-pointer"
          >
            <RefreshCw className="w-3.5 h-3.5" />
            <span>إعادة تشغيل الأداة</span>
          </button>
        </div>
      );
    }

    return this.props.children;
  }
}
