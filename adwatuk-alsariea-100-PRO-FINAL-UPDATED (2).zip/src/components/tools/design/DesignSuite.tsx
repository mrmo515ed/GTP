import React, { useState, useMemo } from 'react';
import {
  Palette,
  Sliders,
  Sparkles,
  Eye,
  Box,
  Copy,
  Check,
  Maximize2,
  Layers,
  Sun,
  Contrast
} from 'lucide-react';

interface Props {
  defaultTab?:
    | 'color-converter'
    | 'gradient-generator'
    | 'palette-generator'
    | 'contrast-checker'
    | 'box-shadow'
    | 'border-radius';
}

export function DesignSuite({ defaultTab = 'color-converter' }: Props) {
  const [activeTab, setActiveTab] = useState<string>(defaultTab);
  const [copied, setCopied] = useState<boolean>(false);

  // 1. Color Converter State
  const [hexColor, setHexColor] = useState<string>('#10b981');

  // 2. Gradient State
  const [gradType, setGradType] = useState<'linear' | 'radial'>('linear');
  const [gradAngle, setGradAngle] = useState<number>(90);
  const [gradColor1, setGradColor1] = useState<string>('#3b82f6');
  const [gradColor2, setGradColor2] = useState<string>('#10b981');

  // 3. Contrast Checker State
  const [textColor, setTextColor] = useState<string>('#ffffff');
  const [bgColor, setBgColor] = useState<string>('#0f172a');

  // 4. Box Shadow State
  const [shadowX, setShadowX] = useState<number>(0);
  const [shadowY, setShadowY] = useState<number>(10);
  const [shadowBlur, setShadowBlur] = useState<number>(25);
  const [shadowSpread, setShadowSpread] = useState<number>(-5);
  const [shadowColor, setShadowColor] = useState<string>('rgba(0, 0, 0, 0.15)');

  // 5. Border Radius State
  const [tl, setTl] = useState<number>(30);
  const [tr, setTr] = useState<number>(70);
  const [br, setBr] = useState<number>(70);
  const [bl, setBl] = useState<number>(30);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Color Conversions
  const colorMetrics = useMemo(() => {
    let cleanHex = hexColor.replace('#', '');
    if (cleanHex.length === 3) {
      cleanHex = cleanHex.split('').map(c => c + c).join('');
    }
    if (cleanHex.length !== 6) {
      return { hex: '#000000', rgb: 'rgb(0, 0, 0)', hsl: 'hsl(0, 0%, 0%)', r: 0, g: 0, b: 0 };
    }
    const r = parseInt(cleanHex.substring(0, 2), 16) || 0;
    const g = parseInt(cleanHex.substring(2, 4), 16) || 0;
    const b = parseInt(cleanHex.substring(4, 6), 16) || 0;

    const rNorm = r / 255;
    const gNorm = g / 255;
    const bNorm = b / 255;
    const max = Math.max(rNorm, gNorm, bNorm);
    const min = Math.min(rNorm, gNorm, bNorm);
    let h = 0;
    let s = 0;
    const l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case rNorm:
          h = (gNorm - bNorm) / d + (gNorm < bNorm ? 6 : 0);
          break;
        case gNorm:
          h = (bNorm - rNorm) / d + 2;
          break;
        case bNorm:
          h = (rNorm - gNorm) / d + 4;
          break;
      }
      h /= 6;
    }

    return {
      hex: `#${cleanHex}`,
      rgb: `rgb(${r}, ${g}, ${b})`,
      hsl: `hsl(${Math.round(h * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`,
      r,
      g,
      b,
      h: Math.round(h * 360),
      s: Math.round(s * 100),
      l: Math.round(l * 100)
    };
  }, [hexColor]);

  // Harmonious Palettes
  const palettes = useMemo(() => {
    const { h, s, l } = colorMetrics;
    const compH = (h + 180) % 360;
    const tri1 = (h + 120) % 360;
    const tri2 = (h + 240) % 360;
    const ana1 = (h + 30) % 360;
    const ana2 = (h + 330) % 360;

    return {
      complementary: [`hsl(${h}, ${s}%, ${l}%)`, `hsl(${compH}, ${s}%, ${l}%)`],
      triadic: [`hsl(${h}, ${s}%, ${l}%)`, `hsl(${tri1}, ${s}%, ${l}%)`, `hsl(${tri2}, ${s}%, ${l}%)`],
      analogous: [`hsl(${ana2}, ${s}%, ${l}%)`, `hsl(${h}, ${s}%, ${l}%)`, `hsl(${ana1}, ${s}%, ${l}%)`],
      monochromatic: [
        `hsl(${h}, ${s}%, 20%)`,
        `hsl(${h}, ${s}%, 40%)`,
        `hsl(${h}, ${s}%, 60%)`,
        `hsl(${h}, ${s}%, 80%)`
      ]
    };
  }, [colorMetrics]);

  // Contrast Calculation (WCAG)
  const contrastRatio = useMemo(() => {
    const getLuminance = (hex: string) => {
      const clean = hex.replace('#', '');
      const r = parseInt(clean.substring(0, 2), 16) / 255;
      const g = parseInt(clean.substring(2, 4), 16) / 255;
      const b = parseInt(clean.substring(4, 6), 16) / 255;
      const a = [r, g, b].map(v => (v <= 0.03928 ? v / 12.92 : Math.pow((v + 0.055) / 1.055, 2.4)));
      return a[0] * 0.2126 + a[1] * 0.7152 + a[2] * 0.0722;
    };
    try {
      const l1 = getLuminance(textColor);
      const l2 = getLuminance(bgColor);
      const ratio = (Math.max(l1, l2) + 0.05) / (Math.min(l1, l2) + 0.05);
      return Number(ratio.toFixed(2));
    } catch {
      return 1;
    }
  }, [textColor, bgColor]);

  // Gradient CSS
  const gradientCss = useMemo(() => {
    return gradType === 'linear'
      ? `linear-gradient(${gradAngle}deg, ${gradColor1}, ${gradColor2})`
      : `radial-gradient(circle, ${gradColor1}, ${gradColor2})`;
  }, [gradType, gradAngle, gradColor1, gradColor2]);

  // Box Shadow CSS
  const boxShadowCss = `${shadowX}px ${shadowY}px ${shadowBlur}px ${shadowSpread}px ${shadowColor}`;

  // Border Radius CSS
  const borderRadiusCss = `${tl}% ${100 - tl}% ${br}% ${100 - br}% / ${100 - tr}% ${bl}% ${100 - bl}% ${tr}%`;

  const tabs = [
    { id: 'color-converter', label: 'محول الألوان (HEX/RGB/HSL)', icon: Palette },
    { id: 'gradient-generator', label: 'مولد التدرجات (Gradient)', icon: Sparkles },
    { id: 'palette-generator', label: 'تناسق الألوان (Palettes)', icon: Layers },
    { id: 'contrast-checker', label: 'فاحص التباين (WCAG Contrast)', icon: Contrast },
    { id: 'box-shadow', label: 'مولد الظلال (Box Shadow)', icon: Box },
    { id: 'border-radius', label: 'مولد الحواف المائلة (Border Radius)', icon: Sliders }
  ];

  return (
    <div className="space-y-6" id="design-suite">
      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-200 dark:scrollbar-thumb-gray-800">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/60 border border-gray-200/80 dark:border-gray-700/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Color Converter */}
      {activeTab === 'color-converter' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="flex items-center gap-4">
            <input
              type="color"
              value={colorMetrics.hex}
              onChange={e => setHexColor(e.target.value)}
              className="w-16 h-16 rounded-2xl cursor-pointer border-none bg-transparent p-0"
            />
            <div className="flex-1 space-y-1">
              <label className="text-xs font-bold text-gray-500">اختر أو اكتب كود اللون HEX:</label>
              <input
                type="text"
                value={hexColor}
                onChange={e => setHexColor(e.target.value)}
                className="w-full p-2.5 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border border-gray-200 dark:border-gray-700 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            {[
              { label: 'HEX', val: colorMetrics.hex },
              { label: 'RGB', val: colorMetrics.rgb },
              { label: 'HSL', val: colorMetrics.hsl }
            ].map((c, i) => (
              <div key={i} className="p-4 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 flex items-center justify-between">
                <div>
                  <span className="text-[11px] font-bold text-gray-400 block">{c.label}</span>
                  <span className="text-xs font-mono font-bold text-emerald-600">{c.val}</span>
                </div>
                <button onClick={() => copyToClipboard(c.val)} className="p-1.5 text-gray-400 hover:text-emerald-600">
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Gradient Generator */}
      {activeTab === 'gradient-generator' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
            <h4 className="text-xs font-black text-gray-700 dark:text-gray-200">إعدادات التدرج اللوني</h4>
            <div className="flex gap-2">
              <button
                onClick={() => setGradType('linear')}
                className={`flex-1 py-2 text-xs font-bold rounded-xl ${gradType === 'linear' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
              >
                خطي (Linear)
              </button>
              <button
                onClick={() => setGradType('radial')}
                className={`flex-1 py-2 text-xs font-bold rounded-xl ${gradType === 'radial' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
              >
                دائري (Radial)
              </button>
            </div>

            {gradType === 'linear' && (
              <div>
                <label className="text-xs font-bold block mb-1">الزاوية: {gradAngle}°</label>
                <input
                  type="range"
                  min="0"
                  max="360"
                  value={gradAngle}
                  onChange={e => setGradAngle(Number(e.target.value))}
                  className="w-full accent-emerald-600"
                />
              </div>
            )}

            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1">
                <label className="text-xs font-bold block">اللون الأول</label>
                <div className="flex items-center gap-2">
                  <input type="color" value={gradColor1} onChange={e => setGradColor1(e.target.value)} className="w-8 h-8 rounded-lg cursor-pointer border-none bg-transparent" />
                  <input type="text" value={gradColor1} onChange={e => setGradColor1(e.target.value)} className="w-full p-2 bg-gray-50 dark:bg-gray-900 rounded-lg text-xs font-mono border" />
                </div>
              </div>
              <div className="space-y-1">
                <label className="text-xs font-bold block">اللون الثاني</label>
                <div className="flex items-center gap-2">
                  <input type="color" value={gradColor2} onChange={e => setGradColor2(e.target.value)} className="w-8 h-8 rounded-lg cursor-pointer border-none bg-transparent" />
                  <input type="text" value={gradColor2} onChange={e => setGradColor2(e.target.value)} className="w-full p-2 bg-gray-50 dark:bg-gray-900 rounded-lg text-xs font-mono border" />
                </div>
              </div>
            </div>

            <button
              onClick={() => copyToClipboard(`background: ${gradientCss};`)}
              className="w-full py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
            >
              <Copy className="w-4 h-4" />
              <span>نسخ كود CSS</span>
            </button>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 flex items-center justify-center min-h-[220px]">
            <div className="w-full h-48 rounded-2xl shadow-lg transition-all" style={{ background: gradientCss }} />
          </div>
        </div>
      )}

      {/* Tab 3: Palette Generator */}
      {activeTab === 'palette-generator' && (
        <div className="space-y-6">
          <div className="flex items-center gap-3 p-4 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
            <span className="text-xs font-bold">اللون الأساسي:</span>
            <input type="color" value={colorMetrics.hex} onChange={e => setHexColor(e.target.value)} className="w-10 h-10 rounded-xl cursor-pointer border-none bg-transparent" />
            <span className="text-xs font-mono font-bold text-emerald-600">{colorMetrics.hex}</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {[
              { title: 'تناسق مكمل (Complementary)', colors: palettes.complementary },
              { title: 'تناسق ثلاثي (Triadic)', colors: palettes.triadic },
              { title: 'تناسق متجاور (Analogous)', colors: palettes.analogous },
              { title: 'تدرج أحادي (Monochromatic)', colors: palettes.monochromatic }
            ].map((p, idx) => (
              <div key={idx} className="p-4 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 space-y-3">
                <span className="text-xs font-bold text-gray-700 dark:text-gray-300 block">{p.title}</span>
                <div className="grid grid-cols-4 gap-2">
                  {p.colors.map((c, ci) => (
                    <div
                      key={ci}
                      onClick={() => copyToClipboard(c)}
                      className="h-16 rounded-xl cursor-pointer hover:scale-105 transition-transform flex items-end justify-center pb-1 text-[10px] text-white font-mono shadow-sm"
                      style={{ backgroundColor: c }}
                    >
                      <span className="bg-black/40 px-1 rounded">نسخ</span>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 4: Contrast Checker */}
      {activeTab === 'contrast-checker' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
            <h4 className="text-xs font-black text-gray-700 dark:text-gray-200">فحص تباين الألوان ومعايير إمكانية الوصول (WCAG)</h4>
            <div className="space-y-3">
              <div>
                <label className="text-xs font-bold block mb-1">لون النص (Text Color)</label>
                <div className="flex items-center gap-2">
                  <input type="color" value={textColor} onChange={e => setTextColor(e.target.value)} className="w-8 h-8 rounded-lg cursor-pointer border-none bg-transparent" />
                  <input type="text" value={textColor} onChange={e => setTextColor(e.target.value)} className="w-full p-2 bg-gray-50 dark:bg-gray-900 rounded-lg text-xs font-mono border" />
                </div>
              </div>
              <div>
                <label className="text-xs font-bold block mb-1">لون الخلفية (Background Color)</label>
                <div className="flex items-center gap-2">
                  <input type="color" value={bgColor} onChange={e => setBgColor(e.target.value)} className="w-8 h-8 rounded-lg cursor-pointer border-none bg-transparent" />
                  <input type="text" value={bgColor} onChange={e => setBgColor(e.target.value)} className="w-full p-2 bg-gray-50 dark:bg-gray-900 rounded-lg text-xs font-mono border" />
                </div>
              </div>
            </div>

            <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl space-y-2">
              <div className="flex justify-between items-center text-xs">
                <span>نسبة التباين (Contrast Ratio):</span>
                <span className="font-mono font-black text-base text-emerald-600">{contrastRatio}:1</span>
              </div>
              <div className="flex gap-2">
                <span className={`px-2.5 py-1 rounded-lg text-[11px] font-bold ${contrastRatio >= 4.5 ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                  WCAG AA: {contrastRatio >= 4.5 ? 'ناجح ✅' : 'فاشل ❌'}
                </span>
                <span className={`px-2.5 py-1 rounded-lg text-[11px] font-bold ${contrastRatio >= 7.0 ? 'bg-emerald-100 text-emerald-700' : 'bg-rose-100 text-rose-700'}`}>
                  WCAG AAA: {contrastRatio >= 7.0 ? 'ناجح ✅' : 'فاشل ❌'}
                </span>
              </div>
            </div>
          </div>

          <div
            className="rounded-2xl p-8 flex flex-col items-center justify-center text-center space-y-2 shadow-sm border border-gray-200 dark:border-gray-700"
            style={{ backgroundColor: bgColor, color: textColor }}
          >
            <h3 className="text-xl font-bold">معاينة النص الحي</h3>
            <p className="text-xs max-w-xs">هذا النص يوضح مدى وضوح القراءة وسهولة التمييز للعين البشرية على هذه الخلفية.</p>
          </div>
        </div>
      )}

      {/* Tab 5: Box Shadow */}
      {activeTab === 'box-shadow' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <h4 className="text-xs font-black text-gray-700 dark:text-gray-200">إعدادات الظل</h4>
            <div className="space-y-2 text-xs font-bold">
              <div>
                <span>الإزاحة الأفقية (X): {shadowX}px</span>
                <input type="range" min="-50" max="50" value={shadowX} onChange={e => setShadowX(Number(e.target.value))} className="w-full accent-emerald-600" />
              </div>
              <div>
                <span>الإزاحة الرأسية (Y): {shadowY}px</span>
                <input type="range" min="-50" max="50" value={shadowY} onChange={e => setShadowY(Number(e.target.value))} className="w-full accent-emerald-600" />
              </div>
              <div>
                <span>التمويه (Blur): {shadowBlur}px</span>
                <input type="range" min="0" max="100" value={shadowBlur} onChange={e => setShadowBlur(Number(e.target.value))} className="w-full accent-emerald-600" />
              </div>
              <div>
                <span>الانتشار (Spread): {shadowSpread}px</span>
                <input type="range" min="-30" max="50" value={shadowSpread} onChange={e => setShadowSpread(Number(e.target.value))} className="w-full accent-emerald-600" />
              </div>
            </div>

            <button
              onClick={() => copyToClipboard(`box-shadow: ${boxShadowCss};`)}
              className="w-full py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
            >
              <Copy className="w-4 h-4" />
              <span>نسخ كود Box-Shadow</span>
            </button>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 flex items-center justify-center min-h-[220px]">
            <div
              className="w-36 h-36 bg-white dark:bg-gray-900 rounded-2xl border border-gray-100 dark:border-gray-800 flex items-center justify-center text-xs font-bold"
              style={{ boxShadow: boxShadowCss }}
            >
              معاينة العنصر
            </div>
          </div>
        </div>
      )}

      {/* Tab 6: Border Radius */}
      {activeTab === 'border-radius' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <h4 className="text-xs font-black text-gray-700 dark:text-gray-200">التحكم في المنحنيات غير المنتظمة (8-Point)</h4>
            <div className="grid grid-cols-2 gap-3 text-xs font-bold">
              <div>
                <span>أعلى يسار: {tl}%</span>
                <input type="range" min="0" max="100" value={tl} onChange={e => setTl(Number(e.target.value))} className="w-full accent-emerald-600" />
              </div>
              <div>
                <span>أعلى يمين: {tr}%</span>
                <input type="range" min="0" max="100" value={tr} onChange={e => setTr(Number(e.target.value))} className="w-full accent-emerald-600" />
              </div>
              <div>
                <span>أسفل يمين: {br}%</span>
                <input type="range" min="0" max="100" value={br} onChange={e => setBr(Number(e.target.value))} className="w-full accent-emerald-600" />
              </div>
              <div>
                <span>أسفل يسار: {bl}%</span>
                <input type="range" min="0" max="100" value={bl} onChange={e => setBl(Number(e.target.value))} className="w-full accent-emerald-600" />
              </div>
            </div>

            <button
              onClick={() => copyToClipboard(`border-radius: ${borderRadiusCss};`)}
              className="w-full py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
            >
              <Copy className="w-4 h-4" />
              <span>نسخ كود Border-Radius</span>
            </button>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 flex items-center justify-center min-h-[220px]">
            <div
              className="w-44 h-44 bg-emerald-600 transition-all duration-300 shadow-xl flex items-center justify-center text-white text-xs font-bold"
              style={{ borderRadius: borderRadiusCss }}
            >
              Blob Shape
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
