import React, { useState } from 'react';
import {
  GitBranch,
  Network,
  Share2,
  FileCode,
  Layout,
  Smartphone,
  Sparkles,
  Layers,
  Crop,
  Maximize2,
  Image as ImageIcon,
  Copy,
  Check,
  Download,
  Code2,
  Tv,
  Monitor,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  defaultTab?: string;
}

export function DiagramsDesignSuite({ defaultTab = 'flowchart' }: Props) {
  const [activeTab, setActiveTab] = useState(defaultTab);

  const tabs = [
    { id: 'flowchart', label: 'مخطط Flowchart', icon: GitBranch },
    { id: 'mermaid', label: 'Mermaid Diagram', icon: Code2 },
    { id: 'er-diagram', label: 'ER Diagram (قواعد البيانات)', icon: Network },
    { id: 'uml-diagram', label: 'UML Diagram', icon: Share2 },
    { id: 'mind-map', label: 'خريطة ذهنية (Mind Map)', icon: Sparkles },
    { id: 'sitemap', label: 'مولد Sitemap المخطط', icon: Layout },
    { id: 'wireframe', label: 'مولد Wireframe الواجهات', icon: Monitor },
    { id: 'logo-mockup', label: 'معاينة الشعار (Mockup)', icon: Layers },
    { id: 'og-image', label: 'بطاقة Open Graph للشبكات', icon: Tv },
    { id: 'social-resizer', label: 'مقاسات السوشيال ميديا', icon: Crop },
    { id: 'aspect-ratio', label: 'حاسبة أبعاد الشاشة والأبعاد', icon: Maximize2 },
    { id: 'svg-generator', label: 'مولد أشكال SVG', icon: FileCode },
    { id: 'app-icon', label: 'أيقونات التطبيقات (iOS & Android)', icon: Smartphone },
  ];

  return (
    <div className="space-y-6" id="diagrams-design-suite">
      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-gray-200 dark:border-gray-800">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                isActive
                  ? 'bg-purple-600 text-white shadow-md'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-5 sm:p-6 shadow-xs">
        {activeTab === 'flowchart' && <FlowchartBuilder />}
        {activeTab === 'mermaid' && <MermaidDiagramBuilder />}
        {activeTab === 'er-diagram' && <ERDiagramTool />}
        {activeTab === 'uml-diagram' && <UMLDiagramTool />}
        {activeTab === 'mind-map' && <MindMapTool />}
        {activeTab === 'sitemap' && <SitemapVisualizerTool />}
        {activeTab === 'wireframe' && <WireframeTool />}
        {activeTab === 'logo-mockup' && <LogoMockupTool />}
        {activeTab === 'og-image' && <OgImageTool />}
        {activeTab === 'social-resizer' && <SocialResizerTool />}
        {activeTab === 'aspect-ratio' && <AspectRatioCalculatorTool />}
        {activeTab === 'svg-generator' && <SvgShapeGenerator />}
        {activeTab === 'app-icon' && <AppIconTool />}
      </div>
    </div>
  );
}

// 1. Flowchart Builder
function FlowchartBuilder() {
  const [nodes, setNodes] = useState([
    { id: '1', label: 'البداية (Start)', type: 'start' },
    { id: '2', label: 'إدخال البيانات والمصادقة', type: 'process' },
    { id: '3', label: 'هل البيانات صحيحة؟', type: 'decision' },
    { id: '4', label: 'تسجيل الدخول بنجاح', type: 'end' },
  ]);
  const [newLabel, setNewLabel] = useState('');
  const [newType, setNewType] = useState('process');

  const addNode = () => {
    if (!newLabel) return;
    setNodes([...nodes, { id: String(Date.now()), label: newLabel, type: newType }]);
    setNewLabel('');
  };

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <GitBranch className="w-5 h-5 text-purple-600" />
        <span>منشئ ومصمم مخططات التدفق العملي (Flowchart Builder)</span>
      </h3>

      <div className="flex gap-2">
        <input
          type="text"
          placeholder="عنوان الخطوة الجديدة..."
          value={newLabel}
          onChange={(e) => setNewLabel(e.target.value)}
          className="flex-1 px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
        <select
          value={newType}
          onChange={(e) => setNewType(e.target.value)}
          className="px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        >
          <option value="start">بداية / نهاية</option>
          <option value="process">عملية معالجة</option>
          <option value="decision">قرار شرطي</option>
        </select>
        <button
          onClick={addNode}
          className="px-4 py-2 bg-purple-600 text-white rounded-xl text-xs font-bold"
        >
          إضافة خطوة
        </button>
      </div>

      <div className="p-6 bg-gray-50 dark:bg-gray-950 rounded-2xl border border-dashed flex flex-col items-center space-y-3">
        {nodes.map((node, i) => (
          <React.Fragment key={node.id}>
            <div
              className={`px-6 py-3 text-xs font-bold text-center shadow-xs transition ${
                node.type === 'start'
                  ? 'bg-emerald-600 text-white rounded-full'
                  : node.type === 'decision'
                  ? 'bg-amber-500 text-white rotate-0 border-2 border-amber-600 rounded-2xl'
                  : 'bg-white dark:bg-gray-800 text-gray-900 dark:text-white border-2 border-purple-500 rounded-xl'
              }`}
            >
              {node.label}
            </div>
            {i < nodes.length - 1 && <div className="w-0.5 h-6 bg-purple-400"></div>}
          </React.Fragment>
        ))}
      </div>
    </div>
  );
}

// 2. Mermaid Diagram Builder
function MermaidDiagramBuilder() {
  const [code, setCode] = useState(`graph TD
    A[مستخدم جديد] --> B{هل لديه حساب؟}
    B -- نعم --> C[تسجيل الدخول]
    B -- لا --> D[إنشاء حساب جديد]
    C --> E[لوحة التحكم]
    D --> E`);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Code2 className="w-5 h-5 text-indigo-500" />
        <span>محرر ومولد مخططات Mermaid البرمجية</span>
      </h3>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div>
          <label className="block text-xs font-bold mb-1">كود Mermaid</label>
          <textarea
            rows={8}
            value={code}
            onChange={(e) => setCode(e.target.value)}
            className="w-full p-3 font-mono text-xs border rounded-xl dark:bg-gray-800 leading-relaxed"
          />
        </div>

        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border flex flex-col justify-between">
          <div>
            <span className="text-xs font-bold text-gray-500 mb-2 block">معاينة بنية المخطط النصي</span>
            <div className="space-y-2 text-xs font-mono text-indigo-600 dark:text-indigo-400">
              {code.split('\n').map((line, idx) => (
                <div key={idx} className="p-1.5 bg-white dark:bg-gray-900 rounded border">
                  {line}
                </div>
              ))}
            </div>
          </div>
          <button
            onClick={() => {
              navigator.clipboard.writeText(code);
              confetti({ particleCount: 25, spread: 50 });
            }}
            className="mt-3 inline-flex items-center justify-center gap-1.5 px-4 py-2 bg-indigo-600 text-white rounded-xl text-xs font-bold"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>نسخ كود Mermaid</span>
          </button>
        </div>
      </div>
    </div>
  );
}

// 3. ER Diagram Tool
function ERDiagramTool() {
  const [tables, setTables] = useState([
    {
      name: 'Users',
      fields: ['id (PK, int)', 'name (varchar)', 'email (unique)', 'created_at (timestamp)'],
    },
    {
      name: 'Orders',
      fields: ['id (PK, int)', 'user_id (FK -> Users.id)', 'total_amount (decimal)', 'status (varchar)'],
    },
  ]);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Network className="w-5 h-5 text-blue-600" />
        <span>منشئ مخطط الكيانات والعلاقات (ER Diagram)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {tables.map((t, idx) => (
          <div key={idx} className="bg-gray-50 dark:bg-gray-800 rounded-xl border border-blue-200 dark:border-blue-900/50 overflow-hidden shadow-xs">
            <div className="bg-blue-600 text-white px-4 py-2 text-xs font-black flex items-center justify-between">
              <span>{t.name}</span>
              <span className="text-[10px] bg-white/20 px-2 py-0.5 rounded">Table</span>
            </div>
            <div className="p-3 space-y-1 text-xs font-mono">
              {t.fields.map((f, fIdx) => (
                <div key={fIdx} className="text-gray-700 dark:text-gray-300 py-0.5 border-b border-gray-100 dark:border-gray-700/50 last:border-0">
                  {f}
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// 4. UML Diagram Tool
function UMLDiagramTool() {
  return <ERDiagramTool />;
}

// 5. Mind Map Tool
function MindMapTool() {
  const [root, setRoot] = useState('فكرة المشروع الرئيسي');
  const [branches, setBranches] = useState(['التصميم و UI/UX', 'البرمجة وقواعد البيانات', 'التسويق والإطلاق', 'الدعم الفني']);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-amber-500" />
        <span>منشئ الخرائط الذهنية والعصف الذهني (Mind Map)</span>
      </h3>

      <div className="p-8 bg-gradient-to-br from-amber-500/10 via-purple-500/10 to-blue-500/10 rounded-2xl border flex flex-col items-center justify-center space-y-6">
        <div className="px-6 py-3 bg-amber-500 text-white rounded-2xl font-black text-sm shadow-md">
          {root}
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 w-full">
          {branches.map((b, i) => (
            <div
              key={i}
              className="p-3 bg-white dark:bg-gray-800 rounded-xl border border-amber-300 text-center text-xs font-bold text-gray-800 dark:text-gray-200 shadow-xs"
            >
              🌱 {b}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// 6. Sitemap Visualizer Tool
function SitemapVisualizerTool() {
  const pages = [
    { title: 'الرئيسية (/)', children: ['من نحن (/about)', 'الخدمات (/services)', 'اتصل بنا (/contact)'] },
    { title: 'المدونة (/blog)', children: ['المقالات (/posts)', 'التصنيفات (/categories)'] },
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Layout className="w-5 h-5 text-teal-600" />
        <span>مولد وتخطيط هيكل صفحات الموقع (Sitemap Tree)</span>
      </h3>

      <div className="space-y-3">
        {pages.map((p, idx) => (
          <div key={idx} className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border space-y-2">
            <div className="font-bold text-xs text-teal-600">📁 {p.title}</div>
            <div className="mr-4 space-y-1 text-xs text-gray-600 dark:text-gray-400 border-r-2 border-teal-300 pr-3">
              {p.children.map((c, cIdx) => (
                <div key={cIdx}>📄 {c}</div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// 7. Wireframe Tool
function WireframeTool() {
  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Monitor className="w-5 h-5 text-indigo-500" />
        <span>معاينة الواجهات السريعة (Wireframe Template)</span>
      </h3>

      <div className="p-4 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-2xl space-y-3 bg-gray-50 dark:bg-gray-900/50">
        <div className="h-10 bg-gray-200 dark:bg-gray-800 rounded-lg flex items-center justify-between px-3 text-[10px] text-gray-500 font-bold">
          <span>[شريط التنقل Navigation Bar]</span>
          <span>[الشعار | الروابط | زر الدخول]</span>
        </div>
        <div className="h-28 bg-gray-200 dark:bg-gray-800 rounded-lg flex items-center justify-center text-xs text-gray-500 font-bold">
          [القسم الترحيبي Hero Banner]
        </div>
        <div className="grid grid-cols-3 gap-2">
          <div className="h-20 bg-gray-200 dark:bg-gray-800 rounded-lg flex items-center justify-center text-[10px] text-gray-500 font-bold">بطاقة 1</div>
          <div className="h-20 bg-gray-200 dark:bg-gray-800 rounded-lg flex items-center justify-center text-[10px] text-gray-500 font-bold">بطاقة 2</div>
          <div className="h-20 bg-gray-200 dark:bg-gray-800 rounded-lg flex items-center justify-center text-[10px] text-gray-500 font-bold">بطاقة 3</div>
        </div>
      </div>
    </div>
  );
}

// 8. Logo Mockup Tool
function LogoMockupTool() {
  const [text, setText] = useState('شعارك هنا');

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Layers className="w-5 h-5 text-purple-600" />
        <span>معاينة الشعار على البطاقات والواجهات (Mockup Preview)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">اسم أو نص الشعار</label>
        <input
          type="text"
          value={text}
          onChange={(e) => setText(e.target.value)}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        <div className="h-44 bg-gradient-to-br from-slate-900 to-slate-800 text-white rounded-2xl flex items-center justify-center shadow-lg border border-slate-700">
          <span className="text-2xl font-black tracking-wider text-amber-400 font-mono">{text}</span>
        </div>
        <div className="h-44 bg-white text-gray-900 rounded-2xl flex items-center justify-center shadow-lg border border-gray-200">
          <span className="text-2xl font-black tracking-wider text-purple-600 font-mono">{text}</span>
        </div>
      </div>
    </div>
  );
}

// 9. Open Graph Tool
function OgImageTool() {
  const [title, setTitle] = useState('منصتي الرائعة للأدوات الشاملة');
  const [desc, setDesc] = useState('أكثر من 100 أداة متخصصة ومحولات فورية بدون إعلانات مزعجة');

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Tv className="w-5 h-5 text-pink-600" />
        <span>مولد بطاقات Open Graph ومشاركات السوشيال ميديا</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">العنوان الرئيسي</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">الوصف المختصر</label>
          <input
            type="text"
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>

      <div className="aspect-[1200/630] max-w-xl mx-auto rounded-2xl bg-gradient-to-tr from-purple-700 via-indigo-800 to-pink-600 text-white p-8 flex flex-col justify-between shadow-xl">
        <div className="text-xs bg-white/20 px-3 py-1 rounded-full w-fit font-bold">OG Social Preview (1200x630)</div>
        <div>
          <h2 className="text-2xl font-black mb-2">{title}</h2>
          <p className="text-xs text-purple-100 line-clamp-2">{desc}</p>
        </div>
        <div className="text-[10px] text-white/70">yoursite.com</div>
      </div>
    </div>
  );
}

// 10. Social Resizer Tool
function SocialResizerTool() {
  const sizes = [
    { platform: 'Instagram Post', size: '1080 × 1080 px', ratio: '1:1' },
    { platform: 'Instagram Story / Reel', size: '1080 × 1920 px', ratio: '9:16' },
    { platform: 'Twitter / X Header', size: '1500 × 500 px', ratio: '3:1' },
    { platform: 'YouTube Thumbnail', size: '1280 × 720 px', ratio: '16:9' },
    { platform: 'LinkedIn Banner', size: '1584 × 396 px', ratio: '4:1' },
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Crop className="w-5 h-5 text-blue-500" />
        <span>دليل ومقاسات الصور لمنصات التواصل الاجتماعي</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {sizes.map((s, idx) => (
          <div key={idx} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
            <h4 className="text-xs font-bold text-gray-900 dark:text-white">{s.platform}</h4>
            <div className="text-sm font-black text-blue-600 font-mono mt-1">{s.size}</div>
            <span className="text-[10px] text-gray-500">النسبة: {s.ratio}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// 11. Aspect Ratio Calculator Tool
function AspectRatioCalculatorTool() {
  const [w1, setW1] = useState(1920);
  const [h1, setH1] = useState(1080);
  const [w2, setW2] = useState(1280);

  const h2 = w1 > 0 ? ((h1 * w2) / w1).toFixed(0) : '0';

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Maximize2 className="w-5 h-5 text-indigo-500" />
        <span>حاسبة أبعاد ودقة الشاشات والنسب (Aspect Ratio Calculator)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">العرض الأصلي (W1)</label>
          <input
            type="number"
            value={w1}
            onChange={(e) => setW1(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">الارتفاع الأصلي (H1)</label>
          <input
            type="number"
            value={h1}
            onChange={(e) => setH1(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">العرض الجديد (W2)</label>
          <input
            type="number"
            value={w2}
            onChange={(e) => setW2(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
      </div>

      <div className="p-4 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 text-center">
        <span className="text-xs font-bold text-indigo-700">الارتفاع المتناسب الجديد (H2)</span>
        <div className="text-3xl font-black text-indigo-600 mt-1 font-mono">{h2} px</div>
      </div>
    </div>
  );
}

// 12. SVG Shape Generator
function SvgShapeGenerator() {
  const [color, setColor] = useState('#8b5cf6');
  const [radius, setRadius] = useState(50);

  const svgCode = `<svg width="100" height="100" viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">
  <circle cx="50" cy="50" r="${radius}" fill="${color}" />
</svg>`;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <FileCode className="w-5 h-5 text-purple-600" />
        <span>مولد أشكال وشفرات SVG المتجهة</span>
      </h3>

      <div className="flex items-center gap-4">
        <input
          type="color"
          value={color}
          onChange={(e) => setColor(e.target.value)}
          className="w-10 h-10 rounded-xl cursor-pointer border"
        />
        <input
          type="range"
          min="10"
          max="50"
          value={radius}
          onChange={(e) => setRadius(Number(e.target.value))}
          className="flex-1 accent-purple-600"
        />
      </div>

      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border flex items-center justify-between">
        <pre className="text-xs font-mono text-purple-600">{svgCode}</pre>
        <button
          onClick={() => {
            navigator.clipboard.writeText(svgCode);
            confetti({ particleCount: 20 });
          }}
          className="px-3 py-1.5 bg-purple-600 text-white rounded-lg text-xs font-bold"
        >
          نسخ SVG
        </button>
      </div>
    </div>
  );
}

// 13. App Icon Tool
function AppIconTool() {
  const sizes = [
    { platform: 'iOS iPhone Icon', size: '180 × 180 px (3x)' },
    { platform: 'iOS iPad Icon', size: '167 × 167 px' },
    { platform: 'Android xxxhdpi', size: '192 × 192 px' },
    { platform: 'Google Play Store', size: '512 × 512 px' },
    { platform: 'Favicon Web', size: '32 × 32 px' },
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Smartphone className="w-5 h-5 text-emerald-500" />
        <span>مولد ودليل مقاسات أيقونات التطبيقات (App Icon Resizer)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {sizes.map((s, idx) => (
          <div key={idx} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
            <h4 className="text-xs font-bold text-gray-900 dark:text-white">{s.platform}</h4>
            <div className="text-sm font-black text-emerald-600 font-mono mt-1">{s.size}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
