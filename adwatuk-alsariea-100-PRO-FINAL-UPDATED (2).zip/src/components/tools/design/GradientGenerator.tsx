import React, { useState } from 'react';
import { Copy, RefreshCw, Palette } from 'lucide-react';

export function GradientGenerator() {
  const [color1, setColor1] = useState('#4f46e5');
  const [color2, setColor2] = useState('#ec4899');
  const [angle, setAngle] = useState(135);

  const generateRandomColor = () => {
    return '#' + Math.floor(Math.random()*16777215).toString(16).padStart(6, '0');
  };

  const randomize = () => {
    setColor1(generateRandomColor());
    setColor2(generateRandomColor());
    setAngle(Math.floor(Math.random() * 360));
  };

  const gradientStyle = {
    background: `linear-gradient(${angle}deg, ${color1}, ${color2})`
  };

  const cssCode = `background: linear-gradient(${angle}deg, ${color1}, ${color2});`;

  const copyCss = () => {
    navigator.clipboard.writeText(cssCode);
  };

  return (
    <div className="space-y-6">
      <div 
        className="w-full h-64 sm:h-80 rounded-3xl shadow-lg relative overflow-hidden transition-all duration-300"
        style={gradientStyle}
      >
        <button 
          onClick={randomize}
          className="absolute top-4 right-4 p-3 bg-white/20 hover:bg-white/30 backdrop-blur-md rounded-full text-white transition"
          title="عشوائي"
        >
          <RefreshCw className="w-5 h-5" />
        </button>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        <div className="space-y-2">
          <label className="text-sm font-bold text-gray-700 dark:text-gray-300">اللون الأول</label>
          <div className="flex gap-2">
            <input
              type="color"
              value={color1}
              onChange={(e) => setColor1(e.target.value)}
              className="w-12 h-12 rounded-xl cursor-pointer border-0 p-0"
            />
            <input
              type="text"
              value={color1}
              onChange={(e) => setColor1(e.target.value)}
              className="flex-1 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-3 font-mono text-center outline-none"
              dir="ltr"
            />
          </div>
        </div>
        
        <div className="space-y-2">
          <label className="text-sm font-bold text-gray-700 dark:text-gray-300">اللون الثاني</label>
          <div className="flex gap-2">
            <input
              type="color"
              value={color2}
              onChange={(e) => setColor2(e.target.value)}
              className="w-12 h-12 rounded-xl cursor-pointer border-0 p-0"
            />
            <input
              type="text"
              value={color2}
              onChange={(e) => setColor2(e.target.value)}
              className="flex-1 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl px-3 font-mono text-center outline-none"
              dir="ltr"
            />
          </div>
        </div>

        <div className="space-y-2">
          <label className="text-sm font-bold text-gray-700 dark:text-gray-300 flex justify-between">
            <span>الزاوية (Angle)</span>
            <span dir="ltr">{angle}°</span>
          </label>
          <input
            type="range"
            min="0"
            max="360"
            value={angle}
            onChange={(e) => setAngle(Number(e.target.value))}
            className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer mt-4"
          />
        </div>
      </div>

      <div className="bg-gray-900 rounded-2xl p-4 flex items-center justify-between gap-4 border border-gray-800">
        <code className="text-emerald-400 font-mono text-sm sm:text-base flex-1 overflow-x-auto whitespace-nowrap scrollbar-hide" dir="ltr">
          {cssCode}
        </code>
        <button
          onClick={copyCss}
          className="p-3 bg-gray-800 hover:bg-gray-700 text-gray-300 rounded-xl transition shrink-0 flex items-center gap-2"
        >
          <Copy className="w-4 h-4" />
          <span className="hidden sm:inline text-sm font-bold">نسخ الكود</span>
        </button>
      </div>
    </div>
  );
}
