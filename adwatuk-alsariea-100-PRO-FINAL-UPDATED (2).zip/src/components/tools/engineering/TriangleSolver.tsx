import React, { useState } from 'react';
import { Triangle, Calculator, AlertCircle } from 'lucide-react';

export function TriangleSolver() {
  const [a, setA] = useState('');
  const [b, setB] = useState('');
  const [c, setC] = useState('');

  const solveTriangle = () => {
    const sA = parseFloat(a);
    const sB = parseFloat(b);
    const sC = parseFloat(c);

    if (isNaN(sA) || isNaN(sB) || isNaN(sC) || sA <= 0 || sB <= 0 || sC <= 0) {
      return null;
    }

    // Check triangle inequality
    if (sA + sB <= sC || sA + sC <= sB || sB + sC <= sA) {
      return { error: 'هذه الأطوال لا يمكن أن تشكل مثلثاً صحيحاً (مخالفة لمتراجحة المثلث).' };
    }

    // Heron's formula for area
    const s = (sA + sB + sC) / 2;
    const area = Math.sqrt(s * (s - sA) * (s - sB) * (s - sC));

    // Angles using Law of Cosines (in radians then to degrees)
    const angleA = Math.acos((sB * sB + sC * sC - sA * sA) / (2 * sB * sC)) * (180 / Math.PI);
    const angleB = Math.acos((sA * sA + sC * sC - sB * sB) / (2 * sA * sC)) * (180 / Math.PI);
    const angleC = Math.acos((sA * sA + sB * sB - sC * sC) / (2 * sA * sB)) * (180 / Math.PI);

    let type = '';
    if (Math.abs(angleA - 90) < 0.1 || Math.abs(angleB - 90) < 0.1 || Math.abs(angleC - 90) < 0.1) {
      type = 'مثلث قائم الزاوية';
    } else if (angleA > 90 || angleB > 90 || angleC > 90) {
      type = 'مثلث منفرج الزاوية';
    } else {
      type = 'مثلث حاد الزوايا';
    }

    if (Math.abs(sA - sB) < 0.01 && Math.abs(sB - sC) < 0.01) {
      type += ' (متطابق الأضلاع)';
    } else if (Math.abs(sA - sB) < 0.01 || Math.abs(sB - sC) < 0.01 || Math.abs(sA - sC) < 0.01) {
      type += ' (متطابق الضلعين)';
    } else {
      type += ' (مختلف الأضلاع)';
    }

    return {
      perimeter: sA + sB + sC,
      area,
      angleA,
      angleB,
      angleC,
      type
    };
  };

  const result = solveTriangle();

  return (
    <div className="space-y-6">
      <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-2xl flex items-start gap-3 border border-emerald-100 dark:border-emerald-800/30">
        <Triangle className="w-5 h-5 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
        <p className="text-sm text-emerald-800 dark:text-emerald-200 leading-relaxed">
          حاسبة المثلثات الهندسية: أدخل أطوال أضلاع المثلث الثلاثة ليتم حساب المساحة (باستخدام صيغة هيرون)، والمحيط، والزوايا الداخلية بدقة، وتحديد نوع المثلث.
        </p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">الضلع الأول (A)</label>
          <input
            type="number"
            value={a}
            onChange={(e) => setA(e.target.value)}
            className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-mono"
            dir="ltr"
            placeholder="مثال: 3"
          />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">الضلع الثاني (B)</label>
          <input
            type="number"
            value={b}
            onChange={(e) => setB(e.target.value)}
            className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-mono"
            dir="ltr"
            placeholder="مثال: 4"
          />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">الضلع الثالث (C)</label>
          <input
            type="number"
            value={c}
            onChange={(e) => setC(e.target.value)}
            className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none font-mono"
            dir="ltr"
            placeholder="مثال: 5"
          />
        </div>
      </div>

      {result && 'error' in result ? (
        <div className="flex items-center gap-2 text-rose-600 bg-rose-50 dark:bg-rose-900/20 p-4 rounded-xl border border-rose-100 dark:border-rose-800/30">
          <AlertCircle className="w-5 h-5 shrink-0" />
          <span className="text-sm font-medium">{result.error}</span>
        </div>
      ) : result ? (
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl p-6 shadow-xs">
          <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-6 flex items-center gap-2">
            <Calculator className="w-5 h-5 text-emerald-500" />
            نتائج التحليل الرياضي
          </h3>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
            <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-xl border border-gray-100 dark:border-gray-800">
              <span className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1">المساحة</span>
              <span className="text-xl font-black text-gray-900 dark:text-white font-mono" dir="ltr">
                {result.area.toFixed(2)}
              </span>
            </div>
            <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-xl border border-gray-100 dark:border-gray-800">
              <span className="block text-xs font-bold text-gray-500 dark:text-gray-400 mb-1">المحيط</span>
              <span className="text-xl font-black text-gray-900 dark:text-white font-mono" dir="ltr">
                {result.perimeter.toFixed(2)}
              </span>
            </div>
            <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-xl border border-emerald-100 dark:border-emerald-800/30 lg:col-span-1 md:col-span-2">
              <span className="block text-xs font-bold text-emerald-600 dark:text-emerald-400 mb-1">تصنيف المثلث</span>
              <span className="text-base font-bold text-emerald-700 dark:text-emerald-300">
                {result.type}
              </span>
            </div>
          </div>

          <div className="space-y-3">
            <h4 className="text-sm font-bold text-gray-700 dark:text-gray-300 border-b border-gray-100 dark:border-gray-800 pb-2">الزوايا الداخلية (بالدرجات):</h4>
            <div className="grid grid-cols-3 gap-3">
              <div className="text-center p-3 rounded-lg bg-gray-50 dark:bg-gray-900">
                <span className="block text-xs text-gray-500 mb-1">الزاوية (a) المقابلة A</span>
                <span className="font-mono font-bold text-gray-900 dark:text-gray-100" dir="ltr">{result.angleA.toFixed(2)}°</span>
              </div>
              <div className="text-center p-3 rounded-lg bg-gray-50 dark:bg-gray-900">
                <span className="block text-xs text-gray-500 mb-1">الزاوية (b) المقابلة B</span>
                <span className="font-mono font-bold text-gray-900 dark:text-gray-100" dir="ltr">{result.angleB.toFixed(2)}°</span>
              </div>
              <div className="text-center p-3 rounded-lg bg-gray-50 dark:bg-gray-900">
                <span className="block text-xs text-gray-500 mb-1">الزاوية (c) المقابلة C</span>
                <span className="font-mono font-bold text-gray-900 dark:text-gray-100" dir="ltr">{result.angleC.toFixed(2)}°</span>
              </div>
            </div>
          </div>

        </div>
      ) : (
        <div className="text-center py-10 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-dashed border-gray-300 dark:border-gray-700">
          <p className="text-sm text-gray-500 dark:text-gray-400 font-bold">أدخل الأطوال الثلاثة للأضلاع لرؤية النتيجة هنا</p>
        </div>
      )}
    </div>
  );
}
