import React, { useState } from 'react';
import {
  Compass,
  Circle,
  Square,
  Triangle,
  Layers,
  Percent,
  Divide,
  BarChart2,
  RotateCw,
  Gauge,
  Zap,
  TrendingUp,
  Scale,
  Hash,
} from 'lucide-react';

interface EngineeringMathSuiteProps {
  defaultTab?: string;
}

export function EngineeringMathSuite({ defaultTab = 'area' }: EngineeringMathSuiteProps) {
  const [activeTab, setActiveTab] = useState(defaultTab);

  const tabs = [
    { id: 'area', label: 'حاسبة المساحة', icon: Square },
    { id: 'volume', label: 'حاسبة الحجم', icon: Layers },
    { id: 'perimeter', label: 'حاسبة المحيط', icon: Circle },
    { id: 'triangle', label: 'المثلث وفيثاغورس', icon: Triangle },
    { id: 'circle', label: 'حاسبة الدائرة', icon: Circle },
    { id: 'rectangle', label: 'حاسبة المستطيل', icon: Square },
    { id: 'cylinder', label: 'حاسبة الأسطوانة', icon: Layers },
    { id: 'sphere', label: 'حاسبة الكرة', icon: Circle },
    { id: 'cone', label: 'حاسبة المخروط', icon: Triangle },
    { id: 'ratio', label: 'النسب والتناسب', icon: TrendingUp },
    { id: 'percentage', label: 'النسبة المئوية', icon: Percent },
    { id: 'fractions', label: 'حاسبة الكسور', icon: Divide },
    { id: 'statistics', label: 'المتوسط والوسيط والمنوال', icon: BarChart2 },
    { id: 'angles', label: 'محول الزوايا (Deg/Rad)', icon: RotateCw },
    { id: 'units', label: 'محول الوحدات الهندسية', icon: Scale },
    { id: 'speed-dist-time', label: 'السرعة والمسافة والزمن', icon: Gauge },
  ];

  return (
    <div className="space-y-6" id="engineering-math-suite">
      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-gray-200 dark:border-gray-800">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-5 sm:p-6 shadow-xs">
        {activeTab === 'area' && <AreaCalculator />}
        {activeTab === 'volume' && <VolumeCalculator />}
        {activeTab === 'perimeter' && <PerimeterCalculator />}
        {activeTab === 'triangle' && <TrianglePythagorasSolver />}
        {activeTab === 'circle' && <CircleSolver />}
        {activeTab === 'rectangle' && <RectangleSolver />}
        {activeTab === 'cylinder' && <CylinderSolver />}
        {activeTab === 'sphere' && <SphereSolver />}
        {activeTab === 'cone' && <ConeSolver />}
        {activeTab === 'ratio' && <RatioProportionCalculator />}
        {activeTab === 'percentage' && <PercentageMathCalculator />}
        {activeTab === 'fractions' && <FractionsCalculator />}
        {activeTab === 'statistics' && <StatisticsCalculator />}
        {activeTab === 'angles' && <AngleConverterTool />}
        {activeTab === 'units' && <EngineeringUnitsTool />}
        {activeTab === 'speed-dist-time' && <SpeedDistanceTimeCalculator />}
      </div>
    </div>
  );
}

// 1. Area Calculator
function AreaCalculator() {
  const [shape, setShape] = useState<'circle' | 'rect' | 'triangle' | 'trapezoid'>('rect');
  const [a, setA] = useState(10);
  const [b, setB] = useState(5);
  const [h, setH] = useState(4);

  let area = 0;
  if (shape === 'rect') area = a * b;
  else if (shape === 'circle') area = Math.PI * Math.pow(a, 2);
  else if (shape === 'triangle') area = 0.5 * a * h;
  else if (shape === 'trapezoid') area = 0.5 * (a + b) * h;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Square className="w-5 h-5 text-blue-600" />
        <span>حاسبة المساحة للأشكال الهندسية</span>
      </h3>

      <div className="flex gap-2">
        {[
          { id: 'rect', label: 'مستطيل' },
          { id: 'circle', label: 'دائرة' },
          { id: 'triangle', label: 'مثلث' },
          { id: 'trapezoid', label: 'شبه منحرف' },
        ].map((s) => (
          <button
            key={s.id}
            onClick={() => setShape(s.id as any)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
              shape === s.id ? 'bg-blue-600 text-white' : 'bg-gray-50 dark:bg-gray-800'
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        {shape === 'circle' ? (
          <div>
            <label className="block text-xs font-bold mb-1">نصف القطر (r)</label>
            <input
              type="number"
              value={a}
              onChange={(e) => setA(Number(e.target.value))}
              className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
            />
          </div>
        ) : (
          <>
            <div>
              <label className="block text-xs font-bold mb-1">{shape === 'triangle' ? 'طول القاعدة' : 'الطول / القاعدة 1'}</label>
              <input
                type="number"
                value={a}
                onChange={(e) => setA(Number(e.target.value))}
                className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
              />
            </div>
            {shape !== 'triangle' && (
              <div>
                <label className="block text-xs font-bold mb-1">{shape === 'trapezoid' ? 'القاعدة 2' : 'العرض'}</label>
                <input
                  type="number"
                  value={b}
                  onChange={(e) => setB(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
                />
              </div>
            )}
            {(shape === 'triangle' || shape === 'trapezoid') && (
              <div>
                <label className="block text-xs font-bold mb-1">الارتفاع (h)</label>
                <input
                  type="number"
                  value={h}
                  onChange={(e) => setH(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
                />
              </div>
            )}
          </>
        )}
      </div>

      <div className="p-4 rounded-xl bg-blue-50 dark:bg-blue-950/40 border border-blue-200 text-center">
        <span className="text-xs font-bold text-blue-700">المساحة الإجمالية</span>
        <div className="text-3xl font-black text-blue-600 mt-1 font-mono">{area.toFixed(2)} وحدة مربعة</div>
      </div>
    </div>
  );
}

// 2. Volume Calculator
function VolumeCalculator() {
  const [shape, setShape] = useState<'cylinder' | 'sphere' | 'cone' | 'cube'>('cylinder');
  const [r, setR] = useState(5);
  const [h, setH] = useState(10);

  let volume = 0;
  if (shape === 'cylinder') volume = Math.PI * Math.pow(r, 2) * h;
  else if (shape === 'sphere') volume = (4 / 3) * Math.PI * Math.pow(r, 3);
  else if (shape === 'cone') volume = (1 / 3) * Math.PI * Math.pow(r, 2) * h;
  else if (shape === 'cube') volume = Math.pow(r, 3);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Layers className="w-5 h-5 text-indigo-600" />
        <span>حاسبة الحجم للمجسمات الهندسية ثلاثية الأبعاد</span>
      </h3>

      <div className="flex gap-2">
        {[
          { id: 'cylinder', label: 'أسطوانة' },
          { id: 'sphere', label: 'كرة' },
          { id: 'cone', label: 'مخروط' },
          { id: 'cube', label: 'مكعب' },
        ].map((s) => (
          <button
            key={s.id}
            onClick={() => setShape(s.id as any)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
              shape === s.id ? 'bg-indigo-600 text-white' : 'bg-gray-50 dark:bg-gray-800'
            }`}
          >
            {s.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">{shape === 'cube' ? 'طول الضلع' : 'نصف القطر (r)'}</label>
          <input
            type="number"
            value={r}
            onChange={(e) => setR(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        {shape !== 'sphere' && shape !== 'cube' && (
          <div>
            <label className="block text-xs font-bold mb-1">الارتفاع (h)</label>
            <input
              type="number"
              value={h}
              onChange={(e) => setH(Number(e.target.value))}
              className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
            />
          </div>
        )}
      </div>

      <div className="p-4 rounded-xl bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 text-center">
        <span className="text-xs font-bold text-indigo-700">الحجم الكلي (Volume)</span>
        <div className="text-3xl font-black text-indigo-600 mt-1 font-mono">{volume.toFixed(2)} وحدة مكعبة</div>
      </div>
    </div>
  );
}

// 3. Perimeter Calculator
function PerimeterCalculator() {
  const [w, setW] = useState(10);
  const [h, setH] = useState(5);
  const perimeter = 2 * (w + h);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Circle className="w-5 h-5 text-teal-600" />
        <span>حاسبة المحيط للأشكال المستوية</span>
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">الطول</label>
          <input
            type="number"
            value={w}
            onChange={(e) => setW(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">العرض</label>
          <input
            type="number"
            value={h}
            onChange={(e) => setH(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>
      <div className="p-4 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 text-center">
        <span className="text-xs font-bold text-teal-700">محيط المستطيل</span>
        <div className="text-3xl font-black text-teal-600 mt-1 font-mono">{perimeter} وحدة</div>
      </div>
    </div>
  );
}

// 4. Triangle & Pythagoras Solver
function TrianglePythagorasSolver() {
  const [a, setA] = useState(3);
  const [b, setB] = useState(4);
  const c = Math.sqrt(Math.pow(a, 2) + Math.pow(b, 2));

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Triangle className="w-5 h-5 text-amber-500" />
        <span>حل المثلث القائم ونظرية فيثاغورس (Pythagorean Theorem)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">الضلع الأول (a)</label>
          <input
            type="number"
            value={a}
            onChange={(e) => setA(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">الضلع الثاني (b)</label>
          <input
            type="number"
            value={b}
            onChange={(e) => setB(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>

      <div className="p-4 rounded-xl bg-amber-50 dark:bg-amber-950/40 border border-amber-200 text-center">
        <span className="text-xs font-bold text-amber-700">طول الوتر (Hypotenuse c)</span>
        <div className="text-3xl font-black text-amber-600 mt-1 font-mono">{c.toFixed(2)}</div>
        <div className="text-xs text-gray-500 mt-1 font-mono">c = √(a² + b²) = √({a}² + {b}²) = {c.toFixed(2)}</div>
      </div>
    </div>
  );
}

// 5. Dedicated Circle Solver
function CircleSolver() {
  const [r, setR] = useState(7);
  const area = Math.PI * Math.pow(r, 2);
  const perimeter = 2 * Math.PI * r;
  const diameter = 2 * r;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Circle className="w-5 h-5 text-rose-500" />
        <span>حاسبة خصائص الدائرة الكاملة</span>
      </h3>
      <div>
        <label className="block text-xs font-bold mb-1">نصف القطر (Radius r)</label>
        <input
          type="number"
          value={r}
          onChange={(e) => setR(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">القطر (Diameter)</span>
          <div className="text-xl font-black mt-1">{diameter}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">المحيط (Circumference)</span>
          <div className="text-xl font-black text-teal-600 mt-1">{perimeter.toFixed(2)}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">المساحة (Area)</span>
          <div className="text-xl font-black text-rose-600 mt-1">{area.toFixed(2)}</div>
        </div>
      </div>
    </div>
  );
}

// 6. Dedicated Rectangle Solver
function RectangleSolver() {
  const [w, setW] = useState(8);
  const [h, setH] = useState(6);
  const area = w * h;
  const perimeter = 2 * (w + h);
  const diagonal = Math.sqrt(w * w + h * h);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Square className="w-5 h-5 text-blue-500" />
        <span>حاسبة المستطيل والقطر والمساحة</span>
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">الطول (Length)</label>
          <input
            type="number"
            value={w}
            onChange={(e) => setW(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">العرض (Width)</label>
          <input
            type="number"
            value={h}
            onChange={(e) => setH(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">المساحة</span>
          <div className="text-xl font-black text-blue-600 mt-1">{area}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">المحيط</span>
          <div className="text-xl font-black text-teal-600 mt-1">{perimeter}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">طول القطر (Diagonal)</span>
          <div className="text-xl font-black text-purple-600 mt-1">{diagonal.toFixed(2)}</div>
        </div>
      </div>
    </div>
  );
}

// 7. Dedicated Cylinder Solver
function CylinderSolver() {
  const [r, setR] = useState(4);
  const [h, setH] = useState(10);
  const vol = Math.PI * r * r * h;
  const lateralArea = 2 * Math.PI * r * h;
  const totalArea = lateralArea + 2 * Math.PI * r * r;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Layers className="w-5 h-5 text-indigo-500" />
        <span>حاسبة الأسطوانة (الحجم والمساحة السطحية)</span>
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">نصف القطر (r)</label>
          <input
            type="number"
            value={r}
            onChange={(e) => setR(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">الارتفاع (h)</label>
          <input
            type="number"
            value={h}
            onChange={(e) => setH(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-center">
        <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-200">
          <span className="text-xs text-indigo-700 font-bold">الحجم (Volume)</span>
          <div className="text-2xl font-black text-indigo-600 mt-1 font-mono">{vol.toFixed(2)}</div>
        </div>
        <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-200">
          <span className="text-xs text-indigo-700 font-bold">المساحة الكلية السطحية</span>
          <div className="text-2xl font-black text-indigo-600 mt-1 font-mono">{totalArea.toFixed(2)}</div>
        </div>
      </div>
    </div>
  );
}

// 8. Sphere Solver
function SphereSolver() {
  const [r, setR] = useState(5);
  const vol = (4 / 3) * Math.PI * Math.pow(r, 3);
  const surfaceArea = 4 * Math.PI * Math.pow(r, 2);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Circle className="w-5 h-5 text-pink-500" />
        <span>حاسبة الكرة (الحجم والمساحة السطحية للكرة)</span>
      </h3>
      <div>
        <label className="block text-xs font-bold mb-1">نصف القطر (r)</label>
        <input
          type="number"
          value={r}
          onChange={(e) => setR(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-center">
        <div className="p-3 bg-pink-50 dark:bg-pink-950/40 rounded-xl border border-pink-200">
          <span className="text-xs text-pink-700 font-bold">حجم الكرة</span>
          <div className="text-2xl font-black text-pink-600 mt-1 font-mono">{vol.toFixed(2)}</div>
        </div>
        <div className="p-3 bg-pink-50 dark:bg-pink-950/40 rounded-xl border border-pink-200">
          <span className="text-xs text-pink-700 font-bold">المساحة السطحية</span>
          <div className="text-2xl font-black text-pink-600 mt-1 font-mono">{surfaceArea.toFixed(2)}</div>
        </div>
      </div>
    </div>
  );
}

// 9. Cone Solver
function ConeSolver() {
  const [r, setR] = useState(3);
  const [h, setH] = useState(7);
  const vol = (1 / 3) * Math.PI * r * r * h;
  const slantHeight = Math.sqrt(r * r + h * h);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Triangle className="w-5 h-5 text-orange-500" />
        <span>حاسبة المخروط (Volume & Slant Height)</span>
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">نصف قطر القاعدة (r)</label>
          <input
            type="number"
            value={r}
            onChange={(e) => setR(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">الارتفاع العمودي (h)</label>
          <input
            type="number"
            value={h}
            onChange={(e) => setH(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-center">
        <div className="p-3 bg-orange-50 dark:bg-orange-950/40 rounded-xl border border-orange-200">
          <span className="text-xs text-orange-700 font-bold">حجم المخروط</span>
          <div className="text-2xl font-black text-orange-600 mt-1 font-mono">{vol.toFixed(2)}</div>
        </div>
        <div className="p-3 bg-orange-50 dark:bg-orange-950/40 rounded-xl border border-orange-200">
          <span className="text-xs text-orange-700 font-bold">الارتفاع الجانبي (Slant Height)</span>
          <div className="text-2xl font-black text-orange-600 mt-1 font-mono">{slantHeight.toFixed(2)}</div>
        </div>
      </div>
    </div>
  );
}

// 10. Ratio & Proportion Calculator
function RatioProportionCalculator() {
  const [a, setA] = useState(2);
  const [b, setB] = useState(4);
  const [c, setC] = useState(10);
  const d = b > 0 ? (b * c) / a : 0;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <TrendingUp className="w-5 h-5 text-emerald-600" />
        <span>حاسبة النسب والتناسب (A : B = C : X)</span>
      </h3>
      <div className="flex items-center gap-2 justify-center py-4 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <input
          type="number"
          value={a}
          onChange={(e) => setA(Number(e.target.value))}
          className="w-16 px-2 py-1.5 text-center text-xs border rounded-lg dark:bg-gray-700 font-bold"
        />
        <span className="font-bold">:</span>
        <input
          type="number"
          value={b}
          onChange={(e) => setB(Number(e.target.value))}
          className="w-16 px-2 py-1.5 text-center text-xs border rounded-lg dark:bg-gray-700 font-bold"
        />
        <span className="font-bold text-base px-2">=</span>
        <input
          type="number"
          value={c}
          onChange={(e) => setC(Number(e.target.value))}
          className="w-16 px-2 py-1.5 text-center text-xs border rounded-lg dark:bg-gray-700 font-bold"
        />
        <span className="font-bold">:</span>
        <div className="w-16 py-1.5 text-center text-xs bg-emerald-600 text-white rounded-lg font-black font-mono">
          {d.toFixed(2)}
        </div>
      </div>
    </div>
  );
}

// 11. Percentage Calculator
function PercentageMathCalculator() {
  const [part, setPart] = useState(25);
  const [total, setTotal] = useState(200);
  const percent = total > 0 ? ((part / total) * 100).toFixed(2) : '0';

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Percent className="w-5 h-5 text-purple-600" />
        <span>حاسبة النسبة المئوية الرياضية</span>
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">القيمة الجزئية</label>
          <input
            type="number"
            value={part}
            onChange={(e) => setPart(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">القيمة الكلية</label>
          <input
            type="number"
            value={total}
            onChange={(e) => setTotal(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>
      <div className="p-4 rounded-xl bg-purple-50 dark:bg-purple-950/40 border border-purple-200 text-center">
        <span className="text-xs font-bold text-purple-700">النسبة المئوية</span>
        <div className="text-3xl font-black text-purple-600 mt-1 font-mono">{percent}%</div>
      </div>
    </div>
  );
}

// 12. Fractions Calculator
function FractionsCalculator() {
  const [n1, setN1] = useState(1);
  const [d1, setD1] = useState(2);
  const [n2, setN2] = useState(1);
  const [d2, setD2] = useState(3);
  const [op, setOp] = useState<'+' | '-' | '*' | '/'>('+');

  let resN = 0;
  let resD = 1;

  if (op === '+') {
    resN = n1 * d2 + n2 * d1;
    resD = d1 * d2;
  } else if (op === '-') {
    resN = n1 * d2 - n2 * d1;
    resD = d1 * d2;
  } else if (op === '*') {
    resN = n1 * n2;
    resD = d1 * d2;
  } else if (op === '/') {
    resN = n1 * d2;
    resD = d1 * n2;
  }

  // simplify
  const gcd = (x: number, y: number): number => (!y ? x : gcd(y, x % y));
  const divisor = Math.abs(gcd(resN, resD)) || 1;
  const simpN = resN / divisor;
  const simpD = resD / divisor;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Divide className="w-5 h-5 text-teal-600" />
        <span>حاسبة جمع وطرح وضرب وقسمة الكسور وتبسيطها</span>
      </h3>

      <div className="flex items-center justify-center gap-4 py-4 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        {/* Fraction 1 */}
        <div className="flex flex-col items-center gap-1">
          <input
            type="number"
            value={n1}
            onChange={(e) => setN1(Number(e.target.value))}
            className="w-12 text-center text-xs p-1 border rounded dark:bg-gray-700 font-bold"
          />
          <div className="w-full h-0.5 bg-gray-400"></div>
          <input
            type="number"
            value={d1}
            onChange={(e) => setD1(Number(e.target.value))}
            className="w-12 text-center text-xs p-1 border rounded dark:bg-gray-700 font-bold"
          />
        </div>

        {/* Operation */}
        <select
          value={op}
          onChange={(e: any) => setOp(e.target.value)}
          className="text-base font-black px-2 py-1 border rounded-lg bg-white dark:bg-gray-700"
        >
          <option value="+">+</option>
          <option value="-">-</option>
          <option value="*">×</option>
          <option value="/">÷</option>
        </select>

        {/* Fraction 2 */}
        <div className="flex flex-col items-center gap-1">
          <input
            type="number"
            value={n2}
            onChange={(e) => setN2(Number(e.target.value))}
            className="w-12 text-center text-xs p-1 border rounded dark:bg-gray-700 font-bold"
          />
          <div className="w-full h-0.5 bg-gray-400"></div>
          <input
            type="number"
            value={d2}
            onChange={(e) => setD2(Number(e.target.value))}
            className="w-12 text-center text-xs p-1 border rounded dark:bg-gray-700 font-bold"
          />
        </div>

        <span className="text-xl font-bold">=</span>

        {/* Result Fraction */}
        <div className="flex flex-col items-center gap-1 px-3 py-1 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 rounded-lg">
          <span className="text-base font-black text-teal-700 dark:text-teal-300 font-mono">{simpN}</span>
          <div className="w-full h-0.5 bg-teal-500"></div>
          <span className="text-base font-black text-teal-700 dark:text-teal-300 font-mono">{simpD}</span>
        </div>
      </div>
    </div>
  );
}

// 13. Statistics Calculator
function StatisticsCalculator() {
  const [dataStr, setDataStr] = useState('10, 20, 30, 40, 50, 20');

  const nums = dataStr
    .split(/[\s,]+/)
    .map(Number)
    .filter((n) => !isNaN(n));

  let mean = 0;
  let median = 0;
  let mode: number[] = [];

  if (nums.length > 0) {
    const sum = nums.reduce((acc, curr) => acc + curr, 0);
    mean = sum / nums.length;

    const sorted = [...nums].sort((a, b) => a - b);
    const mid = Math.floor(sorted.length / 2);
    median = sorted.length % 2 !== 0 ? sorted[mid] : (sorted[mid - 1] + sorted[mid]) / 2;

    const counts: Record<number, number> = {};
    nums.forEach((n) => (counts[n] = (counts[n] || 0) + 1));
    const maxFreq = Math.max(...Object.values(counts));
    mode = Object.keys(counts)
      .map(Number)
      .filter((k) => counts[k] === maxFreq && maxFreq > 1);
  }

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <BarChart2 className="w-5 h-5 text-indigo-500" />
        <span>المتوسط الحسابي، الوسيط، والمنوال (Mean, Median, Mode)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">الأرقام (مفصولة بفواصل أو مسافات)</label>
        <input
          type="text"
          value={dataStr}
          onChange={(e) => setDataStr(e.target.value)}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">المتوسط (Mean)</span>
          <div className="text-xl font-black text-indigo-600 mt-1 font-mono">{mean.toFixed(2)}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">الوسيط (Median)</span>
          <div className="text-xl font-black text-teal-600 mt-1 font-mono">{median}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">المنوال (Mode)</span>
          <div className="text-xl font-black text-amber-600 mt-1 font-mono">
            {mode.length > 0 ? mode.join(', ') : 'لا يوجد'}
          </div>
        </div>
      </div>
    </div>
  );
}

// 14. Angle Converter
function AngleConverterTool() {
  const [val, setVal] = useState(180);
  const [unit, setUnit] = useState<'deg' | 'rad' | 'grad'>('deg');

  let deg = 0;
  let rad = 0;
  let grad = 0;

  if (unit === 'deg') {
    deg = val;
    rad = (val * Math.PI) / 180;
    grad = (val * 200) / 180;
  } else if (unit === 'rad') {
    deg = (val * 180) / Math.PI;
    rad = val;
    grad = (val * 200) / Math.PI;
  } else {
    deg = (val * 180) / 200;
    rad = (val * Math.PI) / 200;
    grad = val;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <RotateCw className="w-5 h-5 text-blue-500" />
        <span>محول الزوايا الهندسية (درجات، راديان، جراديان)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">الوحدة المدخلة</label>
          <select
            value={unit}
            onChange={(e: any) => setUnit(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          >
            <option value="deg">درجات (° Degrees)</option>
            <option value="rad">راديان (Radians)</option>
            <option value="grad">جراديان (Gradians)</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">القيمة</label>
          <input
            type="number"
            value={val}
            onChange={(e) => setVal(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">درجات (° Degrees)</span>
          <div className="text-xl font-black text-blue-600 mt-1 font-mono">{deg.toFixed(2)}°</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">راديان (Radians)</span>
          <div className="text-xl font-black text-teal-600 mt-1 font-mono">{rad.toFixed(4)} rad</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">جراديان (Grad)</span>
          <div className="text-xl font-black text-purple-600 mt-1 font-mono">{grad.toFixed(2)} gon</div>
        </div>
      </div>
    </div>
  );
}

// 15. Engineering Units Tool
function EngineeringUnitsTool() {
  const [val, setVal] = useState(1);
  const [type, setType] = useState<'pressure' | 'power' | 'energy'>('pressure');

  let result = '';
  if (type === 'pressure') {
    result = `${val} Bar = ${(val * 100).toFixed(2)} kPa = ${(val * 14.5038).toFixed(2)} PSI = ${(val * 0.986923).toFixed(2)} atm`;
  } else if (type === 'power') {
    result = `${val} kW = ${(val * 1.34102).toFixed(2)} حصان (HP) = ${(val * 1000).toFixed(0)} Watt`;
  } else if (type === 'energy') {
    result = `${val} kWh = ${(val * 3600000).toFixed(0)} Joules = ${(val * 860.421).toFixed(1)} kcal`;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Scale className="w-5 h-5 text-teal-600" />
        <span>محول الوحدات الهندسية والصناعية المتقدمة</span>
      </h3>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">نوع المقياس الهندسي</label>
          <select
            value={type}
            onChange={(e: any) => setType(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          >
            <option value="pressure">الضغط (Bar ↔ PSI ↔ kPa ↔ atm)</option>
            <option value="power">القدرة (Kilowatts ↔ Horsepower ↔ Watts)</option>
            <option value="energy">الطاقة (kWh ↔ Joules ↔ Calories)</option>
          </select>
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">القيمة</label>
          <input
            type="number"
            value={val}
            onChange={(e) => setVal(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>
      <div className="p-4 rounded-xl bg-teal-50 dark:bg-teal-950/40 border border-teal-200 text-center">
        <span className="text-xs font-bold text-teal-700">التحويلات المكافئة</span>
        <div className="text-base font-black text-teal-800 dark:text-teal-200 mt-1 font-mono">{result}</div>
      </div>
    </div>
  );
}

// 16. Speed, Distance, Time Calculator
function SpeedDistanceTimeCalculator() {
  const [mode, setMode] = useState<'speed' | 'dist' | 'time'>('speed');
  const [speed, setSpeed] = useState(100);
  const [dist, setDist] = useState(250);
  const [time, setTime] = useState(2.5);

  let result = '';
  if (mode === 'speed') {
    const s = time > 0 ? (dist / time).toFixed(1) : '0';
    result = `السرعة = ${s} كم / ساعة`;
  } else if (mode === 'dist') {
    const d = (speed * time).toFixed(1);
    result = `المسافة = ${d} كم`;
  } else {
    const t = speed > 0 ? (dist / speed).toFixed(2) : '0';
    result = `الزمن = ${t} ساعة (${(Number(t) * 60).toFixed(0)} دقيقة)`;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Gauge className="w-5 h-5 text-rose-500" />
        <span>حاسبة السرعة والمسافة والزمن (Speed, Distance, Time)</span>
      </h3>

      <div className="flex gap-2">
        {[
          { id: 'speed', label: 'حساب السرعة' },
          { id: 'dist', label: 'حساب المسافة' },
          { id: 'time', label: 'حساب الزمن' },
        ].map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id as any)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
              mode === m.id ? 'bg-rose-600 text-white' : 'bg-gray-50 dark:bg-gray-800'
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        {mode !== 'speed' && (
          <div>
            <label className="block text-xs font-bold mb-1">السرعة (كم/س)</label>
            <input
              type="number"
              value={speed}
              onChange={(e) => setSpeed(Number(e.target.value))}
              className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
            />
          </div>
        )}
        {mode !== 'dist' && (
          <div>
            <label className="block text-xs font-bold mb-1">المسافة (كم)</label>
            <input
              type="number"
              value={dist}
              onChange={(e) => setDist(Number(e.target.value))}
              className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
            />
          </div>
        )}
        {mode !== 'time' && (
          <div>
            <label className="block text-xs font-bold mb-1">الزمن (بالساعات)</label>
            <input
              type="number"
              value={time}
              onChange={(e) => setTime(Number(e.target.value))}
              className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
            />
          </div>
        )}
      </div>

      <div className="p-4 rounded-xl bg-rose-50 dark:bg-rose-950/40 border border-rose-200 text-center">
        <div className="text-2xl font-black text-rose-600 font-mono">{result}</div>
      </div>
    </div>
  );
}
