import React, { useState } from 'react';
import {
  Code,
  Binary,
  Palette,
  FileJson,
  Link,
  FileCode,
  Sparkles,
  Copy,
  Check,
  RefreshCw,
  Eye,
  Type
} from 'lucide-react';
import confetti from 'canvas-confetti';

export type DevConvertMode =
  | 'base-converter'
  | 'color-converter'
  | 'json-formatter'
  | 'url-encoder'
  | 'base64-text'
  | 'html-entities'
  | 'unicode-converter';

export function DevConverterSuite({ defaultMode }: { defaultMode?: DevConvertMode }) {
  const [currentMode, setCurrentMode] = useState<DevConvertMode>(defaultMode || 'base-converter');

  // 1. Base Converter
  const [decVal, setDecVal] = useState('255');
  const [binVal, setBinVal] = useState('11111111');
  const [hexVal, setHexVal] = useState('FF');
  const [octVal, setOctVal] = useState('377');

  const updateBases = (val: string, base: 'dec' | 'bin' | 'hex' | 'oct') => {
    let num = 0;
    try {
      if (base === 'dec') {
        setDecVal(val);
        num = parseInt(val, 10);
      } else if (base === 'bin') {
        setBinVal(val);
        num = parseInt(val, 2);
      } else if (base === 'hex') {
        setHexVal(val);
        num = parseInt(val, 16);
      } else if (base === 'oct') {
        setOctVal(val);
        num = parseInt(val, 8);
      }

      if (!isNaN(num)) {
        if (base !== 'dec') setDecVal(num.toString(10));
        if (base !== 'bin') setBinVal(num.toString(2));
        if (base !== 'hex') setHexVal(num.toString(16).toUpperCase());
        if (base !== 'oct') setOctVal(num.toString(8));
      }
    } catch {
      // ignore
    }
  };

  // 2. Color Converter
  const [hexColor, setHexColor] = useState('#059669');
  const [rgbColor, setRgbColor] = useState('rgb(5, 150, 105)');
  const [hslColor, setHslColor] = useState('hsl(161, 94%, 30%)');

  const handleColorChange = (hex: string) => {
    setHexColor(hex);
    // Simple RGB conversion
    const r = parseInt(hex.slice(1, 3), 16) || 0;
    const g = parseInt(hex.slice(3, 5), 16) || 0;
    const b = parseInt(hex.slice(5, 7), 16) || 0;
    setRgbColor(`rgb(${r}, ${g}, ${b})`);

    // RGB to HSL
    const rNorm = r / 255, gNorm = g / 255, bNorm = b / 255;
    const max = Math.max(rNorm, gNorm, bNorm), min = Math.min(rNorm, gNorm, bNorm);
    let h = 0, s = 0, l = (max + min) / 2;
    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case rNorm: h = (gNorm - bNorm) / d + (gNorm < bNorm ? 6 : 0); break;
        case gNorm: h = (bNorm - rNorm) / d + 2; break;
        case bNorm: h = (rNorm - gNorm) / d + 4; break;
      }
      h /= 6;
    }
    setHslColor(`hsl(${Math.round(h * 360)}, ${Math.round(s * 100)}%, ${Math.round(l * 100)}%)`);
  };

  // 3. String tools input & output
  const [textInput, setTextInput] = useState('');
  const [textOutput, setTextOutput] = useState('');
  const [copied, setCopied] = useState(false);

  const handleProcessText = (input: string, mode: DevConvertMode) => {
    setTextInput(input);
    if (!input) {
      setTextOutput('');
      return;
    }

    try {
      if (mode === 'url-encoder') {
        setTextOutput(encodeURIComponent(input));
      } else if (mode === 'base64-text') {
        setTextOutput(btoa(unescape(encodeURIComponent(input))));
      } else if (mode === 'html-entities') {
        const entities = input.replace(/[\u00A0-\u9999<>\&]/g, (i) => `&#${i.charCodeAt(0)};`);
        setTextOutput(entities);
      } else if (mode === 'unicode-converter') {
        const unicode = input.split('').map(c => `\\u${c.charCodeAt(0).toString(16).padStart(4, '0')}`).join('');
        setTextOutput(unicode);
      } else if (mode === 'json-formatter') {
        const parsed = JSON.parse(input);
        setTextOutput(JSON.stringify(parsed, null, 2));
      }
    } catch (err: any) {
      setTextOutput(`خطأ: ${err.message}`);
    }
  };

  const copyText = (val: string) => {
    navigator.clipboard.writeText(val);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Modes Grid */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-4 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Code className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-heading font-extrabold text-sm sm:text-base text-gray-900 dark:text-white">
              محولات تقنية للمطورين والمبرمجين
            </h3>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 lg:grid-cols-7 gap-2">
          {[
            { id: 'base-converter', title: 'أنظمة العد (Bin/Hex/Dec)', desc: 'تحويل بين العشري والثنائي والسداسي عشري' },
            { id: 'color-converter', title: 'محول الألوان (RGB/HEX/HSL)', desc: 'تحويل أكواد الألوان البرمجية' },
            { id: 'json-formatter', title: 'تنسيق JSON', desc: 'تدقيق وتنسيق وضغط كود JSON' },
            { id: 'url-encoder', title: 'URL Encode/Decode', desc: 'ترميز وفك روابط URL والـ Query' },
            { id: 'base64-text', title: 'Base64 Encode/Decode', desc: 'تشفير وفك تشفير النصوص بـ Base64' },
            { id: 'html-entities', title: 'HTML Entities', desc: 'تحويل الرموز لرموز كيانات HTML' },
            { id: 'unicode-converter', title: 'Unicode \\uXXXX', desc: 'تحويل النصوص لكود اليونيكود البرمجي' },
          ].map((m) => {
            const isSelected = m.id === currentMode;
            return (
              <button
                key={m.id}
                onClick={() => {
                  setCurrentMode(m.id as any);
                  handleProcessText(textInput, m.id as any);
                }}
                className={`p-3 rounded-2xl border text-right transition-all flex flex-col justify-between gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-900/10'
                    : 'bg-gray-50/50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-emerald-500/50'
                }`}
              >
                <span className="font-heading font-bold text-xs">
                  {m.title}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Workspace */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
        
        {/* 1. Base Converter */}
        {currentMode === 'base-converter' && (
          <div className="space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                  النظام العشري (Decimal):
                </label>
                <input
                  type="number"
                  value={decVal}
                  onChange={(e) => updateBases(e.target.value, 'dec')}
                  className="w-full px-4 py-2.5 font-mono text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                  النظام الثنائي (Binary):
                </label>
                <input
                  type="text"
                  value={binVal}
                  onChange={(e) => updateBases(e.target.value, 'bin')}
                  className="w-full px-4 py-2.5 font-mono text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                  النظام السداسي عشري (Hexadecimal):
                </label>
                <input
                  type="text"
                  value={hexVal}
                  onChange={(e) => updateBases(e.target.value, 'hex')}
                  className="w-full px-4 py-2.5 font-mono text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                  النظام الثماني (Octal):
                </label>
                <input
                  type="text"
                  value={octVal}
                  onChange={(e) => updateBases(e.target.value, 'oct')}
                  className="w-full px-4 py-2.5 font-mono text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* 2. Color Converter */}
        {currentMode === 'color-converter' && (
          <div className="space-y-5">
            <div className="flex items-center gap-4">
              <input
                type="color"
                value={hexColor}
                onChange={(e) => handleColorChange(e.target.value)}
                className="w-16 h-16 rounded-2xl cursor-pointer border-0 bg-transparent"
              />
              <div>
                <span className="text-xs text-gray-400 font-bold block">اللون المحدد:</span>
                <span className="font-heading font-extrabold text-lg text-gray-900 dark:text-white">{hexColor.toUpperCase()}</span>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
                <span className="text-xs text-gray-400 block mb-1">HEX:</span>
                <span className="font-mono font-bold text-sm text-gray-900 dark:text-white">{hexColor.toUpperCase()}</span>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
                <span className="text-xs text-gray-400 block mb-1">RGB:</span>
                <span className="font-mono font-bold text-sm text-gray-900 dark:text-white">{rgbColor}</span>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
                <span className="text-xs text-gray-400 block mb-1">HSL:</span>
                <span className="font-mono font-bold text-sm text-gray-900 dark:text-white">{hslColor}</span>
              </div>
            </div>
          </div>
        )}

        {/* Text Based Tools */}
        {currentMode !== 'base-converter' && currentMode !== 'color-converter' && (
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="space-y-2">
              <label className="font-heading font-extrabold text-xs text-gray-700 dark:text-gray-300">
                النص المدخل:
              </label>
              <textarea
                value={textInput}
                onChange={(e) => handleProcessText(e.target.value, currentMode)}
                rows={8}
                placeholder="اكتب أو الصق النص هنا..."
                className="w-full p-4 font-mono text-xs bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl outline-none"
              />
            </div>

            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <label className="font-heading font-extrabold text-xs text-gray-700 dark:text-gray-300">
                  النتيجة المحولة:
                </label>
                <button
                  onClick={() => copyText(textOutput)}
                  className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'تم النسخ' : 'نسخ الكود'}
                </button>
              </div>
              <textarea
                readOnly
                value={textOutput || 'ستظهر النتيجة هنا...'}
                rows={8}
                className="w-full p-4 font-mono text-xs bg-emerald-50/20 dark:bg-gray-800/80 border border-emerald-200/50 dark:border-gray-700 rounded-2xl outline-none"
              />
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
