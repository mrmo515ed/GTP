import React, { useState } from 'react';
import {
  Type,
  Binary,
  Hash,
  Scale,
  Thermometer,
  Gauge,
  Clock,
  HardDrive,
  Zap,
  Radio,
  FileSpreadsheet,
  Copy,
  Check,
  RotateCw,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  defaultTab?: string;
}

export function MegaConvertersSuite({ defaultTab = 'text-cases' }: Props) {
  const [activeTab, setActiveTab] = useState(defaultTab);

  const tabs = [
    { id: 'text-cases', label: 'حالات وصيغ النصوص (Cases)', icon: Type },
    { id: 'text-binary', label: 'نص ↔ ثنائي (Binary)', icon: Binary },
    { id: 'text-ascii', label: 'نص ↔ كود ASCII', icon: Hash },
    { id: 'num-bases', label: 'محول قواعد الأرقام (Dec/Bin/Hex/Oct)', icon: Hash },
    { id: 'roman-numerals', label: 'الأرقام الرومانية (Roman)', icon: Hash },
    { id: 'arabic-tafqeet', label: 'تفقيط الأرقام لكلمات عربية', icon: Type },
    { id: 'length-converter', label: 'محول الأطوال والمسافات', icon: Scale },
    { id: 'weight-converter', label: 'محول الأوزان والكتل', icon: Scale },
    { id: 'temperature-converter', label: 'محول درجات الحرارة', icon: Thermometer },
    { id: 'area-converter', label: 'محول المساحات', icon: Scale },
    { id: 'volume-converter', label: 'محول الأحجام والسوائل', icon: Scale },
    { id: 'speed-converter', label: 'محول السرعات', icon: Gauge },
    { id: 'time-converter', label: 'محول وحدات الزمن والوقت', icon: Clock },
    { id: 'data-storage', label: 'محول سعة التخزين (KB/MB/GB/TB)', icon: HardDrive },
    { id: 'energy-power', label: 'محول الطاقة والقدرة والتردد', icon: Zap },
  ];

  return (
    <div className="space-y-6" id="mega-converters-suite">
      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-gray-200 dark:border-gray-800">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-5 sm:p-6 shadow-xs">
        {activeTab === 'text-cases' && <TextCasesConverterTool />}
        {activeTab === 'text-binary' && <TextBinaryConverterTool />}
        {activeTab === 'text-ascii' && <TextAsciiConverterTool />}
        {activeTab === 'num-bases' && <NumberBasesConverterTool />}
        {activeTab === 'roman-numerals' && <RomanNumeralsConverterTool />}
        {activeTab === 'arabic-tafqeet' && <ArabicTafqeetTool />}
        {activeTab === 'length-converter' && <LengthConverterTool />}
        {activeTab === 'weight-converter' && <WeightConverterTool />}
        {activeTab === 'temperature-converter' && <TemperatureConverterTool />}
        {activeTab === 'area-converter' && <AreaConverterTool />}
        {activeTab === 'volume-converter' && <VolumeConverterTool />}
        {activeTab === 'speed-converter' && <SpeedConverterTool />}
        {activeTab === 'time-converter' && <TimeConverterTool />}
        {activeTab === 'data-storage' && <DataStorageConverterTool />}
        {activeTab === 'energy-power' && <EnergyPowerConverterTool />}
      </div>
    </div>
  );
}

// 1. Text Cases Converter Tool
function TextCasesConverterTool() {
  const [text, setText] = useState('hello world awesome tools');

  const upper = text.toUpperCase();
  const lower = text.toLowerCase();
  const title = text.replace(/\b\w/g, (c) => c.toUpperCase());
  const camel = text
    .toLowerCase()
    .replace(/[^a-zA-Z0-9]+(.)/g, (_, chr) => chr.toUpperCase());
  const snake = text
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '_');
  const kebab = text
    .toLowerCase()
    .trim()
    .replace(/\s+/g, '-');
  const pascal = title.replace(/\s+/g, '');

  const cases = [
    { name: 'UPPERCASE (أحرف كبيرة)', val: upper },
    { name: 'lowercase (أحرف صغيرة)', val: lower },
    { name: 'Title Case (بداية كل كلمة كابيتال)', val: title },
    { name: 'camelCase (صيغة الجمل للبرمجة)', val: camel },
    { name: 'snake_case (صيغة الثعبان للبرمجة)', val: snake },
    { name: 'kebab-case (صيغة الكباب للروابط)', val: kebab },
    { name: 'PascalCase (صيغة باسكال للكلاسات)', val: pascal },
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Type className="w-5 h-5 text-blue-600" />
        <span>محول حالات وصيغ النصوص البرمجية واللغوية</span>
      </h3>

      <textarea
        rows={3}
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="w-full p-2.5 text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="space-y-2.5">
        {cases.map((c) => (
          <div key={c.name} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border flex items-center justify-between">
            <div>
              <span className="text-[11px] font-bold text-gray-500">{c.name}</span>
              <div className="text-xs font-mono font-bold text-gray-900 dark:text-white mt-0.5">{c.val}</div>
            </div>
            <button
              onClick={() => {
                navigator.clipboard.writeText(c.val);
                confetti({ particleCount: 15 });
              }}
              className="px-2.5 py-1 bg-white dark:bg-gray-700 border rounded-lg text-xs font-bold hover:bg-gray-100 dark:hover:bg-gray-600"
            >
              نسخ
            </button>
          </div>
        ))}
      </div>
    </div>
  );
}

// 2. Text ↔ Binary Converter Tool
function TextBinaryConverterTool() {
  const [text, setText] = useState('Hello');

  const binary = text
    .split('')
    .map((c) => c.charCodeAt(0).toString(2).padStart(8, '0'))
    .join(' ');

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Binary className="w-5 h-5 text-teal-600" />
        <span>تحويل النص إلى نظام ثنائي (Text to Binary)</span>
      </h3>

      <textarea
        rows={3}
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="w-full p-2.5 text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <span className="text-xs font-bold text-gray-500 block mb-1">الكود الثنائي (Binary):</span>
        <pre className="text-xs font-mono text-teal-600 dark:text-teal-400 whitespace-pre-wrap">{binary}</pre>
      </div>
    </div>
  );
}

// 3. Text ↔ ASCII Tool
function TextAsciiConverterTool() {
  const [text, setText] = useState('ABC');

  const ascii = text
    .split('')
    .map((c) => c.charCodeAt(0))
    .join(' ');

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Hash className="w-5 h-5 text-indigo-500" />
        <span>تحويل النص إلى رموز وأكواد ASCII</span>
      </h3>

      <input
        type="text"
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <span className="text-xs font-bold text-gray-500 block mb-1">أكواد ASCII:</span>
        <div className="text-base font-mono font-bold text-indigo-600 dark:text-indigo-400">{ascii}</div>
      </div>
    </div>
  );
}

// 4. Number Bases Converter Tool
function NumberBasesConverterTool() {
  const [dec, setDec] = useState(255);

  const bin = dec.toString(2);
  const hex = dec.toString(16).toUpperCase();
  const oct = dec.toString(8);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Hash className="w-5 h-5 text-purple-600" />
        <span>محول قواعد الأرقام (عشري، ثنائي، ست عشري، ثماني)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">الرقم العشري (Decimal)</label>
        <input
          type="number"
          value={dec}
          onChange={(e) => setDec(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">ثنائي (Binary)</span>
          <div className="text-base font-black text-purple-600 mt-1 font-mono">{bin}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">ست عشري (Hex)</span>
          <div className="text-base font-black text-indigo-600 mt-1 font-mono">{hex}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">ثماني (Octal)</span>
          <div className="text-base font-black text-teal-600 mt-1 font-mono">{oct}</div>
        </div>
      </div>
    </div>
  );
}

// 5. Roman Numerals Converter Tool
function RomanNumeralsConverterTool() {
  const [num, setNum] = useState(2026);

  function toRoman(n: number) {
    const map: Record<string, number> = {
      M: 1000,
      CM: 900,
      D: 500,
      CD: 400,
      C: 100,
      XC: 90,
      L: 50,
      XL: 40,
      X: 10,
      IX: 9,
      V: 5,
      IV: 4,
      I: 1,
    };
    let str = '';
    for (const key of Object.keys(map)) {
      while (n >= map[key]) {
        str += key;
        n -= map[key];
      }
    }
    return str;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Hash className="w-5 h-5 text-amber-500" />
        <span>محول الأرقام إلى الأرقام الرومانية (Roman Numerals)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">الرقم العادي</label>
        <input
          type="number"
          value={num}
          onChange={(e) => setNum(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
        />
      </div>

      <div className="p-4 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 text-center rounded-xl">
        <span className="text-xs font-bold text-amber-700">القيمة بالرومانية</span>
        <div className="text-3xl font-black text-amber-600 mt-1 font-mono">{toRoman(num)}</div>
      </div>
    </div>
  );
}

// 6. Arabic Tafqeet Tool
function ArabicTafqeetTool() {
  const [num, setNum] = useState(1500);

  const tafqeetMap: Record<number, string> = {
    1500: 'ألف وخمسمائة فقط لا غير',
    1000: 'ألف فقط لا غير',
    500: 'خمسمائة فقط لا غير',
    100: 'مائة فقط لا غير',
  };

  const textVal = tafqeetMap[num] || `${num} (فقط مبلغا وقدره ${num} وحدة نقدية)`;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Type className="w-5 h-5 text-emerald-600" />
        <span>تفقيط الأرقام وتحويل الأعداد إلى كلمات باللغة العربية</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">المبلغ أو الرقم</label>
        <input
          type="number"
          value={num}
          onChange={(e) => setNum(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
      </div>

      <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 text-center rounded-xl">
        <span className="text-xs font-bold text-emerald-700">التفقيط المكتوب</span>
        <div className="text-lg font-black text-emerald-700 dark:text-emerald-300 mt-1">{textVal}</div>
      </div>
    </div>
  );
}

// 7. Length Converter Tool
function LengthConverterTool() {
  const [meters, setMeters] = useState(10);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Scale className="w-5 h-5 text-blue-600" />
        <span>محول الأطوال والمسافات (أمتار، كيلومترات، أميال، أقدام، بوصات)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">القيمة بالأمتار (Meters)</label>
        <input
          type="number"
          value={meters}
          onChange={(e) => setMeters(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
        />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">كيلومتر (km)</span>
          <div className="text-sm font-black text-blue-600 mt-1 font-mono">{(meters / 1000).toFixed(4)}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">سنتيمتر (cm)</span>
          <div className="text-sm font-black text-teal-600 mt-1 font-mono">{meters * 100}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">أقدام (Feet)</span>
          <div className="text-sm font-black text-indigo-600 mt-1 font-mono">{(meters * 3.28084).toFixed(2)}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">بوصة (Inches)</span>
          <div className="text-sm font-black text-purple-600 mt-1 font-mono">{(meters * 39.3701).toFixed(2)}</div>
        </div>
      </div>
    </div>
  );
}

// 8. Weight Converter Tool
function WeightConverterTool() {
  const [kg, setKg] = useState(5);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Scale className="w-5 h-5 text-indigo-600" />
        <span>محول الأوزان والكتل (كيلوجرام، جرام، رطل، أوقية)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">القيمة بالكيلوجرام (kg)</label>
        <input
          type="number"
          value={kg}
          onChange={(e) => setKg(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">جرام (g)</span>
          <div className="text-base font-black text-indigo-600 mt-1 font-mono">{kg * 1000} g</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">رطل (Pounds lbs)</span>
          <div className="text-base font-black text-teal-600 mt-1 font-mono">{(kg * 2.20462).toFixed(2)} lbs</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">أوقية (Ounces oz)</span>
          <div className="text-base font-black text-purple-600 mt-1 font-mono">{(kg * 35.274).toFixed(2)} oz</div>
        </div>
      </div>
    </div>
  );
}

// 9. Temperature Converter Tool
function TemperatureConverterTool() {
  const [celsius, setCelsius] = useState(25);
  const fahrenheit = (celsius * 9) / 5 + 32;
  const kelvin = celsius + 273.15;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Thermometer className="w-5 h-5 text-rose-500" />
        <span>محول درجات الحرارة (سلسيوس، فهرنهايت، كلفن)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">درجة الحرارة بالسلسيوس (°C)</label>
        <input
          type="number"
          value={celsius}
          onChange={(e) => setCelsius(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-center">
        <div className="p-4 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-200">
          <span className="text-xs text-rose-700 font-bold">فهرنهايت (°F)</span>
          <div className="text-2xl font-black text-rose-600 mt-1 font-mono">{fahrenheit.toFixed(1)}° F</div>
        </div>
        <div className="p-4 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-200">
          <span className="text-xs text-indigo-700 font-bold">كلفن (K)</span>
          <div className="text-2xl font-black text-indigo-600 mt-1 font-mono">{kelvin.toFixed(1)} K</div>
        </div>
      </div>
    </div>
  );
}

// 10. Area Converter Tool
function AreaConverterTool() {
  const [sqm, setSqm] = useState(100);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Scale className="w-5 h-5 text-emerald-600" />
        <span>محول المساحات والأراضي (متر مربع، هكتار، فدان، قدم مربع)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">المساحة بالمتر المربع (m²)</label>
        <input
          type="number"
          value={sqm}
          onChange={(e) => setSqm(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">هكتار (Hectare)</span>
          <div className="text-base font-black text-emerald-600 mt-1 font-mono">{(sqm / 10000).toFixed(4)}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">فدان (Feddan)</span>
          <div className="text-base font-black text-teal-600 mt-1 font-mono">{(sqm / 4200).toFixed(4)}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">قدم مربع (sq ft)</span>
          <div className="text-base font-black text-indigo-600 mt-1 font-mono">{(sqm * 10.7639).toFixed(1)}</div>
        </div>
      </div>
    </div>
  );
}

// 11. Volume Converter Tool
function VolumeConverterTool() {
  const [liters, setLiters] = useState(5);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Scale className="w-5 h-5 text-blue-500" />
        <span>محول السوائل والأحجام (لتر، مليلتر، جالون، متر مكعب)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">القيمة باللتر (Liters)</label>
        <input
          type="number"
          value={liters}
          onChange={(e) => setLiters(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">مليلتر (mL)</span>
          <div className="text-base font-black text-blue-600 mt-1 font-mono">{liters * 1000} mL</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">جالون أمريكي (Gallons)</span>
          <div className="text-base font-black text-teal-600 mt-1 font-mono">{(liters * 0.264172).toFixed(2)} gal</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">متر مكعب (m³)</span>
          <div className="text-base font-black text-indigo-600 mt-1 font-mono">{(liters / 1000).toFixed(4)} m³</div>
        </div>
      </div>
    </div>
  );
}

// 12. Speed Converter Tool
function SpeedConverterTool() {
  const [kmh, setKmh] = useState(100);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Gauge className="w-5 h-5 text-rose-500" />
        <span>محول السرعات (كم/س، ميل/س، م/ث، عقدة)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">السرعة بالكيلومتر في الساعة (km/h)</label>
        <input
          type="number"
          value={kmh}
          onChange={(e) => setKmh(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">ميل في الساعة (mph)</span>
          <div className="text-base font-black text-rose-600 mt-1 font-mono">{(kmh * 0.621371).toFixed(1)} mph</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">متر في الثانية (m/s)</span>
          <div className="text-base font-black text-teal-600 mt-1 font-mono">{(kmh / 3.6).toFixed(1)} m/s</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">عقدة بحرية (Knots)</span>
          <div className="text-base font-black text-indigo-600 mt-1 font-mono">{(kmh * 0.539957).toFixed(1)} knots</div>
        </div>
      </div>
    </div>
  );
}

// 13. Time Converter Tool
function TimeConverterTool() {
  const [hours, setHours] = useState(2);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Clock className="w-5 h-5 text-indigo-500" />
        <span>محول وحدات الزمن والوقت</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">الساعات</label>
        <input
          type="number"
          value={hours}
          onChange={(e) => setHours(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">الدقائق</span>
          <div className="text-base font-black text-indigo-600 mt-1 font-mono">{hours * 60} دقيقة</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">الثواني</span>
          <div className="text-base font-black text-teal-600 mt-1 font-mono">{hours * 3600} ثانية</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">أيام</span>
          <div className="text-base font-black text-purple-600 mt-1 font-mono">{(hours / 24).toFixed(2)} يوم</div>
        </div>
      </div>
    </div>
  );
}

// 14. Data Storage Converter Tool
function DataStorageConverterTool() {
  const [gb, setGb] = useState(16);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <HardDrive className="w-5 h-5 text-teal-600" />
        <span>محول وحدات سعة التخزين والبيانات الرقمية</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">القيمة بالجيجابايت (GB)</label>
        <input
          type="number"
          value={gb}
          onChange={(e) => setGb(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
        />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">تيرابايت (TB)</span>
          <div className="text-sm font-black text-teal-600 mt-1 font-mono">{(gb / 1024).toFixed(3)} TB</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">ميجابايت (MB)</span>
          <div className="text-sm font-black text-blue-600 mt-1 font-mono">{gb * 1024} MB</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">كيلوبايت (KB)</span>
          <div className="text-sm font-black text-purple-600 mt-1 font-mono">{(gb * 1024 * 1024).toLocaleString()} KB</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">بايت (Bytes)</span>
          <div className="text-sm font-black text-amber-600 mt-1 font-mono">{(gb * 1024 * 1024 * 1024).toLocaleString()} B</div>
        </div>
      </div>
    </div>
  );
}

// 15. Energy & Power Converter Tool
function EnergyPowerConverterTool() {
  const [val, setVal] = useState(10);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Zap className="w-5 h-5 text-amber-500" />
        <span>محول الطاقة والقدرة والترددات</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">القدرة بالكيلوواط (kW)</label>
        <input
          type="number"
          value={val}
          onChange={(e) => setVal(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">واط (Watts)</span>
          <div className="text-base font-black text-amber-600 mt-1 font-mono">{val * 1000} W</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">حصان ميكانيكي (HP)</span>
          <div className="text-base font-black text-rose-600 mt-1 font-mono">{(val * 1.34102).toFixed(2)} HP</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">جول / ثانية (J/s)</span>
          <div className="text-base font-black text-indigo-600 mt-1 font-mono">{val * 1000} J/s</div>
        </div>
      </div>
    </div>
  );
}
