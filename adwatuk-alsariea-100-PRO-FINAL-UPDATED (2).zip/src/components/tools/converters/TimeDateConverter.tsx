import React, { useState, useEffect } from 'react';
import {
  Clock,
  Calendar,
  Globe,
  ArrowRightLeft,
  Sparkles,
  Copy,
  Check,
  RefreshCw,
  Sun,
  Moon
} from 'lucide-react';
import confetti from 'canvas-confetti';

export type TimeDateMode =
  | 'unix-converter'
  | 'timezone-converter'
  | 'time-units'
  | 'hijri-gregorian';

export function TimeDateConverter({ defaultMode }: { defaultMode?: TimeDateMode }) {
  const [currentMode, setCurrentMode] = useState<TimeDateMode>(defaultMode || 'unix-converter');

  // 1. Unix timestamp states
  const [unixInput, setUnixInput] = useState<number>(Math.floor(Date.now() / 1000));
  const [gregDateInput, setGregDateInput] = useState<string>(new Date().toISOString().slice(0, 16));

  // 2. Timezone states
  const [selectedUtcOffset, setSelectedUtcOffset] = useState<number>(3); // GMT+3 (Riyadh/Mecca)
  const [targetUtcOffset, setTargetUtcOffset] = useState<number>(0); // GMT (London/UTC)

  // 3. Time units states
  const [unitSeconds, setUnitSeconds] = useState<number>(3600);

  // 4. Hijri Gregorian states
  const [gregDate, setGregDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [hijriAdjustment, setHijriAdjustment] = useState<number>(0);

  const [copied, setCopied] = useState(false);

  // Unix conversions
  const unixToDate = new Date(unixInput * 1000);
  const unixIso = unixToDate.toISOString();
  const unixLocal = unixToDate.toLocaleString('ar-SA', { dateStyle: 'full', timeStyle: 'medium' });

  // Hijri calculation algorithm (Umm al-Qura approximation)
  const calculateHijri = (dateStr: string, adj: number) => {
    const d = new Date(dateStr);
    d.setDate(d.getDate() + adj);

    // Using Intl.DateTimeFormat with islamic-umalqura calendar
    const formatter = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
      day: 'numeric',
      month: 'long',
      year: 'numeric',
      weekday: 'long'
    });

    const hijriString = formatter.format(d);
    return hijriString;
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Modes Bar */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-4 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-heading font-extrabold text-sm sm:text-base text-gray-900 dark:text-white">
              محولات الوقت والتاريخ والتقويم
            </h3>
          </div>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {[
            { id: 'unix-converter', title: 'Unix Timestamp ↔ تاريخ', desc: 'تحويل الطابع الزمني يونكس وثواني العصر', icon: 'Clock' },
            { id: 'timezone-converter', title: 'تحويل المناطق الزمنية', desc: 'UTC ↔ التوقيت المحلي وعواصم العالم', icon: 'Globe' },
            { id: 'time-units', title: 'ثوانٍ ↔ ساعات ↔ أيام', desc: 'تحويل وحدات القياس الزمني والمدد', icon: 'Hourglass' },
            { id: 'hijri-gregorian', title: 'هجري ↔ ميلادي', desc: 'تحويل التقويم الهجري وتقويم أم القرى بدقة', icon: 'Calendar' },
          ].map((m) => {
            const isSelected = m.id === currentMode;
            return (
              <button
                key={m.id}
                onClick={() => setCurrentMode(m.id as any)}
                className={`p-3 rounded-2xl border text-right transition-all flex flex-col justify-between gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-900/10'
                    : 'bg-gray-50/50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-emerald-500/50'
                }`}
              >
                <span className="font-heading font-bold text-xs">
                  {m.title}
                </span>
                <span className={`text-[10px] line-clamp-1 ${isSelected ? 'text-emerald-100' : 'text-gray-400'}`}>
                  {m.desc}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Workspace */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
        
        {/* 1. Unix Converter */}
        {currentMode === 'unix-converter' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
              <div className="space-y-2">
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
                  طابع يونكس الزمني (Unix Epoch Seconds):
                </label>
                <div className="flex items-center gap-2">
                  <input
                    type="number"
                    value={unixInput}
                    onChange={(e) => setUnixInput(Number(e.target.value))}
                    className="flex-1 px-4 py-2.5 text-sm font-mono bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
                  />
                  <button
                    onClick={() => setUnixInput(Math.floor(Date.now() / 1000))}
                    className="px-3 py-2.5 bg-emerald-100 dark:bg-emerald-900 text-emerald-700 dark:text-emerald-300 font-bold text-xs rounded-xl"
                  >
                    الوقت الحالي
                  </button>
                </div>
              </div>

              <div className="space-y-2">
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
                  تحديد تاريخ ووقت:
                </label>
                <input
                  type="datetime-local"
                  value={gregDateInput}
                  onChange={(e) => {
                    setGregDateInput(e.target.value);
                    const ts = Math.floor(new Date(e.target.value).getTime() / 1000);
                    if (!isNaN(ts)) setUnixInput(ts);
                  }}
                  className="w-full px-4 py-2.5 text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
                />
              </div>
            </div>

            {/* Results */}
            <div className="p-5 bg-emerald-50/50 dark:bg-gray-800/60 rounded-2xl border border-emerald-200 dark:border-gray-700 space-y-3">
              <h4 className="font-heading font-extrabold text-sm text-emerald-900 dark:text-emerald-300">
                نتائج التحويل:
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                <div className="p-3 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
                  <span className="text-gray-400 block mb-1">التوقيت المحلي الكامل:</span>
                  <span className="font-bold text-gray-800 dark:text-gray-200">{unixLocal}</span>
                </div>
                <div className="p-3 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800">
                  <span className="text-gray-400 block mb-1">توقيت غرينتش ISO 8601 (UTC):</span>
                  <span className="font-mono font-bold text-gray-800 dark:text-gray-200">{unixIso}</span>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* 2. Timezone Converter */}
        {currentMode === 'timezone-converter' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                  المنطقة الزمنية المصدر:
                </label>
                <select
                  value={selectedUtcOffset}
                  onChange={(e) => setSelectedUtcOffset(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs font-bold bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
                >
                  <option value="3">مكة المكرمة، الرياض، الكويت، بغداد (UTC+3)</option>
                  <option value="4">دبي، أبوظبي، مسقط (UTC+4)</option>
                  <option value="2">القاهرة، القدس، بيروت، دمشق، الخرطوم (UTC+2)</option>
                  <option value="1">تونس، الجزائر، الرباط (UTC+1)</option>
                  <option value="0">غرينتش العالمي، لندن (UTC+0)</option>
                  <option value="-5">نيويورك، واشنطن، تورونتو (UTC-5)</option>
                  <option value="-8">لوس أنجلوس، سان فرانسيسكو (UTC-8)</option>
                  <option value="9">طوكيو، سيول (UTC+9)</option>
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                  المنطقة الزمنية المستهدفة:
                </label>
                <select
                  value={targetUtcOffset}
                  onChange={(e) => setTargetUtcOffset(Number(e.target.value))}
                  className="w-full px-3 py-2 text-xs font-bold bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
                >
                  <option value="0">غرينتش العالمي، لندن (UTC+0)</option>
                  <option value="3">مكة المكرمة، الرياض، الكويت، بغداد (UTC+3)</option>
                  <option value="4">دبي، أبوظبي، مسقط (UTC+4)</option>
                  <option value="2">القاهرة، القدس، بيروت، دمشق (UTC+2)</option>
                  <option value="1">تونس، الجزائر، الرباط (UTC+1)</option>
                  <option value="-5">نيويورك، واشنطن (UTC-5)</option>
                  <option value="-8">لوس أنجلوس (UTC-8)</option>
                  <option value="9">طوكيو (UTC+9)</option>
                </select>
              </div>
            </div>

            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 text-center space-y-2">
              <span className="text-xs text-emerald-800 dark:text-emerald-300 font-bold">فارق التوقيت:</span>
              <p className="font-heading font-extrabold text-lg text-emerald-950 dark:text-emerald-100">
                {targetUtcOffset - selectedUtcOffset > 0 ? `+${targetUtcOffset - selectedUtcOffset}` : targetUtcOffset - selectedUtcOffset} ساعة
              </p>
            </div>
          </div>
        )}

        {/* 3. Time units */}
        {currentMode === 'time-units' && (
          <div className="space-y-6">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                أدخل عدد الثواني للتحويل:
              </label>
              <input
                type="number"
                value={unitSeconds}
                onChange={(e) => setUnitSeconds(Number(e.target.value))}
                className="w-full px-4 py-2.5 text-sm font-mono bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
              />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
                <span className="text-xs text-gray-400 block mb-1">الدقائق</span>
                <span className="font-heading font-bold text-sm text-gray-900 dark:text-white">{(unitSeconds / 60).toFixed(2)}</span>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
                <span className="text-xs text-gray-400 block mb-1">الساعات</span>
                <span className="font-heading font-bold text-sm text-gray-900 dark:text-white">{(unitSeconds / 3600).toFixed(2)}</span>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
                <span className="text-xs text-gray-400 block mb-1">الأيام</span>
                <span className="font-heading font-bold text-sm text-gray-900 dark:text-white">{(unitSeconds / 86400).toFixed(3)}</span>
              </div>
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
                <span className="text-xs text-gray-400 block mb-1">الأسابيع</span>
                <span className="font-heading font-bold text-sm text-gray-900 dark:text-white">{(unitSeconds / 604800).toFixed(3)}</span>
              </div>
            </div>
          </div>
        )}

        {/* 4. Hijri Gregorian */}
        {currentMode === 'hijri-gregorian' && (
          <div className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                  التاريخ الميلادي:
                </label>
                <input
                  type="date"
                  value={gregDate}
                  onChange={(e) => setGregDate(e.target.value)}
                  className="w-full px-4 py-2.5 text-sm bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                  ضبط فارق رؤية الهلال (أيام): {hijriAdjustment > 0 ? `+${hijriAdjustment}` : hijriAdjustment}
                </label>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setHijriAdjustment(prev => prev - 1)}
                    className="px-3 py-2 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 font-bold rounded-xl"
                  >
                    -1 يوم
                  </button>
                  <button
                    onClick={() => setHijriAdjustment(0)}
                    className="flex-1 py-2 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 text-xs font-bold rounded-xl"
                  >
                    افتراضي
                  </button>
                  <button
                    onClick={() => setHijriAdjustment(prev => prev + 1)}
                    className="px-3 py-2 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 font-bold rounded-xl"
                  >
                    +1 يوم
                  </button>
                </div>
              </div>
            </div>

            {/* Converted Hijri Result */}
            <div className="p-6 bg-emerald-50/80 dark:bg-emerald-950/40 rounded-3xl border border-emerald-200 dark:border-emerald-800/60 text-center space-y-2">
              <span className="text-xs font-bold text-emerald-800 dark:text-emerald-300">
                التاريخ الهجري المقابل (تقويم أم القرى):
              </span>
              <p className="font-heading font-extrabold text-xl sm:text-2xl text-emerald-950 dark:text-emerald-100">
                {calculateHijri(gregDate, hijriAdjustment)}
              </p>
            </div>
          </div>
        )}

      </div>
    </div>
  );
}
