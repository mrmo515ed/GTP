import React, { useEffect, useState, useRef } from 'react';
import { fetchFile } from '@ffmpeg/util';
import { deleteFFmpegFiles, getFFmpeg, safeMediaFileName } from '../../../utils/ffmpegLoader';
import { hasExpectedSignature } from '../../../utils/fileSignatures';
import { triggerToolActionAd } from '../../../utils/adsterraManager';
import {
  Music,
  Upload,
  Download,
  Play,
  Pause,
  RefreshCw,
  Sliders,
  Sparkles,
  Volume2,
  Check,
  Radio,
  FileAudio,
  CheckCircle2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { ProcessingProgressBar } from '../../common/ProcessingProgressBar';

export type AudioConvertMode =
  | 'mp3-to-wav'
  | 'wav-to-mp3'
  | 'm4a-to-mp3'
  | 'flac-to-mp3'
  | 'ogg-to-mp3'
  | 'mp3-to-ogg'
  | 'mp3-to-aac'
  | 'wav-to-flac';

const AUDIO_MODES: { id: AudioConvertMode; title: string; desc: string; targetExt: string }[] = [
  { id: 'mp3-to-wav', title: 'MP3 ↔ WAV', desc: 'تحويل بين صيغتي MP3 و WAV غير المضغوطة بأعلى دقة', targetExt: 'wav' },
  { id: 'wav-to-mp3', title: 'WAV → MP3', desc: 'ضغط ملفات WAV الكبيرة إلى MP3 خفيفة وسريعة', targetExt: 'mp3' },
  { id: 'm4a-to-mp3', title: 'M4A → MP3', desc: 'تحويل تسجيلات آبل والأجهزة الذكية M4A إلى MP3', targetExt: 'mp3' },
  { id: 'flac-to-mp3', title: 'FLAC ↔ WAV/MP3', desc: 'تحويل الصوتيات فائقة الدقة FLAC إلى MP3 متوافق', targetExt: 'mp3' },
  { id: 'ogg-to-mp3', title: 'OGG ↔ MP3', desc: 'تحويل صيغ Ogg Vorbis إلى MP3 القياسية', targetExt: 'mp3' },
  { id: 'mp3-to-aac', title: 'MP3 ↔ AAC', desc: 'تحويل إلى ترميز AAC عالي الكفاءة للأجهزة الحديثة', targetExt: 'aac' },
];

export function AudioConverter({ defaultMode }: { defaultMode?: AudioConvertMode }) {
  const [currentMode, setCurrentMode] = useState<AudioConvertMode>(defaultMode || 'mp3-to-wav');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [audioUrl, setAudioUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [duration, setDuration] = useState<number>(0);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [sampleRate, setSampleRate] = useState<number>(44100);
  const [channels, setChannels] = useState<'stereo' | 'mono'>('stereo');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [statusStep, setStatusStep] = useState<string>('');
  const [convertedResultUrl, setConvertedResultUrl] = useState<string | null>(null);
  const [convertedResultName, setConvertedResultName] = useState<string>('');
  
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setAudioUrl(url);
    setIsPlaying(false);
  };

  const togglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play();
      setIsPlaying(true);
    }
  };

  useEffect(() => {
    return () => {
      if (audioUrl?.startsWith('blob:')) URL.revokeObjectURL(audioUrl);
    };
  }, [audioUrl]);

  useEffect(() => {
    if (convertedResultUrl) triggerToolActionAd('verified_conversion_result');
    return () => {
      if (convertedResultUrl?.startsWith('blob:')) URL.revokeObjectURL(convertedResultUrl);
    };
  }, [convertedResultUrl]);

  const handleConvert = async () => {
    if (!selectedFile) {
      alert('الرجاء اختيار ملف صوتي أولاً');
      return;
    }

    setIsProcessing(true);
    setProgress(10);
    setStatusStep('جاري تحميل محرك معالجة الصوتيات FFmpeg المحلي...');
    setConvertedResultUrl(null);
    setConvertedResultName('');

    let inputName = '';
    let outName = '';
    let ffmpeg: Awaited<ReturnType<typeof getFFmpeg>> | null = null;
    const progressHandler = ({ progress: value }: { progress: number }) => {
      const pct = Math.min(95, 25 + Math.round(value * 70));
      setProgress(pct);
      setStatusStep(`جاري تحويل ومعالجة الصوت... ${pct}%`);
    };

    try {
      ffmpeg = await getFFmpeg();
      setProgress(25);
      setStatusStep('جاري قراءة الملف وتجهيز التحويل الحقيقي...');
      ffmpeg.on('progress', progressHandler);

      const targetExt = AUDIO_MODES.find(m => m.id === currentMode)?.targetExt || 'mp3';
      inputName = safeMediaFileName(selectedFile.name, 'audio-input');
      outName = `audio-output-${Date.now()}.${targetExt}`;
      const baseName = selectedFile.name.replace(/\.[^.]+$/, '') || 'audio';

      await ffmpeg.writeFile(inputName, await fetchFile(selectedFile));
      const command = ['-i', inputName, '-vn', '-ar', String(sampleRate), '-ac', channels === 'mono' ? '1' : '2'];

      if (targetExt === 'mp3') command.push('-c:a', 'libmp3lame', '-q:a', '2');
      else if (targetExt === 'ogg') command.push('-c:a', 'libvorbis', '-q:a', '4');
      else if (targetExt === 'aac') command.push('-c:a', 'aac', '-b:a', '192k');
      else if (targetExt === 'wav') command.push('-c:a', 'pcm_s16le');
      else if (targetExt === 'flac') command.push('-c:a', 'flac');

      command.push(outName);
      const exitCode = await ffmpeg.exec(command);
      if (exitCode !== 0) throw new Error(`تعذر إكمال التحويل (FFmpeg code ${exitCode})`);

      const data = await ffmpeg.readFile(outName);
      if (typeof data === 'string' || data.byteLength < 16) throw new Error('ملف النتيجة فارغ أو غير صالح');
      const bytes = new Uint8Array(data);
      if (!hasExpectedSignature(bytes, targetExt)) {
        throw new Error(`الملف الناتج لا يطابق صيغة ${targetExt.toUpperCase()}`);
      }
      const mimeTypes: Record<string, string> = {
        mp3: 'audio/mpeg', wav: 'audio/wav', ogg: 'audio/ogg', aac: 'audio/aac', flac: 'audio/flac'
      };
      const blob = new Blob([bytes], { type: mimeTypes[targetExt] || 'application/octet-stream' });
      const url = URL.createObjectURL(blob);

      setProgress(100);
      setStatusStep('اكتمل تحويل الملف الصوتي والتحقق من النتيجة!');
      setConvertedResultUrl(url);
      setConvertedResultName(`${baseName}_converted.${targetExt}`);
      confetti({ particleCount: 35, spread: 60, origin: { y: 0.8 } });
    } catch (err: any) {
      setStatusStep('تعذر إكمال التحويل');
      alert('خطأ في معالجة وتحويل الصوت: ' + (err?.message || 'خطأ غير معروف'));
    } finally {
      if (ffmpeg) {
        ffmpeg.off('progress', progressHandler);
        await deleteFFmpegFiles(ffmpeg, inputName, outName);
      }
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (convertedResultUrl && convertedResultName) {
      const a = document.createElement('a');
      a.href = convertedResultUrl;
      a.download = convertedResultName;
      a.click();
    }
  };

  const selectedModeObj = AUDIO_MODES.find(m => m.id === currentMode);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Hidden Audio element for preview */}
      {audioUrl && (
        <audio
          ref={audioRef}
          src={audioUrl}
          onTimeUpdate={() => setCurrentTime(audioRef.current?.currentTime || 0)}
          onLoadedMetadata={() => setDuration(audioRef.current?.duration || 0)}
          onEnded={() => setIsPlaying(false)}
        />
      )}

      {/* Modes Grid */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-4 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Radio className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-heading font-extrabold text-sm sm:text-base text-gray-900 dark:text-white">
              محولات الملفات الصوتية والصوت
            </h3>
          </div>
          <span className="text-xs px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-bold rounded-full border border-emerald-200/60 dark:border-emerald-800/60">
            {AUDIO_MODES.length} صيغ متوفرة
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {AUDIO_MODES.map((m) => {
            const isSelected = m.id === currentMode;
            return (
              <button
                key={m.id}
                onClick={() => setCurrentMode(m.id)}
                className={`p-3 rounded-2xl border text-right transition-all flex flex-col justify-between gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-900/10'
                    : 'bg-gray-50/50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-emerald-500/50'
                }`}
              >
                <span className="font-heading font-bold text-xs" dir="ltr">
                  {m.title}
                </span>
                <span className={`text-[10px] line-clamp-1 ${isSelected ? 'text-emerald-100' : 'text-gray-400'}`}>
                  {m.desc}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Workspace */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
        
        {/* Banner */}
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 flex items-center justify-between">
          <div>
            <h4 className="font-heading font-extrabold text-sm sm:text-base text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>{selectedModeObj?.title}</span>
            </h4>
            <p className="text-xs text-emerald-700 dark:text-emerald-300/80 mt-0.5">
              {selectedModeObj?.desc}
            </p>
          </div>
        </div>

        {/* Upload File */}
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-gray-300 dark:border-gray-700 hover:border-emerald-500 rounded-3xl p-8 text-center cursor-pointer transition bg-gray-50/50 dark:bg-gray-800/30 group"
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="audio/*,.mp3,.wav,.m4a,.flac,.ogg,.aac,.wma"
            className="hidden"
          />
          <div className="w-14 h-14 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition">
            <Music className="w-7 h-7" />
          </div>
          <p className="font-heading font-extrabold text-sm text-gray-800 dark:text-gray-200">
            انقر لاختيار ملف صوتي أو اسحبه هنا
          </p>
          <p className="text-xs text-gray-400 mt-1">
            يدعم MP3, WAV, M4A, FLAC, OGG, AAC وجميع ترميزات الصوت
          </p>
          {selectedFile && (
            <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200 rounded-lg text-xs font-bold">
              <Check className="w-3.5 h-3.5" />
              {selectedFile.name} ({(selectedFile.size / (1024 * 1024)).toFixed(2)} MB)
            </div>
          )}
        </div>

        {/* Audio Player & Controls */}
        {selectedFile && (
          <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-gray-200 dark:border-gray-700 space-y-3">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <button
                  onClick={togglePlay}
                  className="w-10 h-10 bg-emerald-600 hover:bg-emerald-700 text-white rounded-full flex items-center justify-center shadow-md transition"
                >
                  {isPlaying ? <Pause className="w-5 h-5" /> : <Play className="w-5 h-5 ml-0.5" />}
                </button>
                <div>
                  <p className="font-bold text-xs text-gray-800 dark:text-gray-200">{selectedFile.name}</p>
                  <p className="text-[11px] text-gray-400">
                    {Math.floor(currentTime / 60)}:{Math.floor(currentTime % 60).toString().padStart(2, '0')} / {Math.floor(duration / 60)}:{Math.floor(duration % 60).toString().padStart(2, '0')}
                  </p>
                </div>
              </div>

              {/* Channels & Sample rate */}
              <div className="flex items-center gap-2">
                <select
                  value={channels}
                  onChange={(e) => setChannels(e.target.value as any)}
                  className="px-2.5 py-1.5 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none font-bold"
                >
                  <option value="stereo">ستيريو (Stereo 2ch)</option>
                  <option value="mono">مونو (Mono 1ch)</option>
                </select>
              </div>
            </div>
          </div>
        )}

        {/* Progress Bar */}
        {(isProcessing || (progress === 100 && convertedResultUrl)) && (
          <ProcessingProgressBar
            progress={progress}
            statusText={statusStep}
            subText={selectedFile?.name}
            isCompleted={!isProcessing && progress === 100}
            color="indigo"
          />
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
          <button
            onClick={handleConvert}
            disabled={!selectedFile || isProcessing}
            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-indigo-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5"
          >
            {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            <span>{isProcessing ? 'جاري التحويل...' : 'تحويل ومعالجة الصوت'}</span>
          </button>
          
          {convertedResultUrl && (
            <button
              onClick={handleDownload}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-emerald-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5 animate-in fade-in zoom-in"
            >
              <Download className="w-4 h-4" />
              <span>تحميل النتيجة</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
