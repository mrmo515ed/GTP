import React, { useState, useRef } from 'react';
import * as XLSX from 'xlsx';
import Papa from 'papaparse';
import {
  FileSpreadsheet,
  Upload,
  Download,
  Copy,
  Check,
  RefreshCw,
  Database,
  ArrowRightLeft,
  Sparkles,
  Table,
  Code2
} from 'lucide-react';
import confetti from 'canvas-confetti';
import { triggerToolActionAd } from '../../../utils/adsterraManager';

export type TableConvertMode =
  | 'excel-to-csv'
  | 'csv-to-excel'
  | 'json-to-excel'
  | 'excel-to-json'
  | 'xml-to-excel'
  | 'tsv-to-csv'
  | 'csv-to-sql';

const TABLE_MODES: { id: TableConvertMode; title: string; desc: string; icon: string }[] = [
  { id: 'excel-to-csv', title: 'Excel → CSV', desc: 'تحويل ملفات إكسل XLSX / XLS إلى جداول CSV القياسية', icon: 'FileSpreadsheet' },
  { id: 'csv-to-excel', title: 'CSV → Excel', desc: 'تحويل بيانات CSV إلى ملف إكسل XLSX منسق بخلايا وأعمدة', icon: 'FileSpreadsheet' },
  { id: 'json-to-excel', title: 'JSON → Excel', desc: 'تصدير مصفوفات وكائنات JSON إلى مصنف إكسل XLSX كامل', icon: 'FileSpreadsheet' },
  { id: 'excel-to-json', title: 'Excel → JSON', desc: 'استخراج كافة صفوف وأعمدة الإكسل إلى صيغة JSON برمجية', icon: 'Code2' },
  { id: 'tsv-to-csv', title: 'TSV → CSV', desc: 'تحويل الملفات المفصولة بعلامات Tab إلى ملفات CSV بفواصل', icon: 'ArrowRightLeft' },
  { id: 'csv-to-sql', title: 'CSV → SQL', desc: 'توليد استعلامات CREATE TABLE و INSERT INTO لقواعد البيانات', icon: 'Database' },
];

export function DataTableConverter({ defaultMode }: { defaultMode?: TableConvertMode }) {
  const [currentMode, setCurrentMode] = useState<TableConvertMode>(defaultMode || 'excel-to-csv');
  const [tableName, setTableName] = useState('my_table');
  const [sqlDialect, setSqlDialect] = useState<'mysql' | 'postgres' | 'sqlite'>('mysql');
  const [inputData, setInputData] = useState<string>('');
  const [outputData, setOutputData] = useState<string>('');
  const [tablePreview, setTablePreview] = useState<any[]>([]);
  const [headers, setHeaders] = useState<string[]>([]);
  const [copied, setCopied] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsProcessing(true);
    try {
      if (file.name.endsWith('.xlsx') || file.name.endsWith('.xls')) {
        const buffer = await file.arrayBuffer();
        const workbook = XLSX.read(buffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const jsonData = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];

        if (jsonData.length > 0) {
          const hdrs = jsonData[0].map(h => String(h || ''));
          const rows = jsonData.slice(1);
          setHeaders(hdrs);
          setTablePreview(rows.slice(0, 10));

          // Set text
          const csv = Papa.unparse({
            fields: hdrs,
            data: rows
          });
          setInputData(csv);
          processConversion(csv, currentMode);
        }
      } else {
        const text = await file.text();
        setInputData(text);
        processConversion(text, currentMode);
      }
    } catch (err: any) {
      alert('خطأ في قراءة ملف الجدول: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const processConversion = (text: string = inputData, mode: TableConvertMode = currentMode) => {
    if (!text.trim()) {
      setOutputData('');
      return;
    }

    try {
      if (mode === 'excel-to-csv') {
        setOutputData(text);
      } else if (mode === 'csv-to-sql') {
        const parsed = Papa.parse(text, { header: true, skipEmptyLines: true });
        if (parsed.data.length > 0) {
          const cols = Object.keys(parsed.data[0] as object);
          setHeaders(cols);
          setTablePreview(parsed.data.slice(0, 10));

          const safeTable = (tableName || 'my_table').replace(/[^a-zA-Z0-9_]/g, '_');
          const quoteIdentifier = (value: string) => sqlDialect === 'mysql'
            ? `\`${value.replace(/`/g, '``')}\``
            : `"${value.replace(/"/g, '""')}"`;
          const idColumn = sqlDialect === 'postgres'
            ? 'id SERIAL PRIMARY KEY'
            : sqlDialect === 'sqlite'
              ? 'id INTEGER PRIMARY KEY AUTOINCREMENT'
              : 'id INT PRIMARY KEY AUTO_INCREMENT';
          let sql = `-- Generated ${sqlDialect.toUpperCase()} SQL for ${safeTable}\n`;
          sql += `CREATE TABLE ${quoteIdentifier(safeTable)} (\n  ${idColumn},\n`;
          cols.forEach((col, idx) => {
            sql += `  ${quoteIdentifier(col)} VARCHAR(255)${idx < cols.length - 1 ? ',' : ''}\n`;
          });
          sql += `);\n\n`;

          sql += `INSERT INTO ${quoteIdentifier(safeTable)} (${cols.map(quoteIdentifier).join(', ')}) VALUES\n`;
          const rows = parsed.data.map((row: any) => {
            const values = cols.map(c => `'${String(row[c] ?? '').replace(/'/g, "''")}'`);
            return `  (${values.join(', ')})`;
          });
          sql += rows.join(',\n') + ';\n';
          setOutputData(sql);
        }
      } else if (mode === 'excel-to-json' || mode === 'csv-to-excel') {
        const parsed = Papa.parse(text, { header: true, skipEmptyLines: true });
        setOutputData(JSON.stringify(parsed.data, null, 2));
        if (parsed.data.length > 0) {
          setHeaders(Object.keys(parsed.data[0] as object));
          setTablePreview(parsed.data.slice(0, 10));
        }
      } else if (mode === 'json-to-excel') {
        const parsed = JSON.parse(text);
        const csv = Papa.unparse(Array.isArray(parsed) ? parsed : [parsed]);
        setOutputData(csv);
      } else if (mode === 'tsv-to-csv') {
        const parsed = Papa.parse(text, { delimiter: '\t', header: true });
        const csv = Papa.unparse(parsed.data);
        setOutputData(csv);
      }
    } catch (err: any) {
      setOutputData(`خطأ في معالجة البيانات: ${err.message}`);
    }
  };

  const handleDownload = () => {
    const raw = outputData || inputData;
    if (!raw) return;

    if (currentMode === 'csv-to-excel' || currentMode === 'json-to-excel') {
      try {
        let dataToExport: any[] = [];
        if (currentMode === 'json-to-excel') {
          dataToExport = JSON.parse(inputData);
        } else {
          const parsed = Papa.parse(inputData, { header: true, skipEmptyLines: true });
          dataToExport = parsed.data;
        }

        const ws = XLSX.utils.json_to_sheet(dataToExport);
        const wb = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Data');
        XLSX.writeFile(wb, `${tableName}.xlsx`);
        confetti({ particleCount: 30, spread: 50 });
      } catch (err: any) {
        alert('خطأ في تصدير ملف الإكسل: ' + err.message);
      }
      return;
    }

    let extension = 'csv';
    let mimeType = 'text/csv;charset=utf-8';

    if (currentMode === 'csv-to-sql') {
      extension = 'sql';
      mimeType = 'text/plain;charset=utf-8';
    } else if (currentMode === 'excel-to-json') {
      extension = 'json';
      mimeType = 'application/json;charset=utf-8';
    }

    const blob = new Blob([raw], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${tableName}.${extension}`;
    a.click();
    triggerToolActionAd('data_table_result');
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
    confetti({ particleCount: 30, spread: 50 });
  };

  const selectedModeObj = TABLE_MODES.find(m => m.id === currentMode);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Modes Grid */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-4 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Table className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-heading font-extrabold text-sm sm:text-base text-gray-900 dark:text-white">
              محولات الجداول والبيانات وقواعد البيانات
            </h3>
          </div>
          <span className="text-xs px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-bold rounded-full border border-emerald-200/60 dark:border-emerald-800/60">
            {TABLE_MODES.length} محولات
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2">
          {TABLE_MODES.map((m) => {
            const isSelected = m.id === currentMode;
            return (
              <button
                key={m.id}
                onClick={() => {
                  setCurrentMode(m.id);
                  processConversion(inputData, m.id);
                }}
                className={`p-3 rounded-2xl border text-right transition-all flex flex-col justify-between gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-900/10'
                    : 'bg-gray-50/50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-emerald-500/50'
                }`}
              >
                <span className="font-heading font-bold text-xs" dir="ltr">
                  {m.title}
                </span>
                <span className={`text-[10px] line-clamp-1 ${isSelected ? 'text-emerald-100' : 'text-gray-400'}`}>
                  {m.desc}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Workspace */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
        
        {/* Banner */}
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h4 className="font-heading font-extrabold text-sm sm:text-base text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>{selectedModeObj?.title}</span>
            </h4>
            <p className="text-xs text-emerald-700 dark:text-emerald-300/80 mt-0.5">
              {selectedModeObj?.desc}
            </p>
          </div>

          <div className="flex items-center gap-2">
            <input
              type="text"
              value={tableName}
              onChange={(e) => setTableName(e.target.value)}
              placeholder="اسم الجدول / الملف"
              className="px-3 py-1.5 text-xs font-semibold bg-white dark:bg-gray-800 border border-emerald-200 dark:border-emerald-700 rounded-xl outline-none"
            />
          </div>
        </div>

        {/* Upload Zone */}
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-gray-300 dark:border-gray-700 hover:border-emerald-500 rounded-3xl p-6 text-center cursor-pointer transition bg-gray-50/50 dark:bg-gray-800/30 group"
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileUpload}
            accept=".xlsx,.xls,.csv,.tsv,.json,.xml"
            className="hidden"
          />
          <div className="w-12 h-12 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-2 group-hover:scale-110 transition">
            <Upload className="w-6 h-6" />
          </div>
          <p className="font-heading font-extrabold text-xs sm:text-sm text-gray-800 dark:text-gray-200">
            انقر لرفع ملف إكسل XLSX أو ملف CSV أو JSON
          </p>
        </div>

        {/* Two-Pane Editor */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          <div className="space-y-2">
            <label className="font-heading font-extrabold text-xs text-gray-700 dark:text-gray-300">
              البيانات المدخلة (CSV / JSON / TSV):
            </label>
            <textarea
              value={inputData}
              onChange={(e) => {
                setInputData(e.target.value);
                processConversion(e.target.value, currentMode);
              }}
              placeholder="الصق بيانات CSV أو JSON أو صفوف الجداول هنا..."
              rows={10}
              className="w-full p-4 font-mono text-xs bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl outline-none focus:border-emerald-500"
            />
          </div>

          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-heading font-extrabold text-xs text-gray-700 dark:text-gray-300">
                النتيجة المحولة (SQL / JSON / CSV):
              </label>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(outputData);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                }}
                className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'تم النسخ' : 'نسخ الكود'}
              </button>
            </div>
            <textarea
              readOnly
              value={outputData || 'ستظهر النتيجة المحولة هنا...'}
              rows={10}
              className="w-full p-4 font-mono text-xs bg-emerald-50/20 dark:bg-gray-800/80 border border-emerald-200/50 dark:border-gray-700 rounded-2xl outline-none"
            />
          </div>
        </div>

        {/* Action Button */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
          <button
            onClick={handleDownload}
            disabled={!inputData && !outputData}
            className="px-8 py-3 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-emerald-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5"
          >
            <Download className="w-4 h-4" />
            <span>تنزيل الملف الناتج</span>
          </button>
        </div>

      </div>
    </div>
  );
}
