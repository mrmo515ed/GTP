import React, { useEffect, useState } from 'react';
import { FileText, FileCode, FileSpreadsheet, FileBox, Upload, FileType, RefreshCw, Copy, Download, Trash2, CheckCircle2 } from 'lucide-react';
import confetti from 'canvas-confetti';
import * as pdfjsLib from 'pdfjs-dist';
import * as XLSX from 'xlsx';
import JSZip from 'jszip';
import mammoth from 'mammoth';
import { Document, Packer, Paragraph, TextRun, AlignmentType } from 'docx';
import { convertHtmlToPdfBlob } from '../../../utils/pdfHelper';
import { ProcessingProgressBar } from '../../common/ProcessingProgressBar';
import { triggerToolActionAd } from '../../../utils/adsterraManager';

// Configure pdfjs worker
try {
  pdfjsLib.GlobalWorkerOptions.workerSrc = '/vendor/pdf/pdf.worker.min.mjs';
} catch (e) {
  console.warn('PDF.js worker setup note:', e);
}

const escapeHtml = (value: string): string => value
  .replace(/&/g, '&amp;')
  .replace(/</g, '&lt;')
  .replace(/>/g, '&gt;')
  .replace(/"/g, '&quot;')
  .replace(/'/g, '&#039;');

const naturalSlideSort = (a: string, b: string) => {
  const number = (name: string) => Number(name.match(/slide(\d+)\.xml$/)?.[1] || 0);
  return number(a) - number(b);
};

async function extractPptxToHtml(file: File, title: string): Promise<string> {
  if (!file.name.toLowerCase().endsWith('.pptx')) {
    throw new Error('التحويل المحلي يدعم PPTX فقط. احفظ ملف PPT القديم بصيغة PPTX ثم أعد المحاولة.');
  }

  const zip = await JSZip.loadAsync(file);
  const slidePaths = Object.keys(zip.files)
    .filter(path => /^ppt\/slides\/slide\d+\.xml$/.test(path))
    .sort(naturalSlideSort);
  if (slidePaths.length === 0) throw new Error('لا يحتوي ملف PPTX على شرائح قابلة للقراءة');

  const slides: string[] = [];
  for (let index = 0; index < slidePaths.length; index++) {
    const slidePath = slidePaths[index];
    const xml = await zip.file(slidePath)!.async('string');
    const doc = new DOMParser().parseFromString(xml, 'application/xml');
    if (doc.querySelector('parsererror')) throw new Error(`تعذر قراءة الشريحة ${index + 1}`);
    const texts = Array.from(doc.getElementsByTagNameNS('*', 't'))
      .map(node => node.textContent?.trim() || '')
      .filter(Boolean);

    const slideFile = slidePath.split('/').pop()!;
    const relPath = `ppt/slides/_rels/${slideFile}.rels`;
    const imageDataUrls: string[] = [];
    const relFile = zip.file(relPath);
    if (relFile) {
      const relXml = await relFile.async('string');
      const relDoc = new DOMParser().parseFromString(relXml, 'application/xml');
      const targets = Array.from(relDoc.getElementsByTagNameNS('*', 'Relationship'))
        .map(node => node.getAttribute('Target') || '')
        .filter(target => target.includes('/media/') || target.startsWith('../media/'));
      for (const target of [...new Set(targets)]) {
        const imagePath = target.startsWith('../') ? `ppt/${target.slice(3)}` : `ppt/slides/${target}`;
        const image = zip.file(imagePath);
        if (!image) continue;
        const extension = imagePath.split('.').pop()?.toLowerCase() || 'png';
        const mime = extension === 'jpg' || extension === 'jpeg' ? 'image/jpeg'
          : extension === 'svg' ? 'image/svg+xml'
          : extension === 'gif' ? 'image/gif'
          : 'image/png';
        imageDataUrls.push(`data:${mime};base64,${await image.async('base64')}`);
      }
    }

    slides.push(`
      <section class="ppt-slide" dir="rtl">
        <div class="ppt-slide-number">الشريحة ${index + 1}</div>
        <h2>${escapeHtml(texts[0] || `${title} — ${index + 1}`)}</h2>
        ${texts.slice(1).map(text => `<p>${escapeHtml(text)}</p>`).join('')}
        ${imageDataUrls.length ? `<div class="ppt-images">${imageDataUrls.map(src => `<img src="${src}" alt="صورة من الشريحة ${index + 1}" />`).join('')}</div>` : ''}
      </section>
    `);
  }

  return `
    <style>
      .ppt-slide { min-height: 650px; padding: 34px; background: #fff; color: #172033; page-break-after: always; position: relative; overflow: hidden; }
      .ppt-slide:last-child { page-break-after: auto; }
      .ppt-slide h2 { color: #4338ca; border-bottom: 2px solid #c7d2fe; padding-bottom: 12px; font-size: 26px; }
      .ppt-slide p { font-size: 18px; line-height: 1.8; margin: 10px 0; }
      .ppt-slide-number { position: absolute; left: 18px; bottom: 12px; color: #64748b; font-size: 12px; }
      .ppt-images { display: flex; flex-wrap: wrap; align-items: center; justify-content: center; gap: 12px; margin-top: 18px; }
      .ppt-images img { max-width: 45%; max-height: 270px; object-fit: contain; }
    </style>
    ${slides.join('')}
  `;
}

type DocConvertMode = 
  | 'word-to-pdf'
  | 'pdf-to-word'
  | 'pdf-to-txt'
  | 'pdf-to-image'
  | 'txt-to-pdf'
  | 'html-to-pdf'
  | 'excel-to-pdf'
  | 'ppt-to-pdf'
  | 'pdf-to-html';

const DOC_MODES: { id: DocConvertMode; title: string; desc: string; icon: string }[] = [
  { id: 'pdf-to-word', title: 'PDF → Word', desc: 'استخراج محتوى PDF إلى مستند Word DOCX قابل للتعديل', icon: 'FileType' },
  { id: 'pdf-to-txt', title: 'PDF → TXT', desc: 'استخراج كافة النصوص والفقرات من ملفات PDF', icon: 'FileText' },
  { id: 'pdf-to-image', title: 'PDF → JPG/PNG', desc: 'تحويل صفحات PDF إلى صور عالية الجودة والوضوح', icon: 'FileText' },
  { id: 'pdf-to-html', title: 'PDF → HTML', desc: 'تحويل هيكل مستندات PDF إلى صفحات ويب HTML', icon: 'FileCode' },
  { id: 'word-to-pdf', title: 'Word → PDF', desc: 'تحويل مستندات Word (DOCX) إلى ملفات PDF بالخطوط العربية', icon: 'FileType' },
  { id: 'txt-to-pdf', title: 'TXT → PDF', desc: 'تحويل الملفات النصية TXT إلى مستندات PDF منسقة', icon: 'FileText' },
  { id: 'html-to-pdf', title: 'HTML → PDF', desc: 'تحويل كود وصفحات الويب HTML إلى مستندات PDF', icon: 'FileCode' },
  { id: 'excel-to-pdf', title: 'Excel → PDF', desc: 'تحويل جداول البيانات إكسل إلى PDF مع الجداول', icon: 'FileSpreadsheet' },
  { id: 'ppt-to-pdf', title: 'PowerPoint → PDF', desc: 'تحويل عروض PowerPoint التقديمية إلى مستندات PDF', icon: 'FileType' },
];

export function DocumentConverter({ defaultMode }: { defaultMode?: DocConvertMode }) {
  const [currentMode, setCurrentMode] = useState<DocConvertMode>(defaultMode || 'pdf-to-txt');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [docTitle, setDocTitle] = useState<string>('');
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [statusStep, setStatusStep] = useState<string>('جاري التجهيز...');
  const [convertedResultUrls, setConvertedResultUrls] = useState<{url: string, name: string}[]>([]);

  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);

  useEffect(() => {
    if (success && convertedResultUrls.length > 0) triggerToolActionAd('document_conversion_result');
  }, [success, convertedResultUrls.length]);

  useEffect(() => {
    return () => {
      convertedResultUrls.forEach(item => {
        if (item.url.startsWith('blob:')) URL.revokeObjectURL(item.url);
      });
    };
  }, [convertedResultUrls]);

  const handleFileSelect = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    
    setSelectedFile(file);
    setDocTitle(file.name.substring(0, file.name.lastIndexOf('.')) || 'مستند');
    setConvertedResultUrls([]);
    setError(null);
    setSuccess(false);
    setProgress(0);
  };

  const extractPdfText = async (file: File): Promise<string> => {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    let fullText = '';
    const total = pdf.numPages;
    for (let i = 1; i <= total; i++) {
      const page = await pdf.getPage(i);
      const textContent = await page.getTextContent();
      const pageText = textContent.items.map((item: any) => item.str).join(' ');
      fullText += pageText + '\n\n';
      const pct = 15 + Math.round((i / total) * 60);
      setProgress(pct);
      setStatusStep(`جاري قراءة الصفحة ${i} من إجمالي ${total}...`);
    }
    return fullText;
  };

  const handleConvert = async () => {
    if (!selectedFile) {
      alert('الرجاء اختيار أو رفع ملف أولاً');
      return;
    }

    setIsProcessing(true);
    setProgress(5);
    setStatusStep('جاري فحص وقراءة الملف...');
    setConvertedResultUrls([]);
    setError(null);
    setSuccess(false);
    
    const fileName = (docTitle || 'document').replace(/\s+/g, '_');

    try {
      if (currentMode === 'pdf-to-txt' || currentMode === 'pdf-to-word' || currentMode === 'pdf-to-html') {
        const text = await extractPdfText(selectedFile);
        
        setProgress(80);
        setStatusStep('جاري إنشاء وتصدير الملف النهائي...');

        if (currentMode === 'pdf-to-txt') {
          const blob = new Blob([text], { type: 'text/plain;charset=utf-8' });
          setConvertedResultUrls([{ url: URL.createObjectURL(blob), name: `${fileName}.txt` }]);
        } else if (currentMode === 'pdf-to-word') {
          const paragraphs = text.split('\n\n').filter(Boolean).map((pageText, pageIndex) => new Paragraph({
            alignment: AlignmentType.RIGHT,
            pageBreakBefore: pageIndex > 0,
            children: [new TextRun({ text: pageText, rightToLeft: true, font: 'Arial', size: 24 })],
          }));
          const doc = new Document({
             sections: [{
                 properties: {},
                 children: paragraphs.length > 0 ? paragraphs : [new Paragraph({ children: [new TextRun({ text: 'لا يوجد نص' })] })],
             }],
          });
          const blob = await Packer.toBlob(doc);
          setConvertedResultUrls([{ url: URL.createObjectURL(blob), name: `${fileName}.docx` }]);
        } else if (currentMode === 'pdf-to-html') {
          const html = `<!DOCTYPE html><html dir="rtl" lang="ar"><head><meta charset="utf-8"><title>${docTitle}</title><style>body{font-family:system-ui,sans-serif;padding:30px;line-height:1.8;direction:rtl;text-align:right;}</style></head><body><div>${escapeHtml(text).replace(/\n\n/g, '</p><p>').replace(/^/, '<p>').replace(/$/, '</p>')}</div></body></html>`;
          const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
          setConvertedResultUrls([{ url: URL.createObjectURL(blob), name: `${fileName}.html` }]);
        }

        setProgress(100);
        setStatusStep('تم التحويل بنجاح!');
        setSuccess(true);
        confetti({ particleCount: 35, spread: 60 });
      } 
      else if (currentMode === 'pdf-to-image') {
        setProgress(15);
        setStatusStep('جاري فك وتحميل صفحات الـ PDF...');
        const arrayBuffer = await selectedFile.arrayBuffer();
        const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
        const urls = [];
        const total = pdf.numPages;
        
        for (let i = 1; i <= total; i++) {
          const page = await pdf.getPage(i);
          const viewport = page.getViewport({ scale: 2.0 });
          const canvas = document.createElement('canvas');
          const context = canvas.getContext('2d');
          canvas.height = viewport.height;
          canvas.width = viewport.width;
          
          await (page.render as any)({ canvasContext: context!, viewport: viewport, canvas: canvas }).promise;
          const dataUrl = canvas.toDataURL('image/jpeg', 0.95);
          urls.push({ url: dataUrl, name: `${fileName}_page_${i}.jpg` });

          const pct = 20 + Math.round((i / total) * 75);
          setProgress(pct);
          setStatusStep(`تم استخراج صفحة ${i} من ${total}...`);
        }
        setConvertedResultUrls(urls);
        setProgress(100);
        setStatusStep('اكتمل استخراج الصور بنجاح!');
        setSuccess(true);
        confetti({ particleCount: 35, spread: 60 });
      }
      else if (currentMode === 'word-to-pdf') {
        setProgress(20);
        setStatusStep('جاري قراءة بنية ملف Word (DOCX)...');
        const arrayBuffer = await selectedFile.arrayBuffer();
        const result = await mammoth.convertToHtml({ arrayBuffer });
        
        setProgress(50);
        setStatusStep('جاري بناء صفحات الـ PDF بالخطوط والتنسيقات العربية...');
        
        const html = `
          <div dir="rtl" style="text-align: right; line-height: 1.8;">
            <h2 style="margin-bottom: 20px; border-bottom: 2px solid #10b981; padding-bottom: 8px;">${docTitle}</h2>
            ${result.value}
          </div>
        `;
        
        const { url } = await convertHtmlToPdfBlob(html, {
          filename: `${fileName}.pdf`,
          title: docTitle,
          onProgress: (p, msg) => {
            setProgress(50 + Math.round(p * 0.48));
            setStatusStep(msg);
          }
        });
        
        setConvertedResultUrls([{ url, name: `${fileName}.pdf` }]);
        setProgress(100);
        setStatusStep('تم إنشاء ملف الـ PDF بنجاح!');
        setSuccess(true);
        confetti({ particleCount: 35, spread: 60 });
      }
      else if (currentMode === 'txt-to-pdf') {
        setProgress(20);
        setStatusStep('جاري قراءة المحتوى النصي...');
        const text = await selectedFile.text();
        const escaped = text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
        
        const html = `
          <div dir="rtl" style="text-align: right;">
            <h2 style="margin-bottom: 16px; color: #065f46; border-bottom: 1px solid #d1fae5; padding-bottom: 8px;">${docTitle}</h2>
            <div style="white-space: pre-wrap; font-size: 13px; line-height: 1.9; color: #1f2937;">${escaped}</div>
          </div>
        `;
        
        const { url } = await convertHtmlToPdfBlob(html, {
          filename: `${fileName}.pdf`,
          title: docTitle,
          onProgress: (p, msg) => {
            setProgress(30 + Math.round(p * 0.68));
            setStatusStep(msg);
          }
        });

        setConvertedResultUrls([{ url, name: `${fileName}.pdf` }]);
        setProgress(100);
        setStatusStep('تم إنشاء ملف الـ PDF بنجاح!');
        setSuccess(true);
        confetti({ particleCount: 35, spread: 60 });
      }
      else if (currentMode === 'html-to-pdf') {
        setProgress(20);
        setStatusStep('جاري قراءة كود صفحة الـ HTML...');
        const text = await selectedFile.text();
        
        const { url } = await convertHtmlToPdfBlob(text, {
          filename: `${fileName}.pdf`,
          title: docTitle,
          onProgress: (p, msg) => {
            setProgress(30 + Math.round(p * 0.68));
            setStatusStep(msg);
          }
        });

        setConvertedResultUrls([{ url, name: `${fileName}.pdf` }]);
        setProgress(100);
        setStatusStep('تم إنشاء ملف الـ PDF بنجاح!');
        setSuccess(true);
        confetti({ particleCount: 35, spread: 60 });
      }
      else if (currentMode === 'excel-to-pdf') {
        setProgress(20);
        setStatusStep('جاري قراءة جداول بيانات Excel...');
        const arrayBuffer = await selectedFile.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const htmlTable = XLSX.utils.sheet_to_html(worksheet);
        
        setProgress(50);
        setStatusStep('جاري تنسيق الجداول وتوليد صفحات الـ PDF...');
        
        const html = `
          <div dir="rtl" style="text-align: right;">
            <h2 style="margin-bottom: 16px; color: #1e293b;">${docTitle} - (${firstSheetName})</h2>
            <div style="overflow-x: auto;">
              ${htmlTable}
            </div>
          </div>
        `;
        
        const { url } = await convertHtmlToPdfBlob(html, {
          filename: `${fileName}.pdf`,
          title: docTitle,
          orientation: 'landscape',
          onProgress: (p, msg) => {
            setProgress(50 + Math.round(p * 0.48));
            setStatusStep(msg);
          }
        });
        
        setConvertedResultUrls([{ url, name: `${fileName}.pdf` }]);
        setProgress(100);
        setStatusStep('تم إنشاء ملف الـ PDF بنجاح!');
        setSuccess(true);
        confetti({ particleCount: 35, spread: 60 });
      }
      else if (currentMode === 'ppt-to-pdf') {
        setProgress(15);
        setStatusStep('جاري فك بنية PPTX وقراءة الشرائح والصور...');
        const html = await extractPptxToHtml(selectedFile, docTitle);

        setProgress(55);
        setStatusStep('جاري إنشاء صفحة PDF لكل شريحة...');
        const { url } = await convertHtmlToPdfBlob(html, {
          filename: `${fileName}.pdf`,
          title: docTitle,
          orientation: 'landscape',
          margin: 5,
          onProgress: (p, msg) => {
            setProgress(55 + Math.round(p * 0.43));
            setStatusStep(msg);
          }
        });

        setConvertedResultUrls([{ url, name: `${fileName}.pdf` }]);
        setProgress(100);
        setStatusStep('تم تحويل شرائح PPTX الفعلية إلى PDF!');
        setSuccess(true);
        confetti({ particleCount: 35, spread: 60 });
      }
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'حدث خطأ أثناء المعالجة.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownloadAll = () => {
    convertedResultUrls.forEach(file => {
      const a = document.createElement('a');
      a.href = file.url;
      a.download = file.name;
      a.click();
    });
  };

  return (
    <div className="space-y-8" id="document-converter-suite">
      {/* Modes Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
        {DOC_MODES.map((mode) => {
          const isSelected = currentMode === mode.id;
          return (
            <button
              key={mode.id}
              onClick={() => {
                setCurrentMode(mode.id);
                setConvertedResultUrls([]);
                setSelectedFile(null);
                setError(null);
                setSuccess(false);
                setProgress(0);
              }}
              className={`p-3.5 rounded-2xl text-right transition-all flex flex-col gap-2.5 ${
                isSelected 
                  ? 'bg-emerald-600 text-white shadow-lg shadow-emerald-500/20 scale-[1.02]' 
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 border border-gray-100 dark:border-gray-700'
              }`}
            >
              <div className={`w-9 h-9 rounded-xl flex items-center justify-center ${isSelected ? 'bg-white/20' : 'bg-emerald-50 dark:bg-gray-700 text-emerald-600'}`}>
                {mode.icon === 'FileType' && <FileType className="w-4 h-4" />}
                {mode.icon === 'FileText' && <FileText className="w-4 h-4" />}
                {mode.icon === 'FileCode' && <FileCode className="w-4 h-4" />}
                {mode.icon === 'FileSpreadsheet' && <FileSpreadsheet className="w-4 h-4" />}
                {mode.icon === 'FileBox' && <FileBox className="w-4 h-4" />}
              </div>
              <div>
                <div className="font-bold text-xs mb-0.5">{mode.title}</div>
                <div className={`text-[10px] line-clamp-2 ${isSelected ? 'text-emerald-100' : 'text-gray-500'}`}>{mode.desc}</div>
              </div>
            </button>
          );
        })}
      </div>

      {/* Main Converter Area */}
      <div className="bg-white dark:bg-gray-800 rounded-3xl p-5 md:p-8 shadow-xs border border-gray-200/80 dark:border-gray-700">
        
        {/* Upload Zone */}
        {!selectedFile ? (
          <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-2xl p-10 text-center hover:bg-emerald-50/20 dark:hover:bg-gray-900/50 hover:border-emerald-500 transition-all relative group cursor-pointer">
            <input
              type="file"
              accept=".pdf,.doc,.docx,.txt,.html,.htm,.xls,.xlsx,.csv,.ppt,.pptx"
              onChange={handleFileSelect}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />
            <div className="w-16 h-16 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl flex items-center justify-center mx-auto mb-3 text-emerald-600 dark:text-emerald-400 group-hover:scale-110 transition-transform">
              <Upload className="w-8 h-8" />
            </div>
            <h3 className="text-base font-bold text-gray-800 dark:text-white mb-1">
              اسحب وأفلت الملف هنا للتحويل
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              أو اضغط لاختيار ملف من جهازك (PDF, Word, TXT, Excel, HTML)
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {/* File Info Card */}
            <div className="bg-gray-50 dark:bg-gray-900/50 p-4 sm:p-5 rounded-2xl border border-gray-200/80 dark:border-gray-700 flex items-center justify-between gap-3">
              <div className="flex items-center gap-3 min-w-0">
                <div className="w-11 h-11 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 rounded-xl flex items-center justify-center shrink-0">
                  <FileText className="w-5 h-5" />
                </div>
                <div className="truncate">
                  <div className="font-bold text-xs sm:text-sm text-gray-800 dark:text-white truncate">
                    {selectedFile.name}
                  </div>
                  <div className="text-[11px] text-gray-500">
                    الحجم: {(selectedFile.size / 1024 / 1024).toFixed(2)} MB
                  </div>
                </div>
              </div>
              <button
                onClick={() => { setSelectedFile(null); setConvertedResultUrls([]); setProgress(0); }}
                className="p-2 text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-xl transition-colors shrink-0"
                title="إزالة وتغيير الملف"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>

            {/* Real Progress Bar & Status */}
            {(isProcessing || progress > 0) && (
              <ProcessingProgressBar
                progress={progress}
                statusText={statusStep}
                subText={selectedFile.name}
                isCompleted={success}
                color="emerald"
              />
            )}

            <div className="flex flex-wrap items-center justify-end gap-3 pt-3 border-t border-gray-200 dark:border-gray-800">
              
              {error && (
                <div className="mr-auto p-2.5 px-4 bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800 rounded-xl text-xs font-bold flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-rose-600 animate-pulse"></span>
                  خطأ: {error}
                </div>
              )}
              
              {success && convertedResultUrls.length > 0 && (
                <div className="mr-auto p-2.5 px-4 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs font-bold flex items-center gap-2">
                  <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                  تم التحويل بنجاح وبدون أي أخطاء!
                </div>
              )}

              <button
                onClick={handleConvert}
                disabled={isProcessing}
                className="bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white px-6 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-md shadow-emerald-600/20"
              >
                <RefreshCw className={`w-4 h-4 ${isProcessing ? 'animate-spin' : ''}`} />
                <span>{isProcessing ? 'جاري المعالجة...' : 'تحويل الملف الآن'}</span>
              </button>
              
              {convertedResultUrls.length > 0 && (
                <button
                  onClick={handleDownloadAll}
                  className="bg-emerald-700 hover:bg-emerald-800 text-white px-6 py-2.5 rounded-xl text-xs font-bold transition-all flex items-center gap-2 shadow-md"
                >
                  <Download className="w-4 h-4" />
                  <span>تنزيل جميع الملفات ({convertedResultUrls.length})</span>
                </button>
              )}
            </div>

            {/* Results Preview */}
            {convertedResultUrls.length > 0 && (
              <div className="mt-6 pt-6 border-t border-gray-200 dark:border-gray-800 space-y-4">
                <h3 className="text-sm font-bold text-gray-800 dark:text-white">الملفات المحولة الجاهزة للتنزيل:</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3">
                  {convertedResultUrls.map((file, idx) => (
                    <div key={idx} className="bg-gray-50 dark:bg-gray-900/60 p-3.5 rounded-xl border border-gray-200 dark:border-gray-700 flex flex-col items-center gap-2.5">
                      {file.name.endsWith('.jpg') || file.name.endsWith('.png') ? (
                        <img src={file.url} alt={file.name} className="w-full h-28 object-contain bg-white dark:bg-gray-800 rounded-lg p-1" />
                      ) : (
                        <div className="w-full h-20 bg-white dark:bg-gray-800 rounded-lg flex items-center justify-center text-emerald-600">
                          <FileText className="w-10 h-10" />
                        </div>
                      )}
                      <span className="text-xs font-bold text-gray-700 dark:text-gray-300 truncate w-full text-center" title={file.name}>{file.name}</span>
                      <a
                        href={file.url}
                        download={file.name}
                        className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg text-xs font-bold text-center transition flex items-center justify-center gap-1.5 shadow-xs"
                      >
                        <Download className="w-3.5 h-3.5" />
                        <span>تحميل الملف</span>
                      </a>
                    </div>
                  ))}
                </div>
              </div>
            )}

          </div>
        )}
      </div>
    </div>
  );
}

