import React, { useState, useMemo } from 'react';
import {
  Table,
  BarChart,
  PieChart,
  LineChart,
  FileSpreadsheet,
  Filter,
  Layers,
  Sparkles,
  FileText,
  Copy,
  Check,
  Plus,
  Trash2,
  Download,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  defaultTab?: string;
}

export function DataToolsSuite({ defaultTab = 'spreadsheet' }: Props) {
  const [activeTab, setActiveTab] = useState(defaultTab);

  const tabs = [
    { id: 'spreadsheet', label: 'جدول بيانات صغير', icon: FileSpreadsheet },
    { id: 'charts', label: 'مولد المخططات والرسوم البيانية', icon: BarChart },
    { id: 'csv-viewer', label: 'مستعرض ومحلل CSV', icon: Table },
    { id: 'json-viewer', label: 'مستعرض شجرة JSON', icon: Layers },
    { id: 'data-formatter', label: 'تنسيق وتجميل البيانات', icon: Sparkles },
    { id: 'duplicate-finder', label: 'مكتشف ومزيل التكرار', icon: Filter },
    { id: 'text-statistics', label: 'إحصائيات النصوص والكلمات', icon: FileText },
  ];

  return (
    <div className="space-y-6" id="data-tools-suite">
      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-gray-200 dark:border-gray-800">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                isActive
                  ? 'bg-teal-600 text-white shadow-md'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab Content */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-5 sm:p-6 shadow-xs">
        {activeTab === 'spreadsheet' && <MiniSpreadsheetTool />}
        {activeTab === 'charts' && <ChartGeneratorTool />}
        {activeTab === 'csv-viewer' && <CsvViewerAnalyzerTool />}
        {activeTab === 'json-viewer' && <JsonViewerTreeTool />}
        {activeTab === 'data-formatter' && <DataFormatterTool />}
        {activeTab === 'duplicate-finder' && <DuplicateFinderTool />}
        {activeTab === 'text-statistics' && <TextStatisticsTool />}
      </div>
    </div>
  );
}

// 1. Mini Spreadsheet Tool
function MiniSpreadsheetTool() {
  const [rows, setRows] = useState([
    { id: 1, item: 'المنتج أ', qty: 10, price: 50 },
    { id: 2, item: 'المنتج ب', qty: 5, price: 120 },
    { id: 3, item: 'المنتج ج', qty: 2, price: 300 },
  ]);

  const addRow = () => {
    setRows([...rows, { id: Date.now(), item: `عنصر ${rows.length + 1}`, qty: 1, price: 100 }]);
  };

  const deleteRow = (id: number) => {
    setRows(rows.filter((r) => r.id !== id));
  };

  const totalSum = rows.reduce((acc, r) => acc + (r.qty || 0) * (r.price || 0), 0);

  const exportCsv = () => {
    const csvContent = 'data:text/csv;charset=utf-8,Item,Qty,Price,Total\n' +
      rows.map((r) => `"${r.item}",${r.qty},${r.price},${r.qty * r.price}`).join('\n');
    const encodedUri = encodeURI(csvContent);
    const link = document.createElement('a');
    link.setAttribute('href', encodedUri);
    link.setAttribute('download', 'spreadsheet.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <FileSpreadsheet className="w-5 h-5 text-teal-600" />
          <span>جدول بيانات صغير تفاعلي مع حساب التلقائي والتصدير</span>
        </h3>
        <div className="flex gap-2">
          <button
            onClick={addRow}
            className="inline-flex items-center gap-1 px-3 py-1.5 bg-teal-600 text-white rounded-xl text-xs font-bold"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>إضافة صف</span>
          </button>
          <button
            onClick={exportCsv}
            className="inline-flex items-center gap-1 px-3 py-1.5 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-xl text-xs font-bold border"
          >
            <Download className="w-3.5 h-3.5" />
            <span>تصدير CSV</span>
          </button>
        </div>
      </div>

      <div className="overflow-x-auto border rounded-xl">
        <table className="w-full text-xs text-right">
          <thead className="bg-gray-50 dark:bg-gray-800 font-bold border-b">
            <tr>
              <th className="p-2.5">العنصر / البند</th>
              <th className="p-2.5">الكمية (Qty)</th>
              <th className="p-2.5">السعر الفردي</th>
              <th className="p-2.5">الإجمالي</th>
              <th className="p-2.5 text-center">إجراء</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
            {rows.map((r, idx) => (
              <tr key={r.id}>
                <td className="p-2">
                  <input
                    type="text"
                    value={r.item}
                    onChange={(e) => {
                      const newRows = [...rows];
                      newRows[idx].item = e.target.value;
                      setRows(newRows);
                    }}
                    className="w-full px-2 py-1 border rounded dark:bg-gray-800"
                  />
                </td>
                <td className="p-2">
                  <input
                    type="number"
                    value={r.qty}
                    onChange={(e) => {
                      const newRows = [...rows];
                      newRows[idx].qty = Number(e.target.value);
                      setRows(newRows);
                    }}
                    className="w-20 px-2 py-1 border rounded dark:bg-gray-800 font-mono"
                  />
                </td>
                <td className="p-2">
                  <input
                    type="number"
                    value={r.price}
                    onChange={(e) => {
                      const newRows = [...rows];
                      newRows[idx].price = Number(e.target.value);
                      setRows(newRows);
                    }}
                    className="w-24 px-2 py-1 border rounded dark:bg-gray-800 font-mono"
                  />
                </td>
                <td className="p-2 font-mono font-bold text-teal-600">
                  {(r.qty * r.price).toLocaleString()}
                </td>
                <td className="p-2 text-center">
                  <button
                    onClick={() => deleteRow(r.id)}
                    className="text-rose-500 hover:text-rose-700 p-1"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
          <tfoot className="bg-teal-50 dark:bg-teal-950/40 border-t font-black">
            <tr>
              <td colSpan={3} className="p-3 text-left">المجموع الكلي:</td>
              <td colSpan={2} className="p-3 text-teal-700 dark:text-teal-300 font-mono text-sm">
                {totalSum.toLocaleString()}
              </td>
            </tr>
          </tfoot>
        </table>
      </div>
    </div>
  );
}

// 2. Chart Generator Tool
function ChartGeneratorTool() {
  const [chartType, setChartType] = useState<'bar' | 'line' | 'pie'>('bar');
  const data = [
    { name: 'يناير', value: 400 },
    { name: 'فبراير', value: 300 },
    { name: 'مارس', value: 600 },
    { name: 'أبريل', value: 800 },
    { name: 'مايو', value: 500 },
  ];
  const maxVal = 800;
  const colors = ['#0ea5e9', '#10b981', '#f59e0b', '#ec4899', '#8b5cf6'];

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
          <BarChart className="w-5 h-5 text-indigo-600" />
          <span>مولد الرسوم والمخططات البيانية (Bar, Line, Pie)</span>
        </h3>
        <div className="flex gap-2">
          {(['bar', 'line', 'pie'] as const).map((t) => (
            <button
              key={t}
              onClick={() => setChartType(t)}
              className={`px-3 py-1 text-xs font-bold rounded-lg border transition ${
                chartType === t ? 'bg-indigo-600 text-white' : 'bg-gray-50 dark:bg-gray-800'
              }`}
            >
              {t === 'bar' ? 'أعمدة' : t === 'line' ? 'خطي' : 'دائري'}
            </button>
          ))}
        </div>
      </div>

      <div className="h-64 w-full pt-4 flex items-center justify-center bg-gray-50 dark:bg-gray-800/50 rounded-2xl p-4 border">
        {chartType === 'bar' && (
          <div className="w-full h-full flex items-end justify-between gap-4 px-4 pb-4">
            {data.map((d, i) => (
              <div key={d.name} className="flex-1 flex flex-col items-center gap-2 h-full justify-end">
                <span className="text-[10px] font-mono font-bold text-gray-500">{d.value}</span>
                <div
                  className="w-full rounded-t-xl transition-all duration-500"
                  style={{
                    height: `${(d.value / maxVal) * 80}%`,
                    backgroundColor: colors[i % colors.length],
                  }}
                ></div>
                <span className="text-xs font-bold text-gray-700 dark:text-gray-300">{d.name}</span>
              </div>
            ))}
          </div>
        )}

        {chartType === 'line' && (
          <div className="w-full h-full flex flex-col justify-between">
            <svg viewBox="0 0 500 200" className="w-full h-44 overflow-visible">
              <polyline
                fill="none"
                stroke="#6366f1"
                strokeWidth="4"
                strokeLinecap="round"
                strokeLinejoin="round"
                points="50,140 150,170 250,90 350,30 450,110"
              />
              {[
                { cx: 50, cy: 140, val: 400 },
                { cx: 150, cy: 170, val: 300 },
                { cx: 250, cy: 90, val: 600 },
                { cx: 350, cy: 30, val: 800 },
                { cx: 450, cy: 110, val: 500 },
              ].map((p, idx) => (
                <g key={idx}>
                  <circle cx={p.cx} cy={p.cy} r="6" fill="#4f46e5" stroke="#ffffff" strokeWidth="2" />
                  <text x={p.cx} y={p.cy - 12} textAnchor="middle" fontSize="11" fill="#4f46e5" fontWeight="bold">
                    {p.val}
                  </text>
                </g>
              ))}
            </svg>
            <div className="flex justify-between px-6 text-xs font-bold text-gray-500">
              {data.map((d) => (
                <span key={d.name}>{d.name}</span>
              ))}
            </div>
          </div>
        )}

        {chartType === 'pie' && (
          <div className="flex items-center gap-8">
            <div className="relative w-40 h-40 rounded-full border-8 border-indigo-500 flex items-center justify-center bg-gradient-to-tr from-indigo-500/20 to-teal-500/20 shadow-md">
              <PieChart className="w-12 h-12 text-indigo-600" />
            </div>
            <div className="space-y-1.5 text-xs font-bold">
              {data.map((d, i) => (
                <div key={d.name} className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: colors[i] }}></div>
                  <span>{d.name}: {d.value}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// 3. CSV Viewer & Analyzer Tool
function CsvViewerAnalyzerTool() {
  const [csvText, setCsvText] = useState('الاسم,العمر,المدينة,المهنة\nأحمد,28,الرياض,مهندس\nسارة,25,دبي,مصممة\nخالد,32,جدة,طبيب');

  const parsed = useMemo(() => {
    const lines = csvText.trim().split('\n').filter(Boolean);
    if (lines.length === 0) return { headers: [], rows: [] };
    const headers = lines[0].split(',').map((h) => h.trim());
    const rows = lines.slice(1).map((line) => line.split(',').map((c) => c.trim()));
    return { headers, rows };
  }, [csvText]);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Table className="w-5 h-5 text-teal-600" />
        <span>مستعرض ومحلل ملفات CSV</span>
      </h3>

      <textarea
        rows={4}
        value={csvText}
        onChange={(e) => setCsvText(e.target.value)}
        className="w-full p-2.5 font-mono text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="overflow-x-auto border rounded-xl">
        <table className="w-full text-xs text-right">
          <thead className="bg-gray-50 dark:bg-gray-800 font-bold border-b">
            <tr>
              {parsed.headers.map((h, i) => (
                <th key={i} className="p-2.5">{h}</th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100 dark:divide-gray-800">
            {parsed.rows.map((row, rIdx) => (
              <tr key={rIdx}>
                {row.map((cell, cIdx) => (
                  <td key={cIdx} className="p-2.5">{cell}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}

// 4. JSON Viewer & Tree Tool
function JsonViewerTreeTool() {
  const [jsonText, setJsonText] = useState('{\n  "user": "أحمد",\n  "skills": ["React", "TypeScript", "Tailwind"],\n  "active": true\n}');

  let parsed: any = null;
  let isValid = true;
  try {
    parsed = JSON.parse(jsonText);
  } catch {
    isValid = false;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Layers className="w-5 h-5 text-indigo-500" />
        <span>مستعرض ومحلل شجرة JSON التفاعلي</span>
      </h3>

      <textarea
        rows={6}
        value={jsonText}
        onChange={(e) => setJsonText(e.target.value)}
        className="w-full p-2.5 font-mono text-xs border rounded-xl dark:bg-gray-800"
      />

      {isValid ? (
        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <pre className="text-xs font-mono text-indigo-600 dark:text-indigo-400 whitespace-pre-wrap">
            {JSON.stringify(parsed, null, 2)}
          </pre>
        </div>
      ) : (
        <div className="p-3 bg-red-50 text-red-600 rounded-xl text-xs font-bold">
          صيغة JSON غير صالحة
        </div>
      )}
    </div>
  );
}

// 5. Data Formatter Tool
function DataFormatterTool() {
  const [input, setInput] = useState('{"name":"ahmed","age":25,"city":"Riyadh"}');
  const [output, setOutput] = useState('');

  const formatJson = () => {
    try {
      setOutput(JSON.stringify(JSON.parse(input), null, 2));
    } catch {
      setOutput('خطأ في بناء الجملة');
    }
  };

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Sparkles className="w-5 h-5 text-purple-600" />
        <span>تنسيق وتجميل البيانات (Beautifier / Minifier)</span>
      </h3>

      <textarea
        rows={4}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        className="w-full p-2.5 font-mono text-xs border rounded-xl dark:bg-gray-800"
      />

      <button
        onClick={formatJson}
        className="px-4 py-2 bg-purple-600 text-white rounded-xl text-xs font-bold"
      >
        تنسيق البيانات
      </button>

      {output && (
        <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <pre className="text-xs font-mono text-purple-600 whitespace-pre-wrap">{output}</pre>
        </div>
      )}
    </div>
  );
}

// 6. Duplicate Finder Tool
function DuplicateFinderTool() {
  const [text, setText] = useState('تفاح\nموز\nتفاح\nبرتقال\nموز\nعنب');

  const uniqueLines = useMemo(() => {
    const lines = text.split('\n').map((l) => l.trim()).filter(Boolean);
    return Array.from(new Set(lines));
  }, [text]);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Filter className="w-5 h-5 text-rose-500" />
        <span>مكتشف ومزيل التكرار في القوائم والنصوص</span>
      </h3>

      <textarea
        rows={5}
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="w-full p-2.5 font-mono text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <span className="text-xs font-bold text-gray-500 block mb-2">النتائج الفريدة بعد إزالة التكرار ({uniqueLines.length} عنصر):</span>
        <pre className="text-xs font-mono text-emerald-600">{uniqueLines.join('\n')}</pre>
      </div>
    </div>
  );
}

// 7. Text Statistics Tool
function TextStatisticsTool() {
  const [text, setText] = useState('مرحباً بك في المنصة الشاملة للأدوات والمحولات السريعة.');

  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const chars = text.length;
  const charsNoSpaces = text.replace(/\s/g, '').length;
  const readingTime = Math.ceil(words / 200);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <FileText className="w-5 h-5 text-blue-600" />
        <span>إحصائيات وتحليل النصوص الشامل</span>
      </h3>

      <textarea
        rows={4}
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="w-full p-2.5 text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">عدد الكلمات</span>
          <div className="text-xl font-black text-blue-600 mt-1 font-mono">{words}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">عدد الأحرف</span>
          <div className="text-xl font-black text-teal-600 mt-1 font-mono">{chars}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">بدون مسافات</span>
          <div className="text-xl font-black text-purple-600 mt-1 font-mono">{charsNoSpaces}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold">وقت القراءة المقدر</span>
          <div className="text-xl font-black text-amber-600 mt-1 font-mono">{readingTime} دقيقة</div>
        </div>
      </div>
    </div>
  );
}
