import React, { useState } from 'react';
import { Coins, ArrowRightLeft, Sparkles, TrendingUp } from 'lucide-react';

interface Currency {
  code: string;
  nameAr: string;
  symbol: string;
  rateToUSD: number; // base USD
  flag: string;
}

const CURRENCIES: Currency[] = [
  { code: 'USD', nameAr: 'دولار أمريكي', symbol: '$', rateToUSD: 1.0, flag: '🇺🇸' },
  { code: 'SAR', nameAr: 'ريال سعودي', symbol: 'ر.س', rateToUSD: 3.75, flag: '🇸🇦' },
  { code: 'AED', nameAr: 'درهم إماراتي', symbol: 'د.إ', rateToUSD: 3.67, flag: '🇦🇪' },
  { code: 'EGP', nameAr: 'جنيه مصري', symbol: 'ج.م', rateToUSD: 48.5, flag: '🇪🇬' },
  { code: 'KWD', nameAr: 'دينار كويتي', symbol: 'د.ك', rateToUSD: 0.31, flag: '🇰🇼' },
  { code: 'QAR', nameAr: 'ريال قطري', symbol: 'ر.ق', rateToUSD: 3.64, flag: '🇶🇦' },
  { code: 'BHD', nameAr: 'دينار بحريني', symbol: 'د.ب', rateToUSD: 0.38, flag: '🇧🇭' },
  { code: 'OMR', nameAr: 'ريال عماني', symbol: 'ر.ع', rateToUSD: 0.385, flag: '🇴🇲' },
  { code: 'JOD', nameAr: 'دينار أردني', symbol: 'د.أ', rateToUSD: 0.71, flag: '🇯🇴' },
  { code: 'MAD', nameAr: 'درهم مغربي', symbol: 'د.م', rateToUSD: 9.9, flag: '🇲🇦' },
  { code: 'DZD', nameAr: 'دينار جزائري', symbol: 'د.ج', rateToUSD: 134.0, flag: '🇩🇿' },
  { code: 'IQD', nameAr: 'دينار عراقي', symbol: 'د.ع', rateToUSD: 1310.0, flag: '🇮🇶' },
  { code: 'EUR', nameAr: 'يورو أوروبي', symbol: '€', rateToUSD: 0.92, flag: '🇪🇺' },
  { code: 'GBP', nameAr: 'جنيه إسترليني', symbol: '£', rateToUSD: 0.78, flag: '🇬🇧' },
  { code: 'TRY', nameAr: 'ليرة تركية', symbol: '₺', rateToUSD: 34.0, flag: '🇹🇷' },
];

export function CurrencyCalculator() {
  const [amount, setAmount] = useState<number>(100);
  const [fromCode, setFromCode] = useState<string>('USD');
  const [toCode, setToCode] = useState<string>('SAR');

  const fromCurr = CURRENCIES.find((c) => c.code === fromCode) || CURRENCIES[0];
  const toCurr = CURRENCIES.find((c) => c.code === toCode) || CURRENCIES[1];

  // Convert
  const amountInUSD = amount / fromCurr.rateToUSD;
  const result = amountInUSD * toCurr.rateToUSD;

  const handleSwap = () => {
    const temp = fromCode;
    setFromCode(toCode);
    setToCode(temp);
  };

  return (
    <div className="space-y-6" id="currency-calculator-tool">
      {/* Conversion Form */}
      <div className="p-5 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-2xl space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
          {/* From */}
          <div className="sm:col-span-5 space-y-2">
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">المبلغ والعملة:</label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(Number(e.target.value))}
              className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 font-mono text-base font-bold"
            />
            <select
              value={fromCode}
              onChange={(e) => setFromCode(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-xs font-bold"
            >
              {CURRENCIES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.flag} {c.code} - {c.nameAr}
                </option>
              ))}
            </select>
          </div>

          {/* Swap */}
          <div className="sm:col-span-2 flex justify-center py-2 sm:py-0">
            <button
              onClick={handleSwap}
              className="p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full hover:border-emerald-500 hover:text-emerald-600 transition shadow-xs"
              title="تبديل العملات"
            >
              <ArrowRightLeft className="w-4 h-4" />
            </button>
          </div>

          {/* To */}
          <div className="sm:col-span-5 space-y-2">
            <label className="block text-xs font-bold text-emerald-600 dark:text-emerald-400">النتيجة المقابلة:</label>
            <div className="w-full p-2.5 rounded-xl border border-emerald-300 dark:border-emerald-800 bg-white dark:bg-gray-900 font-mono text-base font-extrabold text-emerald-600 dark:text-emerald-400 truncate">
              {result.toLocaleString('ar-EG', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} {toCurr.symbol}
            </div>
            <select
              value={toCode}
              onChange={(e) => setToCode(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-xs font-bold"
            >
              {CURRENCIES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.flag} {c.code} - {c.nameAr}
                </option>
              ))}
            </select>
          </div>
        </div>

        <div className="text-center text-xs text-gray-500 dark:text-gray-400 pt-1">
          1 {fromCurr.code} = {(toCurr.rateToUSD / fromCurr.rateToUSD).toFixed(4)} {toCurr.code}
        </div>
      </div>

      {/* Quick Compare Cards for all currencies */}
      <div className="space-y-2">
        <h4 className="text-xs font-bold text-gray-700 dark:text-gray-300">
          مقارنة فورية لقيمة {amount} {fromCurr.code} بباقي العملات:
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2.5">
          {CURRENCIES.map((c) => {
            const convertedVal = (amountInUSD * c.rateToUSD).toLocaleString('ar-EG', {
              minimumFractionDigits: 2,
              maximumFractionDigits: 2,
            });
            return (
              <div
                key={c.code}
                className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/60 dark:border-gray-700/60"
              >
                <div className="flex items-center gap-1.5 text-xs text-gray-600 dark:text-gray-400 font-semibold">
                  <span>{c.flag}</span>
                  <span>{c.code}</span>
                </div>
                <div className="font-mono text-sm font-bold text-gray-900 dark:text-gray-100 mt-1">
                  {convertedVal} <span className="text-[10px] text-gray-500">{c.symbol}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
