import React, { useState } from 'react';
import { Scale, Ruler, Thermometer, HardDrive, Gauge, Clock, ArrowRightLeft, Square, Box, Wind, Zap, Compass, Droplet } from 'lucide-react';

type UnitCategory = 'length' | 'weight' | 'data' | 'temp' | 'speed' | 'time' | 'area' | 'volume' | 'pressure' | 'energy' | 'power' | 'angle' | 'fuel' | 'force' | 'dataRate';

interface UnitDef {
  id: string;
  nameAr: string;
  factorToBase: number; // multiplier to base unit
}

const UNIT_GROUPS: Record<UnitCategory, { nameAr: string; icon: any; baseUnit: string; units: UnitDef[] }> = {
  length: {
    nameAr: 'الأطوال والمسافات',
    icon: Ruler,
    baseUnit: 'متر',
    units: [
      { id: 'm', nameAr: 'متر (m)', factorToBase: 1 },
      { id: 'km', nameAr: 'كيلومتر (km)', factorToBase: 1000 },
      { id: 'cm', nameAr: 'سنتيمتر (cm)', factorToBase: 0.01 },
      { id: 'mm', nameAr: 'ميليمتر (mm)', factorToBase: 0.001 },
      { id: 'inch', nameAr: 'بوصة (Inch)', factorToBase: 0.0254 },
      { id: 'ft', nameAr: 'قدم (Foot)', factorToBase: 0.3048 },
      { id: 'yd', nameAr: 'ياردة (Yard)', factorToBase: 0.9144 },
      { id: 'mile', nameAr: 'ميل (Mile)', factorToBase: 1609.344 },
    ],
  },
  weight: {
    nameAr: 'الأوزان والكتلة',
    icon: Scale,
    baseUnit: 'جرام',
    units: [
      { id: 'g', nameAr: 'جرام (g)', factorToBase: 1 },
      { id: 'kg', nameAr: 'كيلوجرام (kg)', factorToBase: 1000 },
      { id: 'mg', nameAr: 'ميليجرام (mg)', factorToBase: 0.001 },
      { id: 'ton', nameAr: 'طن متري (Ton)', factorToBase: 1000000 },
      { id: 'lb', nameAr: 'رطل (Pound)', factorToBase: 453.59237 },
      { id: 'oz', nameAr: 'أونصة (Ounce)', factorToBase: 28.349523 },
    ],
  },
  data: {
    nameAr: 'تخزين البيانات الرقمية',
    icon: HardDrive,
    baseUnit: 'بايت',
    units: [
      { id: 'b', nameAr: 'بايت (Byte)', factorToBase: 1 },
      { id: 'kb', nameAr: 'كيلوبايت (KB)', factorToBase: 1024 },
      { id: 'mb', nameAr: 'ميجابايت (MB)', factorToBase: 1024 * 1024 },
      { id: 'gb', nameAr: 'جيجابايت (GB)', factorToBase: 1024 * 1024 * 1024 },
      { id: 'tb', nameAr: 'تيرابايت (TB)', factorToBase: 1024 * 1024 * 1024 * 1024 },
      { id: 'pb', nameAr: 'بيتابايت (PB)', factorToBase: 1024 * 1024 * 1024 * 1024 * 1024 },
    ],
  },
  temp: {
    nameAr: 'درجات الحرارة',
    icon: Thermometer,
    baseUnit: 'مئوية',
    units: [
      { id: 'c', nameAr: 'درجة مئوية (°C)', factorToBase: 1 },
      { id: 'f', nameAr: 'فهرنهايت (°F)', factorToBase: 1 },
      { id: 'k', nameAr: 'كلفن (K)', factorToBase: 1 },
    ],
  },
  speed: {
    nameAr: 'السرعة',
    icon: Gauge,
    baseUnit: 'م/ث',
    units: [
      { id: 'kmh', nameAr: 'كم/ساعة (km/h)', factorToBase: 1 },
      { id: 'ms', nameAr: 'متر/ثانية (m/s)', factorToBase: 3.6 },
      { id: 'mph', nameAr: 'ميل/ساعة (mph)', factorToBase: 1.609344 },
      { id: 'knot', nameAr: 'عقدة بحرية (Knot)', factorToBase: 1.852 },
    ],
  },
  time: {
    nameAr: 'الوقت والزمن',
    icon: Clock,
    baseUnit: 'ثانية',
    units: [
      { id: 's', nameAr: 'ثانية (Second)', factorToBase: 1 },
      { id: 'min', nameAr: 'دقيقة (Minute)', factorToBase: 60 },
      { id: 'h', nameAr: 'ساعة (Hour)', factorToBase: 3600 },
      { id: 'day', nameAr: 'يوم (Day)', factorToBase: 86400 },
      { id: 'week', nameAr: 'أسبوع (Week)', factorToBase: 604800 },
      { id: 'year', nameAr: 'سنة (Year)', factorToBase: 31536000 },
    ],
  },
  area: {
    nameAr: 'المساحة',
    icon: Square,
    baseUnit: 'متر مربع',
    units: [
      { id: 'sq_m', nameAr: 'متر مربع (m²)', factorToBase: 1 },
      { id: 'sq_km', nameAr: 'كيلومتر مربع (km²)', factorToBase: 1e6 },
      { id: 'sq_cm', nameAr: 'سنتيمتر مربع (cm²)', factorToBase: 1e-4 },
      { id: 'sq_mm', nameAr: 'ميليمتر مربع (mm²)', factorToBase: 1e-6 },
      { id: 'hectare', nameAr: 'هكتار (Hectare)', factorToBase: 10000 },
      { id: 'acre', nameAr: 'فدان (Acre)', factorToBase: 4046.85642 },
      { id: 'sq_mile', nameAr: 'ميل مربع (sq mi)', factorToBase: 2589988.11 },
      { id: 'sq_ft', nameAr: 'قدم مربع (sq ft)', factorToBase: 0.09290304 },
      { id: 'sq_in', nameAr: 'بوصة مربعة (sq in)', factorToBase: 0.00064516 },
    ],
  },
  volume: {
    nameAr: 'الحجم',
    icon: Box,
    baseUnit: 'لتر',
    units: [
      { id: 'l', nameAr: 'لتر (L)', factorToBase: 1 },
      { id: 'ml', nameAr: 'ميليلتر (ml)', factorToBase: 0.001 },
      { id: 'cubic_m', nameAr: 'متر مكعب (m³)', factorToBase: 1000 },
      { id: 'cubic_cm', nameAr: 'سنتيمتر مكعب (cm³)', factorToBase: 0.001 },
      { id: 'gal_us', nameAr: 'جالون أمريكي (US gal)', factorToBase: 3.78541 },
      { id: 'gal_uk', nameAr: 'جالون إمبراطوري (Imp gal)', factorToBase: 4.54609 },
      { id: 'floz_us', nameAr: 'أونصة سائلة أمريكية (US fl oz)', factorToBase: 0.0295735 },
      { id: 'cup', nameAr: 'كوب متري (Metric Cup)', factorToBase: 0.25 },
    ],
  },
  pressure: {
    nameAr: 'الضغط',
    icon: Wind,
    baseUnit: 'باسكال',
    units: [
      { id: 'pa', nameAr: 'باسكال (Pa)', factorToBase: 1 },
      { id: 'kpa', nameAr: 'كيلوباسكال (kPa)', factorToBase: 1000 },
      { id: 'mpa', nameAr: 'ميجاباسكال (MPa)', factorToBase: 1e6 },
      { id: 'bar', nameAr: 'بار (Bar)', factorToBase: 100000 },
      { id: 'psi', nameAr: 'رطل/بوصة مربعة (PSI)', factorToBase: 6894.75729 },
      { id: 'atm', nameAr: 'ضغط جوي (atm)', factorToBase: 101325 },
      { id: 'torr', nameAr: 'تور / ملم زئبق (Torr/mmHg)', factorToBase: 133.322368 },
    ],
  },
  energy: {
    nameAr: 'الطاقة',
    icon: Zap,
    baseUnit: 'جول',
    units: [
      { id: 'j', nameAr: 'جول (J)', factorToBase: 1 },
      { id: 'kj', nameAr: 'كيلوجول (kJ)', factorToBase: 1000 },
      { id: 'cal', nameAr: 'سعرة حرارية (cal)', factorToBase: 4.184 },
      { id: 'kcal', nameAr: 'كيلوكالوري (kcal)', factorToBase: 4184 },
      { id: 'wh', nameAr: 'واط ساعي (Wh)', factorToBase: 3600 },
      { id: 'kwh', nameAr: 'كيلوواط ساعي (kWh)', factorToBase: 3.6e6 },
      { id: 'ev', nameAr: 'إلكترون فولت (eV)', factorToBase: 1.60217663e-19 },
    ],
  },
  power: {
    nameAr: 'القدرة',
    icon: Zap,
    baseUnit: 'واط',
    units: [
      { id: 'w', nameAr: 'واط (W)', factorToBase: 1 },
      { id: 'kw', nameAr: 'كيلوواط (kW)', factorToBase: 1000 },
      { id: 'mw', nameAr: 'ميجاواط (MW)', factorToBase: 1e6 },
      { id: 'hp_m', nameAr: 'حصان متري (Metric hp)', factorToBase: 735.49875 },
      { id: 'hp_i', nameAr: 'حصان ميكانيكي (Mech hp)', factorToBase: 745.699872 },
    ],
  },
  angle: {
    nameAr: 'الزوايا',
    icon: Compass,
    baseUnit: 'درجة',
    units: [
      { id: 'deg', nameAr: 'درجة (Degree)', factorToBase: 1 },
      { id: 'rad', nameAr: 'راديان (Radian)', factorToBase: 57.295779513 },
      { id: 'grad', nameAr: 'جراديان (Gradian)', factorToBase: 0.9 },
      { id: 'min', nameAr: 'دقيقة قوسية (Arcmin)', factorToBase: 1 / 60 },
      { id: 'sec', nameAr: 'ثانية قوسية (Arcsec)', factorToBase: 1 / 3600 },
    ],
  },
  force: {
    nameAr: 'القوة',
    icon: Zap,
    baseUnit: 'نيوتن',
    units: [
      { id: 'n', nameAr: 'نيوتن (Newton)', factorToBase: 1 },
      { id: 'kn', nameAr: 'كيلونيوتن (kN)', factorToBase: 1000 },
      { id: 'lbf', nameAr: 'باوند-قوة (lbf)', factorToBase: 4.44822162 },
      { id: 'kgf', nameAr: 'كيلوجرام-قوة (kgf)', factorToBase: 9.80665 },
    ],
  },
  dataRate: {
    nameAr: 'نقل البيانات',
    icon: HardDrive,
    baseUnit: 'بت/ثانية',
    units: [
      { id: 'bps', nameAr: 'بت/ث (bps)', factorToBase: 1 },
      { id: 'kbps', nameAr: 'كيلوبت/ث (kbps)', factorToBase: 1000 },
      { id: 'mbps', nameAr: 'ميجابت/ث (Mbps)', factorToBase: 1e6 },
      { id: 'gbps', nameAr: 'جيجابت/ث (Gbps)', factorToBase: 1e9 },
      { id: 'Bps', nameAr: 'بايت/ث (B/s)', factorToBase: 8 },
      { id: 'KBps', nameAr: 'كيلوبايت/ث (KB/s)', factorToBase: 8000 },
      { id: 'MBps', nameAr: 'ميجابايت/ث (MB/s)', factorToBase: 8e6 },
      { id: 'GBps', nameAr: 'جيجابايت/ث (GB/s)', factorToBase: 8e9 },
    ],
  },
  fuel: {
    nameAr: 'استهلاك الوقود',
    icon: Droplet,
    baseUnit: 'لتر/100كم',
    units: [
      { id: 'l100km', nameAr: 'لتر لكل 100 كم (L/100km)', factorToBase: 1 },
      { id: 'km_l', nameAr: 'كيلومتر لكل لتر (km/L)', factorToBase: 1 },
      { id: 'mpg_us', nameAr: 'ميل/جالون أمريكي (MPG US)', factorToBase: 1 },
      { id: 'mpg_uk', nameAr: 'ميل/جالون بريطاني (MPG UK)', factorToBase: 1 },
    ],
  },
};

export function UnitConverter() {
  const [category, setCategory] = useState<UnitCategory>('length');
  const [inputValue, setInputValue] = useState<number>(1);
  const [fromUnit, setFromUnit] = useState<string>('km');
  const [toUnit, setToUnit] = useState<string>('m');

  const currentGroup = UNIT_GROUPS[category];

  // Calculate conversion
  const calculateResult = () => {
    if (category === 'temp') {
      let c = inputValue;
      if (fromUnit === 'f') c = (inputValue - 32) * (5 / 9);
      if (fromUnit === 'k') c = inputValue - 273.15;

      if (toUnit === 'c') return c;
      if (toUnit === 'f') return (c * 9) / 5 + 32;
      if (toUnit === 'k') return c + 273.15;
      return c;
    }

    if (category === 'fuel') {
      // Base is L/100km
      let l100 = inputValue;
      if (fromUnit === 'km_l') l100 = inputValue === 0 ? 0 : 100 / inputValue;
      if (fromUnit === 'mpg_us') l100 = inputValue === 0 ? 0 : 235.214583 / inputValue;
      if (fromUnit === 'mpg_uk') l100 = inputValue === 0 ? 0 : 282.480936 / inputValue;

      if (toUnit === 'l100km') return l100;
      if (toUnit === 'km_l') return l100 === 0 ? 0 : 100 / l100;
      if (toUnit === 'mpg_us') return l100 === 0 ? 0 : 235.214583 / l100;
      if (toUnit === 'mpg_uk') return l100 === 0 ? 0 : 282.480936 / l100;
      return l100;
    }

    const fromDef = currentGroup.units.find((u) => u.id === fromUnit);
    const toDef = currentGroup.units.find((u) => u.id === toUnit);
    if (!fromDef || !toDef) return 0;

    const baseVal = inputValue * fromDef.factorToBase;
    return baseVal / toDef.factorToBase;
  };

  const handleSwapUnits = () => {
    const temp = fromUnit;
    setFromUnit(toUnit);
    setToUnit(temp);
  };

  const result = calculateResult();

  return (
    <div className="space-y-6" id="unit-converter-tool">
      {/* Category Pills */}
      <div className="flex flex-wrap gap-2">
        {(Object.keys(UNIT_GROUPS) as UnitCategory[]).map((catKey) => {
          const cat = UNIT_GROUPS[catKey];
          const Icon = cat.icon;
          const isActive = category === catKey;
          return (
            <button
              key={catKey}
              onClick={() => {
                setCategory(catKey);
                setFromUnit(UNIT_GROUPS[catKey].units[0].id);
                setToUnit(UNIT_GROUPS[catKey].units[1]?.id || UNIT_GROUPS[catKey].units[0].id);
              }}
              className={`grow min-w-[120px] p-2.5 rounded-xl border text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                isActive
                  ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:border-emerald-400'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{cat.nameAr}</span>
            </button>
          );
        })}
      </div>

      {/* Main Conversion Block */}
      <div className="p-5 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-2xl space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-12 gap-3 items-center">
          {/* From */}
          <div className="sm:col-span-5 space-y-2">
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">من:</label>
            <input
              type="number"
              value={inputValue}
              onChange={(e) => setInputValue(Number(e.target.value))}
              className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 font-mono text-base font-bold"
            />
            <select
              value={fromUnit}
              onChange={(e) => setFromUnit(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-xs font-bold"
            >
              {currentGroup.units.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.nameAr}
                </option>
              ))}
            </select>
          </div>

          {/* Swap Button */}
          <div className="sm:col-span-2 flex justify-center py-2 sm:py-0">
            <button
              onClick={handleSwapUnits}
              className="p-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-full hover:border-emerald-500 hover:text-emerald-600 transition shadow-xs"
              title="تبديل الوحدات"
            >
              <ArrowRightLeft className="w-4 h-4" />
            </button>
          </div>

          {/* To */}
          <div className="sm:col-span-5 space-y-2">
            <label className="block text-xs font-bold text-emerald-600 dark:text-emerald-400">إلى:</label>
            <div className="w-full p-2.5 rounded-xl border border-emerald-300 dark:border-emerald-800 bg-white dark:bg-gray-900 font-mono text-base font-extrabold text-emerald-600 dark:text-emerald-400 truncate">
              {Number(result.toFixed(6)).toLocaleString('ar-EG')}
            </div>
            <select
              value={toUnit}
              onChange={(e) => setToUnit(e.target.value)}
              className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-xs font-bold"
            >
              {currentGroup.units.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.nameAr}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Live All-Units Table for the category */}
      <div className="space-y-2">
        <h4 className="text-xs font-bold text-gray-700 dark:text-gray-300">
          جدول التحويل لجميع وحدات {currentGroup.nameAr} المقابلة لقيمتك:
        </h4>
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-2.5">
          {currentGroup.units.map((u) => {
            let val = 0;
            if (category === 'temp') {
              let c = inputValue;
              if (fromUnit === 'f') c = (inputValue - 32) * (5 / 9);
              if (fromUnit === 'k') c = inputValue - 273.15;
              if (u.id === 'c') val = c;
              else if (u.id === 'f') val = (c * 9) / 5 + 32;
              else if (u.id === 'k') val = c + 273.15;
            } else if (category === 'fuel') {
              let l100 = inputValue;
              if (fromUnit === 'km_l') l100 = inputValue === 0 ? 0 : 100 / inputValue;
              if (fromUnit === 'mpg_us') l100 = inputValue === 0 ? 0 : 235.214583 / inputValue;
              if (fromUnit === 'mpg_uk') l100 = inputValue === 0 ? 0 : 282.480936 / inputValue;

              if (u.id === 'l100km') val = l100;
              else if (u.id === 'km_l') val = l100 === 0 ? 0 : 100 / l100;
              else if (u.id === 'mpg_us') val = l100 === 0 ? 0 : 235.214583 / l100;
              else if (u.id === 'mpg_uk') val = l100 === 0 ? 0 : 282.480936 / l100;
            } else {
              const fromDef = currentGroup.units.find((item) => item.id === fromUnit);
              if (fromDef) {
                const baseVal = inputValue * fromDef.factorToBase;
                val = baseVal / u.factorToBase;
              }
            }

            return (
              <div
                key={u.id}
                className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/60 dark:border-gray-700/60"
              >
                <div className="text-[11px] text-gray-500 dark:text-gray-400">{u.nameAr}</div>
                <div className="font-mono text-sm font-bold text-gray-800 dark:text-gray-200 truncate mt-1">
                  {Number(val.toFixed(4)).toLocaleString('ar-EG')}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
