import React, { useState } from 'react';
import { Copy, Check, Sparkles, RefreshCw, FileText } from 'lucide-react';
import confetti from 'canvas-confetti';

const ARABIC_PARAGRAPHS = [
  'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربى، حيث يمكنك أن تولد مثل هذا النص أو العديد من النصوص الأخرى إضافة إلى زيادة عدد الحروف التى يولدها التطبيق. إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك مولد النص العربى زيادة عدد الفقرات كما تريد.',
  'يمثل المحتوى الجيد الركيزة الأساسية لأي مشروع رقمي ناجح، حيث يمنح المصممين والمطورين تصوراً حقيقياً للشكل النهائي للواجهات قبل إدراج النصوص الرسمية. تتيح لك هذه المنصة توليد نصوص باللغة العربية الفصحى البليغة المتناسقة لملء القوالب وتجربة توزيع الكتل التصميمية وتناسق الخطوط.',
  'تعتبر الطباعة الرقمية وتنسيق النصوص فنّاً قائماً بذاته يتطلب مراعاة المسافات بين الحروف والكلمات وارتفاع الأسطر، واستخدام نصوص محاكاة عربية واقعية يساعد على اتخاذ القرارات الصحيحة في اختيار أحجام الخطوط والعناوين والهوامش بطريقة بصرية احترافية ومتوازنة.',
  'في عالم التصميم العصري، تتكامل واجهات المستخدم السلسة مع التجربة البصرية الممتازة لإبراز جماليات اللغة العربية وفنون خطوطها المتنوعة من الكوفي والنسخ والخطوط الحديثة، موفرة بذلك أداة عملية تسرع وتيرة التطوير والابتكار في المشاريع البرمجية والإعلامية.',
  'إن تجربة المستخدم المثالية تبدأ بالتخطيط الدقيق للنماذج الأولية، ووجود نصوص بديلة سلسة وذات معنى سياقي يضمن فهم الهيكل المعماري للموقع أو التطبيق دون تشتيت الانتباه بالتفاصيل التحريرية أثناء مراحل التصميم الأولى.',
];

const LATIN_PARAGRAPHS = [
  'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.',
  'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.',
  'Curabitur pretium tincidunt lacus. Nulla gravida orci a odio. Nullam varius, turpis et commodo pharetra, est eros bibendum elit, nec luctus magna felis sollicitudin mauris. Integer in mauris eu nibh euismod gravida.',
  'Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Proin pharetra nonummy pede. Mauris et orci. Aenean nec lorem. In porttitor. Donec laoreet nonummy augue.',
];

export function LoremGenerator() {
  const [lang, setLang] = useState<'ar' | 'en'>('ar');
  const [count, setCount] = useState<number>(3);
  const [unit, setUnit] = useState<'paragraphs' | 'words'>('paragraphs');
  const [copied, setCopied] = useState(false);

  const generateContent = () => {
    const source = lang === 'ar' ? ARABIC_PARAGRAPHS : LATIN_PARAGRAPHS;

    if (unit === 'paragraphs') {
      const result: string[] = [];
      for (let i = 0; i < count; i++) {
        result.push(source[i % source.length]);
      }
      return result.join('\n\n');
    } else {
      // words count
      const allWords = source.join(' ').split(/\s+/);
      const selectedWords = [];
      for (let i = 0; i < count; i++) {
        selectedWords.push(allWords[i % allWords.length]);
      }
      return selectedWords.join(' ') + (lang === 'ar' ? '.' : '.');
    }
  };

  const text = generateContent();

  const handleCopy = () => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    confetti({ particleCount: 30, spread: 45, origin: { y: 0.8 } });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6" id="lorem-generator-tool">
      {/* Controls Header */}
      <div className="p-4 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-xl space-y-4">
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
              لغة النص التجريبي:
            </label>
            <div className="flex rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-800">
              <button
                onClick={() => setLang('ar')}
                className={`flex-1 py-1.5 text-xs font-semibold transition ${
                  lang === 'ar'
                    ? 'bg-emerald-600 text-white'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
              >
                اللغة العربية
              </button>
              <button
                onClick={() => setLang('en')}
                className={`flex-1 py-1.5 text-xs font-semibold transition ${
                  lang === 'en'
                    ? 'bg-emerald-600 text-white'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
              >
                Latin (English)
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
              نوع التوليد:
            </label>
            <div className="flex rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-800">
              <button
                onClick={() => {
                  setUnit('paragraphs');
                  setCount(3);
                }}
                className={`flex-1 py-1.5 text-xs font-semibold transition ${
                  unit === 'paragraphs'
                    ? 'bg-emerald-600 text-white'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
              >
                فقرات
              </button>
              <button
                onClick={() => {
                  setUnit('words');
                  setCount(50);
                }}
                className={`flex-1 py-1.5 text-xs font-semibold transition ${
                  unit === 'words'
                    ? 'bg-emerald-600 text-white'
                    : 'text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700'
                }`}
              >
                كلمات
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
              العدد ({unit === 'paragraphs' ? 'فقرات' : 'كلمة'}):
            </label>
            <input
              type="number"
              min={1}
              max={unit === 'paragraphs' ? 20 : 500}
              value={count}
              onChange={(e) => setCount(Math.max(1, parseInt(e.target.value) || 1))}
              className="w-full p-1.5 text-xs font-bold rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 text-center"
            />
          </div>
        </div>
      </div>

      {/* Generated Result Container */}
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
          <span className="font-semibold text-gray-700 dark:text-gray-300">النص المولد:</span>
          <button
            onClick={handleCopy}
            className="px-3 py-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-100/60 dark:bg-emerald-950/50 hover:bg-emerald-200/70 rounded-lg transition flex items-center gap-1.5 font-bold"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'تم النسخ بنجاح!' : 'نسخ النص المولد'}
          </button>
        </div>

        <textarea
          value={text}
          readOnly
          dir={lang === 'ar' ? 'rtl' : 'ltr'}
          rows={9}
          className="w-full p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 outline-none text-sm leading-relaxed"
        />
      </div>
    </div>
  );
}
