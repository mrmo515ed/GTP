import React, { useState, useMemo } from 'react';
import {
  Copy,
  Check,
  RotateCcw,
  Sparkles,
  ArrowUpDown,
  ListFilter,
  Link as LinkIcon,
  Mail,
  FileText,
  Split,
  GitCompare,
  Trash2,
  Share2,
  FileDown
} from 'lucide-react';

interface Props {
  defaultTab?:
    | 'extra-spaces'
    | 'word-counter'
    | 'case-converter'
    | 'reverse-text'
    | 'remove-duplicates'
    | 'extract-urls'
    | 'extract-emails'
    | 'sort-lines'
    | 'merge-lines'
    | 'split-text'
    | 'text-diff'
    | 'lorem-generator';
}

export function TextProcessingSuite({ defaultTab = 'extra-spaces' }: Props) {
  const [activeTab, setActiveTab] = useState<string>(defaultTab);
  const [inputText, setInputText] = useState<string>('مرحباً بك في منصة الأدوات السريعة! يمكنك تجربة كافة أدوات معالجة النصوص بسهولة.');
  const [secondText, setSecondText] = useState<string>('مرحباً بك في منصة الأدوات السريعة الرائعة! يمكنك تجربة كافة أدوات معالجة وتنسيق النصوص بسهولة وسرعة.');
  const [copied, setCopied] = useState(false);
  const [joinSeparator, setJoinSeparator] = useState<string>(' ');
  const [splitDelimiter, setSplitDelimiter] = useState<string>(',');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc' | 'length-asc' | 'length-desc'>('asc');
  const [loremCount, setLoremCount] = useState<number>(3);
  const [loremType, setLoremType] = useState<'paragraphs' | 'sentences' | 'words'>('paragraphs');
  const [loremLang, setLoremLang] = useState<'ar' | 'la'>('ar');

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // 1. Remove extra spaces
  const cleanSpacesResult = useMemo(() => {
    return inputText
      .split('\n')
      .map(line => line.replace(/\s+/g, ' ').trim())
      .filter(line => line.length > 0)
      .join('\n');
  }, [inputText]);

  // 2. Word & char stats
  const stats = useMemo(() => {
    const charsWithSpaces = inputText.length;
    const charsWithoutSpaces = inputText.replace(/\s+/g, '').length;
    const words = inputText.trim() ? inputText.trim().split(/\s+/).length : 0;
    const lines = inputText ? inputText.split('\n').length : 0;
    const paragraphs = inputText.split(/\n+/).filter(p => p.trim().length > 0).length;
    const readingTimeMin = Math.ceil(words / 200);
    return { charsWithSpaces, charsWithoutSpaces, words, lines, paragraphs, readingTimeMin };
  }, [inputText]);

  // 3. Case converter
  const caseResults = useMemo(() => {
    const text = inputText;
    return {
      upper: text.toUpperCase(),
      lower: text.toLowerCase(),
      title: text.replace(/\w\S*/g, w => w.charAt(0).toUpperCase() + w.substring(1).toLowerCase()),
      sentence: text.toLowerCase().replace(/(^\s*\w|[.!?]\s*\w)/g, c => c.toUpperCase()),
      camel: text.toLowerCase().replace(/[^a-zA-Z0-9]+(.)/g, (_, chr) => chr.toUpperCase()),
      snake: text.trim().toLowerCase().replace(/[\s\W-]+/g, '_'),
      kebab: text.trim().toLowerCase().replace(/[\s\W-]+/g, '-'),
      pascal: text.replace(/(^\w|\s+\w)/g, w => w.trim().toUpperCase())
    };
  }, [inputText]);

  // 4. Reverse Text
  const reverseResults = useMemo(() => {
    const chars = inputText.split('').reverse().join('');
    const words = inputText.split(/\s+/).reverse().join(' ');
    const lines = inputText.split('\n').reverse().join('\n');
    return { chars, words, lines };
  }, [inputText]);

  // 5. Remove duplicates
  const deduplicateResult = useMemo(() => {
    const lines = inputText.split('\n');
    const seen = new Set<string>();
    const uniqueLines: string[] = [];
    let dupCount = 0;
    for (const l of lines) {
      const trimmed = l.trim();
      if (!seen.has(trimmed)) {
        seen.add(trimmed);
        uniqueLines.push(l);
      } else {
        dupCount++;
      }
    }
    return { text: uniqueLines.join('\n'), dupCount, uniqueCount: uniqueLines.length };
  }, [inputText]);

  // 6. Extract URLs
  const extractedUrls = useMemo(() => {
    const urlRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}(?:\/[^\s]*)?)/gi;
    const matches = inputText.match(urlRegex) || [];
    return Array.from(new Set(matches));
  }, [inputText]);

  // 7. Extract Emails
  const extractedEmails = useMemo(() => {
    const emailRegex = /([a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+)/gi;
    const matches = inputText.match(emailRegex) || [];
    return Array.from(new Set(matches));
  }, [inputText]);

  // 8. Sort Lines
  const sortedLines = useMemo(() => {
    const lines = inputText.split('\n').filter(l => l.trim().length > 0);
    if (sortOrder === 'asc') {
      return [...lines].sort((a, b) => a.localeCompare(b, 'ar')).join('\n');
    } else if (sortOrder === 'desc') {
      return [...lines].sort((a, b) => b.localeCompare(a, 'ar')).join('\n');
    } else if (sortOrder === 'length-asc') {
      return [...lines].sort((a, b) => a.length - b.length).join('\n');
    } else {
      return [...lines].sort((a, b) => b.length - a.length).join('\n');
    }
  }, [inputText, sortOrder]);

  // 9. Merge Lines
  const mergedLines = useMemo(() => {
    return inputText
      .split('\n')
      .map(l => l.trim())
      .filter(l => l.length > 0)
      .join(joinSeparator === '\\n' ? '\n' : joinSeparator);
  }, [inputText, joinSeparator]);

  // 10. Split Text
  const splitResult = useMemo(() => {
    const delim = splitDelimiter === '\\n' ? '\n' : splitDelimiter;
    return inputText.split(delim).map(part => part.trim()).filter(Boolean).join('\n');
  }, [inputText, splitDelimiter]);

  // 11. Text Diff
  const diffResult = useMemo(() => {
    const lines1 = inputText.split('\n');
    const lines2 = secondText.split('\n');
    const max = Math.max(lines1.length, lines2.length);
    const comparison = [];
    for (let i = 0; i < max; i++) {
      const l1 = lines1[i] !== undefined ? lines1[i] : null;
      const l2 = lines2[i] !== undefined ? lines2[i] : null;
      if (l1 === l2) {
        comparison.push({ type: 'same', text1: l1, text2: l2 });
      } else if (l1 !== null && l2 === null) {
        comparison.push({ type: 'deleted', text1: l1, text2: '' });
      } else if (l1 === null && l2 !== null) {
        comparison.push({ type: 'added', text1: '', text2: l2 });
      } else {
        comparison.push({ type: 'modified', text1: l1, text2: l2 });
      }
    }
    return comparison;
  }, [inputText, secondText]);

  // 12. Lorem generator
  const generatedLorem = useMemo(() => {
    const arabicSentences = [
      'هذا النص هو مثال لنص يمكن أن يستبدل في نفس المساحة، لقد تم توليد هذا النص من مولد النص العربي.',
      'إذا كنت تحتاج إلى عدد أكبر من الفقرات يتيح لك هذا الموقع زيادة عدد الفقرات كما تريد.',
      'النص لن يبدو مقسما ولا يحوي أخطاء لغوية، مولد النص العربي مفيد لمصممي الجرافيك والمواقع.',
      'يعمل هذا النص كأداة معاينة واقعية لتصميم واجهات المستخدم والمنشورات الطباعية.',
      'تتيح منصة الأدوات معالجة النصوص بأعلى سرعة واحترافية وبشكل فوري.'
    ];
    const latinSentences = [
      'Lorem ipsum dolor sit amet, consectetur adipiscing elit.',
      'Sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.',
      'Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris.',
      'Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore.',
      'Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia.'
    ];

    const source = loremLang === 'ar' ? arabicSentences : latinSentences;
    if (loremType === 'paragraphs') {
      return Array.from({ length: loremCount }, () => source.join(' ')).join('\n\n');
    } else if (loremType === 'sentences') {
      return Array.from({ length: loremCount }, (_, i) => source[i % source.length]).join(' ');
    } else {
      const words = source.join(' ').split(' ');
      return words.slice(0, Math.min(loremCount, words.length)).join(' ');
    }
  }, [loremCount, loremType, loremLang]);

  const tabs = [
    { id: 'extra-spaces', label: 'إزالة المسافات الزائدة', icon: Sparkles },
    { id: 'word-counter', label: 'عداد الكلمات والحروف', icon: FileText },
    { id: 'case-converter', label: 'حالة الأحرف', icon: ArrowUpDown },
    { id: 'reverse-text', label: 'عكس النص', icon: RotateCcw },
    { id: 'remove-duplicates', label: 'حذف الأسطر المكررة', icon: Trash2 },
    { id: 'extract-urls', label: 'استخراج الروابط', icon: LinkIcon },
    { id: 'extract-emails', label: 'استخراج الإيميلات', icon: Mail },
    { id: 'sort-lines', label: 'ترتيب النص أبجدياً', icon: ListFilter },
    { id: 'merge-lines', label: 'دمج الأسطر', icon: ArrowUpDown },
    { id: 'split-text', label: 'تقسيم النص', icon: Split },
    { id: 'text-diff', label: 'مقارنة نصين', icon: GitCompare },
    { id: 'lorem-generator', label: 'مولد نصوص Lorem', icon: FileDown },
  ];

  return (
    <div className="space-y-6" id="text-processing-suite">
      {/* Tab Navigation */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-200 dark:scrollbar-thumb-gray-800">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/60 border border-gray-200/80 dark:border-gray-700/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Main Container */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left / Input Column */}
        <div className={activeTab === 'text-diff' ? 'lg:col-span-6 space-y-4' : activeTab === 'lorem-generator' ? 'lg:col-span-5 space-y-4' : 'lg:col-span-6 space-y-4'}>
          <div className="bg-white dark:bg-gray-800/90 rounded-2xl border border-gray-200/80 dark:border-gray-700/70 p-5 shadow-sm space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-gray-700 dark:text-gray-200 flex items-center gap-1.5">
                <FileText className="w-4 h-4 text-emerald-600" />
                {activeTab === 'text-diff' ? 'النص الأول (الأصلي)' : activeTab === 'lorem-generator' ? 'إعدادات توليد النص' : 'النص المدخل'}
              </label>
              {activeTab !== 'lorem-generator' && (
                <button
                  onClick={() => setInputText('')}
                  className="text-[11px] font-bold text-gray-400 hover:text-red-500 transition-colors"
                >
                  مسح النص
                </button>
              )}
            </div>

            {activeTab === 'lorem-generator' ? (
              <div className="space-y-4 pt-2">
                <div>
                  <label className="block text-xs font-bold text-gray-600 dark:text-gray-300 mb-1">اللغة</label>
                  <div className="grid grid-cols-2 gap-2">
                    <button
                      onClick={() => setLoremLang('ar')}
                      className={`py-2 px-3 rounded-xl text-xs font-bold transition-all ${loremLang === 'ar' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
                    >
                      اللغة العربية
                    </button>
                    <button
                      onClick={() => setLoremLang('la')}
                      className={`py-2 px-3 rounded-xl text-xs font-bold transition-all ${loremLang === 'la' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
                    >
                      Latin (Lorem Ipsum)
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-600 dark:text-gray-300 mb-1">نوع التوليد</label>
                  <div className="grid grid-cols-3 gap-2">
                    <button
                      onClick={() => setLoremType('paragraphs')}
                      className={`py-2 text-xs font-bold rounded-xl ${loremType === 'paragraphs' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
                    >
                      فقرات
                    </button>
                    <button
                      onClick={() => setLoremType('sentences')}
                      className={`py-2 text-xs font-bold rounded-xl ${loremType === 'sentences' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
                    >
                      جمل
                    </button>
                    <button
                      onClick={() => setLoremType('words')}
                      className={`py-2 text-xs font-bold rounded-xl ${loremType === 'words' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
                    >
                      كلمات
                    </button>
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-600 dark:text-gray-300 mb-1">
                    العدد: <span className="text-emerald-600">{loremCount}</span>
                  </label>
                  <input
                    type="range"
                    min="1"
                    max="20"
                    value={loremCount}
                    onChange={e => setLoremCount(Number(e.target.value))}
                    className="w-full accent-emerald-600"
                  />
                </div>
              </div>
            ) : (
              <textarea
                value={inputText}
                onChange={e => setInputText(e.target.value)}
                placeholder="اكتب أو الصق النص هنا..."
                rows={10}
                className="w-full p-3.5 bg-gray-50 dark:bg-gray-900/90 text-gray-900 dark:text-gray-100 rounded-xl border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-sans text-sm resize-y leading-relaxed outline-none"
              />
            )}

            {/* Sub Controls for specific tabs */}
            {activeTab === 'sort-lines' && (
              <div className="pt-2 border-t border-gray-100 dark:border-gray-700/60">
                <label className="block text-xs font-bold text-gray-600 dark:text-gray-300 mb-2">نوع الترتيب</label>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  <button
                    onClick={() => setSortOrder('asc')}
                    className={`p-2 rounded-xl text-xs font-bold ${sortOrder === 'asc' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
                  >
                    أبجدي (أ - ي)
                  </button>
                  <button
                    onClick={() => setSortOrder('desc')}
                    className={`p-2 rounded-xl text-xs font-bold ${sortOrder === 'desc' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
                  >
                    أبجدي (ي - أ)
                  </button>
                  <button
                    onClick={() => setSortOrder('length-asc')}
                    className={`p-2 rounded-xl text-xs font-bold ${sortOrder === 'length-asc' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
                  >
                    الطول (تصاعدي)
                  </button>
                  <button
                    onClick={() => setSortOrder('length-desc')}
                    className={`p-2 rounded-xl text-xs font-bold ${sortOrder === 'length-desc' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
                  >
                    الطول (تنازلي)
                  </button>
                </div>
              </div>
            )}

            {activeTab === 'merge-lines' && (
              <div className="pt-2 border-t border-gray-100 dark:border-gray-700/60">
                <label className="block text-xs font-bold text-gray-600 dark:text-gray-300 mb-1">الفاصل بين الأسطر المدمجة</label>
                <div className="flex gap-2">
                  {[' ', ', ', ' - ', ' | ', '\\n'].map(sep => (
                    <button
                      key={sep}
                      onClick={() => setJoinSeparator(sep)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold ${joinSeparator === sep ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
                    >
                      {sep === ' ' ? 'مسافة' : sep === '\\n' ? 'سطر جديد' : sep}
                    </button>
                  ))}
                  <input
                    type="text"
                    placeholder="فاصل مخصص"
                    value={joinSeparator}
                    onChange={e => setJoinSeparator(e.target.value)}
                    className="flex-1 px-3 py-1.5 text-xs bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>
              </div>
            )}

            {activeTab === 'split-text' && (
              <div className="pt-2 border-t border-gray-100 dark:border-gray-700/60">
                <label className="block text-xs font-bold text-gray-600 dark:text-gray-300 mb-1">رمز أو فاصل التقسيم</label>
                <div className="flex gap-2">
                  {[',', ' ', '-', '/', '|'].map(sep => (
                    <button
                      key={sep}
                      onClick={() => setSplitDelimiter(sep)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-bold ${splitDelimiter === sep ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
                    >
                      {sep === ' ' ? 'مسافة' : sep}
                    </button>
                  ))}
                  <input
                    type="text"
                    placeholder="فاصل مخصص"
                    value={splitDelimiter}
                    onChange={e => setSplitDelimiter(e.target.value)}
                    className="flex-1 px-3 py-1.5 text-xs bg-gray-50 dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-700 outline-none"
                  />
                </div>
              </div>
            )}
          </div>

          {/* Quick Counter Strip */}
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-2 text-center">
            <div className="bg-white dark:bg-gray-800 p-2.5 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm">
              <span className="text-[11px] text-gray-500 block">الكلمات</span>
              <span className="text-sm font-black text-emerald-600">{stats.words}</span>
            </div>
            <div className="bg-white dark:bg-gray-800 p-2.5 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm">
              <span className="text-[11px] text-gray-500 block">الحروف</span>
              <span className="text-sm font-black text-indigo-600">{stats.charsWithSpaces}</span>
            </div>
            <div className="bg-white dark:bg-gray-800 p-2.5 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm">
              <span className="text-[11px] text-gray-500 block">بدون مسافات</span>
              <span className="text-sm font-black text-amber-600">{stats.charsWithoutSpaces}</span>
            </div>
            <div className="bg-white dark:bg-gray-800 p-2.5 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm">
              <span className="text-[11px] text-gray-500 block">الأسطر</span>
              <span className="text-sm font-black text-purple-600">{stats.lines}</span>
            </div>
            <div className="bg-white dark:bg-gray-800 p-2.5 rounded-xl border border-gray-100 dark:border-gray-700 shadow-sm col-span-2 sm:col-span-1">
              <span className="text-[11px] text-gray-500 block">وقت القراءة</span>
              <span className="text-sm font-black text-rose-600">{stats.readingTimeMin} دقيقة</span>
            </div>
          </div>
        </div>

        {/* Right / Result Column */}
        <div className={activeTab === 'text-diff' ? 'lg:col-span-6 space-y-4' : activeTab === 'lorem-generator' ? 'lg:col-span-7 space-y-4' : 'lg:col-span-6 space-y-4'}>
          {activeTab === 'text-diff' ? (
            <div className="bg-white dark:bg-gray-800/90 rounded-2xl border border-gray-200/80 dark:border-gray-700/70 p-5 shadow-sm space-y-3">
              <label className="text-xs font-black text-gray-700 dark:text-gray-200 flex items-center gap-1.5">
                <GitCompare className="w-4 h-4 text-emerald-600" />
                النص الثاني (للمقارنة)
              </label>
              <textarea
                value={secondText}
                onChange={e => setSecondText(e.target.value)}
                placeholder="الصق النص الثاني لمقارنته مع الأول..."
                rows={10}
                className="w-full p-3.5 bg-gray-50 dark:bg-gray-900/90 text-gray-900 dark:text-gray-100 rounded-xl border border-gray-200 dark:border-gray-700 focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all font-sans text-sm resize-y leading-relaxed outline-none"
              />
            </div>
          ) : (
            <div className="bg-white dark:bg-gray-800/90 rounded-2xl border border-gray-200/80 dark:border-gray-700/70 p-5 shadow-sm space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-black text-gray-700 dark:text-gray-200 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  النتيجة والمعالجة
                </label>
                <button
                  onClick={() => {
                    let targetText = '';
                    if (activeTab === 'extra-spaces') targetText = cleanSpacesResult;
                    else if (activeTab === 'sort-lines') targetText = sortedLines;
                    else if (activeTab === 'merge-lines') targetText = mergedLines;
                    else if (activeTab === 'split-text') targetText = splitResult;
                    else if (activeTab === 'remove-duplicates') targetText = deduplicateResult.text;
                    else if (activeTab === 'extract-urls') targetText = extractedUrls.join('\n');
                    else if (activeTab === 'extract-emails') targetText = extractedEmails.join('\n');
                    else if (activeTab === 'lorem-generator') targetText = generatedLorem;
                    else targetText = inputText;
                    copyToClipboard(targetText);
                  }}
                  className="flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/50 px-3 py-1.5 rounded-lg hover:bg-emerald-100 transition-colors"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copied ? 'تم النسخ!' : 'نسخ النتيجة'}</span>
                </button>
              </div>

              {/* Specific tab results */}
              {activeTab === 'extra-spaces' && (
                <div className="space-y-2">
                  <textarea
                    readOnly
                    value={cleanSpacesResult}
                    rows={9}
                    className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 rounded-xl border border-gray-200 dark:border-gray-700 text-sm leading-relaxed"
                  />
                  <p className="text-[11px] text-gray-500">تم تنظيف المسافات الزائدة بين الكلمات وفي بدايات ونهايات الأسطر والفقرات الفارغة.</p>
                </div>
              )}

              {activeTab === 'case-converter' && (
                <div className="space-y-3 max-h-[360px] overflow-y-auto pr-1">
                  {[
                    { label: 'UPPERCASE (أحرف كبيرة)', val: caseResults.upper },
                    { label: 'lowercase (أحرف صغيرة)', val: caseResults.lower },
                    { label: 'Title Case (بداية كل كلمة حرف كبير)', val: caseResults.title },
                    { label: 'camelCase', val: caseResults.camel },
                    { label: 'snake_case', val: caseResults.snake },
                    { label: 'kebab-case', val: caseResults.kebab },
                    { label: 'PascalCase', val: caseResults.pascal }
                  ].map((item, idx) => (
                    <div key={idx} className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-700/60 flex items-center justify-between gap-3">
                      <div className="overflow-hidden">
                        <span className="text-[11px] font-bold text-gray-400 block">{item.label}</span>
                        <span className="text-xs font-mono text-gray-800 dark:text-gray-200 truncate block">{item.val}</span>
                      </div>
                      <button
                        onClick={() => copyToClipboard(item.val)}
                        className="p-1.5 text-gray-500 hover:text-emerald-600 rounded-lg hover:bg-gray-200 dark:hover:bg-gray-800 shrink-0"
                      >
                        <Copy className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  ))}
                </div>
              )}

              {activeTab === 'reverse-text' && (
                <div className="space-y-3">
                  <div>
                    <span className="text-[11px] font-bold text-gray-500 block mb-1">عكس الحروف بالكامل</span>
                    <textarea readOnly value={reverseResults.chars} rows={3} className="w-full p-2.5 bg-gray-50 dark:bg-gray-900 text-xs rounded-xl border border-gray-200 dark:border-gray-700" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-gray-500 block mb-1">عكس ترتيب الكلمات</span>
                    <textarea readOnly value={reverseResults.words} rows={3} className="w-full p-2.5 bg-gray-50 dark:bg-gray-900 text-xs rounded-xl border border-gray-200 dark:border-gray-700" />
                  </div>
                  <div>
                    <span className="text-[11px] font-bold text-gray-500 block mb-1">عكس ترتيب الأسطر</span>
                    <textarea readOnly value={reverseResults.lines} rows={3} className="w-full p-2.5 bg-gray-50 dark:bg-gray-900 text-xs rounded-xl border border-gray-200 dark:border-gray-700" />
                  </div>
                </div>
              )}

              {activeTab === 'remove-duplicates' && (
                <div className="space-y-2">
                  <div className="flex gap-2 text-xs font-bold">
                    <span className="text-emerald-600 bg-emerald-50 dark:bg-emerald-950/40 px-2 py-1 rounded-md">الأسطر الفريدة: {deduplicateResult.uniqueCount}</span>
                    <span className="text-amber-600 bg-amber-50 dark:bg-amber-950/40 px-2 py-1 rounded-md">المكررات المحذوفة: {deduplicateResult.dupCount}</span>
                  </div>
                  <textarea
                    readOnly
                    value={deduplicateResult.text}
                    rows={9}
                    className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 rounded-xl border border-gray-200 dark:border-gray-700 text-sm leading-relaxed"
                  />
                </div>
              )}

              {activeTab === 'extract-urls' && (
                <div className="space-y-2">
                  <span className="text-xs font-bold text-emerald-600">تم العثور على ({extractedUrls.length}) روابط:</span>
                  {extractedUrls.length > 0 ? (
                    <div className="space-y-1.5 max-h-[300px] overflow-y-auto">
                      {extractedUrls.map((url, i) => (
                        <div key={i} className="flex items-center justify-between p-2.5 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-700 text-xs">
                          <a href={url.startsWith('http') ? url : `https://${url}`} target="_blank" rel="noreferrer" className="text-blue-600 hover:underline truncate max-w-[80%]">
                            {url}
                          </a>
                          <button onClick={() => copyToClipboard(url)} className="p-1 text-gray-500 hover:text-emerald-600">
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-6 text-center text-xs text-gray-400 bg-gray-50 dark:bg-gray-900 rounded-xl border border-dashed border-gray-200 dark:border-gray-700">
                      لم يتم العثور على روابط في النص المدخل
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'extract-emails' && (
                <div className="space-y-2">
                  <span className="text-xs font-bold text-emerald-600">تم العثور على ({extractedEmails.length}) بريد إلكتروني:</span>
                  {extractedEmails.length > 0 ? (
                    <div className="space-y-1.5 max-h-[300px] overflow-y-auto">
                      {extractedEmails.map((email, i) => (
                        <div key={i} className="flex items-center justify-between p-2.5 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-700 text-xs font-mono">
                          <span className="text-indigo-600 dark:text-indigo-400 truncate max-w-[80%]">{email}</span>
                          <button onClick={() => copyToClipboard(email)} className="p-1 text-gray-500 hover:text-emerald-600">
                            <Copy className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <div className="p-6 text-center text-xs text-gray-400 bg-gray-50 dark:bg-gray-900 rounded-xl border border-dashed border-gray-200 dark:border-gray-700">
                      لم يتم العثور على أي بريد إلكتروني في النص
                    </div>
                  )}
                </div>
              )}

              {activeTab === 'sort-lines' && (
                <textarea
                  readOnly
                  value={sortedLines}
                  rows={9}
                  className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 rounded-xl border border-gray-200 dark:border-gray-700 text-sm leading-relaxed"
                />
              )}

              {activeTab === 'merge-lines' && (
                <textarea
                  readOnly
                  value={mergedLines}
                  rows={9}
                  className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 rounded-xl border border-gray-200 dark:border-gray-700 text-sm leading-relaxed"
                />
              )}

              {activeTab === 'split-text' && (
                <textarea
                  readOnly
                  value={splitResult}
                  rows={9}
                  className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 rounded-xl border border-gray-200 dark:border-gray-700 text-sm leading-relaxed"
                />
              )}

              {activeTab === 'lorem-generator' && (
                <textarea
                  readOnly
                  value={generatedLorem}
                  rows={10}
                  className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 rounded-xl border border-gray-200 dark:border-gray-700 text-sm leading-relaxed"
                />
              )}

              {activeTab === 'word-counter' && (
                <div className="space-y-4">
                  <div className="p-4 bg-emerald-50 dark:bg-emerald-950/30 rounded-xl border border-emerald-200 dark:border-emerald-800/40 text-xs text-emerald-800 dark:text-emerald-200 space-y-1">
                    <p className="font-bold">تحليل النص الإحصائي الشامل:</p>
                    <p>• يحتوي النص على {stats.words} كلمة مقسمة على {stats.paragraphs} فقرات و {stats.lines} أسطر.</p>
                    <p>• متوسط وقت القراءة التقديري: {stats.readingTimeMin} دقيقة (بمعدل 200 كلمة/دقيقة).</p>
                  </div>
                  <textarea
                    readOnly
                    value={inputText}
                    rows={7}
                    className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 text-gray-900 dark:text-gray-100 rounded-xl border border-gray-200 dark:border-gray-700 text-sm"
                  />
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Diff Result Table if in Diff Mode */}
      {activeTab === 'text-diff' && (
        <div className="bg-white dark:bg-gray-800/90 rounded-2xl border border-gray-200/80 dark:border-gray-700/70 p-5 shadow-sm space-y-3">
          <h3 className="text-xs font-black text-gray-700 dark:text-gray-200 flex items-center gap-1.5">
            <GitCompare className="w-4 h-4 text-emerald-600" />
            جدول المقارنة واكتشاف الفروقات سطراً بسطر
          </h3>
          <div className="rounded-xl overflow-hidden border border-gray-200 dark:border-gray-700 text-xs font-mono">
            <div className="grid grid-cols-2 bg-gray-100 dark:bg-gray-900/80 p-2 font-bold text-gray-600 dark:text-gray-300 border-b border-gray-200 dark:border-gray-700">
              <div>النص الأول (الأصلي)</div>
              <div>النص الثاني (المعدل)</div>
            </div>
            <div className="divide-y divide-gray-100 dark:divide-gray-800 max-h-[300px] overflow-y-auto">
              {diffResult.map((d, i) => (
                <div
                  key={i}
                  className={`grid grid-cols-2 p-2 ${
                    d.type === 'added'
                      ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-200'
                      : d.type === 'deleted'
                      ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-200'
                      : d.type === 'modified'
                      ? 'bg-amber-50 dark:bg-amber-950/40 text-amber-800 dark:text-amber-200'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300'
                  }`}
                >
                  <div className="pr-2 border-l border-gray-200/60 dark:border-gray-700/60 break-words">{d.text1 || '—'}</div>
                  <div className="pl-2 break-words">{d.text2 || '—'}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
