import React, { useState } from 'react';
import { Copy, Trash2, Check, ArrowUpDown, Filter, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

export function DuplicateRemover() {
  const [input, setInput] = useState(`تفاح
موز
برتقال
تفاح
عنب
موز
مانجو
فراولة
تفاح`);
  const [trimLines, setTrimLines] = useState(true);
  const [removeEmpty, setRemoveEmpty] = useState(true);
  const [caseSensitive, setCaseSensitive] = useState(false);
  const [sortOrder, setSortOrder] = useState<'none' | 'asc' | 'desc'>('none');
  const [copied, setCopied] = useState(false);

  const processLines = () => {
    let lines = input.split('\n');

    if (trimLines) {
      lines = lines.map((l) => l.trim());
    }

    if (removeEmpty) {
      lines = lines.filter((l) => l.length > 0);
    }

    // Remove duplicates
    const seen = new Set<string>();
    const uniqueLines: string[] = [];

    for (const line of lines) {
      const key = caseSensitive ? line : line.toLowerCase();
      if (!seen.has(key)) {
        seen.add(key);
        uniqueLines.push(line);
      }
    }

    // Sorting
    if (sortOrder === 'asc') {
      uniqueLines.sort((a, b) => a.localeCompare(b, 'ar'));
    } else if (sortOrder === 'desc') {
      uniqueLines.sort((a, b) => b.localeCompare(a, 'ar'));
    }

    return uniqueLines;
  };

  const outputLines = processLines();
  const rawCount = input.split('\n').length;
  const uniqueCount = outputLines.length;
  const removedDuplicatesCount = rawCount - uniqueCount;

  const handleCopy = () => {
    navigator.clipboard.writeText(outputLines.join('\n'));
    setCopied(true);
    confetti({ particleCount: 30, spread: 45, origin: { y: 0.8 } });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6" id="duplicate-remover-tool">
      {/* Controls */}
      <div className="p-4 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-xl space-y-3">
        <div className="flex flex-wrap gap-4 text-xs sm:text-sm text-gray-700 dark:text-gray-300">
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={trimLines}
              onChange={(e) => setTrimLines(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded"
            />
            <span>حذف المسافات الزائدة من البداية والنهاية</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={removeEmpty}
              onChange={(e) => setRemoveEmpty(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded"
            />
            <span>تجاهل الأسطر الفارغة</span>
          </label>
          <label className="flex items-center gap-2 cursor-pointer">
            <input
              type="checkbox"
              checked={caseSensitive}
              onChange={(e) => setCaseSensitive(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded"
            />
            <span>التمييز بين الحروف الكبيرة والصغيرة</span>
          </label>
        </div>

        <div className="flex flex-wrap items-center gap-3 pt-2 border-t border-emerald-200/50 dark:border-emerald-900/40">
          <span className="text-xs font-bold text-gray-700 dark:text-gray-300">الترتيب الأبجدي:</span>
          <button
            onClick={() => setSortOrder('none')}
            className={`px-2.5 py-1 text-xs rounded-lg transition ${
              sortOrder === 'none'
                ? 'bg-emerald-600 text-white font-bold'
                : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700'
            }`}
          >
            نفس الترتيب الأصلي
          </button>
          <button
            onClick={() => setSortOrder('asc')}
            className={`px-2.5 py-1 text-xs rounded-lg transition ${
              sortOrder === 'asc'
                ? 'bg-emerald-600 text-white font-bold'
                : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700'
            }`}
          >
            أبجدي تصاعدي (أ ← ي)
          </button>
          <button
            onClick={() => setSortOrder('desc')}
            className={`px-2.5 py-1 text-xs rounded-lg transition ${
              sortOrder === 'desc'
                ? 'bg-emerald-600 text-white font-bold'
                : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700'
            }`}
          >
            أبجدي تنازلي (ي ← أ)
          </button>
        </div>
      </div>

      {/* Grid Text areas */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
            <span className="font-semibold">القائمة الأصلية ({rawCount} سطر)</span>
            <button
              onClick={() => setInput('')}
              className="text-rose-500 hover:underline flex items-center gap-1 text-xs"
            >
              <Trash2 className="w-3 h-3" /> مسح
            </button>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            rows={8}
            className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-emerald-500 outline-none text-sm font-mono"
            placeholder="أدخل العناصر، كل عنصر في سطر منفصل..."
          />
        </div>

        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
            <span className="font-semibold text-emerald-600 dark:text-emerald-400">
              القائمة الفريدة ({uniqueCount} عنصر فريد | تم حذف {removedDuplicatesCount > 0 ? removedDuplicatesCount : 0} مكرر)
            </span>
            <button
              onClick={handleCopy}
              className="text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-bold text-xs"
            >
              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              {copied ? 'تم النسخ' : 'نسخ القائمة'}
            </button>
          </div>
          <textarea
            value={outputLines.join('\n')}
            readOnly
            rows={8}
            className="w-full p-3 rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50/20 dark:bg-gray-900 text-gray-900 dark:text-gray-100 outline-none text-sm font-mono"
            placeholder="ستظهر القائمة المنقاة هنا..."
          />
        </div>
      </div>
    </div>
  );
}
