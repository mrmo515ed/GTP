import React, { useState, useMemo } from 'react';
import {
  Sparkles,
  Bot,
  User,
  CheckCircle2,
  AlertTriangle,
  RefreshCw,
  Copy,
  Check,
  Trash2,
  HelpCircle,
  FileText,
  PieChart,
  BarChart3,
  ShieldAlert,
  ArrowRight,
  Lightbulb,
  Zap,
  Info
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface AnalysisResult {
  aiScore: number; // 0 to 100
  confidence: 'high' | 'medium' | 'low';
  humanScore: number;
  wordCount: number;
  sentenceCount: number;
  avgSentenceLength: number;
  sentenceLengthVariance: number;
  lexicalDiversity: number; // TTR
  burstinessScore: number;
  clicheMatches: string[];
  sentenceScores: { text: string; score: number; flag: 'likely-ai' | 'mixed' | 'likely-human' }[];
  summaryAr: string;
}

const COMMON_ARABIC_AI_CLICHES = [
  'في الختام',
  'ختاماً يمكن القول',
  'من الجدير بالذكر',
  'يلعب دوراً حاسماً',
  'تلعب دوراً محورياً',
  'حجر الزاوية',
  'سلاح ذو حدين',
  'لا يخفى على أحد',
  'في ظل التطور المتسارع',
  'على وجه الخصوص',
  'بشكل لا لبس فيه',
  'نسيج المجتمع',
  'يسلط الضوء على',
  'تفتح آفاقاً جديدة',
  'تجدر الإشارة إلى أن',
  'يجدر التنويه بأن',
  'من الأهمية بمكان',
  'على صعيد متصل',
  'من منظور شامل',
  'في هذا السياق'
];

const COMMON_ENGLISH_AI_CLICHES = [
  'in conclusion',
  'furthermore',
  'moreover',
  'it is important to note',
  'it is worth noting',
  'delve into',
  'testament to',
  'tapestry',
  'beacon of hope',
  'pivotal role',
  'crucial aspect',
  'ever-evolving landscape',
  'multifaceted',
  'holistic approach',
  'in summary',
  'fosters a sense of',
  'underscores the importance',
  'serves as a reminder',
  'unwavering commitment',
  'paradigm shift'
];

export function AITextDetector() {
  const [inputText, setInputText] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [result, setResult] = useState<AnalysisResult | null>(null);
  const [copied, setCopied] = useState<boolean>(false);
  const [activeViewMode, setActiveViewMode] = useState<'overview' | 'sentences' | 'metrics'>('overview');

  const sampleTexts = [
    {
      title: 'نموذج نص مولد بالذكاء الاصطناعي (AI)',
      text: 'في ظل التطور المتسارع الذي يشهده العالم اليوم، تلعب التكنولوجيا دوراً محورياً وحاسماً في تشكيل معالم المستقبل. ومن الجدير بالذكر أن الذكاء الاصطناعي لا يمثل مجرد أداة حسابية متقدمة، بل يعد حجر الزاوية في إحداث نقلة نوعية عبر مختلف القطاعات الحيوية. علاوة على ذلك، فإن تبني هذا النهج الشامل يفتح آفاقاً جديدة تسلط الضوء على أهمية الابتكار المستدام وتطوير القدرات البشرية. في الختام، يمكن القول إن الاستثمار الواعي في هذه التقنيات هو السبيل الأمثل لضمان مستقبل مزدهر.'
    },
    {
      title: 'نموذج نص مكتوب بأسلوب بشري طبيعي',
      text: 'أمس وأنا راجع من الدوام مريت على المكتبة القديمة اللي جنب بيتنا. شفت كتاب غريب عن تاريخ الزراعة باليمن قبل مية سنة، بصراحة شدني العنوان واشتريته على طول. قعدت أقرأ فيه وأنا أشرب شاي، والمعلومات اللي فيه كانت صادمة وممتعة جداً، خصوصاً طريقة توزيع المياه بين المزارعين. ما كنت متخيل أبداً إن عندهم نظام دقيق بهالشكل!'
    }
  ];

  const analyzeText = () => {
    if (!inputText.trim()) return;

    setIsAnalyzing(true);
    setResult(null);

    setTimeout(() => {
      const text = inputText.trim();
      const words = text.split(/\s+/).filter(Boolean);
      const sentences = text.split(/[.!?؟\n]+/).map(s => s.trim()).filter(s => s.length > 3);

      const wordCount = words.length;
      const sentenceCount = sentences.length || 1;

      // 1. Average sentence length and variance
      const sentenceLengths = sentences.map(s => s.split(/\s+/).filter(Boolean).length);
      const avgSentenceLength = wordCount / sentenceCount;

      let varianceSum = 0;
      for (const len of sentenceLengths) {
        varianceSum += Math.pow(len - avgSentenceLength, 2);
      }
      const sentenceLengthVariance = sentenceLengths.length > 1 ? varianceSum / sentenceLengths.length : 15;

      // 2. Lexical Diversity (Type-Token Ratio)
      const uniqueWords = new Set(words.map(w => w.toLowerCase().replace(/^[^\w\u0600-\u06FF]+|[^\w\u0600-\u06FF]+$/g, '')));
      const lexicalDiversity = words.length > 0 ? (uniqueWords.size / words.length) : 1;

      // 3. Cliche Detection
      const lowerText = text.toLowerCase();
      const matchedCliches: string[] = [];
      [...COMMON_ARABIC_AI_CLICHES, ...COMMON_ENGLISH_AI_CLICHES].forEach(cliche => {
        if (lowerText.includes(cliche.toLowerCase())) {
          matchedCliches.push(cliche);
        }
      });

      // 4. Calculate Burstiness & Uniformity
      // AI text usually has very uniform sentence lengths (low variance) and lots of transition clichés
      let aiIndicators = 0;
      let maxPoints = 100;

      // Low sentence length variance -> AI like
      if (sentenceLengthVariance < 12) {
        aiIndicators += 25;
      } else if (sentenceLengthVariance < 25) {
        aiIndicators += 15;
      }

      // Cliche density
      const clichePoints = Math.min(35, matchedCliches.length * 10);
      aiIndicators += clichePoints;

      // Moderate-to-low lexical diversity with medium-long uniform sentences
      if (lexicalDiversity < 0.65 && avgSentenceLength > 12) {
        aiIndicators += 20;
      } else if (lexicalDiversity < 0.75) {
        aiIndicators += 10;
      }

      // Sentence structures & uniform transition words
      const formalTransitionMatches = (lowerText.match(/(علاوة على ذلك|بالإضافة إلى ذلك|من ناحية أخرى|من جهة ثانية|consequently|furthermore|moreover|in addition)/g) || []).length;
      if (formalTransitionMatches >= 2) {
        aiIndicators += 15;
      }

      // Base adjustments
      let finalAiScore = Math.min(96, Math.max(8, Math.round(aiIndicators + (matchedCliches.length > 0 ? 10 : 0))));

      // If text is very colloquial or has slang/emojis/extreme variance
      const hasColloquialPatterns = /([!؟]{2,}|هههه|والله|بصراحة|يا جماعة|شفت|رحت|أمس|يلا|ياخي|loool|omg|haha|tbh)/i.test(text);
      if (hasColloquialPatterns) {
        finalAiScore = Math.max(5, finalAiScore - 40);
      }

      if (sentenceLengthVariance > 60 && matchedCliches.length === 0) {
        finalAiScore = Math.max(5, finalAiScore - 25);
      }

      // Sentence level scores
      const sentenceScores = sentences.map(sent => {
        let sentAiScore = finalAiScore;
        const sentLower = sent.toLowerCase();
        const hasCliche = [...COMMON_ARABIC_AI_CLICHES, ...COMMON_ENGLISH_AI_CLICHES].some(c => sentLower.includes(c.toLowerCase()));
        const wordsInSent = sent.split(/\s+/).filter(Boolean).length;

        if (hasCliche) sentAiScore = Math.min(98, sentAiScore + 25);
        if (wordsInSent > 12 && wordsInSent < 24) sentAiScore = Math.min(95, sentAiScore + 10);
        if (wordsInSent < 6 || wordsInSent > 35) sentAiScore = Math.max(10, sentAiScore - 20);

        let flag: 'likely-ai' | 'mixed' | 'likely-human' = 'mixed';
        if (sentAiScore >= 65) flag = 'likely-ai';
        else if (sentAiScore <= 35) flag = 'likely-human';

        return {
          text: sent,
          score: sentAiScore,
          flag
        };
      });

      const humanScore = 100 - finalAiScore;
      const confidence: 'high' | 'medium' | 'low' = wordCount > 60 ? 'high' : wordCount > 25 ? 'medium' : 'low';

      let summaryAr = '';
      if (finalAiScore >= 70) {
        summaryAr = 'يُظهر النص مؤشرات واضحة وتراكيب نمطية تتوافق مع خصائص النصوص المولدة بأنظمة الذكاء الاصطناعي (مثل انتظام أطوال الجمل، وكثرة العبارات الانتقالية النمطية).';
      } else if (finalAiScore >= 40) {
        summaryAr = 'يحتوي النص على مزيج من التراكيب الطبيعية والعبارات المنتظمة؛ قد يكون نصاً بشرياً مصاغاً بأسلوب رسمي أو نصاً تم تحسينه بأدوات لغوية.';
      } else {
        summaryAr = 'يُظهر النص تبايناً حراً وعفوية لغوية عالية وتنوعاً كبيراً في الأسلوب يتوافق بشكل وثيق مع الأسلوب البشري الطبيعي.';
      }

      setResult({
        aiScore: finalAiScore,
        confidence,
        humanScore,
        wordCount,
        sentenceCount,
        avgSentenceLength: Math.round(avgSentenceLength * 10) / 10,
        sentenceLengthVariance: Math.round(sentenceLengthVariance * 10) / 10,
        lexicalDiversity: Math.round(lexicalDiversity * 100),
        burstinessScore: Math.round(sentenceLengthVariance),
        clicheMatches: matchedCliches,
        sentenceScores,
        summaryAr
      });

      setIsAnalyzing(false);

      if (finalAiScore < 40) {
        try {
          confetti({
            particleCount: 50,
            spread: 60,
            origin: { y: 0.8 }
          });
        } catch {
          // ignore
        }
      }
    }, 600);
  };

  const copyAnalysis = () => {
    if (!result) return;
    const report = `📊 تقرير تحليل كاشف النص الذكي:
- احتمالية التوافق مع الذكاء الاصطناعي (AI): ${result.aiScore}%
- احتمالية الأسلوب البشري: ${result.humanScore}%
- درجة الثقة: ${result.confidence === 'high' ? 'عالية' : result.confidence === 'medium' ? 'متوسطة' : 'منخفضة'}
- عدد الكلمات: ${result.wordCount} | عدد الجمل: ${result.sentenceCount}
- التنوع المعجمي: ${result.lexicalDiversity}%
- العبارات النمطية المكتشفة: ${result.clicheMatches.length > 0 ? result.clicheMatches.join(', ') : 'لا توجد'}

ملخص التحليل:
${result.summaryAr}

تم التحليل عبر منصة أدواتك السريعة.`;

    navigator.clipboard.writeText(report);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="w-full max-w-5xl mx-auto space-y-6">
      {/* Header Banner */}
      <div className="p-6 sm:p-8 rounded-3xl bg-gradient-to-br from-indigo-900 via-slate-900 to-gray-950 text-white border border-indigo-800/50 shadow-2xl relative overflow-hidden">
        <div className="absolute top-0 left-0 w-80 h-80 bg-indigo-500/10 rounded-full blur-3xl pointer-events-none" />
        <div className="relative z-10 space-y-3">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-indigo-500/20 border border-indigo-400/30 flex items-center justify-center text-indigo-300 shadow-inner">
              <Bot className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h1 className="text-xl sm:text-2xl font-black text-white">
                  كاشف النص الذكي — AI Text Detector
                </h1>
                <span className="px-2.5 py-0.5 rounded-full text-xs font-bold bg-indigo-500/30 text-indigo-200 border border-indigo-400/30">
                  تحليل احتمالي متقدم
                </span>
              </div>
              <p className="text-xs sm:text-sm text-indigo-200/80 mt-1">
                تحليل لغوي وإحصائي ذكي للكشف عن أنماط وخصائص النصوص المولدة بالذكاء الاصطناعي بدقة عالية.
              </p>
            </div>
          </div>

          <div className="pt-2 flex flex-wrap gap-2 text-xs text-indigo-300/90">
            <span className="flex items-center gap-1 bg-white/5 px-2.5 py-1 rounded-lg border border-white/10">
              <Zap className="w-3.5 h-3.5 text-amber-400" />
              <span>فحص الحيرة (Perplexity)</span>
            </span>
            <span className="flex items-center gap-1 bg-white/5 px-2.5 py-1 rounded-lg border border-white/10">
              <BarChart3 className="w-3.5 h-3.5 text-emerald-400" />
              <span>تنوع المفردات والتراكيب</span>
            </span>
            <span className="flex items-center gap-1 bg-white/5 px-2.5 py-1 rounded-lg border border-white/10">
              <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
              <span>كشف العبارات النمطية</span>
            </span>
          </div>
        </div>
      </div>

      {/* Main Input Area */}
      <div className="p-5 sm:p-7 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-sm space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-gray-100 dark:border-gray-800">
          <label className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <FileText className="w-4 h-4 text-indigo-600" />
            <span>ألصق النص المراد فحصه وتحليله:</span>
          </label>

          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs text-gray-500 dark:text-gray-400">
              {inputText.trim() ? `${inputText.trim().split(/\s+/).length} كلمة` : '0 كلمات'}
            </span>
            {inputText && (
              <button
                onClick={() => {
                  setInputText('');
                  setResult(null);
                }}
                className="px-2.5 py-1 rounded-lg text-xs font-semibold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition flex items-center gap-1"
              >
                <Trash2 className="w-3 h-3" />
                <span>مسح النص</span>
              </button>
            )}
          </div>
        </div>

        {/* Textarea */}
        <div className="relative">
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="اكتب أو ألصق المقال أو الفقرة هنا (يُفضل 30 كلمة فأكثر للحصول على دقة تحليل أعلى)..."
            rows={7}
            className="w-full p-4 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50/50 dark:bg-gray-950/60 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-indigo-500 focus:border-transparent outline-none transition text-sm sm:text-base leading-relaxed resize-y"
          />
        </div>

        {/* Sample Texts Selector & Action Button */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pt-2">
          <div className="flex items-center gap-2 flex-wrap text-xs text-gray-600 dark:text-gray-400">
            <span className="font-bold flex items-center gap-1">
              <Lightbulb className="w-3.5 h-3.5 text-amber-500" />
              <span>جرب نموذجاً:</span>
            </span>
            {sampleTexts.map((sample, idx) => (
              <button
                key={idx}
                onClick={() => {
                  setInputText(sample.text);
                }}
                className="px-2.5 py-1 rounded-lg bg-gray-100 dark:bg-gray-800 hover:bg-indigo-50 dark:hover:bg-indigo-950/40 hover:text-indigo-600 dark:hover:text-indigo-400 text-xs font-medium transition"
              >
                {sample.title}
              </button>
            ))}
          </div>

          <button
            onClick={analyzeText}
            disabled={!inputText.trim() || isAnalyzing}
            className={`px-6 py-3 rounded-2xl text-sm font-black transition-all flex items-center justify-center gap-2 shadow-lg ${
              !inputText.trim() || isAnalyzing
                ? 'bg-gray-200 dark:bg-gray-800 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-indigo-600 via-indigo-700 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white shadow-indigo-500/20 active:scale-95'
            }`}
          >
            {isAnalyzing ? (
              <>
                <RefreshCw className="w-4 h-4 animate-spin" />
                <span>جاري التحليل اللغوي الإحصائي...</span>
              </>
            ) : (
              <>
                <Bot className="w-4 h-4" />
                <span>تحليل النص وكشف النمط</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Analysis Results Display */}
      {result && (
        <div className="space-y-5 animate-in fade-in slide-in-from-bottom-3 duration-500">
          {/* Main Score Card */}
          <div className="p-6 sm:p-8 rounded-3xl bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 shadow-md space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 dark:border-gray-800 pb-4">
              <div>
                <span className="text-xs font-black text-indigo-600 dark:text-indigo-400 tracking-wide uppercase">
                  نتيجة التقييم الاحتمالي
                </span>
                <h3 className="text-lg sm:text-xl font-black text-gray-900 dark:text-white mt-0.5">
                  تقدير احتمالية توافق النص مع أنماط الذكاء الاصطناعي
                </h3>
              </div>

              <div className="flex items-center gap-2">
                <button
                  onClick={copyAnalysis}
                  className="px-3 py-1.5 rounded-xl border border-gray-200 dark:border-gray-700 hover:bg-gray-50 dark:hover:bg-gray-800 text-xs font-bold text-gray-700 dark:text-gray-300 transition flex items-center gap-1.5"
                >
                  {copied ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-500" />
                      <span className="text-emerald-600">تم نسخ التقرير</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5 text-gray-500" />
                      <span>نسخ النتيجة</span>
                    </>
                  )}
                </button>
              </div>
            </div>

            {/* Visual Probability Gauges */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
              {/* AI Probability */}
              <div className="p-5 rounded-2xl bg-indigo-50/60 dark:bg-indigo-950/30 border border-indigo-100 dark:border-indigo-900/50 flex items-center gap-4">
                <div className="relative w-20 h-20 shrink-0 flex items-center justify-center rounded-2xl bg-indigo-600 text-white font-black text-2xl shadow-lg shadow-indigo-600/20">
                  <span>{result.aiScore}%</span>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-indigo-900 dark:text-indigo-300">
                    <Bot className="w-4 h-4 text-indigo-600" />
                    <span>احتمالية نمط الذكاء الاصطناعي (AI-like)</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 h-2.5 rounded-full overflow-hidden">
                    <div
                      className={`h-full transition-all duration-1000 ${
                        result.aiScore >= 70
                          ? 'bg-rose-500'
                          : result.aiScore >= 40
                          ? 'bg-amber-500'
                          : 'bg-indigo-500'
                      }`}
                      style={{ width: `${result.aiScore}%` }}
                    />
                  </div>
                  <p className="text-[11px] text-gray-600 dark:text-gray-400">
                    {result.aiScore >= 70
                      ? 'مؤشرات عالية للتركيب الآلي'
                      : result.aiScore >= 40
                      ? 'مؤشرات مختلطة متوسطة'
                      : 'مؤشرات منخفضة جداً'}
                  </p>
                </div>
              </div>

              {/* Human Probability */}
              <div className="p-5 rounded-2xl bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/50 flex items-center gap-4">
                <div className="relative w-20 h-20 shrink-0 flex items-center justify-center rounded-2xl bg-emerald-600 text-white font-black text-2xl shadow-lg shadow-emerald-600/20">
                  <span>{result.humanScore}%</span>
                </div>
                <div className="space-y-1">
                  <div className="flex items-center gap-1.5 text-xs font-bold text-emerald-900 dark:text-emerald-300">
                    <User className="w-4 h-4 text-emerald-600" />
                    <span>احتمالية الأسلوب البشري (Human-like)</span>
                  </div>
                  <div className="w-full bg-gray-200 dark:bg-gray-700 h-2.5 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 transition-all duration-1000"
                      style={{ width: `${result.humanScore}%` }}
                    />
                  </div>
                  <p className="text-[11px] text-gray-600 dark:text-gray-400">
                    {result.humanScore >= 60
                      ? 'عفوية وتنوع لغوي بشري طبيعي'
                      : 'انتظام قد يقلل من النمط العفوي'}
                  </p>
                </div>
              </div>
            </div>

            {/* Summary Box */}
            <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-950/60 border border-gray-200 dark:border-gray-800 text-xs sm:text-sm leading-relaxed text-gray-800 dark:text-gray-200">
              <div className="font-bold mb-1 flex items-center gap-1.5 text-gray-900 dark:text-white">
                <Sparkles className="w-4 h-4 text-indigo-500" />
                <span>الخلاصة التحليلية:</span>
              </div>
              <p>{result.summaryAr}</p>
            </div>

            {/* Tabs for Detailed Breakdown */}
            <div className="space-y-4 pt-2">
              <div className="flex items-center gap-2 border-b border-gray-100 dark:border-gray-800 pb-2">
                {[
                  { id: 'overview', label: 'المؤشرات الإحصائية', icon: PieChart },
                  { id: 'sentences', label: 'تحليل الجمل بالتفصيل', icon: FileText },
                  { id: 'metrics', label: 'العبارات النمطية المكتشفة', icon: AlertTriangle }
                ].map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeViewMode === tab.id;
                  return (
                    <button
                      key={tab.id}
                      onClick={() => setActiveViewMode(tab.id as any)}
                      className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
                        isActive
                          ? 'bg-indigo-600 text-white shadow-sm'
                          : 'bg-gray-100 dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-200'
                      }`}
                    >
                      <Icon className="w-3.5 h-3.5" />
                      <span>{tab.label}</span>
                    </button>
                  );
                })}
              </div>

              {/* View 1: Overview Metrics */}
              {activeViewMode === 'overview' && (
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                  <div className="p-3.5 rounded-2xl bg-gray-50 dark:bg-gray-950/50 border border-gray-200/80 dark:border-gray-800">
                    <span className="text-[11px] text-gray-500 dark:text-gray-400 block mb-1 font-medium">
                      درجة الثقة بالتحليل
                    </span>
                    <span className="text-sm font-black text-indigo-600 dark:text-indigo-400">
                      {result.confidence === 'high' ? 'عالية (نص كافٍ)' : result.confidence === 'medium' ? 'متوسطة' : 'منخفضة (نص قصير)'}
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-gray-50 dark:bg-gray-950/50 border border-gray-200/80 dark:border-gray-800">
                    <span className="text-[11px] text-gray-500 dark:text-gray-400 block mb-1 font-medium">
                      التنوع المعجمي (TTR)
                    </span>
                    <span className="text-sm font-black text-gray-900 dark:text-white">
                      {result.lexicalDiversity}%
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-gray-50 dark:bg-gray-950/50 border border-gray-200/80 dark:border-gray-800">
                    <span className="text-[11px] text-gray-500 dark:text-gray-400 block mb-1 font-medium">
                      متوسط طول الجملة
                    </span>
                    <span className="text-sm font-black text-gray-900 dark:text-white">
                      {result.avgSentenceLength} كلمة
                    </span>
                  </div>

                  <div className="p-3.5 rounded-2xl bg-gray-50 dark:bg-gray-950/50 border border-gray-200/80 dark:border-gray-800">
                    <span className="text-[11px] text-gray-500 dark:text-gray-400 block mb-1 font-medium">
                      تباين وتفاوت الجمل (Burstiness)
                    </span>
                    <span className="text-sm font-black text-gray-900 dark:text-white">
                      {result.sentenceLengthVariance > 25 ? 'عالي (بشري طبيعي)' : 'منخفض (منتظم)'}
                    </span>
                  </div>
                </div>
              )}

              {/* View 2: Highlighted Sentences */}
              {activeViewMode === 'sentences' && (
                <div className="space-y-2 max-h-80 overflow-y-auto pr-1">
                  <p className="text-xs text-gray-500 dark:text-gray-400 mb-2">
                    يتم تمييز كل جملة بحسب درجة انتظامها وتطابقها مع الصياغات الآلية:
                  </p>
                  {result.sentenceScores.map((sent, idx) => (
                    <div
                      key={idx}
                      className={`p-3 rounded-xl border text-xs leading-relaxed transition ${
                        sent.flag === 'likely-ai'
                          ? 'bg-rose-50/60 dark:bg-rose-950/30 border-rose-200 dark:border-rose-900/60 text-rose-900 dark:text-rose-200'
                          : sent.flag === 'mixed'
                          ? 'bg-amber-50/60 dark:bg-amber-950/30 border-amber-200 dark:border-amber-900/60 text-amber-900 dark:text-amber-200'
                          : 'bg-emerald-50/60 dark:bg-emerald-950/30 border-emerald-200 dark:border-emerald-900/60 text-emerald-900 dark:text-emerald-200'
                      }`}
                    >
                      <div className="flex items-center justify-between gap-2 mb-1">
                        <span className="font-bold text-[10px] opacity-75">
                          جملة {idx + 1}
                        </span>
                        <span className="font-mono text-[10px] px-1.5 py-0.5 rounded bg-white/70 dark:bg-black/40 font-bold">
                          {sent.flag === 'likely-ai' ? 'صياغة نمطية AI' : sent.flag === 'mixed' ? 'نمط مختلط' : 'صياغة عفوية'}
                        </span>
                      </div>
                      <p>{sent.text}</p>
                    </div>
                  ))}
                </div>
              )}

              {/* View 3: Cliches */}
              {activeViewMode === 'metrics' && (
                <div className="p-4 rounded-2xl bg-gray-50 dark:bg-gray-950/60 border border-gray-200 dark:border-gray-800 space-y-3">
                  <div className="text-xs font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-500" />
                    <span>العبارات النمطية والانتقالات الشائعة في نصوص الذكاء الاصطناعي:</span>
                  </div>

                  {result.clicheMatches.length > 0 ? (
                    <div className="flex flex-wrap gap-2">
                      {result.clicheMatches.map((c, i) => (
                        <span
                          key={i}
                          className="px-2.5 py-1 rounded-lg bg-rose-100 dark:bg-rose-900/50 text-rose-800 dark:text-rose-300 text-xs font-bold border border-rose-200 dark:border-rose-800"
                        >
                          "{c}"
                        </span>
                      ))}
                    </div>
                  ) : (
                    <p className="text-xs text-emerald-600 dark:text-emerald-400 font-bold flex items-center gap-1">
                      <CheckCircle2 className="w-4 h-4" />
                      <span>لم يتم رصد أي عبارات ختامية أو انتقالية نمطية مكررة.</span>
                    </p>
                  )}
                </div>
              )}
            </div>
          </div>

          {/* Legal / Scientific Disclaimer Note */}
          <div className="p-4 rounded-2xl bg-amber-50/70 dark:bg-amber-950/30 border border-amber-200/80 dark:border-amber-900/50 text-xs text-amber-800 dark:text-amber-300 flex items-start gap-2.5">
            <Info className="w-4 h-4 shrink-0 mt-0.5 text-amber-600" />
            <div className="leading-relaxed">
              <strong>تنويه علمي وأخلاقي هام:</strong> تُقدم نتائج هذا الفحص كتقدير إحصائي واحتمالي إرشادي فقط مبني على تحليل بنية الجمل والمفردات والتكرار، ولا تمثل حكماً قطعياً قاطعاً بمصدر النص. النصوص البشرية المصاغة بأسلوب رسمي جداً قد تتشابه أحياناً مع هذه الأنماط.
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
