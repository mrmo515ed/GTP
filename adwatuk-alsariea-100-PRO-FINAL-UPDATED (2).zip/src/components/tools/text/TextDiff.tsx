import React, { useState } from 'react';
import { GitCompare, Sparkles, Trash2, ArrowRightLeft } from 'lucide-react';

export function TextDiff() {
  const [originalText, setOriginalText] = useState(
    `أدواتك السريعة هو موقع يقدم أدوات مجانية للمستخدمين.
يمكنك استخدام ضاغط الصور ومحول النصوص.
يتميز التطبيق بالسرعة وحفظ الخصوصية.`
  );

  const [modifiedText, setModifiedText] = useState(
    `أدواتك السريعة هي منصة حديثة تقدم أدوات مجانية وسريعة 100% للمستخدمين.
يمكنك استخدام ضاغط الصور الفوري ومحول النصوص المتقدم ورموز QR.
تتميز المنصة بالسرعة الفائقة وحفظ الخصوصية الكاملة داخل المتصفح.`
  );

  const computeDiffLines = () => {
    const origLines = originalText.split('\n');
    const modLines = modifiedText.split('\n');
    const max = Math.max(origLines.length, modLines.length);

    const diffs = [];
    for (let i = 0; i < max; i++) {
      const orig = origLines[i] ?? '';
      const mod = modLines[i] ?? '';
      const isIdentical = orig === mod;
      diffs.push({
        lineNumber: i + 1,
        orig,
        mod,
        isIdentical,
        isAdded: orig === '' && mod !== '',
        isRemoved: orig !== '' && mod === '',
        isModified: orig !== '' && mod !== '' && orig !== mod,
      });
    }
    return diffs;
  };

  const diffLines = computeDiffLines();
  const modifiedCount = diffLines.filter((d) => !d.isIdentical).length;

  const handleSwap = () => {
    const temp = originalText;
    setOriginalText(modifiedText);
    setModifiedText(temp);
  };

  return (
    <div className="space-y-6" id="text-diff-tool">
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/60 dark:border-gray-700/60">
        <div className="flex items-center gap-2 text-xs font-semibold text-gray-700 dark:text-gray-300">
          <GitCompare className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>
            {modifiedCount === 0
              ? 'النصان متطابقان تماماً'
              : `تم العثور على ${modifiedCount} سطر يحتوي على اختلافات`}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleSwap}
            id="btn-swap-diff-texts"
            className="px-3 py-1.5 text-xs font-medium bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-600 hover:border-emerald-500 rounded-lg transition flex items-center gap-1.5"
          >
            <ArrowRightLeft className="w-3.5 h-3.5" />
            تبديل النصين
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Left / Original */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-gray-600 dark:text-gray-400">
            <span>النص الأصلي (Original)</span>
            <button
              onClick={() => setOriginalText('')}
              className="text-rose-500 hover:underline flex items-center gap-1 text-xs"
            >
              <Trash2 className="w-3 h-3" /> مسح
            </button>
          </div>
          <textarea
            value={originalText}
            onChange={(e) => setOriginalText(e.target.value)}
            placeholder="أدخل النص الأصلي هنا..."
            rows={7}
            id="diff-original-textarea"
            className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-emerald-500 outline-none text-xs leading-relaxed font-mono"
          />
        </div>

        {/* Right / Modified */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs font-semibold text-gray-600 dark:text-gray-400">
            <span>النص المعدل (Modified)</span>
            <button
              onClick={() => setModifiedText('')}
              className="text-rose-500 hover:underline flex items-center gap-1 text-xs"
            >
              <Trash2 className="w-3 h-3" /> مسح
            </button>
          </div>
          <textarea
            value={modifiedText}
            onChange={(e) => setModifiedText(e.target.value)}
            placeholder="أدخل النص بعد التعديل هنا..."
            rows={7}
            id="diff-modified-textarea"
            className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-emerald-500 outline-none text-xs leading-relaxed font-mono"
          />
        </div>
      </div>

      {/* Comparison View */}
      <div className="space-y-2">
        <h4 className="text-xs font-bold text-gray-700 dark:text-gray-300">
          جدول الفروقات سطر بسطر:
        </h4>
        <div className="rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-900 divide-y divide-gray-100 dark:divide-gray-800 text-xs font-mono">
          {diffLines.map((d) => (
            <div
              key={d.lineNumber}
              className={`grid grid-cols-12 p-2.5 items-center transition ${
                d.isIdentical
                  ? 'bg-transparent text-gray-700 dark:text-gray-300'
                  : d.isAdded
                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-300'
                  : d.isRemoved
                  ? 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-300'
                  : 'bg-amber-50/80 dark:bg-amber-950/30 text-amber-900 dark:text-amber-200'
              }`}
            >
              <div className="col-span-1 text-gray-400 dark:text-gray-500 text-center font-semibold">
                #{d.lineNumber}
              </div>
              <div className="col-span-5 px-2 border-r border-gray-200 dark:border-gray-800 break-words line-through-when-removed">
                {d.orig || <span className="text-gray-300 dark:text-gray-600 italic">فارغ</span>}
              </div>
              <div className="col-span-6 px-2 font-medium break-words">
                {d.mod || <span className="text-gray-300 dark:text-gray-600 italic">محذوف</span>}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
