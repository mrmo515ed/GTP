import React, { useState, useMemo } from 'react';
import { Copy, Trash2, Check, FileText, Clock, AlignLeft, Hash, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

export function WordCounter() {
  const [text, setText] = useState<string>(
    'أهلاً بك في منصة أدواتك السريعة! هذه الأداة تتيح لك حساب الكلمات، الأحرف، الأسطر، والفقرات مع تقدير سرعة القراءة وزمن الإلقاء الصوتي للنص بكل دقة وبشكل فوري داخل متصفحك دون رفع أي بيانات.'
  );
  const [copied, setCopied] = useState(false);

  const stats = useMemo(() => {
    const rawText = text.trim();
    if (!rawText) {
      return {
        characters: 0,
        charactersNoSpaces: 0,
        words: 0,
        sentences: 0,
        paragraphs: 0,
        lines: 0,
        readingTimeMinutes: 0,
        speakingTimeMinutes: 0,
        arabicDiacritics: 0,
        arabicLetters: 0,
        englishLetters: 0,
        numbersCount: 0,
      };
    }

    const characters = text.length;
    const charactersNoSpaces = text.replace(/\s+/g, '').length;
    
    // Words count (handling Arabic & Latin spacing)
    const wordsArray = rawText.split(/\s+/).filter(Boolean);
    const words = wordsArray.length;

    // Sentences count (. ! ? ؟)
    const sentencesArray = rawText.split(/[.!?؟]+/).filter(s => s.trim().length > 0);
    const sentences = sentencesArray.length;

    // Paragraphs
    const paragraphsArray = text.split(/\n+/).filter(p => p.trim().length > 0);
    const paragraphs = paragraphsArray.length;

    // Lines
    const lines = text.split('\n').length;

    // Arabic diacritics count (َ ً ُ ٌ ِ ٍ ْ ّ)
    const diacriticsMatch = text.match(/[\u064B-\u0652\u0670]/g);
    const arabicDiacritics = diacriticsMatch ? diacriticsMatch.length : 0;

    // Arabic letters
    const arabicLettersMatch = text.match(/[\u0600-\u06FF]/g);
    const arabicLetters = arabicLettersMatch ? arabicLettersMatch.length : 0;

    // English letters
    const englishLettersMatch = text.match(/[a-zA-Z]/g);
    const englishLetters = englishLettersMatch ? englishLettersMatch.length : 0;

    // Numbers
    const numbersMatch = text.match(/[0-9\u0660-\u0669]/g);
    const numbersCount = numbersMatch ? numbersMatch.length : 0;

    // Reading time (average 200 words per minute for Arabic/English)
    const readingTimeMinutes = Math.ceil((words / 200) * 10) / 10;
    // Speaking time (average 130 words per minute)
    const speakingTimeMinutes = Math.ceil((words / 130) * 10) / 10;

    return {
      characters,
      charactersNoSpaces,
      words,
      sentences,
      paragraphs,
      lines,
      readingTimeMinutes,
      speakingTimeMinutes,
      arabicDiacritics,
      arabicLetters,
      englishLetters,
      numbersCount,
    };
  }, [text]);

  const handleCopy = () => {
    if (!text) return;
    navigator.clipboard.writeText(text);
    setCopied(true);
    confetti({ particleCount: 40, spread: 60, origin: { y: 0.8 } });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleClear = () => {
    setText('');
  };

  const handleLoadSample = () => {
    setText(
      'تعتبر منصة أدواتك السريعة الوجهة المثالية لجميع المستخدمين الباحثين عن الإنتاجية والسرعة. تضمن المنصة تنفيذ كافة العمليات كضغط الصور، تحويل الأنساق، وتنسيق الأكواد بنسبة مئة بالمئة داخل المتصفح دون نقل بياناتك عبر الإنترنت، مما يمنحك أقصى درجات الأمان وحفظ الخصوصية.'
    );
  };

  return (
    <div className="space-y-6" id="word-counter-tool">
      {/* Top action bar */}
      <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-gray-100 dark:border-gray-800">
        <div className="flex items-center gap-2 text-sm text-gray-500 dark:text-gray-400">
          <FileText className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>تحليل فوري وتلقائي للنص أثناء الكتابة</span>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={handleLoadSample}
            id="btn-load-sample-text"
            className="px-3 py-1.5 text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 hover:bg-emerald-100 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5" />
            نص تجريبي
          </button>
          <button
            onClick={handleCopy}
            id="btn-copy-wordcount-text"
            className="px-3 py-1.5 text-xs font-medium text-gray-700 dark:text-gray-300 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-lg transition-colors flex items-center gap-1.5"
          >
            {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'تم النسخ' : 'نسخ النص'}
          </button>
          <button
            onClick={handleClear}
            id="btn-clear-wordcount-text"
            className="px-3 py-1.5 text-xs font-medium text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/40 hover:bg-rose-100 rounded-lg transition-colors flex items-center gap-1.5"
          >
            <Trash2 className="w-3.5 h-3.5" />
            مسح
          </button>
        </div>
      </div>

      {/* Main Textarea */}
      <div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="اكتب أو الصق النص هنا لمعرفة عدد الكلمات والأحرف..."
          rows={7}
          id="word-counter-textarea"
          className="w-full p-4 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-emerald-500 focus:border-transparent outline-none transition text-base leading-relaxed resize-y shadow-xs"
        />
      </div>

      {/* Primary KPI Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3.5">
        <div className="p-4 rounded-xl bg-emerald-50/80 dark:bg-emerald-950/30 border border-emerald-100 dark:border-emerald-900/40 text-center">
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-700 dark:text-emerald-400 font-heading">
            {stats.words.toLocaleString('ar-EG')}
          </div>
          <div className="text-xs font-medium text-gray-600 dark:text-gray-400 mt-1">عدد الكلمات</div>
        </div>

        <div className="p-4 rounded-xl bg-blue-50/80 dark:bg-blue-950/30 border border-blue-100 dark:border-blue-900/40 text-center">
          <div className="text-2xl sm:text-3xl font-extrabold text-blue-700 dark:text-blue-400 font-heading">
            {stats.characters.toLocaleString('ar-EG')}
          </div>
          <div className="text-xs font-medium text-gray-600 dark:text-gray-400 mt-1">إجمالي الأحرف</div>
        </div>

        <div className="p-4 rounded-xl bg-purple-50/80 dark:bg-purple-950/30 border border-purple-100 dark:border-purple-900/40 text-center">
          <div className="text-2xl sm:text-3xl font-extrabold text-purple-700 dark:text-purple-400 font-heading">
            {stats.charactersNoSpaces.toLocaleString('ar-EG')}
          </div>
          <div className="text-xs font-medium text-gray-600 dark:text-gray-400 mt-1">أحرف بدون مسافات</div>
        </div>

        <div className="p-4 rounded-xl bg-amber-50/80 dark:bg-amber-950/30 border border-amber-100 dark:border-amber-900/40 text-center">
          <div className="text-2xl sm:text-3xl font-extrabold text-amber-700 dark:text-amber-400 font-heading">
            {stats.sentences.toLocaleString('ar-EG')}
          </div>
          <div className="text-xs font-medium text-gray-600 dark:text-gray-400 mt-1">عدد الجمل</div>
        </div>
      </div>

      {/* Secondary Stats Details */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-2">
        <div className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/60 dark:border-gray-700/60 flex items-center justify-between">
          <span className="text-xs text-gray-500 dark:text-gray-400">الفقرات:</span>
          <span className="font-bold text-gray-900 dark:text-gray-100 font-heading text-sm">{stats.paragraphs}</span>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/60 dark:border-gray-700/60 flex items-center justify-between">
          <span className="text-xs text-gray-500 dark:text-gray-400">الأسطر:</span>
          <span className="font-bold text-gray-900 dark:text-gray-100 font-heading text-sm">{stats.lines}</span>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/60 dark:border-gray-700/60 flex items-center justify-between">
          <span className="text-xs text-gray-500 dark:text-gray-400">حركات التشكيل:</span>
          <span className="font-bold text-emerald-600 dark:text-emerald-400 font-heading text-sm">{stats.arabicDiacritics}</span>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/60 dark:border-gray-700/60 flex items-center justify-between">
          <span className="text-xs text-gray-500 dark:text-gray-400">الأرقام:</span>
          <span className="font-bold text-gray-900 dark:text-gray-100 font-heading text-sm">{stats.numbersCount}</span>
        </div>
      </div>

      {/* Reading and Speaking Time estimate banner */}
      <div className="p-4 rounded-xl bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-blue-500/10 border border-emerald-500/20 flex flex-col sm:flex-row items-center justify-around gap-4 text-center sm:text-right">
        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-emerald-500/20 text-emerald-600 dark:text-emerald-400 rounded-xl">
            <Clock className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-gray-500 dark:text-gray-400">وقت القراءة الصامتة التقديري</div>
            <div className="text-sm font-bold text-gray-800 dark:text-gray-200">
              {stats.readingTimeMinutes < 1 ? 'أقل من دقيقة' : `${stats.readingTimeMinutes} دقيقة`}
            </div>
          </div>
        </div>

        <div className="w-px h-8 bg-gray-200 dark:bg-gray-700 hidden sm:block"></div>

        <div className="flex items-center gap-3">
          <div className="p-2.5 bg-blue-500/20 text-blue-600 dark:text-blue-400 rounded-xl">
            <AlignLeft className="w-5 h-5" />
          </div>
          <div>
            <div className="text-xs text-gray-500 dark:text-gray-400">وقت الإلقاء الصوتي التقديري</div>
            <div className="text-sm font-bold text-gray-800 dark:text-gray-200">
              {stats.speakingTimeMinutes < 1 ? 'أقل من دقيقة' : `${stats.speakingTimeMinutes} دقيقة`}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
