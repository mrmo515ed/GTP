import React, { useState } from 'react';
import { Copy, Check, Sparkles, Trash2, ArrowUpDown } from 'lucide-react';
import confetti from 'canvas-confetti';

export function CaseConverter() {
  const [text, setText] = useState('welcome to quick tools platform - the fastest browser utilities');
  const [copiedFormat, setCopiedFormat] = useState<string | null>(null);

  const copyToClipboard = (convertedText: string, formatName: string) => {
    navigator.clipboard.writeText(convertedText);
    setCopiedFormat(formatName);
    confetti({ particleCount: 30, spread: 45, origin: { y: 0.8 } });
    setTimeout(() => setCopiedFormat(null), 2000);
  };

  const toSentenceCase = (str: string) => {
    return str
      .toLowerCase()
      .replace(/(^\s*\w|[.!?]\s*\w)/g, (c) => c.toUpperCase());
  };

  const toTitleCase = (str: string) => {
    return str
      .toLowerCase()
      .split(' ')
      .map((word) => word.charAt(0).toUpperCase() + word.slice(1))
      .join(' ');
  };

  const toCamelCase = (str: string) => {
    return str
      .replace(/(?:^\w|[A-Z]|\b\w|\s+)/g, (match, index) => {
        if (+match === 0) return '';
        return index === 0 ? match.toLowerCase() : match.toUpperCase();
      })
      .replace(/[^a-zA-Z0-9]/g, '');
  };

  const toPascalCase = (str: string) => {
    return str
      .replace(/(?:^\w|[A-Z]|\b\w|\s+)/g, (match) => {
        if (+match === 0) return '';
        return match.toUpperCase();
      })
      .replace(/[^a-zA-Z0-9]/g, '');
  };

  const toSnakeCase = (str: string) => {
    return str
      .trim()
      .toLowerCase()
      .replace(/\s+/g, '_')
      .replace(/[^a-zA-Z0-9_]/g, '');
  };

  const toKebabCase = (str: string) => {
    return str
      .trim()
      .toLowerCase()
      .replace(/\s+/g, '-')
      .replace(/[^a-zA-Z0-9-]/g, '');
  };

  const toConstantCase = (str: string) => {
    return str
      .trim()
      .toUpperCase()
      .replace(/\s+/g, '_')
      .replace(/[^a-zA-Z0-9_]/g, '');
  };

  const toAlternatingCase = (str: string) => {
    return str
      .split('')
      .map((c, i) => (i % 2 === 0 ? c.toLowerCase() : c.toUpperCase()))
      .join('');
  };

  const conversions = [
    { id: 'upper', name: 'أحرف كبيرة (UPPERCASE)', value: text.toUpperCase() },
    { id: 'lower', name: 'أحرف صغيرة (lowercase)', value: text.toLowerCase() },
    { id: 'title', name: 'حالة العناوين (Title Case)', value: toTitleCase(text) },
    { id: 'sentence', name: 'حالة الجملة (Sentence case)', value: toSentenceCase(text) },
    { id: 'camel', name: 'كود كامل كيس (camelCase)', value: toCamelCase(text) },
    { id: 'pascal', name: 'باسكال كيس (PascalCase)', value: toPascalCase(text) },
    { id: 'snake', name: 'سنيك كيس (snake_case)', value: toSnakeCase(text) },
    { id: 'kebab', name: 'كباب كيس (kebab-case)', value: toKebabCase(text) },
    { id: 'constant', name: 'ثوابت برمجية (CONSTANT_CASE)', value: toConstantCase(text) },
    { id: 'alternating', name: 'أحرف متبادلة (aLtErNaTiNg)', value: toAlternatingCase(text) },
  ];

  return (
    <div className="space-y-6" id="case-converter-tool">
      <div className="space-y-2">
        <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
          <span className="font-semibold">أدخل النص المراد تحويل حالته:</span>
          <button
            onClick={() => setText('')}
            className="text-rose-500 hover:text-rose-600 transition flex items-center gap-1"
          >
            <Trash2 className="w-3.5 h-3.5" />
            مسح النص
          </button>
        </div>
        <textarea
          value={text}
          onChange={(e) => setText(e.target.value)}
          placeholder="Type or paste your text here..."
          rows={3}
          id="case-converter-textarea"
          className="w-full p-3.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-emerald-500 outline-none text-base"
        />
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-3.5">
        {conversions.map((item) => (
          <div
            key={item.id}
            className="p-3.5 bg-gray-50/90 dark:bg-gray-800/60 rounded-xl border border-gray-200/70 dark:border-gray-700/60 hover:border-emerald-500/50 transition-all flex flex-col justify-between gap-2"
          >
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">{item.name}</span>
              <button
                onClick={() => copyToClipboard(item.value, item.id)}
                id={`btn-copy-${item.id}`}
                className="px-2.5 py-1 text-xs font-medium text-emerald-700 dark:text-emerald-400 bg-emerald-100/60 dark:bg-emerald-950/50 hover:bg-emerald-200/70 rounded-md transition flex items-center gap-1"
              >
                {copiedFormat === item.id ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                {copiedFormat === item.id ? 'تم النسخ!' : 'نسخ'}
              </button>
            </div>
            <div className="p-2.5 rounded-lg bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 text-xs font-mono text-gray-800 dark:text-gray-200 truncate select-all">
              {item.value || '...'}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
