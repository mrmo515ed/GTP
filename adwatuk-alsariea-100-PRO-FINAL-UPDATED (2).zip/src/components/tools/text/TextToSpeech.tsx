import React, { useState, useEffect } from 'react';
import { Play, Square, Settings, Volume2, Globe } from 'lucide-react';

export function TextToSpeech() {
  const [text, setText] = useState('');
  const [voices, setVoices] = useState<SpeechSynthesisVoice[]>([]);
  const [selectedVoiceUri, setSelectedVoiceUri] = useState<string>('');
  const [pitch, setPitch] = useState(1);
  const [rate, setRate] = useState(1);
  const [isSpeaking, setIsSpeaking] = useState(false);

  useEffect(() => {
    const loadVoices = () => {
      const availableVoices = window.speechSynthesis.getVoices();
      setVoices(availableVoices);
      
      // Try to find a good Arabic voice by default
      const arabicVoice = availableVoices.find(v => v.lang.includes('ar'));
      if (arabicVoice) {
        setSelectedVoiceUri(arabicVoice.voiceURI || arabicVoice.name);
      } else if (availableVoices.length > 0) {
        setSelectedVoiceUri(availableVoices[0].voiceURI || availableVoices[0].name);
      }
    };

    loadVoices();
    if (speechSynthesis.onvoiceschanged !== undefined) {
      speechSynthesis.onvoiceschanged = loadVoices;
    }
  }, []);

  useEffect(() => {
    return () => {
      window.speechSynthesis.cancel(); // cleanup on unmount
    };
  }, []);

  const handleSpeak = () => {
    if (!text.trim()) return;

    window.speechSynthesis.cancel(); // Stop anything currently playing

    const utterance = new SpeechSynthesisUtterance(text);
    
    if (selectedVoiceUri) {
      const voice = voices.find(v => (v.voiceURI || v.name) === selectedVoiceUri);
      if (voice) utterance.voice = voice;
    }

    utterance.pitch = pitch;
    utterance.rate = rate;
    
    utterance.onend = () => setIsSpeaking(false);
    utterance.onerror = () => setIsSpeaking(false);

    window.speechSynthesis.speak(utterance);
    setIsSpeaking(true);
  };

  const handleStop = () => {
    window.speechSynthesis.cancel();
    setIsSpeaking(false);
  };

  return (
    <div className="space-y-6">
      <div className="bg-amber-50 dark:bg-amber-900/20 p-4 rounded-2xl flex gap-3 text-sm text-amber-800 dark:text-amber-300">
        <Volume2 className="w-5 h-5 shrink-0 mt-0.5" />
        <p>استخدم هذه الأداة لتحويل النصوص المكتوبة إلى صوت منطوق. تعمل الأداة بناءً على الأصوات المدعومة في نظام التشغيل والمتصفح الخاص بك.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="md:col-span-2 space-y-4">
          <label className="text-sm font-bold text-gray-700 dark:text-gray-300 block">النص المراد تحويله</label>
          <textarea
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="اكتب النص هنا..."
            className="w-full h-48 sm:h-64 px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-amber-500 outline-none resize-none leading-relaxed"
          ></textarea>
          
          <div className="flex items-center gap-3">
            <button
              onClick={handleSpeak}
              disabled={!text.trim() || isSpeaking}
              className="flex-1 flex items-center justify-center gap-2 py-3 bg-amber-500 hover:bg-amber-600 text-white rounded-xl font-bold transition disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Play className="w-5 h-5" />
              تحدث
            </button>
            
            <button
              onClick={handleStop}
              disabled={!isSpeaking}
              className="flex items-center justify-center gap-2 px-6 py-3 bg-gray-200 dark:bg-gray-800 text-gray-800 dark:text-white rounded-xl font-bold transition hover:bg-gray-300 dark:hover:bg-gray-700 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              <Square className="w-5 h-5" />
              إيقاف
            </button>
          </div>
        </div>

        <div className="space-y-6 bg-gray-50 dark:bg-gray-800/50 p-5 rounded-2xl border border-gray-100 dark:border-gray-700">
          <div className="flex items-center gap-2 text-gray-800 dark:text-gray-200 font-bold border-b border-gray-200 dark:border-gray-700 pb-3">
            <Settings className="w-5 h-5" />
            <h3>إعدادات الصوت</h3>
          </div>

          <div className="space-y-2">
            <label className="text-xs font-semibold text-gray-600 dark:text-gray-400 flex items-center gap-1.5">
              <Globe className="w-3.5 h-3.5" /> الصوت واللغة
            </label>
            <select
              value={selectedVoiceUri}
              onChange={(e) => setSelectedVoiceUri(e.target.value)}
              className="w-full px-3 py-2 text-sm bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg outline-none"
            >
              {voices.map((v, index) => {
                const uniqueKey = `${v.voiceURI || v.name}-${v.lang}-${index}`;
                const value = v.voiceURI || v.name;
                return (
                  <option key={uniqueKey} value={value}>
                    {v.name} ({v.lang})
                  </option>
                );
              })}
            </select>
          </div>

          <div className="space-y-3">
            <label className="text-xs font-semibold text-gray-600 dark:text-gray-400 flex justify-between">
              <span>السرعة (Rate)</span>
              <span>{rate.toFixed(1)}x</span>
            </label>
            <input
              type="range"
              min="0.5"
              max="2"
              step="0.1"
              value={rate}
              onChange={(e) => setRate(parseFloat(e.target.value))}
              className="w-full accent-amber-500"
              dir="ltr"
            />
          </div>

          <div className="space-y-3">
            <label className="text-xs font-semibold text-gray-600 dark:text-gray-400 flex justify-between">
              <span>الحدة (Pitch)</span>
              <span>{pitch.toFixed(1)}</span>
            </label>
            <input
              type="range"
              min="0"
              max="2"
              step="0.1"
              value={pitch}
              onChange={(e) => setPitch(parseFloat(e.target.value))}
              className="w-full accent-amber-500"
              dir="ltr"
            />
          </div>
        </div>
      </div>
    </div>
  );
}
