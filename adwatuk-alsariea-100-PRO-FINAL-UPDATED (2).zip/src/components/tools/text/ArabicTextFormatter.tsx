import React, { useState } from 'react';
import { Copy, Trash2, Check, Sparkles, RefreshCw, Wand2 } from 'lucide-react';
import confetti from 'canvas-confetti';

export function ArabicTextFormatter() {
  const [inputText, setInputText] = useState(
    'بِسْمِ اللَّـهِ الرَّحْمَـٰنِ الرَّحِيمِ، أَهْلاً بِكُمْ فِي مَنَصَّةِ أَدَوَاتِكَ السَّرِيعَةِ! هَــٰذَا النَّــصُّ يَحْتَوِي عَلَى تَشْكِيلٍ وَتَطْوِيلٍ وَهَمَزَاتٍ مُتَنَوِّعَةٍ: إِبْرَاهِيم، آمَال، أحمد، أُمَيْمَة.'
  );
  const [copied, setCopied] = useState(false);

  // Settings
  const [removeTashkeel, setRemoveTashkeel] = useState(true);
  const [removeTatweel, setRemoveTatweel] = useState(true);
  const [unifyAlef, setUnifyAlef] = useState(false);
  const [unifyYaa, setUnifyYaa] = useState(false);
  const [unifyTaaMarbuta, setUnifyTaaMarbuta] = useState(false);
  const [cleanSpaces, setCleanSpaces] = useState(true);
  const [numberConversion, setNumberConversion] = useState<'none' | 'toArabic' | 'toEnglish'>('none');

  const formatText = (text: string) => {
    let result = text;

    // 1. Remove Tashkeel (Diacritics: َ ً ُ ٌ ِ ٍ ْ ّ ٰ)
    if (removeTashkeel) {
      result = result.replace(/[\u064B-\u0652\u0670]/g, '');
    }

    // 2. Remove Tatweel (ـ)
    if (removeTatweel) {
      result = result.replace(/\u0640/g, '');
    }

    // 3. Unify Alef (أ, إ, آ, ٱ -> ا)
    if (unifyAlef) {
      result = result.replace(/[أإآٱ]/g, 'ا');
    }

    // 4. Unify Yaa (ى -> ي)
    if (unifyYaa) {
      result = result.replace(/ى/g, 'ي');
    }

    // 5. Unify Taa Marbuta (ة -> ه)
    if (unifyTaaMarbuta) {
      result = result.replace(/ة/g, 'ه');
    }

    // 6. Clean extra spaces
    if (cleanSpaces) {
      result = result
        .replace(/[ \t]+/g, ' ')
        .replace(/\n\s*\n/g, '\n\n')
        .trim();
    }

    // 7. Numbers conversion
    if (numberConversion === 'toArabic') {
      const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
      result = result.replace(/[0-9]/g, (w) => arabicNumbers[+w]);
    } else if (numberConversion === 'toEnglish') {
      const arabicNumbersMap: Record<string, string> = {
        '٠': '0', '١': '1', '٢': '2', '٣': '3', '٤': '4',
        '٥': '5', '٦': '6', '٧': '7', '٨': '8', '٩': '9'
      };
      result = result.replace(/[\u0660-\u0669]/g, (w) => arabicNumbersMap[w] || w);
    }

    return result;
  };

  const outputText = formatText(inputText);

  const handleCopy = () => {
    if (!outputText) return;
    navigator.clipboard.writeText(outputText);
    setCopied(true);
    confetti({ particleCount: 35, spread: 50, origin: { y: 0.8 } });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleApplyPreset = (type: 'all' | 'clean_only' | 'seo') => {
    if (type === 'all') {
      setRemoveTashkeel(true);
      setRemoveTatweel(true);
      setUnifyAlef(true);
      setUnifyYaa(true);
      setUnifyTaaMarbuta(false);
      setCleanSpaces(true);
    } else if (type === 'clean_only') {
      setRemoveTashkeel(true);
      setRemoveTatweel(true);
      setUnifyAlef(false);
      setUnifyYaa(false);
      setUnifyTaaMarbuta(false);
      setCleanSpaces(true);
    } else if (type === 'seo') {
      setRemoveTashkeel(true);
      setRemoveTatweel(true);
      setUnifyAlef(true);
      setUnifyYaa(true);
      setUnifyTaaMarbuta(true);
      setCleanSpaces(true);
    }
  };

  return (
    <div className="space-y-6" id="arabic-formatter-tool">
      {/* Quick Presets */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/60 dark:border-gray-700/60">
        <div className="flex items-center gap-2 text-xs font-semibold text-gray-700 dark:text-gray-300">
          <Wand2 className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>تجهيزات سريعة بنقرة واحدة:</span>
        </div>
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => handleApplyPreset('clean_only')}
            id="preset-clean"
            className="px-3 py-1 text-xs font-medium bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-600 hover:border-emerald-500 rounded-lg transition-colors"
          >
            تنظيف التشكيل والتطويل فقط
          </button>
          <button
            onClick={() => handleApplyPreset('all')}
            id="preset-full"
            className="px-3 py-1 text-xs font-medium bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-600 hover:border-emerald-500 rounded-lg transition-colors"
          >
            توحيد الحروف والنص الشامل
          </button>
          <button
            onClick={() => handleApplyPreset('seo')}
            id="preset-seo"
            className="px-3 py-1 text-xs font-medium bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-600 hover:border-emerald-500 rounded-lg transition-colors"
          >
            معالجة لمحركات البحث (SEO)
          </button>
        </div>
      </div>

      {/* Options Checkboxes */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 p-4 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-xl">
        <label className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
          <input
            type="checkbox"
            checked={removeTashkeel}
            onChange={(e) => setRemoveTashkeel(e.target.checked)}
            id="check-remove-tashkeel"
            className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
          />
          <span>إزالة حركات التشكيل والتنوين</span>
        </label>

        <label className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
          <input
            type="checkbox"
            checked={removeTatweel}
            onChange={(e) => setRemoveTatweel(e.target.checked)}
            id="check-remove-tatweel"
            className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
          />
          <span>إزالة علامات التطويل والكشيدة (ـ)</span>
        </label>

        <label className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
          <input
            type="checkbox"
            checked={unifyAlef}
            onChange={(e) => setUnifyAlef(e.target.checked)}
            id="check-unify-alef"
            className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
          />
          <span>توحيد الهمزات (أ، إ، آ ← ا)</span>
        </label>

        <label className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
          <input
            type="checkbox"
            checked={unifyYaa}
            onChange={(e) => setUnifyYaa(e.target.checked)}
            id="check-unify-yaa"
            className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
          />
          <span>توحيد الياء والألف المقصورة (ى ← ي)</span>
        </label>

        <label className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
          <input
            type="checkbox"
            checked={unifyTaaMarbuta}
            onChange={(e) => setUnifyTaaMarbuta(e.target.checked)}
            id="check-unify-taa"
            className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
          />
          <span>توحيد التاء المربوطة (ة ← ه)</span>
        </label>

        <label className="flex items-center gap-2 text-sm text-gray-700 dark:text-gray-300 cursor-pointer">
          <input
            type="checkbox"
            checked={cleanSpaces}
            onChange={(e) => setCleanSpaces(e.target.checked)}
            id="check-clean-spaces"
            className="w-4 h-4 text-emerald-600 rounded focus:ring-emerald-500"
          />
          <span>تنظيف المسافات والأسطر الفارغة</span>
        </label>

        <div className="col-span-full flex flex-wrap items-center gap-3 pt-2 border-t border-emerald-200/40 dark:border-emerald-900/40">
          <span className="text-xs font-semibold text-gray-600 dark:text-gray-400">تحويل الأرقام:</span>
          <label className="flex items-center gap-1.5 text-xs text-gray-700 dark:text-gray-300 cursor-pointer">
            <input
              type="radio"
              name="num-conv"
              checked={numberConversion === 'none'}
              onChange={() => setNumberConversion('none')}
            />
            <span>بدون تغيير</span>
          </label>
          <label className="flex items-center gap-1.5 text-xs text-gray-700 dark:text-gray-300 cursor-pointer">
            <input
              type="radio"
              name="num-conv"
              checked={numberConversion === 'toEnglish'}
              onChange={() => setNumberConversion('toEnglish')}
            />
            <span>إلى أرقام إنجليزية (123)</span>
          </label>
          <label className="flex items-center gap-1.5 text-xs text-gray-700 dark:text-gray-300 cursor-pointer">
            <input
              type="radio"
              name="num-conv"
              checked={numberConversion === 'toArabic'}
              onChange={() => setNumberConversion('toArabic')}
            />
            <span>إلى أرقام مشرقية (١٢٣)</span>
          </label>
        </div>
      </div>

      {/* Inputs & Outputs Panels */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {/* Input */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
            <span className="font-semibold">النص الأصلي ({inputText.length} حرف)</span>
            <button
              onClick={() => setInputText('')}
              className="text-rose-500 hover:text-rose-600 transition flex items-center gap-1"
            >
              <Trash2 className="w-3 h-3" />
              مسح
            </button>
          </div>
          <textarea
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
            placeholder="الصق النص العربي هنا لتنسيقه..."
            rows={8}
            id="arabic-input-textarea"
            className="w-full p-3.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-emerald-500 outline-none text-sm leading-relaxed"
          />
        </div>

        {/* Output */}
        <div className="space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400">
            <span className="font-semibold text-emerald-600 dark:text-emerald-400">
              النتيجة بعد التنسيق ({outputText.length} حرف)
            </span>
            <button
              onClick={handleCopy}
              id="btn-copy-arabic-formatted"
              className="text-emerald-600 dark:text-emerald-400 hover:underline transition flex items-center gap-1 font-bold"
            >
              {copied ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
              {copied ? 'تم النسخ!' : 'نسخ النتيجة'}
            </button>
          </div>
          <textarea
            value={outputText}
            readOnly
            placeholder="ستظهر النتيجة المعالجة هنا تلقائياً..."
            rows={8}
            id="arabic-output-textarea"
            className="w-full p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50/20 dark:bg-gray-900 text-gray-900 dark:text-gray-100 outline-none text-sm leading-relaxed"
          />
        </div>
      </div>
    </div>
  );
}
