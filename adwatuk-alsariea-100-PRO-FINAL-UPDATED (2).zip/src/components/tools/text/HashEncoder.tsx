import React, { useState, useEffect } from 'react';
import { Copy, Check, Lock, KeyRound, Sparkles, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';

export function HashEncoder() {
  const [input, setInput] = useState('أدواتك السريعة 2026');
  const [activeTab, setActiveTab] = useState<'crypto' | 'base64' | 'url'>('crypto');
  
  const [sha256, setSha256] = useState('');
  const [sha1, setSha1] = useState('');
  const [sha512, setSha512] = useState('');
  
  const [base64Encoded, setBase64Encoded] = useState('');
  const [base64Decoded, setBase64Decoded] = useState('');
  
  const [urlEncoded, setUrlEncoded] = useState('');
  const [urlDecoded, setUrlDecoded] = useState('');
  
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Compute Hashes using Web Crypto API
  useEffect(() => {
    async function computeHashes() {
      if (!input) {
        setSha256('');
        setSha1('');
        setSha512('');
        setBase64Encoded('');
        setBase64Decoded('');
        setUrlEncoded('');
        setUrlDecoded('');
        return;
      }

      const encoder = new TextEncoder();
      const data = encoder.encode(input);

      // SHA-256
      try {
        const hashBuffer256 = await crypto.subtle.digest('SHA-256', data);
        const hashArray256 = Array.from(new Uint8Array(hashBuffer256));
        setSha256(hashArray256.map((b) => b.toString(16).padStart(2, '0')).join(''));
      } catch {
        setSha256('غير مدعوم في المتصفح');
      }

      // SHA-1
      try {
        const hashBuffer1 = await crypto.subtle.digest('SHA-1', data);
        const hashArray1 = Array.from(new Uint8Array(hashBuffer1));
        setSha1(hashArray1.map((b) => b.toString(16).padStart(2, '0')).join(''));
      } catch {
        setSha1('');
      }

      // SHA-512
      try {
        const hashBuffer512 = await crypto.subtle.digest('SHA-512', data);
        const hashArray512 = Array.from(new Uint8Array(hashBuffer512));
        setSha512(hashArray512.map((b) => b.toString(16).padStart(2, '0')).join(''));
      } catch {
        setSha512('');
      }

      // Base64 (Unicode safe)
      try {
        const utf8Bytes = new TextEncoder().encode(input);
        let binary = '';
        for (let i = 0; i < utf8Bytes.length; i++) {
          binary += String.fromCharCode(utf8Bytes[i]);
        }
        setBase64Encoded(btoa(binary));
      } catch {
        setBase64Encoded('خطأ في الترميز');
      }

      // Base64 decode attempt
      try {
        const decodedBinary = atob(input);
        const bytes = new Uint8Array(decodedBinary.length);
        for (let i = 0; i < decodedBinary.length; i++) {
          bytes[i] = decodedBinary.charCodeAt(i);
        }
        setBase64Decoded(new TextDecoder().decode(bytes));
      } catch {
        setBase64Decoded('النص المدخل ليس بصيغة Base64 صالحة');
      }

      // URL encode/decode
      try {
        setUrlEncoded(encodeURIComponent(input));
      } catch {
        setUrlEncoded('');
      }

      try {
        setUrlDecoded(decodeURIComponent(input));
      } catch {
        setUrlDecoded('النص غير مشفر بصيغة URL صالحة');
      }
    }

    computeHashes();
  }, [input]);

  const copyItem = (val: string, key: string) => {
    navigator.clipboard.writeText(val);
    setCopiedKey(key);
    confetti({ particleCount: 30, spread: 45, origin: { y: 0.8 } });
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-6" id="hash-encoder-tool">
      {/* Input */}
      <div className="space-y-2">
        <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
          النص أو القيمة المراد تشفيرها أو تحويلها:
        </label>
        <textarea
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="أدخل النص هنا..."
          rows={3}
          className="w-full p-3.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-emerald-500 outline-none text-sm"
        />
      </div>

      {/* Tabs */}
      <div className="flex border-b border-gray-200 dark:border-gray-700 gap-2">
        <button
          onClick={() => setActiveTab('crypto')}
          className={`pb-2.5 px-4 text-xs font-bold transition border-b-2 flex items-center gap-1.5 ${
            activeTab === 'crypto'
              ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
        >
          <Lock className="w-3.5 h-3.5" />
          بصمات التشفير (Hashes)
        </button>
        <button
          onClick={() => setActiveTab('base64')}
          className={`pb-2.5 px-4 text-xs font-bold transition border-b-2 flex items-center gap-1.5 ${
            activeTab === 'base64'
              ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
        >
          <KeyRound className="w-3.5 h-3.5" />
          ترميز Base64
        </button>
        <button
          onClick={() => setActiveTab('url')}
          className={`pb-2.5 px-4 text-xs font-bold transition border-b-2 flex items-center gap-1.5 ${
            activeTab === 'url'
              ? 'border-emerald-500 text-emerald-600 dark:text-emerald-400'
              : 'border-transparent text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          ترميز روابط الويب (URL)
        </button>
      </div>

      {/* Crypto Hashes Tab */}
      {activeTab === 'crypto' && (
        <div className="space-y-4">
          <div className="p-4 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/70 dark:border-gray-700/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">SHA-256:</span>
              <button
                onClick={() => copyItem(sha256, 'sha256')}
                className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
              >
                {copiedKey === 'sha256' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'sha256' ? 'تم النسخ' : 'نسخ'}
              </button>
            </div>
            <div className="p-2.5 bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 font-mono text-xs text-gray-800 dark:text-gray-200 break-all select-all">
              {sha256 || '...'}
            </div>
          </div>

          <div className="p-4 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/70 dark:border-gray-700/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">SHA-1:</span>
              <button
                onClick={() => copyItem(sha1, 'sha1')}
                className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
              >
                {copiedKey === 'sha1' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'sha1' ? 'تم النسخ' : 'نسخ'}
              </button>
            </div>
            <div className="p-2.5 bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 font-mono text-xs text-gray-800 dark:text-gray-200 break-all select-all">
              {sha1 || '...'}
            </div>
          </div>

          <div className="p-4 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/70 dark:border-gray-700/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">SHA-512:</span>
              <button
                onClick={() => copyItem(sha512, 'sha512')}
                className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
              >
                {copiedKey === 'sha512' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'sha512' ? 'تم النسخ' : 'نسخ'}
              </button>
            </div>
            <div className="p-2.5 bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 font-mono text-xs text-gray-800 dark:text-gray-200 break-all select-all max-h-24 overflow-y-auto">
              {sha512 || '...'}
            </div>
          </div>
        </div>
      )}

      {/* Base64 Tab */}
      {activeTab === 'base64' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/70 dark:border-gray-700/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">تشفير (Base64 Encode):</span>
              <button
                onClick={() => copyItem(base64Encoded, 'b64e')}
                className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
              >
                {copiedKey === 'b64e' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'b64e' ? 'تم النسخ' : 'نسخ'}
              </button>
            </div>
            <textarea
              readOnly
              value={base64Encoded}
              rows={5}
              className="w-full p-2.5 bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 font-mono text-xs text-gray-800 dark:text-gray-200 break-all outline-none"
            />
          </div>

          <div className="p-4 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/70 dark:border-gray-700/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">فك تشفير (Base64 Decode):</span>
              <button
                onClick={() => copyItem(base64Decoded, 'b64d')}
                className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
              >
                {copiedKey === 'b64d' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'b64d' ? 'تم النسخ' : 'نسخ'}
              </button>
            </div>
            <textarea
              readOnly
              value={base64Decoded}
              rows={5}
              className="w-full p-2.5 bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 font-mono text-xs text-gray-800 dark:text-gray-200 break-all outline-none"
            />
          </div>
        </div>
      )}

      {/* URL Tab */}
      {activeTab === 'url' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-4 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/70 dark:border-gray-700/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">ترميز الرابط (URL Encoded):</span>
              <button
                onClick={() => copyItem(urlEncoded, 'urle')}
                className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
              >
                {copiedKey === 'urle' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'urle' ? 'تم النسخ' : 'نسخ'}
              </button>
            </div>
            <textarea
              readOnly
              value={urlEncoded}
              rows={5}
              className="w-full p-2.5 bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 font-mono text-xs text-gray-800 dark:text-gray-200 break-all outline-none"
            />
          </div>

          <div className="p-4 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/70 dark:border-gray-700/60 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">فك ترميز الرابط (URL Decoded):</span>
              <button
                onClick={() => copyItem(urlDecoded, 'urld')}
                className="text-xs text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
              >
                {copiedKey === 'urld' ? <Check className="w-3 h-3" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'urld' ? 'تم النسخ' : 'نسخ'}
              </button>
            </div>
            <textarea
              readOnly
              value={urlDecoded}
              rows={5}
              className="w-full p-2.5 bg-white dark:bg-gray-900 rounded-lg border border-gray-200 dark:border-gray-800 font-mono text-xs text-gray-800 dark:text-gray-200 break-all outline-none"
            />
          </div>
        </div>
      )}
    </div>
  );
}
