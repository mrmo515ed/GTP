import React, { useState, useMemo } from 'react';
import { HeartPulse, Droplets, Flame, Scale, Activity } from 'lucide-react';

export function HealthCalculator() {
  const [gender, setGender] = useState<'male' | 'female'>('male');
  const [age, setAge] = useState<number>(25);
  const [heightCm, setHeightCm] = useState<number>(175);
  const [weightKg, setWeightKg] = useState<number>(72);
  const [activity, setActivity] = useState<number>(1.375); // 1.2, 1.375, 1.55, 1.725

  const stats = useMemo(() => {
    const heightM = heightCm / 100;
    if (heightM <= 0 || weightKg <= 0) return null;

    // BMI
    const bmi = weightKg / (heightM * heightM);
    let bmiCategory = '';
    let bmiColor = '';
    if (bmi < 18.5) {
      bmiCategory = 'نقص في الوزن (Underweight)';
      bmiColor = 'text-blue-500';
    } else if (bmi < 25) {
      bmiCategory = 'وزن مثالي وطبيعي (Normal weight)';
      bmiColor = 'text-emerald-500';
    } else if (bmi < 30) {
      bmiCategory = 'زيادة في الوزن (Overweight)';
      bmiColor = 'text-amber-500';
    } else {
      bmiCategory = 'سمنة (Obese)';
      bmiColor = 'text-rose-500';
    }

    // Ideal Weight Range (BMI 18.5 - 24.9)
    const minIdealWeight = 18.5 * (heightM * heightM);
    const maxIdealWeight = 24.9 * (heightM * heightM);

    // BMR (Mifflin-St Jeor)
    let bmr = 10 * weightKg + 6.25 * heightCm - 5 * age;
    if (gender === 'male') {
      bmr += 5;
    } else {
      bmr -= 161;
    }

    // TDEE (Total Daily Energy Expenditure)
    const tdee = Math.round(bmr * activity);

    // Calories for weight loss / gain
    const weightLossCalories = tdee - 500;
    const weightGainCalories = tdee + 500;

    // Daily Water Intake (approx 35ml per kg)
    const dailyWaterLiters = (weightKg * 0.035).toFixed(1);
    const waterGlasses = Math.round(weightKg * 0.035 * 4); // 250ml cup

    return {
      bmi: bmi.toFixed(1),
      bmiCategory,
      bmiColor,
      minIdealWeight: minIdealWeight.toFixed(1),
      maxIdealWeight: maxIdealWeight.toFixed(1),
      bmr: Math.round(bmr),
      tdee,
      weightLossCalories,
      weightGainCalories,
      dailyWaterLiters,
      waterGlasses,
    };
  }, [gender, age, heightCm, weightKg, activity]);

  return (
    <div className="space-y-6" id="health-calculator-tool">
      {/* Inputs Header */}
      <div className="p-4 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-2xl space-y-4">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
              الجنس:
            </label>
            <div className="flex rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-800 text-xs">
              <button
                onClick={() => setGender('male')}
                className={`flex-1 py-2 font-bold transition ${
                  gender === 'male' ? 'bg-emerald-600 text-white' : 'text-gray-700 dark:text-gray-300'
                }`}
              >
                ذكر
              </button>
              <button
                onClick={() => setGender('female')}
                className={`flex-1 py-2 font-bold transition ${
                  gender === 'female' ? 'bg-emerald-600 text-white' : 'text-gray-700 dark:text-gray-300'
                }`}
              >
                أنثى
              </button>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
              العمر (سنة):
            </label>
            <input
              type="number"
              min={10}
              max={100}
              value={age}
              onChange={(e) => setAge(Number(e.target.value))}
              className="w-full p-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold text-center"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
              الطول (سم):
            </label>
            <input
              type="number"
              min={100}
              max={230}
              value={heightCm}
              onChange={(e) => setHeightCm(Number(e.target.value))}
              className="w-full p-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold text-center"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
              الوزن (كجم):
            </label>
            <input
              type="number"
              min={30}
              max={250}
              value={weightKg}
              onChange={(e) => setWeightKg(Number(e.target.value))}
              className="w-full p-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold text-center"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
            مستوى النشاط البدني اليومي:
          </label>
          <select
            value={activity}
            onChange={(e) => setActivity(Number(e.target.value))}
            className="w-full p-2 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-xs font-bold"
          >
            <option value={1.2}>خامل (قليل أو بدون نشاط رياضي)</option>
            <option value={1.375}>نشاط خفيف (تمارين 1-3 أيام أسبوعياً)</option>
            <option value={1.55}>نشاط متوسط (تمارين 3-5 أيام أسبوعياً)</option>
            <option value={1.725}>نشاط عالي جداً (تمارين قوية يومية أو عمل شاق)</option>
          </select>
        </div>
      </div>

      {stats && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {/* BMI Card */}
          <div className="p-5 bg-white dark:bg-gray-800/80 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-xs space-y-3">
            <div className="flex items-center gap-2.5 text-sm font-bold text-gray-800 dark:text-gray-200">
              <Scale className="w-5 h-5 text-emerald-600" />
              <span>مؤشر كتلة الجسم (BMI)</span>
            </div>
            <div className="text-center py-2">
              <span className="text-4xl font-extrabold font-heading text-emerald-600 dark:text-emerald-400">
                {stats.bmi}
              </span>
              <div className={`text-xs font-bold mt-1 ${stats.bmiColor}`}>
                {stats.bmiCategory}
              </div>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs text-gray-600 dark:text-gray-400 flex justify-between">
              <span>نطاق الوزن المثالي لطولك:</span>
              <strong className="text-gray-900 dark:text-gray-100">
                {stats.minIdealWeight} - {stats.maxIdealWeight} كجم
              </strong>
            </div>
          </div>

          {/* Calories Card */}
          <div className="p-5 bg-white dark:bg-gray-800/80 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-xs space-y-3">
            <div className="flex items-center gap-2.5 text-sm font-bold text-gray-800 dark:text-gray-200">
              <Flame className="w-5 h-5 text-amber-500" />
              <span>الاحتياج اليومي من السعرات (TDEE)</span>
            </div>
            <div className="text-center py-2">
              <span className="text-4xl font-extrabold font-heading text-amber-600 dark:text-amber-400">
                {stats.tdee.toLocaleString('ar-EG')}
              </span>
              <span className="text-xs text-gray-500 block mt-1">سعرة حرارية لتثبيت الوزن الحالي</span>
            </div>
            <div className="grid grid-cols-2 gap-2 text-xs">
              <div className="p-2.5 bg-rose-50 dark:bg-rose-950/30 rounded-lg text-center border border-rose-100 dark:border-rose-900/30">
                <span className="text-gray-500 block">لإنقاص الوزن:</span>
                <strong className="text-rose-600 dark:text-rose-400 text-sm font-bold">{stats.weightLossCalories} سعرة</strong>
              </div>
              <div className="p-2.5 bg-blue-50 dark:bg-blue-950/30 rounded-lg text-center border border-blue-100 dark:border-blue-900/30">
                <span className="text-gray-500 block">لزيادة الوزن:</span>
                <strong className="text-blue-600 dark:text-blue-400 text-sm font-bold">{stats.weightGainCalories} سعرة</strong>
              </div>
            </div>
          </div>

          {/* Water Intake */}
          <div className="md:col-span-2 p-4 bg-gradient-to-r from-blue-500/10 via-cyan-500/10 to-teal-500/10 border border-blue-500/20 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-500 text-white rounded-xl">
                <Droplets className="w-6 h-6" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200">
                  احتياجك اليومي الموصى به من الماء:
                </h4>
                <p className="text-xs text-gray-500 dark:text-gray-400">
                  للحفاظ على نشاطك وصحة الكلى والجهاز الهضمي
                </p>
              </div>
            </div>
            <div className="text-center sm:text-left">
              <span className="text-2xl sm:text-3xl font-extrabold text-blue-600 dark:text-blue-400 font-heading">
                {stats.dailyWaterLiters} لتر
              </span>
              <span className="text-xs text-gray-500 block">
                (ما يعادل حوالي {stats.waterGlasses} أكواب يومياً)
              </span>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
