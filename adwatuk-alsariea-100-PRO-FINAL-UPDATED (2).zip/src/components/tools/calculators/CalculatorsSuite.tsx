import React, { useState, useMemo } from 'react';
import {
  Calculator,
  Percent,
  Tag,
  Receipt,
  TrendingUp,
  Activity,
  Calendar,
  CreditCard,
  Type,
  Copy,
  Check
} from 'lucide-react';

interface Props {
  defaultTab?:
    | 'percentage'
    | 'discount'
    | 'vat'
    | 'profit-margin'
    | 'bmi'
    | 'age-calculator'
    | 'loan-installment'
    | 'number-to-words';
}

export function CalculatorsSuite({ defaultTab = 'percentage' }: Props) {
  const [activeTab, setActiveTab] = useState<string>(defaultTab);
  const [copied, setCopied] = useState<boolean>(false);

  // 1. Percentage State
  const [pctVal, setPctVal] = useState<number>(15);
  const [pctTotal, setPctTotal] = useState<number>(500);

  // 2. Discount State
  const [originalPrice, setOriginalPrice] = useState<number>(200);
  const [discountPercent, setDiscountPercent] = useState<number>(25);

  // 3. VAT State
  const [vatAmount, setVatAmount] = useState<number>(1000);
  const [vatRate, setVatRate] = useState<number>(15);
  const [vatMode, setVatMode] = useState<'exclusive' | 'inclusive'>('exclusive');

  // 4. Profit & Margin State
  const [costPrice, setCostPrice] = useState<number>(80);
  const [sellingPrice, setSellingPrice] = useState<number>(120);

  // 5. BMI State
  const [bmiWeight, setBmiWeight] = useState<number>(75);
  const [bmiHeight, setBmiHeight] = useState<number>(175);

  // 6. Age Calculator State
  const [birthDate, setBirthDate] = useState<string>('1995-06-15');

  // 7. Loan State
  const [loanAmount, setLoanAmount] = useState<number>(100000);
  const [annualInterest, setAnnualInterest] = useState<number>(4.5);
  const [loanMonths, setLoanMonths] = useState<number>(60);

  // 8. Number to Words State
  const [numInput, setNumInput] = useState<number>(1450250);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // 1. Percentage calculation
  const percentageResult = (pctVal / 100) * pctTotal;

  // 2. Discount calculation
  const discountSaved = (discountPercent / 100) * originalPrice;
  const finalPriceAfterDiscount = Math.max(0, originalPrice - discountSaved);

  // 3. VAT calculation
  const vatCalculations = useMemo(() => {
    if (vatMode === 'exclusive') {
      const tax = (vatRate / 100) * vatAmount;
      return { net: vatAmount, tax, total: vatAmount + tax };
    } else {
      const net = vatAmount / (1 + vatRate / 100);
      const tax = vatAmount - net;
      return { net, tax, total: vatAmount };
    }
  }, [vatAmount, vatRate, vatMode]);

  // 4. Profit & Margin
  const profitMetrics = useMemo(() => {
    const profit = sellingPrice - costPrice;
    const margin = sellingPrice > 0 ? (profit / sellingPrice) * 100 : 0;
    const markup = costPrice > 0 ? (profit / costPrice) * 100 : 0;
    return { profit, margin, markup };
  }, [costPrice, sellingPrice]);

  // 5. BMI
  const bmiMetrics = useMemo(() => {
    const hMeter = bmiHeight / 100;
    if (hMeter <= 0) return { bmi: 0, category: '', color: '' };
    const bmi = bmiWeight / (hMeter * hMeter);
    let category = 'وزن طبيعي ومثالي';
    let color = 'text-emerald-600';
    if (bmi < 18.5) { category = 'نقص في الوزن (نحافة)'; color = 'text-amber-500'; }
    else if (bmi >= 25 && bmi < 30) { category = 'وزن زائد'; color = 'text-amber-600'; }
    else if (bmi >= 30) { category = 'سمنة'; color = 'text-rose-600'; }
    return { bmi: Number(bmi.toFixed(1)), category, color };
  }, [bmiWeight, bmiHeight]);

  // 6. Age & Birthday
  const ageMetrics = useMemo(() => {
    const birth = new Date(birthDate);
    const now = new Date();
    if (isNaN(birth.getTime())) return null;

    let years = now.getFullYear() - birth.getFullYear();
    let months = now.getMonth() - birth.getMonth();
    let days = now.getDate() - birth.getDate();

    if (days < 0) {
      months--;
      const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0);
      days += prevMonth.getDate();
    }
    if (months < 0) {
      years--;
      months += 12;
    }

    // Days until next birthday
    const nextBday = new Date(now.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBday < now) nextBday.setFullYear(now.getFullYear() + 1);
    const daysUntilNext = Math.ceil((nextBday.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));

    const totalDaysLived = Math.floor((now.getTime() - birth.getTime()) / (1000 * 60 * 60 * 24));

    return { years, months, days, daysUntilNext, totalDaysLived };
  }, [birthDate]);

  // 7. Loan Installment
  const loanMetrics = useMemo(() => {
    const r = annualInterest / 100 / 12;
    const n = loanMonths;
    if (r === 0) {
      const p = loanAmount / n;
      return { monthly: p, totalInterest: 0, totalPaid: loanAmount };
    }
    const monthly = (loanAmount * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPaid = monthly * n;
    const totalInterest = totalPaid - loanAmount;
    return {
      monthly: Math.round(monthly),
      totalInterest: Math.round(totalInterest),
      totalPaid: Math.round(totalPaid)
    };
  }, [loanAmount, annualInterest, loanMonths]);

  // 8. Number to Arabic Words (Tafqeet)
  const arabicWords = useMemo(() => {
    const ones = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة'];
    const tens = ['', 'عشرة', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
    const hundreds = ['', 'مائة', 'مئتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];

    const num = Math.abs(Math.floor(numInput));
    if (num === 0) return 'صفر';

    const convertChunk = (n: number): string => {
      const h = Math.floor(n / 100);
      const t = Math.floor((n % 100) / 10);
      const o = n % 10;
      const parts: string[] = [];

      if (h > 0) parts.push(hundreds[h]);
      if (t === 1 && o > 0) {
        if (o === 1) parts.push('أحد عشر');
        else if (o === 2) parts.push('اثنا عشر');
        else parts.push(`${ones[o]} عشر`);
      } else {
        if (o > 0) parts.push(ones[o]);
        if (t > 0) parts.push(tens[t]);
      }
      return parts.join(' و ');
    };

    const millions = Math.floor(num / 1000000);
    const thousands = Math.floor((num % 1000000) / 1000);
    const remainder = num % 1000;

    const sections: string[] = [];
    if (millions > 0) sections.push(`${convertChunk(millions)} مليون`);
    if (thousands > 0) sections.push(`${convertChunk(thousands)} ألف`);
    if (remainder > 0) sections.push(convertChunk(remainder));

    return sections.join(' و ') + ' ريال فقط لا غير';
  }, [numInput]);

  const tabs = [
    { id: 'percentage', label: 'النسبة المئوية', icon: Percent },
    { id: 'discount', label: 'حاسبة الخصم', icon: Tag },
    { id: 'vat', label: 'الضريبة المضافة (VAT)', icon: Receipt },
    { id: 'profit-margin', label: 'الربح والهامش', icon: TrendingUp },
    { id: 'bmi', label: 'كتلة الجسم (BMI)', icon: Activity },
    { id: 'age-calculator', label: 'حاسبة العمر', icon: Calendar },
    { id: 'loan-installment', label: 'حاسبة القروض والأقساط', icon: CreditCard },
    { id: 'number-to-words', label: 'تفقيد الأرقام لكلمات', icon: Type }
  ];

  return (
    <div className="space-y-6" id="calculators-suite">
      {/* Tabs */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-200 dark:scrollbar-thumb-gray-800">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/60 border border-gray-200/80 dark:border-gray-700/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: Percentage */}
      {activeTab === 'percentage' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold block mb-1">النسبة المئوية (%)</label>
              <input
                type="number"
                value={pctVal}
                onChange={e => setPctVal(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
              />
            </div>
            <div>
              <label className="text-xs font-bold block mb-1">من إجمالي المبلغ / الرقم</label>
              <input
                type="number"
                value={pctTotal}
                onChange={e => setPctTotal(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
              />
            </div>
          </div>

          <div className="p-6 bg-gray-50 dark:bg-gray-900 rounded-2xl text-center space-y-1">
            <span className="text-xs font-bold text-gray-400">الناتج:</span>
            <div className="text-3xl font-black text-emerald-600 font-mono">{percentageResult}</div>
            <p className="text-xs text-gray-500">{pctVal}% من {pctTotal} تساوي {percentageResult}</p>
          </div>
        </div>
      )}

      {/* Tab 2: Discount */}
      {activeTab === 'discount' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold block mb-1">السعر الأصلي</label>
              <input
                type="number"
                value={originalPrice}
                onChange={e => setOriginalPrice(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
              />
            </div>
            <div>
              <label className="text-xs font-bold block mb-1">نسبة الخصم (%)</label>
              <input
                type="number"
                value={discountPercent}
                onChange={e => setDiscountPercent(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 text-center">
              <span className="text-xs text-emerald-700 dark:text-emerald-300 block font-bold">السعر النهائي بعد الخصم</span>
              <span className="text-2xl font-black text-emerald-600 font-mono">{finalPriceAfterDiscount.toFixed(2)}</span>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 text-center">
              <span className="text-xs text-gray-500 block font-bold">المبلغ الموفر</span>
              <span className="text-2xl font-black text-indigo-600 font-mono">{discountSaved.toFixed(2)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: VAT */}
      {activeTab === 'vat' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="flex gap-2">
            <button
              onClick={() => setVatMode('exclusive')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl ${vatMode === 'exclusive' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
            >
              المبلغ غير شامل الضريبة (إضافة VAT)
            </button>
            <button
              onClick={() => setVatMode('inclusive')}
              className={`flex-1 py-2 text-xs font-bold rounded-xl ${vatMode === 'inclusive' ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700'}`}
            >
              المبلغ شامل الضريبة (استخراج VAT)
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold block mb-1">المبلغ</label>
              <input
                type="number"
                value={vatAmount}
                onChange={e => setVatAmount(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
              />
            </div>
            <div>
              <label className="text-xs font-bold block mb-1">نسبة الضريبة (%)</label>
              <input
                type="number"
                value={vatRate}
                onChange={e => setVatRate(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl">
              <span className="text-xs text-gray-400 block mb-1">المبلغ الصافي</span>
              <span className="text-base font-bold font-mono">{vatCalculations.net.toFixed(2)}</span>
            </div>
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl">
              <span className="text-xs text-rose-500 block mb-1">قيمة الضريبة</span>
              <span className="text-base font-bold font-mono text-rose-600">{vatCalculations.tax.toFixed(2)}</span>
            </div>
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200">
              <span className="text-xs text-emerald-700 block mb-1 font-bold">الإجمالي الكلي</span>
              <span className="text-base font-black font-mono text-emerald-600">{vatCalculations.total.toFixed(2)}</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: Profit & Margin */}
      {activeTab === 'profit-margin' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold block mb-1">سعر التكلفة (Cost)</label>
              <input
                type="number"
                value={costPrice}
                onChange={e => setCostPrice(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
              />
            </div>
            <div>
              <label className="text-xs font-bold block mb-1">سعر البيع (Revenue)</label>
              <input
                type="number"
                value={sellingPrice}
                onChange={e => setSellingPrice(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-xl">
              <span className="text-xs text-gray-400 block mb-1">صافي الربح</span>
              <span className="text-xl font-bold font-mono text-emerald-600">{profitMetrics.profit.toFixed(2)}</span>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-xl">
              <span className="text-xs text-gray-400 block mb-1">هامش الربح (Margin)</span>
              <span className="text-xl font-bold font-mono text-indigo-600">{profitMetrics.margin.toFixed(1)}%</span>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-xl">
              <span className="text-xs text-gray-400 block mb-1">نسبة الزيادة (Markup)</span>
              <span className="text-xl font-bold font-mono text-amber-600">{profitMetrics.markup.toFixed(1)}%</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: BMI */}
      {activeTab === 'bmi' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-bold block mb-1">الوزن (كجم)</label>
              <input
                type="number"
                value={bmiWeight}
                onChange={e => setBmiWeight(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
              />
            </div>
            <div>
              <label className="text-xs font-bold block mb-1">الطول (سم)</label>
              <input
                type="number"
                value={bmiHeight}
                onChange={e => setBmiHeight(Number(e.target.value))}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
              />
            </div>
          </div>

          <div className="p-6 bg-gray-50 dark:bg-gray-900 rounded-2xl text-center space-y-2">
            <span className="text-xs font-bold text-gray-400">مؤشر كتلة جسمك (BMI):</span>
            <div className="text-4xl font-black font-mono text-emerald-600">{bmiMetrics.bmi}</div>
            <div className={`text-sm font-bold ${bmiMetrics.color}`}>{bmiMetrics.category}</div>
          </div>
        </div>
      )}

      {/* Tab 6: Age */}
      {activeTab === 'age-calculator' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold block">اختر تاريخ الميلاد:</label>
            <input
              type="date"
              value={birthDate}
              onChange={e => setBirthDate(e.target.value)}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
            />
          </div>

          {ageMetrics && (
            <div className="space-y-4">
              <div className="grid grid-cols-3 gap-3 text-center">
                <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200">
                  <span className="text-2xl font-black text-emerald-600 font-mono block">{ageMetrics.years}</span>
                  <span className="text-xs font-bold text-gray-600 dark:text-gray-400">سنة</span>
                </div>
                <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200">
                  <span className="text-2xl font-black text-emerald-600 font-mono block">{ageMetrics.months}</span>
                  <span className="text-xs font-bold text-gray-600 dark:text-gray-400">شهر</span>
                </div>
                <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200">
                  <span className="text-2xl font-black text-emerald-600 font-mono block">{ageMetrics.days}</span>
                  <span className="text-xs font-bold text-gray-600 dark:text-gray-400">يوم</span>
                </div>
              </div>

              <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-xl flex items-center justify-between text-xs font-bold">
                <span className="text-gray-500">الأيام المتبقية على عيد ميلادك القادم:</span>
                <span className="text-indigo-600 font-mono text-sm">{ageMetrics.daysUntilNext} يوم</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 7: Loans & Installments */}
      {activeTab === 'loan-installment' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="text-xs font-bold block mb-1">مبلغ التمويل</label>
              <input type="number" value={loanAmount} onChange={e => setLoanAmount(Number(e.target.value))} className="w-full p-2.5 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border" />
            </div>
            <div>
              <label className="text-xs font-bold block mb-1">نسبة الفائدة السنوية (%)</label>
              <input type="number" step="0.1" value={annualInterest} onChange={e => setAnnualInterest(Number(e.target.value))} className="w-full p-2.5 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border" />
            </div>
            <div>
              <label className="text-xs font-bold block mb-1">المدة (بالشهور)</label>
              <input type="number" value={loanMonths} onChange={e => setLoanMonths(Number(e.target.value))} className="w-full p-2.5 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border" />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 text-center">
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200">
              <span className="text-xs font-bold text-emerald-700 block mb-1">القسط الشهري</span>
              <span className="text-xl font-black text-emerald-600 font-mono">{loanMetrics.monthly.toLocaleString()}</span>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-xl">
              <span className="text-xs font-bold text-gray-400 block mb-1">إجمالي الفوائد</span>
              <span className="text-lg font-bold font-mono text-rose-600">{loanMetrics.totalInterest.toLocaleString()}</span>
            </div>
            <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-xl">
              <span className="text-xs font-bold text-gray-400 block mb-1">المبلغ الكلي للسداد</span>
              <span className="text-lg font-bold font-mono">{loanMetrics.totalPaid.toLocaleString()}</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 8: Number to Words (Tafqeet) */}
      {activeTab === 'number-to-words' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold block">أدخل الرقم المراد تفقيطه بالكلمات العربية:</label>
            <input
              type="number"
              value={numInput}
              onChange={e => setNumInput(Number(e.target.value))}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border"
            />
          </div>

          <div className="p-5 bg-gray-50 dark:bg-gray-900 rounded-2xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-400">الصيغة العربية المكتوبة:</span>
              <button
                onClick={() => copyToClipboard(arabicWords)}
                className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 text-xs font-bold rounded-lg flex items-center gap-1"
              >
                <Copy className="w-3.5 h-3.5" /> نسخ النص
              </button>
            </div>
            <div className="text-base font-bold text-gray-800 dark:text-gray-100 leading-relaxed font-sans">
              {arabicWords}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
