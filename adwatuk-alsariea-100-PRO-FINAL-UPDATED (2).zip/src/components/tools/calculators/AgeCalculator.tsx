import React, { useState, useMemo } from 'react';
import { Calendar, Cake, Star, Clock, Sparkles, Gift } from 'lucide-react';
import confetti from 'canvas-confetti';

export function AgeCalculator() {
  const [birthDate, setBirthDate] = useState<string>('2000-01-01');

  const ageData = useMemo(() => {
    if (!birthDate) return null;
    const birth = new Date(birthDate);
    const now = new Date();

    if (isNaN(birth.getTime()) || birth > now) {
      return null;
    }

    let years = now.getFullYear() - birth.getFullYear();
    let months = now.getMonth() - birth.getMonth();
    let days = now.getDate() - birth.getDate();

    if (days < 0) {
      months--;
      // get days in previous month
      const prevMonth = new Date(now.getFullYear(), now.getMonth(), 0);
      days += prevMonth.getDate();
    }

    if (months < 0) {
      years--;
      months += 12;
    }

    const totalDiffMs = now.getTime() - birth.getTime();
    const totalDays = Math.floor(totalDiffMs / (1000 * 60 * 60 * 24));
    const totalWeeks = Math.floor(totalDays / 7);
    const totalHours = Math.floor(totalDiffMs / (1000 * 60 * 60));
    const totalMinutes = Math.floor(totalDiffMs / (1000 * 60));
    const totalSeconds = Math.floor(totalDiffMs / 1000);

    // Day of the week born
    const daysOfWeekAr = [
      'الأحد',
      'الإثنين',
      'الثلاثاء',
      'الأربعاء',
      'الخميس',
      'الجمعة',
      'السبت',
    ];
    const bornDayName = daysOfWeekAr[birth.getDay()];

    // Next Birthday calculation
    let nextBirthday = new Date(now.getFullYear(), birth.getMonth(), birth.getDate());
    if (nextBirthday < now) {
      nextBirthday = new Date(now.getFullYear() + 1, birth.getMonth(), birth.getDate());
    }
    const daysUntilNextBirthday = Math.ceil(
      (nextBirthday.getTime() - now.getTime()) / (1000 * 60 * 60 * 24)
    );
    const nextBirthdayDayName = daysOfWeekAr[nextBirthday.getDay()];

    // Zodiac Sign
    const m = birth.getMonth() + 1;
    const d = birth.getDate();
    let zodiac = '';
    let zodiacIcon = '♈';

    if ((m === 3 && d >= 21) || (m === 4 && d <= 19)) {
      zodiac = 'برج الحمل (Aries)';
      zodiacIcon = '♈';
    } else if ((m === 4 && d >= 20) || (m === 5 && d <= 20)) {
      zodiac = 'برج الثور (Taurus)';
      zodiacIcon = '♉';
    } else if ((m === 5 && d >= 21) || (m === 6 && d <= 20)) {
      zodiac = 'برج الجوزاء (Gemini)';
      zodiacIcon = '♊';
    } else if ((m === 6 && d >= 21) || (m === 7 && d <= 22)) {
      zodiac = 'برج السرطان (Cancer)';
      zodiacIcon = '♋';
    } else if ((m === 7 && d >= 23) || (m === 8 && d <= 22)) {
      zodiac = 'برج الأسد (Leo)';
      zodiacIcon = '♌';
    } else if ((m === 8 && d >= 23) || (m === 9 && d <= 22)) {
      zodiac = 'برج العذراء (Virgo)';
      zodiacIcon = '♍';
    } else if ((m === 9 && d >= 23) || (m === 10 && d <= 22)) {
      zodiac = 'برج الميزان (Libra)';
      zodiacIcon = '♎';
    } else if ((m === 10 && d >= 23) || (m === 11 && d <= 21)) {
      zodiac = 'برج العقرب (Scorpio)';
      zodiacIcon = '♏';
    } else if ((m === 11 && d >= 22) || (m === 12 && d <= 21)) {
      zodiac = 'برج القوس (Sagittarius)';
      zodiacIcon = '♐';
    } else if ((m === 12 && d >= 22) || (m === 1 && d <= 19)) {
      zodiac = 'برج الجدي (Capricorn)';
      zodiacIcon = '♑';
    } else if ((m === 1 && d >= 20) || (m === 2 && d <= 18)) {
      zodiac = 'برج الدلو (Aquarius)';
      zodiacIcon = '♒';
    } else {
      zodiac = 'برج الحوت (Pisces)';
      zodiacIcon = '♓';
    }

    return {
      years,
      months,
      days,
      totalDays,
      totalWeeks,
      totalHours,
      totalMinutes,
      totalSeconds,
      bornDayName,
      daysUntilNextBirthday,
      nextBirthdayDayName,
      zodiac,
      zodiacIcon,
    };
  }, [birthDate]);

  return (
    <div className="space-y-6" id="age-calculator-tool">
      {/* Date Picker Input */}
      <div className="p-4 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-2xl flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-emerald-500 text-white rounded-xl shadow-xs">
            <Cake className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-sm font-bold text-gray-800 dark:text-gray-200">
              اختر تاريخ ميلادك:
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400">
              حساب العمر الدقيق حتى الثانية الحالية
            </p>
          </div>
        </div>

        <input
          type="date"
          value={birthDate}
          max={new Date().toISOString().split('T')[0]}
          onChange={(e) => {
            setBirthDate(e.target.value);
            confetti({ particleCount: 20, spread: 40, origin: { y: 0.8 } });
          }}
          className="p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 font-bold text-sm text-gray-800 dark:text-gray-200 outline-none focus:ring-2 focus:ring-emerald-500"
        />
      </div>

      {ageData && (
        <div className="space-y-6">
          {/* Main Age Card */}
          <div className="p-6 bg-gradient-to-br from-emerald-500/10 via-teal-500/10 to-blue-500/10 border border-emerald-500/20 rounded-2xl text-center space-y-3">
            <span className="text-xs font-semibold text-gray-500 dark:text-gray-400 uppercase">
              عمرك الحالي بدقة هو:
            </span>
            <div className="flex flex-wrap items-center justify-center gap-4 text-emerald-700 dark:text-emerald-400">
              <div className="p-3 bg-white/80 dark:bg-gray-900/80 rounded-xl border border-emerald-100 dark:border-emerald-900/30 min-w-24 shadow-xs">
                <span className="text-3xl sm:text-4xl font-extrabold font-heading block">{ageData.years}</span>
                <span className="text-xs text-gray-600 dark:text-gray-400 font-semibold">سنة</span>
              </div>
              <div className="p-3 bg-white/80 dark:bg-gray-900/80 rounded-xl border border-emerald-100 dark:border-emerald-900/30 min-w-24 shadow-xs">
                <span className="text-3xl sm:text-4xl font-extrabold font-heading block">{ageData.months}</span>
                <span className="text-xs text-gray-600 dark:text-gray-400 font-semibold">شهر</span>
              </div>
              <div className="p-3 bg-white/80 dark:bg-gray-900/80 rounded-xl border border-emerald-100 dark:border-emerald-900/30 min-w-24 shadow-xs">
                <span className="text-3xl sm:text-4xl font-extrabold font-heading block">{ageData.days}</span>
                <span className="text-xs text-gray-600 dark:text-gray-400 font-semibold">يوم</span>
              </div>
            </div>
            <div className="text-xs text-gray-600 dark:text-gray-400 pt-2 font-medium">
              يوم ولادتك كان يوم <strong className="text-emerald-600 dark:text-emerald-400">{ageData.bornDayName}</strong> • {ageData.zodiacIcon} {ageData.zodiac}
            </div>
          </div>

          {/* Next Birthday & Zodiac */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div className="p-4 bg-amber-50/80 dark:bg-amber-950/20 border border-amber-200/60 dark:border-amber-900/30 rounded-xl flex items-center gap-3">
              <div className="p-3 bg-amber-500 text-white rounded-xl">
                <Gift className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs text-gray-500 dark:text-gray-400">يوم ميلادك القادم بعد:</div>
                <div className="text-base font-extrabold text-amber-700 dark:text-amber-400 font-heading">
                  {ageData.daysUntilNextBirthday === 0 ? 'اليوم! 🎉 عيد ميلاد سعيد!' : `${ageData.daysUntilNextBirthday} يوم (يوم ${ageData.nextBirthdayDayName})`}
                </div>
              </div>
            </div>

            <div className="p-4 bg-purple-50/80 dark:bg-purple-950/20 border border-purple-200/60 dark:border-purple-900/30 rounded-xl flex items-center gap-3">
              <div className="p-3 bg-purple-500 text-white rounded-xl">
                <Star className="w-5 h-5" />
              </div>
              <div>
                <div className="text-xs text-gray-500 dark:text-gray-400">البرج الفلكي:</div>
                <div className="text-base font-extrabold text-purple-700 dark:text-purple-400 font-heading">
                  {ageData.zodiac}
                </div>
              </div>
            </div>
          </div>

          {/* Detailed Lifetime Units Grid */}
          <div className="space-y-2">
            <h4 className="text-xs font-bold text-gray-700 dark:text-gray-300">
              إجمالي ما عشته بوحدات القياس المختلفة:
            </h4>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
              <div className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200 dark:border-gray-700 text-center">
                <div className="text-xs text-gray-500">الأسابيع:</div>
                <div className="text-lg font-bold text-gray-900 dark:text-gray-100 font-heading">
                  {ageData.totalWeeks.toLocaleString('ar-EG')}
                </div>
              </div>
              <div className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200 dark:border-gray-700 text-center">
                <div className="text-xs text-gray-500">الأيام:</div>
                <div className="text-lg font-bold text-gray-900 dark:text-gray-100 font-heading">
                  {ageData.totalDays.toLocaleString('ar-EG')}
                </div>
              </div>
              <div className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200 dark:border-gray-700 text-center">
                <div className="text-xs text-gray-500">الساعات:</div>
                <div className="text-lg font-bold text-gray-900 dark:text-gray-100 font-heading">
                  {ageData.totalHours.toLocaleString('ar-EG')}
                </div>
              </div>
              <div className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200 dark:border-gray-700 text-center">
                <div className="text-xs text-gray-500">الدقائق:</div>
                <div className="text-lg font-bold text-gray-900 dark:text-gray-100 font-heading">
                  {ageData.totalMinutes.toLocaleString('ar-EG')}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
