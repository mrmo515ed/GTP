import React, { useState } from 'react';
import { Calendar, Clock, Plus, Minus, ArrowRightLeft } from 'lucide-react';

export function DateCalculator() {
  const [activeTab, setActiveTab] = useState<'diff' | 'add' | 'hijri'>('diff');

  // 1. Difference
  const [startDate, setStartDate] = useState<string>('2026-01-01');
  const [endDate, setEndDate] = useState<string>('2026-12-31');

  const diffMs = Math.abs(new Date(endDate).getTime() - new Date(startDate).getTime());
  const diffDays = Math.round(diffMs / (1000 * 60 * 60 * 24));
  const diffWeeks = Math.floor(diffDays / 7);
  const diffMonths = (diffDays / 30.4375).toFixed(1);

  // 2. Add / Subtract days
  const [baseDate, setBaseDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [daysCount, setDaysCount] = useState<number>(30);
  const [operation, setOperation] = useState<'add' | 'sub'>('add');

  const targetDateObj = new Date(baseDate);
  if (operation === 'add') {
    targetDateObj.setDate(targetDateObj.getDate() + daysCount);
  } else {
    targetDateObj.setDate(targetDateObj.getDate() - daysCount);
  }
  const resultFormatted = isNaN(targetDateObj.getTime())
    ? ''
    : targetDateObj.toLocaleDateString('ar-EG', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric',
      });

  // 3. Hijri / Gregorian conversion
  const [gregorianDate, setGregorianDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const hijriFormatted = new Intl.DateTimeFormat('ar-SA-u-ca-islamic-umalqura', {
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date(gregorianDate));

  return (
    <div className="space-y-6" id="date-calculator-tool">
      <div className="flex flex-wrap gap-2 p-1.5 bg-gray-100 dark:bg-gray-800 rounded-xl">
        <button
          onClick={() => setActiveTab('diff')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            activeTab === 'diff'
              ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Clock className="w-3.5 h-3.5" />
          الفارق بين تاريخين
        </button>
        <button
          onClick={() => setActiveTab('add')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            activeTab === 'add'
              ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Plus className="w-3.5 h-3.5" />
          إضافة أو طرح أيام من تاريخ
        </button>
        <button
          onClick={() => setActiveTab('hijri')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            activeTab === 'hijri'
              ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Calendar className="w-3.5 h-3.5" />
          التحويل للهجري (تقويم أم القرى)
        </button>
      </div>

      {activeTab === 'diff' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                تاريخ البداية:
              </label>
              <input
                type="date"
                value={startDate}
                onChange={(e) => setStartDate(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
                تاريخ النهاية:
              </label>
              <input
                type="date"
                value={endDate}
                onChange={(e) => setEndDate(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3 p-5 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-2xl text-center">
            <div>
              <div className="text-xs text-gray-500">الفارق بالأيام</div>
              <div className="text-2xl sm:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 font-heading">
                {diffDays} يوم
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-500">الأسابيع</div>
              <div className="text-2xl sm:text-3xl font-extrabold text-blue-600 dark:text-blue-400 font-heading">
                {diffWeeks} أسبوع
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-500">تقريباً بالأشهر</div>
              <div className="text-2xl sm:text-3xl font-extrabold text-purple-600 dark:text-purple-400 font-heading">
                {diffMonths} شهر
              </div>
            </div>
          </div>
        </div>
      )}

      {activeTab === 'add' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">التاريخ المبدئي:</label>
              <input
                type="date"
                value={baseDate}
                onChange={(e) => setBaseDate(e.target.value)}
                className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">العملية:</label>
              <div className="flex rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-800 text-xs">
                <button
                  onClick={() => setOperation('add')}
                  className={`flex-1 py-2 font-bold ${operation === 'add' ? 'bg-emerald-600 text-white' : 'text-gray-700 dark:text-gray-300'}`}
                >
                  إضافة (+)
                </button>
                <button
                  onClick={() => setOperation('sub')}
                  className={`flex-1 py-2 font-bold ${operation === 'sub' ? 'bg-emerald-600 text-white' : 'text-gray-700 dark:text-gray-300'}`}
                >
                  طرح (-)
                </button>
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">عدد الأيام:</label>
              <input
                type="number"
                min={1}
                max={10000}
                value={daysCount}
                onChange={(e) => setDaysCount(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold text-center"
              />
            </div>
          </div>

          <div className="p-5 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl text-center space-y-1">
            <span className="text-xs text-gray-500">التاريخ الناتج:</span>
            <div className="text-xl sm:text-2xl font-extrabold text-emerald-700 dark:text-emerald-400 font-heading">
              {resultFormatted}
            </div>
          </div>
        </div>
      )}

      {activeTab === 'hijri' && (
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
              اختر التاريخ الميلادي للتحويل إلى الهجري:
            </label>
            <input
              type="date"
              value={gregorianDate}
              onChange={(e) => setGregorianDate(e.target.value)}
              className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold"
            />
          </div>

          <div className="p-6 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-2xl text-center space-y-2">
            <span className="text-xs text-gray-500">التاريخ الهجري المقابل (أم القرى):</span>
            <div className="text-2xl sm:text-3xl font-extrabold text-emerald-700 dark:text-emerald-400 font-heading">
              {hijriFormatted}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
