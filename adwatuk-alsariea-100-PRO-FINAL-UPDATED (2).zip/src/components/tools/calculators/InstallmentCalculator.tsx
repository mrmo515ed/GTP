import React, { useState } from 'react';
import { Landmark, Calculator, AlertCircle } from 'lucide-react';

export function InstallmentCalculator() {
  const [loanAmount, setLoanAmount] = useState<string>('50000');
  const [interestRate, setInterestRate] = useState<string>('5');
  const [months, setMonths] = useState<string>('60');

  const calculate = () => {
    const p = parseFloat(loanAmount);
    const r = parseFloat(interestRate) / 100 / 12;
    const n = parseInt(months);

    if (isNaN(p) || isNaN(r) || isNaN(n) || p <= 0 || n <= 0) return null;

    if (r === 0) {
      const monthly = p / n;
      return {
        monthly: monthly,
        totalPayment: p,
        totalInterest: 0
      };
    }

    const monthly = (p * r * Math.pow(1 + r, n)) / (Math.pow(1 + r, n) - 1);
    const totalPayment = monthly * n;
    const totalInterest = totalPayment - p;

    return {
      monthly,
      totalPayment,
      totalInterest
    };
  };

  const result = calculate();

  const formatCurrency = (val: number) => {
    return val.toLocaleString('en-US', { maximumFractionDigits: 2 });
  };

  return (
    <div className="space-y-6">
      <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-2xl flex items-start gap-3 border border-emerald-100 dark:border-emerald-800/30">
        <Landmark className="w-5 h-5 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
        <p className="text-sm text-emerald-800 dark:text-emerald-200 leading-relaxed">
          حاسبة الأقساط والقروض (التمويل الشخصي، العقاري، أو السيارات). تدخل قيمة القرض ونسبة الفائدة السنوية ومدة السداد بالأشهر، وتحسب لك القسط الشهري والإجمالي بناءً على طريقة القسط الثابت المتبعة في أغلب البنوك.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">قيمة التمويل / القرض</label>
          <input
            type="number"
            value={loanAmount}
            onChange={(e) => setLoanAmount(e.target.value)}
            className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-left"
            placeholder="مثال: 50000"
            dir="ltr"
          />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">نسبة الفائدة السنوية (%)</label>
          <input
            type="number"
            value={interestRate}
            onChange={(e) => setInterestRate(e.target.value)}
            className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-left"
            placeholder="مثال: 5"
            dir="ltr"
          />
        </div>
        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">مدة السداد (بالأشهر)</label>
          <input
            type="number"
            value={months}
            onChange={(e) => setMonths(e.target.value)}
            className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-left"
            placeholder="مثال: 60"
            dir="ltr"
          />
        </div>
      </div>

      {result ? (
        <div className="bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl p-6">
          <h3 className="text-lg font-bold text-gray-900 dark:text-gray-100 mb-6 flex items-center gap-2">
            <Calculator className="w-5 h-5 text-emerald-500" />
            نتيجة الحساب
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-gray-50 dark:bg-gray-900 p-4 rounded-xl border border-gray-100 dark:border-gray-800">
              <span className="block text-sm text-gray-500 dark:text-gray-400 mb-1">القسط الشهري</span>
              <span className="text-2xl font-black text-gray-900 dark:text-white" dir="ltr">
                {formatCurrency(result.monthly)}
              </span>
            </div>
            <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-xl border border-emerald-100 dark:border-emerald-800/30">
              <span className="block text-sm text-emerald-600 dark:text-emerald-400 mb-1">إجمالي الفوائد</span>
              <span className="text-2xl font-black text-emerald-700 dark:text-emerald-300" dir="ltr">
                {formatCurrency(result.totalInterest)}
              </span>
            </div>
            <div className="bg-rose-50 dark:bg-rose-900/20 p-4 rounded-xl border border-rose-100 dark:border-rose-800/30">
              <span className="block text-sm text-rose-600 dark:text-rose-400 mb-1">إجمالي التكلفة (مع الفوائد)</span>
              <span className="text-2xl font-black text-rose-700 dark:text-rose-300" dir="ltr">
                {formatCurrency(result.totalPayment)}
              </span>
            </div>
          </div>
        </div>
      ) : (
        <div className="flex items-center gap-2 text-amber-600 bg-amber-50 dark:bg-amber-900/20 p-4 rounded-xl">
          <AlertCircle className="w-5 h-5" />
          <span className="text-sm font-medium">الرجاء إدخال أرقام صحيحة وموجبة للحصول على النتيجة.</span>
        </div>
      )}
    </div>
  );
}
