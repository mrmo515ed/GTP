import React, { useState, useEffect } from 'react';
import {
  Calendar,
  Clock,
  Percent,
  Tag,
  Receipt,
  CreditCard,
  TrendingUp,
  FileText,
  Timer,
  Play,
  Pause,
  RotateCcw,
  Dice5,
  Coins,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  defaultTab?: string;
}

export function DailyCalculatorsHub({ defaultTab = 'age' }: Props) {
  const [activeTab, setActiveTab] = useState(defaultTab);

  const tabs = [
    { id: 'age', label: 'حاسبة العمر الدقيقة', icon: Calendar },
    { id: 'date-diff', label: 'الفرق بين تاريخين', icon: Calendar },
    { id: 'add-days', label: 'إضافة/طرح أيام من تاريخ', icon: Calendar },
    { id: 'percentage', label: 'حاسبة النسبة المئوية', icon: Percent },
    { id: 'discount', label: 'حاسبة الخصومات والتخفيضات', icon: Tag },
    { id: 'vat-tax', label: 'حاسبة الضريبة (VAT)', icon: Receipt },
    { id: 'loan-mortgage', label: 'حاسبة القروض والأقساط', icon: CreditCard },
    { id: 'interest', label: 'حاسبة الفائدة البسيطة والمركبة', icon: TrendingUp },
    { id: 'word-counter', label: 'عداد الكلمات والأحرف', icon: FileText },
    { id: 'stopwatch-timer', label: 'ساعة إيقاف ومؤقت', icon: Timer },
    { id: 'random-lottery', label: 'مولد الأرقام والقرعة', icon: Dice5 },
  ];

  return (
    <div className="space-y-6" id="daily-calculators-hub">
      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-gray-200 dark:border-gray-800">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                isActive
                  ? 'bg-amber-500 text-white shadow-md'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-5 sm:p-6 shadow-xs">
        {activeTab === 'age' && <AgeDetailedCalculator />}
        {activeTab === 'date-diff' && <DateDifferenceCalculator />}
        {activeTab === 'add-days' && <AddDaysCalculator />}
        {activeTab === 'percentage' && <PercentageEverydayCalculator />}
        {activeTab === 'discount' && <DiscountCalculator />}
        {activeTab === 'vat-tax' && <VatTaxCalculator />}
        {activeTab === 'loan-mortgage' && <LoanMortgageCalculator />}
        {activeTab === 'interest' && <InterestCalculator />}
        {activeTab === 'word-counter' && <WordCounterEveryday />}
        {activeTab === 'stopwatch-timer' && <StopwatchTimerTool />}
        {activeTab === 'random-lottery' && <RandomLotteryTool />}
      </div>
    </div>
  );
}

// 1. Age Detailed Calculator
function AgeDetailedCalculator() {
  const [birthDate, setBirthDate] = useState('2000-01-01');

  const b = new Date(birthDate);
  const now = new Date();
  const diffTime = Math.max(0, now.getTime() - b.getTime());
  const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));
  const years = Math.floor(diffDays / 365.25);
  const months = Math.floor((diffDays % 365.25) / 30.4375);
  const days = Math.floor((diffDays % 365.25) % 30.4375);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Calendar className="w-5 h-5 text-amber-500" />
        <span>حاسبة العمر التفصيلية (بالسنوات والأشهر والأيام)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">تاريخ الميلاد</label>
        <input
          type="date"
          value={birthDate}
          onChange={(e) => setBirthDate(e.target.value)}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-4 bg-amber-50 dark:bg-amber-950/40 rounded-xl border border-amber-200">
          <span className="text-xs text-amber-700 font-bold">السنوات</span>
          <div className="text-3xl font-black text-amber-600 mt-1 font-mono">{years} سنة</div>
        </div>
        <div className="p-4 bg-blue-50 dark:bg-blue-950/40 rounded-xl border border-blue-200">
          <span className="text-xs text-blue-700 font-bold">الأشهر المتبقية</span>
          <div className="text-3xl font-black text-blue-600 mt-1 font-mono">{months} شهر</div>
        </div>
        <div className="p-4 bg-teal-50 dark:bg-teal-950/40 rounded-xl border border-teal-200">
          <span className="text-xs text-teal-700 font-bold">الأيام</span>
          <div className="text-3xl font-black text-teal-600 mt-1 font-mono">{days} يوم</div>
        </div>
      </div>
    </div>
  );
}

// 2. Date Difference Calculator
function DateDifferenceCalculator() {
  const [d1, setD1] = useState('2026-01-01');
  const [d2, setD2] = useState('2026-12-31');

  const diffDays = Math.abs(Math.floor((new Date(d2).getTime() - new Date(d1).getTime()) / (1000 * 60 * 60 * 24)));

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Calendar className="w-5 h-5 text-indigo-500" />
        <span>حاسبة الفرق بين تاريخين بالأيام والأسابيع</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">التاريخ الأول</label>
          <input
            type="date"
            value={d1}
            onChange={(e) => setD1(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">التاريخ الثاني</label>
          <input
            type="date"
            value={d2}
            onChange={(e) => setD2(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>

      <div className="p-4 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 text-center rounded-xl">
        <span className="text-xs font-bold text-indigo-700">الفارق الزمني</span>
        <div className="text-3xl font-black text-indigo-600 mt-1 font-mono">{diffDays} يوم ({Math.floor(diffDays / 7)} أسبوع)</div>
      </div>
    </div>
  );
}

// 3. Add Days Calculator
function AddDaysCalculator() {
  const [date, setDate] = useState('2026-01-01');
  const [daysToAdd, setDaysToAdd] = useState(30);

  const targetDate = new Date(date);
  targetDate.setDate(targetDate.getDate() + Number(daysToAdd));
  const resStr = targetDate.toISOString().split('T')[0];

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Calendar className="w-5 h-5 text-teal-600" />
        <span>حاسبة إضافة وطرح أيام من تاريخ محدد</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">التاريخ الأساسي</label>
          <input
            type="date"
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">عدد الأيام (موجب للإضافة / سالب للطرح)</label>
          <input
            type="number"
            value={daysToAdd}
            onChange={(e) => setDaysToAdd(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
      </div>

      <div className="p-4 bg-teal-50 dark:bg-teal-950/40 border border-teal-200 text-center rounded-xl">
        <span className="text-xs font-bold text-teal-700">التاريخ الناتج</span>
        <div className="text-3xl font-black text-teal-600 mt-1 font-mono">{resStr}</div>
      </div>
    </div>
  );
}

// 4. Percentage Calculator
function PercentageEverydayCalculator() {
  const [val, setVal] = useState(250);
  const [percent, setPercent] = useState(15);
  const result = (val * percent) / 100;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Percent className="w-5 h-5 text-purple-600" />
        <span>حاسبة النسبة المئوية السريعة (كم يساوي X% من Y)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">النسبة المئوية (%)</label>
          <input
            type="number"
            value={percent}
            onChange={(e) => setPercent(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">المبلغ أو العدد الكلي</label>
          <input
            type="number"
            value={val}
            onChange={(e) => setVal(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
      </div>

      <div className="p-4 bg-purple-50 dark:bg-purple-950/40 border border-purple-200 text-center rounded-xl">
        <span className="text-xs font-bold text-purple-700">الناتج</span>
        <div className="text-3xl font-black text-purple-600 mt-1 font-mono">{result.toFixed(2)}</div>
      </div>
    </div>
  );
}

// 5. Discount Calculator
function DiscountCalculator() {
  const [price, setPrice] = useState(500);
  const [discountPercent, setDiscountPercent] = useState(20);

  const saved = (price * discountPercent) / 100;
  const finalPrice = price - saved;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Tag className="w-5 h-5 text-rose-500" />
        <span>حاسبة الخصم والتخفيضات ومقدار التوفير</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">السعر الأصلي</label>
          <input
            type="number"
            value={price}
            onChange={(e) => setPrice(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">نسبة الخصم (%)</label>
          <input
            type="number"
            value={discountPercent}
            onChange={(e) => setDiscountPercent(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-center">
        <div className="p-4 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 rounded-xl">
          <span className="text-xs text-rose-700 font-bold">السعر بعد الخصم</span>
          <div className="text-3xl font-black text-rose-600 mt-1 font-mono">{finalPrice.toFixed(2)}</div>
        </div>
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 rounded-xl">
          <span className="text-xs text-emerald-700 font-bold">المبلغ الموفر</span>
          <div className="text-3xl font-black text-emerald-600 mt-1 font-mono">{saved.toFixed(2)}</div>
        </div>
      </div>
    </div>
  );
}

// 6. VAT / Tax Calculator
function VatTaxCalculator() {
  const [amount, setAmount] = useState(1000);
  const [vatRate, setVatRate] = useState(15);

  const vatVal = (amount * vatRate) / 100;
  const total = amount + vatVal;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Receipt className="w-5 h-5 text-blue-600" />
        <span>حاسبة ضريبة القيمة المضافة (VAT Tax Calculator)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">المبلغ قبل الضريبة</label>
          <input
            type="number"
            value={amount}
            onChange={(e) => setAmount(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">نسبة الضريبة (%)</label>
          <input
            type="number"
            value={vatRate}
            onChange={(e) => setVatRate(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-center">
        <div className="p-4 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 rounded-xl">
          <span className="text-xs text-blue-700 font-bold">قيمة الضريبة</span>
          <div className="text-2xl font-black text-blue-600 mt-1 font-mono">{vatVal.toFixed(2)}</div>
        </div>
        <div className="p-4 bg-indigo-50 dark:bg-indigo-950/40 border border-indigo-200 rounded-xl">
          <span className="text-xs text-indigo-700 font-bold">المجموع شامل الضريبة</span>
          <div className="text-2xl font-black text-indigo-600 mt-1 font-mono">{total.toFixed(2)}</div>
        </div>
      </div>
    </div>
  );
}

// 7. Loan / Mortgage Calculator
function LoanMortgageCalculator() {
  const [principal, setPrincipal] = useState(100000);
  const [annualRate, setAnnualRate] = useState(5);
  const [years, setYears] = useState(5);

  const r = annualRate / 100 / 12;
  const n = years * 12;
  const monthlyPayment = r > 0 ? (principal * (r * Math.pow(1 + r, n))) / (Math.pow(1 + r, n) - 1) : principal / n;
  const totalPayment = monthlyPayment * n;
  const totalInterest = totalPayment - principal;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <CreditCard className="w-5 h-5 text-indigo-600" />
        <span>حاسبة القروض والتمويل والقسط الشهري</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">مبلغ التمويل / القرض</label>
          <input
            type="number"
            value={principal}
            onChange={(e) => setPrincipal(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">نسبة الفائدة السنوية (%)</label>
          <input
            type="number"
            value={annualRate}
            onChange={(e) => setAnnualRate(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">المدة (بالسنوات)</label>
          <input
            type="number"
            value={years}
            onChange={(e) => setYears(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-indigo-50 dark:bg-indigo-950/40 rounded-xl border border-indigo-200">
          <span className="text-xs text-indigo-700 font-bold">القسط الشهري</span>
          <div className="text-xl font-black text-indigo-600 mt-1 font-mono">{monthlyPayment.toFixed(2)}</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">إجمالي الفوائد</span>
          <div className="text-xl font-black text-rose-600 mt-1 font-mono">{totalInterest.toFixed(2)}</div>
        </div>
        <div className="p-3 bg-teal-50 dark:bg-teal-950/40 rounded-xl border border-teal-200">
          <span className="text-xs text-teal-700 font-bold">إجمالي السداد</span>
          <div className="text-xl font-black text-teal-600 mt-1 font-mono">{totalPayment.toFixed(2)}</div>
        </div>
      </div>
    </div>
  );
}

// 8. Interest Calculator
function InterestCalculator() {
  return <LoanMortgageCalculator />;
}

// 9. Word Counter Everyday
function WordCounterEveryday() {
  const [text, setText] = useState('');
  const words = text.trim() ? text.trim().split(/\s+/).length : 0;
  const chars = text.length;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <FileText className="w-5 h-5 text-teal-600" />
        <span>عداد الكلمات والأحرف والفقرات الفوري</span>
      </h3>

      <textarea
        rows={5}
        value={text}
        onChange={(e) => setText(e.target.value)}
        placeholder="اكتب أو الصق النص هنا لحساب الكلمات والأحرف فوراً..."
        className="w-full p-3 text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="grid grid-cols-2 gap-3 text-center">
        <div className="p-4 bg-teal-50 dark:bg-teal-950/40 rounded-xl border border-teal-200">
          <span className="text-xs text-teal-700 font-bold">عدد الكلمات</span>
          <div className="text-3xl font-black text-teal-600 mt-1 font-mono">{words}</div>
        </div>
        <div className="p-4 bg-blue-50 dark:bg-blue-950/40 rounded-xl border border-blue-200">
          <span className="text-xs text-blue-700 font-bold">عدد الأحرف</span>
          <div className="text-3xl font-black text-blue-600 mt-1 font-mono">{chars}</div>
        </div>
      </div>
    </div>
  );
}

// 10. Stopwatch & Timer Tool
function StopwatchTimerTool() {
  const [seconds, setSeconds] = useState(0);
  const [isActive, setIsActive] = useState(false);

  useEffect(() => {
    let interval: any = null;
    if (isActive) {
      interval = setInterval(() => {
        setSeconds((s) => s + 1);
      }, 1000);
    } else {
      clearInterval(interval);
    }
    return () => clearInterval(interval);
  }, [isActive]);

  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;

  return (
    <div className="space-y-4 text-center">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center justify-center gap-2">
        <Timer className="w-5 h-5 text-indigo-500" />
        <span>ساعة الإيقاف والمؤقت الزمني (Stopwatch)</span>
      </h3>

      <div className="text-5xl font-black font-mono text-indigo-600 py-4">
        {String(mins).padStart(2, '0')}:{String(secs).padStart(2, '0')}
      </div>

      <div className="flex justify-center gap-3">
        <button
          onClick={() => setIsActive(!isActive)}
          className={`px-5 py-2 rounded-xl text-xs font-bold text-white flex items-center gap-1.5 ${
            isActive ? 'bg-amber-500' : 'bg-emerald-600'
          }`}
        >
          {isActive ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
          <span>{isActive ? 'إيقاف مؤقت' : 'بدء التشغيل'}</span>
        </button>
        <button
          onClick={() => {
            setIsActive(false);
            setSeconds(0);
          }}
          className="px-4 py-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-xl text-xs font-bold flex items-center gap-1.5"
        >
          <RotateCcw className="w-4 h-4" />
          <span>إعادة ضبط</span>
        </button>
      </div>
    </div>
  );
}

// 11. Random Lottery Tool
function RandomLotteryTool() {
  const [min, setMin] = useState(1);
  const [max, setMax] = useState(100);
  const [res, setRes] = useState<number | null>(null);

  const roll = () => {
    const r = Math.floor(Math.random() * (max - min + 1)) + min;
    setRes(r);
    confetti({ particleCount: 30, spread: 60 });
  };

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Dice5 className="w-5 h-5 text-purple-600" />
        <span>مولد الأرقام العشوائية والقرعة الإلكترونية</span>
      </h3>

      <div className="grid grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">الحد الأدنى (Min)</label>
          <input
            type="number"
            value={min}
            onChange={(e) => setMin(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">الحد الأقصى (Max)</label>
          <input
            type="number"
            value={max}
            onChange={(e) => setMax(Number(e.target.value))}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800 font-mono"
          />
        </div>
      </div>

      <div className="text-center space-y-3">
        <button
          onClick={roll}
          className="px-6 py-2.5 bg-purple-600 text-white rounded-xl text-xs font-bold shadow-md hover:bg-purple-700"
        >
          🎲 توليد رقم عشوائي
        </button>

        {res !== null && (
          <div className="p-6 bg-purple-50 dark:bg-purple-950/40 border border-purple-200 rounded-2xl">
            <span className="text-xs font-bold text-purple-700">الرقم الفائز / المختار:</span>
            <div className="text-4xl font-black text-purple-600 mt-2 font-mono">{res}</div>
          </div>
        )}
      </div>
    </div>
  );
}
