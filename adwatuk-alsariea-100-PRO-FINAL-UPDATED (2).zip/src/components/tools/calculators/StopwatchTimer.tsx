import React, { useState, useEffect, useRef } from 'react';
import { Play, Pause, Square, RotateCcw, Flag } from 'lucide-react';

export function StopwatchTimer() {
  const [activeTab, setActiveTab] = useState<'stopwatch' | 'timer'>('stopwatch');
  
  // Stopwatch State
  const [swTime, setSwTime] = useState(0);
  const [swIsRunning, setSwIsRunning] = useState(false);
  const [swLaps, setSwLaps] = useState<{lap: number, time: number}[]>([]);
  
  // Timer State
  const [tmTime, setTmTime] = useState(0); // in seconds
  const [tmIsRunning, setTmIsRunning] = useState(false);
  const [tmInputHours, setTmInputHours] = useState('');
  const [tmInputMinutes, setTmInputMinutes] = useState('');
  const [tmInputSeconds, setTmInputSeconds] = useState('');

  // Format Helper
  const formatTime = (timeInMs: number, showMs = true) => {
    const ms = Math.floor((timeInMs % 1000) / 10);
    const s = Math.floor((timeInMs / 1000) % 60);
    const m = Math.floor((timeInMs / (1000 * 60)) % 60);
    const h = Math.floor(timeInMs / (1000 * 60 * 60));

    const parts = [];
    if (h > 0) parts.push(h.toString().padStart(2, '0'));
    parts.push(m.toString().padStart(2, '0'));
    parts.push(s.toString().padStart(2, '0'));
    
    let formatted = parts.join(':');
    if (showMs) {
      formatted += '.' + ms.toString().padStart(2, '0');
    }
    return formatted;
  };

  // Format Seconds for Timer
  const formatSeconds = (totalS: number) => {
    const h = Math.floor(totalS / 3600);
    const m = Math.floor((totalS % 3600) / 60);
    const s = totalS % 60;
    
    const parts = [];
    if (h > 0) parts.push(h.toString().padStart(2, '0'));
    parts.push(m.toString().padStart(2, '0'));
    parts.push(s.toString().padStart(2, '0'));
    return parts.join(':');
  };

  // Stopwatch Effect
  useEffect(() => {
    let interval: number;
    if (swIsRunning) {
      interval = window.setInterval(() => setSwTime(t => t + 10), 10);
    }
    return () => clearInterval(interval);
  }, [swIsRunning]);

  // Timer Effect
  useEffect(() => {
    let interval: number;
    if (tmIsRunning && tmTime > 0) {
      interval = window.setInterval(() => setTmTime(t => t - 1), 1000);
    } else if (tmTime === 0 && tmIsRunning) {
      setTmIsRunning(false);
      // Optional: Play a sound or alert
      alert('انتهى الوقت!');
    }
    return () => clearInterval(interval);
  }, [tmIsRunning, tmTime]);

  // Handlers
  const handleStartTimer = () => {
    if (tmTime === 0) {
      const h = parseInt(tmInputHours) || 0;
      const m = parseInt(tmInputMinutes) || 0;
      const s = parseInt(tmInputSeconds) || 0;
      setTmTime((h * 3600) + (m * 60) + s);
    }
    setTmIsRunning(true);
  };

  const handleResetTimer = () => {
    setTmIsRunning(false);
    setTmTime(0);
    setTmInputHours('');
    setTmInputMinutes('');
    setTmInputSeconds('');
  };

  return (
    <div className="space-y-6">
      <div className="flex p-1 bg-gray-100 dark:bg-gray-800/50 rounded-xl max-w-sm mx-auto">
        <button
          onClick={() => setActiveTab('stopwatch')}
          className={`flex-1 py-2 text-sm font-bold rounded-lg transition ${activeTab === 'stopwatch' ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
        >
          ساعة إيقاف
        </button>
        <button
          onClick={() => setActiveTab('timer')}
          className={`flex-1 py-2 text-sm font-bold rounded-lg transition ${activeTab === 'timer' ? 'bg-white dark:bg-gray-700 text-gray-900 dark:text-white shadow-sm' : 'text-gray-500 hover:text-gray-700'}`}
        >
          مؤقت
        </button>
      </div>

      {activeTab === 'stopwatch' ? (
        <div className="flex flex-col items-center space-y-8">
          <div className="font-mono text-5xl sm:text-7xl font-extrabold text-gray-900 dark:text-white tracking-tighter" dir="ltr">
            {formatTime(swTime)}
          </div>
          
          <div className="flex items-center gap-4">
            {!swIsRunning ? (
              <button onClick={() => setSwIsRunning(true)} className="w-16 h-16 flex items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400 hover:scale-105 transition">
                <Play className="w-8 h-8 ml-1" />
              </button>
            ) : (
              <button onClick={() => setSwIsRunning(false)} className="w-16 h-16 flex items-center justify-center rounded-full bg-rose-100 text-rose-600 dark:bg-rose-900/30 dark:text-rose-400 hover:scale-105 transition">
                <Pause className="w-8 h-8" />
              </button>
            )}
            
            <button 
              onClick={() => {
                if (swIsRunning) {
                  setSwLaps([...swLaps, { lap: swLaps.length + 1, time: swTime }]);
                } else {
                  setSwTime(0);
                  setSwLaps([]);
                }
              }} 
              className="w-16 h-16 flex items-center justify-center rounded-full bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400 hover:scale-105 transition"
            >
              {swIsRunning ? <Flag className="w-7 h-7" /> : <RotateCcw className="w-7 h-7" />}
            </button>
          </div>

          {swLaps.length > 0 && (
            <div className="w-full max-w-sm mt-8 max-h-48 overflow-y-auto space-y-2 px-2">
              {[...swLaps].reverse().map((lap) => (
                <div key={lap.lap} className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-800 text-sm font-mono">
                  <span className="text-gray-500">دورة {lap.lap.toString().padStart(2, '0')}</span>
                  <span className="text-gray-900 dark:text-white">{formatTime(lap.time)}</span>
                </div>
              ))}
            </div>
          )}
        </div>
      ) : (
        <div className="flex flex-col items-center space-y-8">
          {tmTime > 0 || tmIsRunning ? (
            <div className="font-mono text-5xl sm:text-7xl font-extrabold text-gray-900 dark:text-white tracking-tighter" dir="ltr">
              {formatSeconds(tmTime)}
            </div>
          ) : (
            <div className="flex items-center gap-2" dir="ltr">
              <input type="number" min="0" max="99" value={tmInputHours} onChange={e => setTmInputHours(e.target.value)} placeholder="00" className="w-20 text-center text-4xl sm:text-6xl font-extrabold font-mono bg-transparent border-b-2 border-gray-200 dark:border-gray-700 focus:border-emerald-500 outline-none text-gray-900 dark:text-white" />
              <span className="text-4xl sm:text-6xl font-light text-gray-400">:</span>
              <input type="number" min="0" max="59" value={tmInputMinutes} onChange={e => setTmInputMinutes(e.target.value)} placeholder="00" className="w-20 text-center text-4xl sm:text-6xl font-extrabold font-mono bg-transparent border-b-2 border-gray-200 dark:border-gray-700 focus:border-emerald-500 outline-none text-gray-900 dark:text-white" />
              <span className="text-4xl sm:text-6xl font-light text-gray-400">:</span>
              <input type="number" min="0" max="59" value={tmInputSeconds} onChange={e => setTmInputSeconds(e.target.value)} placeholder="00" className="w-20 text-center text-4xl sm:text-6xl font-extrabold font-mono bg-transparent border-b-2 border-gray-200 dark:border-gray-700 focus:border-emerald-500 outline-none text-gray-900 dark:text-white" />
            </div>
          )}

          <div className="flex items-center gap-4">
            {!tmIsRunning ? (
              <button 
                onClick={handleStartTimer} 
                disabled={!tmIsRunning && tmTime === 0 && !tmInputHours && !tmInputMinutes && !tmInputSeconds}
                className="w-16 h-16 flex items-center justify-center rounded-full bg-emerald-100 text-emerald-600 dark:bg-emerald-900/30 dark:text-emerald-400 hover:scale-105 transition disabled:opacity-50 disabled:hover:scale-100"
              >
                <Play className="w-8 h-8 ml-1" />
              </button>
            ) : (
              <button onClick={() => setTmIsRunning(false)} className="w-16 h-16 flex items-center justify-center rounded-full bg-rose-100 text-rose-600 dark:bg-rose-900/30 dark:text-rose-400 hover:scale-105 transition">
                <Pause className="w-8 h-8" />
              </button>
            )}
            
            <button 
              onClick={handleResetTimer} 
              className="w-16 h-16 flex items-center justify-center rounded-full bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400 hover:scale-105 transition"
            >
              <Square className="w-7 h-7" />
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
