import React, { useState } from 'react';
import { Calculator, Coins, AlertCircle } from 'lucide-react';

export function ZakatCalculator() {
  const [goldWeight, setGoldWeight] = useState<number | ''>('');
  const [goldPrice, setGoldPrice] = useState<number | ''>('');
  const [silverWeight, setSilverWeight] = useState<number | ''>('');
  const [silverPrice, setSilverPrice] = useState<number | ''>('');
  const [cash, setCash] = useState<number | ''>('');
  const [businessInventory, setBusinessInventory] = useState<number | ''>('');
  const [debts, setDebts] = useState<number | ''>('');

  const calculateZakat = () => {
    // 85 grams of gold or 595 grams of silver
    const goldNisab = 85 * (Number(goldPrice) || 0);
    const silverNisab = 595 * (Number(silverPrice) || 0);
    
    // Choose the lowest for Nisab to be safe, or just default to gold
    const activeNisab = goldNisab > 0 ? goldNisab : (silverNisab > 0 ? silverNisab : 0);

    const totalAssets = 
      ((Number(goldWeight) || 0) * (Number(goldPrice) || 0)) +
      ((Number(silverWeight) || 0) * (Number(silverPrice) || 0)) +
      (Number(cash) || 0) +
      (Number(businessInventory) || 0);
      
    const netAssets = totalAssets - (Number(debts) || 0);
    
    const isEligible = activeNisab > 0 && netAssets >= activeNisab;
    const zakatAmount = isEligible ? netAssets * 0.025 : 0;

    return {
      activeNisab,
      totalAssets,
      netAssets,
      isEligible,
      zakatAmount
    };
  };

  const results = calculateZakat();

  return (
    <div className="space-y-6">
      <div className="bg-emerald-50 dark:bg-emerald-950/30 p-4 rounded-2xl text-emerald-800 dark:text-emerald-300 text-sm leading-relaxed flex gap-3 border border-emerald-100 dark:border-emerald-900/50">
        <AlertCircle className="w-5 h-5 shrink-0 mt-0.5" />
        <p>تُحسب زكاة المال بنسبة ربع العشر (2.5%) على الأموال التي بلغت النصاب وحال عليها الحول (عام هجري كامل). يمكنك حساب النصاب بناءً على سعر جرام الذهب أو الفضة الحالي.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <h3 className="font-bold text-gray-800 dark:text-white flex items-center gap-2">
            <Coins className="w-4 h-4 text-emerald-500" />
            أسعار المعادن (لتحديد النصاب)
          </h3>
          
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-600 dark:text-gray-300">سعر جرام الذهب عيار 24</label>
              <input
                type="number"
                value={goldPrice}
                onChange={(e) => setGoldPrice(e.target.value ? Number(e.target.value) : '')}
                placeholder="مثال: 300"
                className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-left"
                dir="ltr"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-600 dark:text-gray-300">سعر جرام الفضة</label>
              <input
                type="number"
                value={silverPrice}
                onChange={(e) => setSilverPrice(e.target.value ? Number(e.target.value) : '')}
                placeholder="مثال: 4"
                className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-left"
                dir="ltr"
              />
            </div>
          </div>

          <h3 className="font-bold text-gray-800 dark:text-white pt-2 border-t border-gray-100 dark:border-gray-800">
            الأصول والممتلكات
          </h3>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-600 dark:text-gray-300">وزن الذهب المملوك (جرام)</label>
              <input
                type="number"
                value={goldWeight}
                onChange={(e) => setGoldWeight(e.target.value ? Number(e.target.value) : '')}
                className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-left"
                dir="ltr"
              />
            </div>
            <div className="space-y-1.5">
              <label className="text-xs font-semibold text-gray-600 dark:text-gray-300">وزن الفضة المملوك (جرام)</label>
              <input
                type="number"
                value={silverWeight}
                onChange={(e) => setSilverWeight(e.target.value ? Number(e.target.value) : '')}
                className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-left"
                dir="ltr"
              />
            </div>
          </div>

          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-600 dark:text-gray-300">السيولة النقدية (في البنك والمنزل)</label>
            <input
              type="number"
              value={cash}
              onChange={(e) => setCash(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-left"
              dir="ltr"
            />
          </div>
          
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-600 dark:text-gray-300">قيمة عروض التجارة</label>
            <input
              type="number"
              value={businessInventory}
              onChange={(e) => setBusinessInventory(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none text-left"
              dir="ltr"
            />
          </div>
          
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-gray-600 dark:text-gray-300">الديون التي عليك (تُخصم من الإجمالي)</label>
            <input
              type="number"
              value={debts}
              onChange={(e) => setDebts(e.target.value ? Number(e.target.value) : '')}
              className="w-full px-3 py-2 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-rose-500 outline-none text-left text-rose-600"
              dir="ltr"
            />
          </div>
        </div>

        <div className="bg-gray-50 dark:bg-gray-800/50 p-6 rounded-3xl border border-gray-100 dark:border-gray-700 flex flex-col justify-center">
          <div className="space-y-6">
            <div className="text-center space-y-2">
              <h4 className="text-gray-500 dark:text-gray-400 text-sm">مبلغ الزكاة الواجب إخراجه</h4>
              <div className="text-4xl font-extrabold text-emerald-600 dark:text-emerald-400 font-mono tracking-tight" dir="ltr">
                {results.zakatAmount.toLocaleString('en-US', { minimumFractionDigits: 0, maximumFractionDigits: 2 })}
              </div>
            </div>

            <div className="space-y-3 pt-6 border-t border-gray-200 dark:border-gray-700">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">إجمالي الأصول:</span>
                <span className="font-bold font-mono text-gray-900 dark:text-white" dir="ltr">
                  {results.totalAssets.toLocaleString('en-US')}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">صافي الثروة (بعد الديون):</span>
                <span className="font-bold font-mono text-gray-900 dark:text-white" dir="ltr">
                  {results.netAssets.toLocaleString('en-US')}
                </span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600 dark:text-gray-400">قيمة النصاب (تقريبي):</span>
                <span className="font-bold font-mono text-gray-900 dark:text-white" dir="ltr">
                  {results.activeNisab > 0 ? results.activeNisab.toLocaleString('en-US') : 'أدخل سعر الذهب'}
                </span>
              </div>
              
              <div className={`mt-4 p-3 rounded-xl text-center text-sm font-bold ${results.activeNisab > 0 ? (results.isEligible ? 'bg-emerald-100 text-emerald-800 dark:bg-emerald-900/30 dark:text-emerald-400' : 'bg-gray-200 text-gray-700 dark:bg-gray-800 dark:text-gray-300') : 'bg-gray-100 text-gray-500 dark:bg-gray-800 dark:text-gray-400'}`}>
                {results.activeNisab === 0 
                  ? 'يرجى إدخال سعر جرام الذهب أو الفضة لتحديد النصاب' 
                  : (results.isEligible ? 'المال قد بلغ النصاب، وتجب فيه الزكاة' : 'المال لم يبلغ النصاب، ولا زكاة فيه')}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
