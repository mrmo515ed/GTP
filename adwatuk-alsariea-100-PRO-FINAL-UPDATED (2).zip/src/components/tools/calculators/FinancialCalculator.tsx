import React, { useState } from 'react';
import { Percent, Tag, ReceiptText, Calculator, Coins } from 'lucide-react';

export function FinancialCalculator() {
  const [activeTab, setActiveTab] = useState<'discount' | 'vat' | 'percentage' | 'loan'>('discount');

  // 1. Discount state
  const [originalPrice, setOriginalPrice] = useState<number>(200);
  const [discountPercent, setDiscountPercent] = useState<number>(25);

  const discountAmount = (originalPrice * discountPercent) / 100;
  const finalPrice = Math.max(0, originalPrice - discountAmount);

  // 2. VAT state
  const [vatAmountInput, setVatAmountInput] = useState<number>(500);
  const [vatRate, setVatRate] = useState<number>(15); // standard in KSA/UAE
  const [vatMode, setVatMode] = useState<'exclusive' | 'inclusive'>('exclusive');

  const calculatedVat =
    vatMode === 'exclusive'
      ? (vatAmountInput * vatRate) / 100
      : vatAmountInput - vatAmountInput / (1 + vatRate / 100);

  const totalWithVat =
    vatMode === 'exclusive' ? vatAmountInput + calculatedVat : vatAmountInput;
  const netBeforeVat =
    vatMode === 'exclusive' ? vatAmountInput : vatAmountInput - calculatedVat;

  // 3. Percentage Calculation
  const [percNumA, setPercNumA] = useState<number>(20);
  const [percNumB, setPercNumB] = useState<number>(150);
  const percentResult1 = (percNumA / 100) * percNumB;

  const [fromNum, setFromNum] = useState<number>(100);
  const [toNum, setToNum] = useState<number>(125);
  const percentDifference = fromNum !== 0 ? (((toNum - fromNum) / fromNum) * 100).toFixed(2) : '0';

  // 4. Loan state
  const [loanPrincipal, setLoanPrincipal] = useState<number>(100000);
  const [annualInterest, setAnnualInterest] = useState<number>(5);
  const [loanYears, setLoanYears] = useState<number>(5);

  const monthlyRate = annualInterest / 100 / 12;
  const numberOfPayments = loanYears * 12;
  const monthlyPayment =
    monthlyRate > 0
      ? (loanPrincipal * (monthlyRate * Math.pow(1 + monthlyRate, numberOfPayments))) /
        (Math.pow(1 + monthlyRate, numberOfPayments) - 1)
      : loanPrincipal / numberOfPayments;

  const totalLoanPayment = monthlyPayment * numberOfPayments;
  const totalInterestPaid = totalLoanPayment - loanPrincipal;

  return (
    <div className="space-y-6" id="financial-calculator-tool">
      {/* Sub Tabs */}
      <div className="flex flex-wrap gap-2 p-1.5 bg-gray-100 dark:bg-gray-800 rounded-xl">
        <button
          onClick={() => setActiveTab('discount')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            activeTab === 'discount'
              ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Tag className="w-3.5 h-3.5" />
          حاسبة الخصم
        </button>
        <button
          onClick={() => setActiveTab('vat')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            activeTab === 'vat'
              ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <ReceiptText className="w-3.5 h-3.5" />
          ضريبة القيمة المضافة (VAT)
        </button>
        <button
          onClick={() => setActiveTab('percentage')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            activeTab === 'percentage'
              ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Percent className="w-3.5 h-3.5" />
          النسب المئوية
        </button>
        <button
          onClick={() => setActiveTab('loan')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            activeTab === 'loan'
              ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Coins className="w-3.5 h-3.5" />
          حاسبة الأقساط والقروض
        </button>
      </div>

      {/* Discount Calculator */}
      {activeTab === 'discount' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 bg-gray-50 dark:bg-gray-800/60 rounded-2xl border border-gray-200 dark:border-gray-700 space-y-4">
            <h4 className="text-xs font-bold text-gray-700 dark:text-gray-300">بيانات السعر والخصم:</h4>
            <div>
              <label className="block text-xs text-gray-600 dark:text-gray-400 mb-1">السعر الأصلي:</label>
              <input
                type="number"
                value={originalPrice}
                onChange={(e) => setOriginalPrice(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold"
              />
            </div>
            <div>
              <div className="flex justify-between text-xs text-gray-600 dark:text-gray-400 mb-1">
                <span>نسبة الخصم (%):</span>
                <span className="font-bold text-emerald-600 dark:text-emerald-400">{discountPercent}%</span>
              </div>
              <input
                type="range"
                min={1}
                max={99}
                value={discountPercent}
                onChange={(e) => setDiscountPercent(Number(e.target.value))}
                className="w-full accent-emerald-600 cursor-pointer"
              />
            </div>
          </div>

          <div className="p-6 bg-gradient-to-br from-emerald-500/10 to-teal-500/10 border border-emerald-500/20 rounded-2xl flex flex-col justify-center items-center text-center gap-3">
            <span className="text-xs font-semibold text-gray-500">السعر النهائي بعد الخصم:</span>
            <div className="text-4xl font-extrabold text-emerald-600 dark:text-emerald-400 font-heading">
              {finalPrice.toFixed(2)}
            </div>
            <div className="px-3 py-1 bg-emerald-100 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 rounded-full text-xs font-bold">
              وفرت: {discountAmount.toFixed(2)} ({discountPercent}%)
            </div>
          </div>
        </div>
      )}

      {/* VAT Calculator */}
      {activeTab === 'vat' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 bg-gray-50 dark:bg-gray-800/60 rounded-2xl border border-gray-200 dark:border-gray-700 space-y-4">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">المبلغ:</label>
              <input
                type="number"
                value={vatAmountInput}
                onChange={(e) => setVatAmountInput(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold"
              />
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">نسبة الضريبة:</label>
              <div className="flex gap-2">
                {[5, 10, 15, 18, 20].map((rate) => (
                  <button
                    key={rate}
                    onClick={() => setVatRate(rate)}
                    className={`flex-1 py-1.5 text-xs font-bold rounded-lg transition ${
                      vatRate === rate ? 'bg-emerald-600 text-white' : 'bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700'
                    }`}
                  >
                    {rate}%
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">نوع العملية:</label>
              <div className="flex rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-800 text-xs">
                <button
                  onClick={() => setVatMode('exclusive')}
                  className={`flex-1 py-2 font-bold ${
                    vatMode === 'exclusive' ? 'bg-emerald-600 text-white' : 'text-gray-700 dark:text-gray-300'
                  }`}
                >
                  إضافة الضريبة على المبلغ
                </button>
                <button
                  onClick={() => setVatMode('inclusive')}
                  className={`flex-1 py-2 font-bold ${
                    vatMode === 'inclusive' ? 'bg-emerald-600 text-white' : 'text-gray-700 dark:text-gray-300'
                  }`}
                >
                  المبلغ شامل الضريبة (استخراجها)
                </button>
              </div>
            </div>
          </div>

          <div className="p-5 bg-white dark:bg-gray-800/80 rounded-2xl border border-gray-200 dark:border-gray-700 flex flex-col justify-around gap-3">
            <div className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
              <span className="text-xs text-gray-500">المبلغ قبل الضريبة (الصافي):</span>
              <strong className="text-sm font-bold text-gray-800 dark:text-gray-200">{netBeforeVat.toFixed(2)}</strong>
            </div>
            <div className="flex justify-between items-center py-2 border-b border-gray-100 dark:border-gray-700">
              <span className="text-xs text-gray-500">قيمة الضريبة ({vatRate}%):</span>
              <strong className="text-sm font-bold text-emerald-600 dark:text-emerald-400">{calculatedVat.toFixed(2)}</strong>
            </div>
            <div className="flex justify-between items-center py-2">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">الإجمالي الكلي المستحق:</span>
              <strong className="text-xl font-extrabold text-emerald-700 dark:text-emerald-400 font-heading">
                {totalWithVat.toFixed(2)}
              </strong>
            </div>
          </div>
        </div>
      )}

      {/* Percentage */}
      {activeTab === 'percentage' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div className="p-5 bg-gray-50 dark:bg-gray-800/60 rounded-2xl border border-gray-200 dark:border-gray-700 space-y-3">
            <h4 className="text-xs font-bold text-gray-700 dark:text-gray-300">حساب النسبة من رقم:</h4>
            <div className="flex items-center gap-2 text-xs">
              <span>ما هي نسبة</span>
              <input
                type="number"
                value={percNumA}
                onChange={(e) => setPercNumA(Number(e.target.value))}
                className="w-16 p-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-center font-bold"
              />
              <span>% من الرقم</span>
              <input
                type="number"
                value={percNumB}
                onChange={(e) => setPercNumB(Number(e.target.value))}
                className="w-20 p-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-center font-bold"
              />
              <span>؟</span>
            </div>
            <div className="p-3 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl text-center">
              <span className="text-xs text-gray-500">النتيجة: </span>
              <strong className="text-lg font-bold text-emerald-600 dark:text-emerald-400">{percentResult1}</strong>
            </div>
          </div>

          <div className="p-5 bg-gray-50 dark:bg-gray-800/60 rounded-2xl border border-gray-200 dark:border-gray-700 space-y-3">
            <h4 className="text-xs font-bold text-gray-700 dark:text-gray-300">حساب نسبة الزيادة أو النقصان:</h4>
            <div className="flex items-center gap-2 text-xs">
              <span>من</span>
              <input
                type="number"
                value={fromNum}
                onChange={(e) => setFromNum(Number(e.target.value))}
                className="w-20 p-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-center font-bold"
              />
              <span>إلى</span>
              <input
                type="number"
                value={toNum}
                onChange={(e) => setToNum(Number(e.target.value))}
                className="w-20 p-1.5 rounded-lg border border-gray-200 dark:border-gray-700 text-center font-bold"
              />
            </div>
            <div className="p-3 bg-blue-50 dark:bg-blue-950/40 rounded-xl text-center">
              <span className="text-xs text-gray-500">نسبة التغير: </span>
              <strong className="text-lg font-bold text-blue-600 dark:text-blue-400">{percentDifference}%</strong>
            </div>
          </div>
        </div>
      )}

      {/* Loan */}
      {activeTab === 'loan' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="p-5 bg-gray-50 dark:bg-gray-800/60 rounded-2xl border border-gray-200 dark:border-gray-700 space-y-3">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">مبلغ التمويل أو القرض:</label>
              <input
                type="number"
                value={loanPrincipal}
                onChange={(e) => setLoanPrincipal(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">نسبة الفائدة السنوية (%):</label>
              <input
                type="number"
                step="0.1"
                value={annualInterest}
                onChange={(e) => setAnnualInterest(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">مدة السداد (سنوات):</label>
              <input
                type="number"
                min={1}
                max={30}
                value={loanYears}
                onChange={(e) => setLoanYears(Number(e.target.value))}
                className="w-full p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm font-bold"
              />
            </div>
          </div>

          <div className="p-5 bg-white dark:bg-gray-800/80 rounded-2xl border border-gray-200 dark:border-gray-700 flex flex-col justify-around gap-3">
            <div className="text-center py-2">
              <span className="text-xs text-gray-500">القسط الشهري المتوقع:</span>
              <div className="text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 font-heading">
                {monthlyPayment.toFixed(2)}
              </div>
            </div>
            <div className="flex justify-between items-center py-2 border-t border-gray-100 dark:border-gray-700 text-xs">
              <span className="text-gray-500">إجمالي الأرباح/الفائدة:</span>
              <strong className="font-bold text-rose-500">{totalInterestPaid.toFixed(2)}</strong>
            </div>
            <div className="flex justify-between items-center py-2 border-t border-gray-100 dark:border-gray-700 text-xs">
              <span className="text-gray-500">إجمالي المبلغ المسدد:</span>
              <strong className="font-bold text-gray-800 dark:text-gray-200">{totalLoanPayment.toFixed(2)}</strong>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
