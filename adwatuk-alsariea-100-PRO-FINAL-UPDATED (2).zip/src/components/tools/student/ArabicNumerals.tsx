import React, { useState } from 'react';
import { Languages, Copy, CheckCircle2 } from 'lucide-react';

export function ArabicNumerals() {
  const [textInput, setTextInput] = useState<string>('');
  const [copied, setCopied] = useState(false);
  const [conversionType, setConversionType] = useState<'to-arabic' | 'to-english'>('to-arabic');

  const arabicNumbers = ['٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩'];
  const englishNumbers = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];

  const convertNumbers = (text: string, type: 'to-arabic' | 'to-english') => {
    return text.replace(/[0-9٠-٩]/g, (w) => {
      if (type === 'to-arabic') {
        // Convert English (0-9) to Arabic/Hindi (٠-٩)
        const index = englishNumbers.indexOf(w);
        if (index !== -1) return arabicNumbers[index];
        return w;
      } else {
        // Convert Arabic/Hindi (٠-٩) to English (0-9)
        const index = arabicNumbers.indexOf(w);
        if (index !== -1) return englishNumbers[index];
        return w;
      }
    });
  };

  const result = convertNumbers(textInput, conversionType);

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-emerald-50 dark:bg-emerald-900/20 p-4 rounded-2xl flex items-start gap-3 border border-emerald-100 dark:border-emerald-800/30">
        <Languages className="w-5 h-5 text-emerald-600 dark:text-emerald-400 mt-0.5 shrink-0" />
        <p className="text-sm text-emerald-800 dark:text-emerald-200 leading-relaxed">
          أداة تحويل الأرقام: تقوم باستبدال الأرقام الإنجليزية (1, 2, 3) داخل أي نص إلى الأرقام العربية/الهندية (١, ٢, ٣) أو العكس بضغطة زر.
        </p>
      </div>

      <div className="flex bg-gray-100 dark:bg-gray-800 p-1 rounded-xl">
        <button
          onClick={() => setConversionType('to-arabic')}
          className={`flex-1 py-2 text-sm font-bold rounded-lg transition ${
            conversionType === 'to-arabic'
              ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
        >
          إلى أرقام عربية (١٢٣)
        </button>
        <button
          onClick={() => setConversionType('to-english')}
          className={`flex-1 py-2 text-sm font-bold rounded-lg transition ${
            conversionType === 'to-english'
              ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs'
              : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
          }`}
        >
          إلى أرقام إنجليزية (123)
        </button>
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">أدخل النص هنا</label>
        <textarea
          value={textInput}
          onChange={(e) => setTextInput(e.target.value)}
          className="w-full px-4 py-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-emerald-500 outline-none resize-y min-h-[120px] leading-relaxed"
          placeholder="اكتب النص الذي يحتوي على الأرقام هنا..."
        />
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">النتيجة</label>
        <div className="relative">
          <textarea
            readOnly
            value={result}
            className="w-full px-4 py-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl outline-none resize-y min-h-[120px] leading-relaxed"
            placeholder="النتيجة ستظهر هنا..."
          />
          {result && (
            <button
              onClick={handleCopy}
              className="absolute top-4 left-4 p-2 bg-white dark:bg-gray-800 text-gray-500 hover:text-emerald-600 dark:hover:text-emerald-400 border border-gray-200 dark:border-gray-700 rounded-lg shadow-xs transition"
              title="نسخ النتيجة"
            >
              {copied ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
