import React, { useState } from 'react';
import { Calculator, Plus, Trash2 } from 'lucide-react';

interface Course {
  id: string;
  name: string;
  credits: number;
  grade: string;
}

const GRADE_POINTS: Record<string, number> = {
  'A+': 4.0, 'A': 3.75, 'B+': 3.5, 'B': 3.0, 'C+': 2.5, 'C': 2.0, 'D+': 1.5, 'D': 1.0, 'F': 0.0
};

export function GpaCalculator() {
  const [courses, setCourses] = useState<Course[]>([
    { id: '1', name: '', credits: 3, grade: 'A' },
    { id: '2', name: '', credits: 3, grade: 'B+' },
    { id: '3', name: '', credits: 3, grade: 'B' },
  ]);

  const addCourse = () => {
    setCourses([...courses, { id: Math.random().toString(), name: '', credits: 3, grade: 'A' }]);
  };

  const removeCourse = (id: string) => {
    setCourses(courses.filter(c => c.id !== id));
  };

  const updateCourse = (id: string, field: keyof Course, value: any) => {
    setCourses(courses.map(c => c.id === id ? { ...c, [field]: value } : c));
  };

  const calculateGPA = () => {
    let totalCredits = 0;
    let totalPoints = 0;

    courses.forEach(course => {
      if (course.credits > 0 && course.grade in GRADE_POINTS) {
        totalCredits += course.credits;
        totalPoints += course.credits * GRADE_POINTS[course.grade];
      }
    });

    return totalCredits === 0 ? 0 : totalPoints / totalCredits;
  };

  const gpa = calculateGPA();

  return (
    <div className="space-y-6">
      <div className="bg-indigo-50 dark:bg-indigo-950/30 p-4 rounded-2xl flex gap-3 text-sm text-indigo-800 dark:text-indigo-300">
        <Calculator className="w-5 h-5 shrink-0 mt-0.5" />
        <p>أدخل الساعات المعتمدة لكل مادة والتقدير لحساب المعدل التراكمي (GPA) من 4.0.</p>
      </div>

      <div className="space-y-4">
        {courses.map((course, index) => (
          <div key={course.id} className="flex flex-wrap sm:flex-nowrap items-center gap-3 bg-gray-50 dark:bg-gray-800/50 p-3 rounded-xl border border-gray-100 dark:border-gray-700">
            <span className="text-sm font-bold text-gray-400 w-6">{index + 1}.</span>
            <input
              type="text"
              placeholder="اسم المادة (اختياري)"
              value={course.name}
              onChange={(e) => updateCourse(course.id, 'name', e.target.value)}
              className="flex-1 min-w-[120px] px-3 py-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg outline-none text-sm"
            />
            <div className="flex items-center gap-2">
              <input
                type="number"
                min="1"
                max="10"
                value={course.credits}
                onChange={(e) => updateCourse(course.id, 'credits', Number(e.target.value))}
                className="w-20 px-3 py-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg outline-none text-sm text-center"
                title="الساعات المعتمدة"
              />
              <select
                value={course.grade}
                onChange={(e) => updateCourse(course.id, 'grade', e.target.value)}
                className="w-20 px-3 py-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-lg outline-none text-sm font-bold text-center"
                dir="ltr"
              >
                {Object.keys(GRADE_POINTS).map(g => <option key={g} value={g}>{g}</option>)}
              </select>
              <button
                onClick={() => removeCourse(course.id)}
                className="p-2 text-gray-400 hover:text-rose-500 hover:bg-rose-50 dark:hover:bg-rose-900/30 rounded-lg transition"
                disabled={courses.length === 1}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          </div>
        ))}

        <button
          onClick={addCourse}
          className="flex items-center gap-2 px-4 py-2 text-sm font-bold text-indigo-600 dark:text-indigo-400 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-xl transition"
        >
          <Plus className="w-4 h-4" />
          إضافة مادة
        </button>
      </div>

      <div className="bg-gray-900 dark:bg-black p-6 rounded-3xl text-center space-y-2 border border-gray-800 shadow-xl">
        <h4 className="text-gray-400 text-sm">المعدل الفصلي (GPA)</h4>
        <div className="text-5xl font-extrabold text-white font-mono tracking-tight" dir="ltr">
          {gpa.toFixed(2)}
        </div>
      </div>
    </div>
  );
}
