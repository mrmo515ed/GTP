import React, { useState } from 'react';
import { WholeWord, Copy, CheckCircle2 } from 'lucide-react';

export function NumbersToWords() {
  const [numberInput, setNumberInput] = useState<string>('');
  const [copied, setCopied] = useState(false);

  // Simple Arabic Tafqeet implementation
  const tafqeet = (numString: string): string => {
    let num = parseInt(numString.replace(/,/g, ''), 10);
    if (isNaN(num)) return '';
    if (num === 0) return 'صفر';
    
    // Very basic implementation for up to 999,999,999 to cover most daily uses
    // Note: a full Arabic tafqeet requires complex grammar rules (Tazkeer, Taneeth, etc.)
    // This is a robust simplified version.
    const units = ['', 'واحد', 'اثنان', 'ثلاثة', 'أربعة', 'خمسة', 'ستة', 'سبعة', 'ثمانية', 'تسعة'];
    const teens = ['عشرة', 'أحد عشر', 'اثنا عشر', 'ثلاثة عشر', 'أربعة عشر', 'خمسة عشر', 'ستة عشر', 'سبعة عشر', 'ثمانية عشر', 'تسعة عشر'];
    const tens = ['', 'عشرة', 'عشرون', 'ثلاثون', 'أربعون', 'خمسون', 'ستون', 'سبعون', 'ثمانون', 'تسعون'];
    const hundreds = ['', 'مائة', 'مائتان', 'ثلاثمائة', 'أربعمائة', 'خمسمائة', 'ستمائة', 'سبعمائة', 'ثمانمائة', 'تسعمائة'];

    const getThreeDigits = (n: number): string => {
      if (n === 0) return '';
      let res = '';
      const h = Math.floor(n / 100);
      const t = Math.floor((n % 100) / 10);
      const u = n % 10;

      if (h > 0) res += hundreds[h];
      
      let rest = '';
      if (t === 0) {
        if (u > 0) rest = units[u];
      } else if (t === 1) {
        rest = teens[u];
      } else {
        if (u > 0) rest = units[u] + ' و ' + tens[t];
        else rest = tens[t];
      }

      if (res && rest) res += ' و ' + rest;
      else if (rest) res += rest;
      
      return res;
    };

    const parts = [];
    
    // Billions
    const b = Math.floor(num / 1000000000);
    if (b > 0) {
      if (b === 1) parts.push('مليار');
      else if (b === 2) parts.push('ملياران');
      else if (b >= 3 && b <= 10) parts.push(getThreeDigits(b) + ' مليارات');
      else parts.push(getThreeDigits(b) + ' مليار');
      num %= 1000000000;
    }

    // Millions
    const m = Math.floor(num / 1000000);
    if (m > 0) {
      if (m === 1) parts.push('مليون');
      else if (m === 2) parts.push('مليونان');
      else if (m >= 3 && m <= 10) parts.push(getThreeDigits(m) + ' ملايين');
      else parts.push(getThreeDigits(m) + ' مليون');
      num %= 1000000;
    }

    // Thousands
    const k = Math.floor(num / 1000);
    if (k > 0) {
      if (k === 1) parts.push('ألف');
      else if (k === 2) parts.push('ألفان');
      else if (k >= 3 && k <= 10) parts.push(getThreeDigits(k) + ' آلاف');
      else parts.push(getThreeDigits(k) + ' ألف');
      num %= 1000;
    }

    // Remaining
    if (num > 0) {
      parts.push(getThreeDigits(num));
    }

    return parts.join(' و ');
  };

  const result = tafqeet(numberInput);

  const handleCopy = () => {
    if (!result) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-2xl flex items-start gap-3 border border-blue-100 dark:border-blue-800/30">
        <WholeWord className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 shrink-0" />
        <p className="text-sm text-blue-800 dark:text-blue-200 leading-relaxed">
          أداة تفقيط الأرقام: تحويل الأرقام المكتوبة إلى نصوص باللغة العربية. تستخدم بشكل واسع في كتابة المبالغ المالية على الشيكات والعقود لضمان عدم التلاعب.
        </p>
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">أدخل الرقم هنا</label>
        <input
          type="number"
          value={numberInput}
          onChange={(e) => setNumberInput(e.target.value)}
          className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none text-left text-lg font-bold"
          placeholder="مثال: 1450"
          dir="ltr"
        />
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">النتيجة (التفقيط)</label>
        <div className="relative">
          <textarea
            readOnly
            value={result || 'النتيجة ستظهر هنا...'}
            className="w-full px-4 py-4 pr-12 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl outline-none resize-none text-lg font-bold leading-relaxed min-h-[120px]"
          />
          {result && (
            <button
              onClick={handleCopy}
              className="absolute top-4 right-4 p-2 bg-white dark:bg-gray-800 text-gray-500 hover:text-blue-600 dark:hover:text-blue-400 border border-gray-200 dark:border-gray-700 rounded-lg shadow-xs transition"
              title="نسخ النتيجة"
            >
              {copied ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
