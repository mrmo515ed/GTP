import React, { useState, useEffect } from 'react';
import { ArrowRightLeft } from 'lucide-react';

export function BaseConverter() {
  const [decimal, setDecimal] = useState('');
  const [binary, setBinary] = useState('');
  const [octal, setOctal] = useState('');
  const [hex, setHex] = useState('');

  const updateFromDecimal = (val: string) => {
    if (!val || isNaN(Number(val))) {
      setBinary('');
      setOctal('');
      setHex('');
      return;
    }
    try {
      const num = BigInt(val);
      setBinary(num.toString(2));
      setOctal(num.toString(8));
      setHex(num.toString(16).toUpperCase());
    } catch {
      // Ignore if too big or invalid
    }
  };

  const handleDecimalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/[^0-9-]/g, '');
    setDecimal(val);
    updateFromDecimal(val);
  };

  const handleBinaryChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/[^01-]/g, '');
    setBinary(val);
    if (!val) { setDecimal(''); setOctal(''); setHex(''); return; }
    try {
      const num = BigInt('0b' + val);
      setDecimal(num.toString(10));
      setOctal(num.toString(8));
      setHex(num.toString(16).toUpperCase());
    } catch { }
  };

  const handleOctalChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/[^0-7-]/g, '');
    setOctal(val);
    if (!val) { setDecimal(''); setBinary(''); setHex(''); return; }
    try {
      const num = BigInt('0o' + val);
      setDecimal(num.toString(10));
      setBinary(num.toString(2));
      setHex(num.toString(16).toUpperCase());
    } catch { }
  };

  const handleHexChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const val = e.target.value.replace(/[^0-9a-fA-F-]/g, '').toUpperCase();
    setHex(val);
    if (!val) { setDecimal(''); setBinary(''); setOctal(''); return; }
    try {
      const num = BigInt('0x' + val);
      setDecimal(num.toString(10));
      setBinary(num.toString(2));
      setOctal(num.toString(8));
    } catch { }
  };

  return (
    <div className="space-y-6">
      <div className="bg-blue-50 dark:bg-blue-900/20 p-4 rounded-2xl flex gap-3 text-sm text-blue-800 dark:text-blue-300">
        <ArrowRightLeft className="w-5 h-5 shrink-0 mt-0.5" />
        <p>قم بإدخال الرقم في أي حقل ليتم تحويله تلقائياً وبشكل فوري للأنظمة الأخرى.</p>
      </div>

      <div className="space-y-4">
        <div className="space-y-1.5">
          <label className="text-sm font-bold text-gray-700 dark:text-gray-300">النظام العشري (Decimal - Base 10)</label>
          <input
            type="text"
            value={decimal}
            onChange={handleDecimalChange}
            placeholder="مثال: 42"
            className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-mono text-lg"
            dir="ltr"
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-sm font-bold text-gray-700 dark:text-gray-300">النظام الثنائي (Binary - Base 2)</label>
          <input
            type="text"
            value={binary}
            onChange={handleBinaryChange}
            placeholder="مثال: 101010"
            className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-mono text-lg"
            dir="ltr"
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-sm font-bold text-gray-700 dark:text-gray-300">النظام السداسي عشر (Hexadecimal - Base 16)</label>
          <input
            type="text"
            value={hex}
            onChange={handleHexChange}
            placeholder="مثال: 2A"
            className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-mono text-lg"
            dir="ltr"
          />
        </div>

        <div className="space-y-1.5">
          <label className="text-sm font-bold text-gray-700 dark:text-gray-300">النظام الثماني (Octal - Base 8)</label>
          <input
            type="text"
            value={octal}
            onChange={handleOctalChange}
            placeholder="مثال: 52"
            className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-blue-500 outline-none font-mono text-lg"
            dir="ltr"
          />
        </div>
      </div>
    </div>
  );
}
