import React, { useState, useEffect, useRef, useMemo } from 'react';
import {
  Shield,
  Key,
  QrCode,
  Scan,
  FileCode,
  Copy,
  Check,
  RefreshCw,
  Eye,
  EyeOff,
  Download,
  Upload,
  AlertCircle,
  FileJson,
  Code
} from 'lucide-react';
import QRCode from 'qrcode';
import jsQR from 'jsqr';
import * as yaml from 'js-yaml';

// Helper for client-side MD5
function md5(string: string) {
  function rotateLeft(lValue: number, iShiftBits: number) {
    return (lValue << iShiftBits) | (lValue >>> (32 - iShiftBits));
  }
  function addUnsigned(lX: number, lY: number) {
    const lX8 = lX & 0x80000000;
    const lY8 = lY & 0x80000000;
    const lX4 = lX & 0x40000000;
    const lY4 = lY & 0x40000000;
    const lResult = (lX & 0x3fffffff) + (lY & 0x3fffffff);
    if (lX4 & lY4) return lResult ^ 0x80000000 ^ lX8 ^ lY8;
    if (lX4 | lY4) {
      if (lResult & 0x40000000) return lResult ^ 0xc0000000 ^ lX8 ^ lY8;
      else return lResult ^ 0x40000000 ^ lX8 ^ lY8;
    } else return lResult ^ lX8 ^ lY8;
  }
  function F(x: number, y: number, z: number) { return (x & y) | (~x & z); }
  function G(x: number, y: number, z: number) { return (x & z) | (y & ~z); }
  function H(x: number, y: number, z: number) { return x ^ y ^ z; }
  function I(x: number, y: number, z: number) { return y ^ (x | ~z); }
  function FF(a: number, b: number, c: number, d: number, x: number, s: number, ac: number) {
    a = addUnsigned(a, addUnsigned(addUnsigned(F(b, c, d), x), ac));
    return addUnsigned(rotateLeft(a, s), b);
  }
  function GG(a: number, b: number, c: number, d: number, x: number, s: number, ac: number) {
    a = addUnsigned(a, addUnsigned(addUnsigned(G(b, c, d), x), ac));
    return addUnsigned(rotateLeft(a, s), b);
  }
  function HH(a: number, b: number, c: number, d: number, x: number, s: number, ac: number) {
    a = addUnsigned(a, addUnsigned(addUnsigned(H(b, c, d), x), ac));
    return addUnsigned(rotateLeft(a, s), b);
  }
  function II(a: number, b: number, c: number, d: number, x: number, s: number, ac: number) {
    a = addUnsigned(a, addUnsigned(addUnsigned(I(b, c, d), x), ac));
    return addUnsigned(rotateLeft(a, s), b);
  }
  function convertToWordArray(str: string) {
    let lWordCount;
    const lMessageLength = str.length;
    const lNumberOfWordsTemp1 = lMessageLength + 8;
    const lNumberOfWordsTemp2 = (lNumberOfWordsTemp1 - (lNumberOfWordsTemp1 % 64)) / 64;
    const lNumberOfWords = (lNumberOfWordsTemp2 + 1) * 16;
    const lWordArray = Array(lNumberOfWords - 1);
    let lBytePosition = 0;
    let lByteCount = 0;
    while (lByteCount < lMessageLength) {
      lWordCount = (lByteCount - (lByteCount % 4)) / 4;
      lBytePosition = (lByteCount % 4) * 8;
      lWordArray[lWordCount] = (lWordArray[lWordCount] | (str.charCodeAt(lByteCount) << lBytePosition));
      lByteCount++;
    }
    lWordCount = (lByteCount - (lByteCount % 4)) / 4;
    lBytePosition = (lByteCount % 4) * 8;
    lWordArray[lWordCount] = lWordArray[lWordCount] | (0x80 << lBytePosition);
    lWordArray[lNumberOfWords - 2] = lMessageLength << 3;
    lWordArray[lNumberOfWords - 1] = lMessageLength >>> 29;
    return lWordArray;
  }
  function wordToHex(lValue: number) {
    let wordToHexValue = '', wordToHexValueTemp = '', lByte, lCount;
    for (lCount = 0; lCount <= 3; lCount++) {
      lByte = (lValue >>> (lCount * 8)) & 255;
      wordToHexValueTemp = '0' + lByte.toString(16);
      wordToHexValue = wordToHexValue + wordToHexValueTemp.substr(wordToHexValueTemp.length - 2, 2);
    }
    return wordToHexValue;
  }
  const x = convertToWordArray(unescape(encodeURIComponent(string)));
  let a = 0x67452301, b = 0xefcdab89, c = 0x98badcfe, d = 0x10325476;
  const S11 = 7, S12 = 12, S13 = 17, S14 = 22;
  const S21 = 5, S22 = 9, S23 = 14, S24 = 20;
  const S31 = 4, S32 = 11, S33 = 16, S34 = 23;
  const S41 = 6, S42 = 10, S43 = 15, S44 = 21;

  for (let k = 0; k < x.length; k += 16) {
    const AA = a, BB = b, CC = c, DD = d;
    a = FF(a, b, c, d, x[k + 0], S11, 0xd76aa478);
    d = FF(d, a, b, c, x[k + 1], S12, 0xe8c7b756);
    c = FF(c, d, a, b, x[k + 2], S13, 0x242070db);
    b = FF(b, c, d, a, x[k + 3], S14, 0xc1bdceee);
    a = FF(a, b, c, d, x[k + 4], S11, 0xf57c0faf);
    d = FF(d, a, b, c, x[k + 5], S12, 0x4787c62a);
    c = FF(c, d, a, b, x[k + 6], S13, 0xa8304613);
    b = FF(b, c, d, a, x[k + 7], S14, 0xfd469501);
    a = FF(a, b, c, d, x[k + 8], S11, 0x698098d8);
    d = FF(d, a, b, c, x[k + 9], S12, 0x8b44f7af);
    c = FF(c, d, a, b, x[k + 10], S13, 0xffff5bb1);
    b = FF(b, c, d, a, x[k + 11], S14, 0x895cd7be);
    a = FF(a, b, c, d, x[k + 12], S11, 0x6b901122);
    d = FF(d, a, b, c, x[k + 13], S12, 0xfd987193);
    c = FF(c, d, a, b, x[k + 14], S13, 0xa679438e);
    b = FF(b, c, d, a, x[k + 15], S14, 0x49b40821);

    a = GG(a, b, c, d, x[k + 1], S21, 0xf61e2562);
    d = GG(d, a, b, c, x[k + 6], S22, 0xc040b340);
    c = GG(c, d, a, b, x[k + 11], S23, 0x265e5a51);
    b = GG(b, c, d, a, x[k + 0], S24, 0xe9b6c7aa);
    a = GG(a, b, c, d, x[k + 5], S21, 0xd62f105d);
    d = GG(d, a, b, c, x[k + 10], S22, 0x02441453);
    c = GG(c, d, a, b, x[k + 15], S23, 0xd8a1e681);
    b = GG(b, c, d, a, x[k + 4], S24, 0xe7d3fbc8);
    a = GG(a, b, c, d, x[k + 9], S21, 0x21e1cde6);
    d = GG(d, a, b, c, x[k + 14], S22, 0xc33707d6);
    c = GG(c, d, a, b, x[k + 3], S23, 0xf4d50d87);
    b = GG(b, c, d, a, x[k + 8], S24, 0x455a14ed);
    a = GG(a, b, c, d, x[k + 13], S21, 0xa9e3e905);
    d = GG(d, a, b, c, x[k + 2], S22, 0xfcefa3f8);
    c = GG(c, d, a, b, x[k + 7], S23, 0x676f02d9);
    b = GG(b, c, d, a, x[k + 12], S24, 0x8d2a4c8a);

    a = HH(a, b, c, d, x[k + 5], S31, 0xfffa3942);
    d = HH(d, a, b, c, x[k + 8], S32, 0x8771f681);
    c = HH(c, d, a, b, x[k + 11], S33, 0x6d9d6122);
    b = HH(b, c, d, a, x[k + 14], S34, 0xfde5380c);
    a = HH(a, b, c, d, x[k + 1], S31, 0xa4beea44);
    d = HH(d, a, b, c, x[k + 4], S32, 0x4bdecfa9);
    c = HH(c, d, a, b, x[k + 7], S33, 0xf6bb4b60);
    b = HH(b, c, d, a, x[k + 10], S34, 0xbebfbc70);
    a = HH(a, b, c, d, x[k + 13], S31, 0x289b7ec6);
    d = HH(d, a, b, c, x[k + 0], S32, 0xeaa127fa);
    c = HH(c, d, a, b, x[k + 3], S33, 0xd4ef3085);
    b = HH(b, c, d, a, x[k + 6], S34, 0x04881d05);
    a = HH(a, b, c, d, x[k + 9], S31, 0xd9d4d039);
    d = HH(d, a, b, c, x[k + 12], S32, 0xe6db99e5);
    c = HH(c, d, a, b, x[k + 15], S33, 0x1fa27cf8);
    b = HH(b, c, d, a, x[k + 2], S34, 0xc4ac5665);

    a = II(a, b, c, d, x[k + 0], S41, 0xf4292244);
    d = II(d, a, b, c, x[k + 7], S42, 0x432aff97);
    c = II(c, d, a, b, x[k + 14], S43, 0xab9423a7);
    b = II(b, c, d, a, x[k + 5], S44, 0xfc93a039);
    a = II(a, b, c, d, x[k + 12], S41, 0x655b59c3);
    d = II(d, a, b, c, x[k + 3], S42, 0x8f0ccc92);
    c = II(c, d, a, b, x[k + 10], S43, 0xffeff47d);
    b = II(b, c, d, a, x[k + 1], S44, 0x85845dd1);
    a = II(a, b, c, d, x[k + 8], S41, 0x6fa87e4f);
    d = II(d, a, b, c, x[k + 15], S42, 0xfe2ce6e0);
    c = II(c, d, a, b, x[k + 6], S43, 0xa3014314);
    b = II(b, c, d, a, x[k + 13], S44, 0x4e0811a1);
    a = II(a, b, c, d, x[k + 4], S41, 0xf7537e82);
    d = II(d, a, b, c, x[k + 11], S42, 0xbd3af235);
    c = II(c, d, a, b, x[k + 2], S43, 0x2ad7d2bb);
    b = II(b, c, d, a, x[k + 9], S44, 0xeb86d391);

    a = addUnsigned(a, AA);
    b = addUnsigned(b, BB);
    c = addUnsigned(c, CC);
    d = addUnsigned(d, DD);
  }
  return (wordToHex(a) + wordToHex(b) + wordToHex(c) + wordToHex(d)).toLowerCase();
}

interface Props {
  defaultTab?:
    | 'hash-crypto'
    | 'base64-url'
    | 'jwt-decoder'
    | 'uuid-generator'
    | 'password-generator'
    | 'qr-generator'
    | 'qr-reader'
    | 'json-suite'
    | 'xml-formatter'
    | 'yaml-json';
}

export function SecurityDataSuite({ defaultTab = 'hash-crypto' }: Props) {
  const [activeTab, setActiveTab] = useState<string>(defaultTab);
  const [copied, setCopied] = useState(false);

  // Hash state
  const [hashInput, setHashInput] = useState('SecurePassword123!');
  const [sha1, setSha1] = useState('');
  const [sha256, setSha256] = useState('');
  const [sha512, setSha512] = useState('');

  // Base64 & URL
  const [b64Input, setB64Input] = useState('مرحباً بالعالم! Hello World!');
  const [b64Encoded, setB64Encoded] = useState('');
  const [urlEncoded, setUrlEncoded] = useState('');

  // JWT state
  const [jwtInput, setJwtInput] = useState(
    'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkFobWVkIEhhc3NhbiIsImFkbWluIjp0cnVlLCJpYXQiOjE1MTYyMzkwMjIsImV4cCI6MTgwMDAwMDAwMH0.signature'
  );

  // Password generator
  const [passLength, setPassLength] = useState(16);
  const [includeUpper, setIncludeUpper] = useState(true);
  const [includeLower, setIncludeLower] = useState(true);
  const [includeNumbers, setIncludeNumbers] = useState(true);
  const [includeSymbols, setIncludeSymbols] = useState(true);
  const [generatedPassword, setGeneratedPassword] = useState('');

  // UUID generator
  const [uuidCount, setUuidCount] = useState(5);
  const [uuidList, setUuidList] = useState<string[]>([]);

  // QR Code generator
  const [qrText, setQrText] = useState('https://adwatuk-alsariea.netlify.app');
  const [qrDataUrl, setQrDataUrl] = useState('');
  const [qrFgColor, setQrFgColor] = useState('#000000');
  const [qrBgColor, setQrBgColor] = useState('#ffffff');

  // QR Code reader
  const [qrScanResult, setQrScanResult] = useState('');
  const [qrScanError, setQrScanError] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  // JSON suite
  const [jsonInput, setJsonInput] = useState('{"name":"Adwatuk","tools":100,"active":true,"features":["Free","Fast"]}');
  const [jsonFormatted, setJsonFormatted] = useState('');
  const [jsonError, setJsonError] = useState('');

  // XML formatter
  const [xmlInput, setXmlInput] = useState('<root><user id="1"><name>Ahmed</name><role>Admin</role></user></root>');
  const [xmlFormatted, setXmlFormatted] = useState('');

  // YAML ↔ JSON
  const [yamlInput, setYamlInput] = useState('app:\n  name: Adwatuk\n  version: 2.0\n  features:\n    - Fast\n    - Free\n');
  const [yamlToJsonOut, setYamlToJsonOut] = useState('');

  // Compute Hashes
  useEffect(() => {
    const computeWebCrypto = async () => {
      const msgUint8 = new TextEncoder().encode(hashInput);
      try {
        const hash1Buffer = await crypto.subtle.digest('SHA-1', msgUint8);
        const hash1Array = Array.from(new Uint8Array(hash1Buffer));
        setSha1(hash1Array.map(b => b.toString(16).padStart(2, '0')).join(''));

        const hash256Buffer = await crypto.subtle.digest('SHA-256', msgUint8);
        const hash256Array = Array.from(new Uint8Array(hash256Buffer));
        setSha256(hash256Array.map(b => b.toString(16).padStart(2, '0')).join(''));

        const hash512Buffer = await crypto.subtle.digest('SHA-512', msgUint8);
        const hash512Array = Array.from(new Uint8Array(hash512Buffer));
        setSha512(hash512Array.map(b => b.toString(16).padStart(2, '0')).join(''));
      } catch (err) {
        console.error(err);
      }
    };
    computeWebCrypto();
  }, [hashInput]);

  // Compute Base64 & URL
  useEffect(() => {
    try {
      setB64Encoded(btoa(unescape(encodeURIComponent(b64Input))));
      setUrlEncoded(encodeURIComponent(b64Input));
    } catch {
      setB64Encoded('');
    }
  }, [b64Input]);

  // Generate QR
  useEffect(() => {
    if (!qrText) return;
    QRCode.toDataURL(qrText, {
      color: { dark: qrFgColor, light: qrBgColor },
      width: 320,
      margin: 2
    })
      .then(url => setQrDataUrl(url))
      .catch(console.error);
  }, [qrText, qrFgColor, qrBgColor]);

  // Password Generator function
  const generateNewPassword = () => {
    let chars = '';
    if (includeUpper) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (includeLower) chars += 'abcdefghijklmnopqrstuvwxyz';
    if (includeNumbers) chars += '0123456789';
    if (includeSymbols) chars += '!@#$%^&*()_+-=[]{}|;:,.<>?';
    if (!chars) chars = 'abcdefghijklmnopqrstuvwxyz';

    let result = '';
    const array = new Uint32Array(passLength);
    window.crypto.getRandomValues(array);
    for (let i = 0; i < passLength; i++) {
      result += chars[array[i] % chars.length];
    }
    setGeneratedPassword(result);
  };

  useEffect(() => {
    generateNewPassword();
  }, [passLength, includeUpper, includeLower, includeNumbers, includeSymbols]);

  // UUID Generator function
  const generateUUIDs = () => {
    const list = Array.from({ length: uuidCount }, () => crypto.randomUUID());
    setUuidList(list);
  };

  useEffect(() => {
    generateUUIDs();
  }, [uuidCount]);

  // JSON Formatter logic
  useEffect(() => {
    try {
      const parsed = JSON.parse(jsonInput);
      setJsonFormatted(JSON.stringify(parsed, null, 2));
      setJsonError('');
    } catch (err: any) {
      setJsonError(err.message || 'خطأ في بنية JSON');
    }
  }, [jsonInput]);

  // XML Formatter logic
  useEffect(() => {
    try {
      let formatted = '';
      let pad = 0;
      xmlInput.split(/>\s*</).forEach(node => {
        let indent = 0;
        if (node.match(/^\/\w/)) indent = -1;
        else if (node.match(/^<?\w[^>]*[^\/]>$/)) indent = 1;
        pad += indent;
        formatted += '  '.repeat(Math.max(0, pad - (indent > 0 ? 1 : 0))) + '<' + node + '>\n';
      });
      setXmlFormatted(formatted.trim().replace(/^<</, '<').replace(/>>$/, '>'));
    } catch {
      setXmlFormatted(xmlInput);
    }
  }, [xmlInput]);

  // YAML to JSON logic
  useEffect(() => {
    try {
      const doc = yaml.load(yamlInput);
      setYamlToJsonOut(JSON.stringify(doc, null, 2));
    } catch (err: any) {
      setYamlToJsonOut(`خطأ: ${err.message}`);
    }
  }, [yamlInput]);

  // JWT Decoder parse
  const jwtDecoded = useMemo(() => {
    try {
      const parts = jwtInput.trim().split('.');
      if (parts.length < 2) return { error: 'التوكن غير صالح (يجب أن يحتوي على أجزاء مفصولة بنقاط)' };
      const header = JSON.parse(decodeURIComponent(escape(atob(parts[0]))));
      const payload = JSON.parse(decodeURIComponent(escape(atob(parts[1]))));
      const expDate = payload.exp ? new Date(payload.exp * 1000).toLocaleString('ar-SA') : 'غير محدد';
      const isExpired = payload.exp ? Date.now() > payload.exp * 1000 : false;
      return { header, payload, expDate, isExpired, signature: parts[2] || 'لا يوجد' };
    } catch {
      return { error: 'تعذر فك تشفير JWT. تأكد من صحة التوكن.' };
    }
  }, [jwtInput]);

  // QR Image scan handler
  const handleQrImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setQrScanError('');
    setQrScanResult('');

    const reader = new FileReader();
    reader.onload = () => {
      const img = new Image();
      img.onload = () => {
        const canvas = document.createElement('canvas');
        const ctx = canvas.getContext('2d');
        if (!ctx) return;
        canvas.width = img.width;
        canvas.height = img.height;
        ctx.drawImage(img, 0, 0);
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const code = jsQR(imageData.data, imageData.width, imageData.height);
        if (code) {
          setQrScanResult(code.data);
        } else {
          setQrScanError('لم يتم العثور على رمز QR صالح في الصورة. يرجى تجربة صورة أوضح.');
        }
      };
      img.src = reader.result as string;
    };
    reader.readAsDataURL(file);
  };

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const tabs = [
    { id: 'hash-crypto', label: 'MD5 & SHA Hash', icon: Shield },
    { id: 'base64-url', label: 'Base64 & URL', icon: FileCode },
    { id: 'jwt-decoder', label: 'فك تشفير JWT', icon: Key },
    { id: 'password-generator', label: 'مولد كلمات المرور', icon: Shield },
    { id: 'uuid-generator', label: 'مولد UUID', icon: RefreshCw },
    { id: 'qr-generator', label: 'صانع QR Code', icon: QrCode },
    { id: 'qr-reader', label: 'قارئ وفاحص QR', icon: Scan },
    { id: 'json-suite', label: 'JSON Formatter', icon: FileJson },
    { id: 'xml-formatter', label: 'XML Formatter', icon: Code },
    { id: 'yaml-json', label: 'YAML ↔ JSON', icon: FileCode }
  ];

  return (
    <div className="space-y-6" id="security-data-suite">
      {/* Tabs bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-200 dark:scrollbar-thumb-gray-800">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/60 border border-gray-200/80 dark:border-gray-700/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: MD5 / SHA Hashes */}
      {activeTab === 'hash-crypto' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <label className="text-xs font-black text-gray-700 dark:text-gray-200 block">النص المراد تشفيره وتوليد الـ Hashes له:</label>
            <input
              type="text"
              value={hashInput}
              onChange={e => setHashInput(e.target.value)}
              placeholder="اكتب أي نص أو كلمة مرور هنا..."
              className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 text-sm font-sans outline-none focus:border-emerald-500"
            />
          </div>

          <div className="grid grid-cols-1 gap-3">
            {[
              { label: 'MD5 Hash (128-bit)', val: md5(hashInput) },
              { label: 'SHA-1 Hash (160-bit)', val: sha1 },
              { label: 'SHA-256 Hash (256-bit)', val: sha256 },
              { label: 'SHA-512 Hash (512-bit)', val: sha512 }
            ].map((h, i) => (
              <div key={i} className="bg-white dark:bg-gray-800 p-4 rounded-xl border border-gray-200 dark:border-gray-700 flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <div className="overflow-hidden">
                  <span className="text-xs font-bold text-emerald-600 block mb-0.5">{h.label}</span>
                  <span className="text-xs font-mono text-gray-800 dark:text-gray-200 break-all">{h.val || 'جارٍ الحساب...'}</span>
                </div>
                <button
                  onClick={() => copyToClipboard(h.val)}
                  className="self-end sm:self-center px-3 py-1.5 bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300 hover:bg-emerald-600 hover:text-white rounded-lg text-xs font-bold transition-colors flex items-center gap-1.5 shrink-0"
                >
                  <Copy className="w-3.5 h-3.5" />
                  <span>نسخ</span>
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 2: Base64 & URL */}
      {activeTab === 'base64-url' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <label className="text-xs font-black text-gray-700 dark:text-gray-200 block">النص الأصلي</label>
            <textarea
              rows={8}
              value={b64Input}
              onChange={e => setB64Input(e.target.value)}
              className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 text-sm outline-none resize-none"
            />
          </div>

          <div className="space-y-4">
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-emerald-600">Base64 Encoded:</span>
                <button onClick={() => copyToClipboard(b64Encoded)} className="text-xs text-gray-500 hover:text-emerald-600 flex items-center gap-1">
                  <Copy className="w-3.5 h-3.5" /> نسخ
                </button>
              </div>
              <textarea readOnly rows={3} value={b64Encoded} className="w-full p-2.5 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border border-gray-200 dark:border-gray-700" />
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-2">
              <div className="flex items-center justify-between">
                <span className="text-xs font-bold text-indigo-600">URL Encoded:</span>
                <button onClick={() => copyToClipboard(urlEncoded)} className="text-xs text-gray-500 hover:text-indigo-600 flex items-center gap-1">
                  <Copy className="w-3.5 h-3.5" /> نسخ
                </button>
              </div>
              <textarea readOnly rows={3} value={urlEncoded} className="w-full p-2.5 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border border-gray-200 dark:border-gray-700" />
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: JWT Decoder */}
      {activeTab === 'jwt-decoder' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <label className="text-xs font-black text-gray-700 dark:text-gray-200 block">الصق توكن JWT هنا:</label>
            <textarea
              rows={4}
              value={jwtInput}
              onChange={e => setJwtInput(e.target.value)}
              placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
              className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 text-xs font-mono outline-none"
            />
          </div>

          {'error' in jwtDecoded && jwtDecoded.error ? (
            <div className="p-4 bg-rose-50 dark:bg-rose-950/40 text-rose-600 rounded-xl text-xs font-bold flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{jwtDecoded.error}</span>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-2">
                <span className="text-xs font-bold text-rose-500 block">HEADER: Algorithm & Token Type</span>
                <pre className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono overflow-x-auto text-gray-800 dark:text-gray-200">
                  {JSON.stringify(jwtDecoded.header, null, 2)}
                </pre>
              </div>

              <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold text-indigo-500">PAYLOAD: Data Claims</span>
                  <span className={`text-[11px] font-bold px-2 py-0.5 rounded-full ${jwtDecoded.isExpired ? 'bg-rose-100 text-rose-700' : 'bg-emerald-100 text-emerald-700'}`}>
                    {jwtDecoded.isExpired ? 'منتهي الصلاحية' : 'ساري الصلاحية'}
                  </span>
                </div>
                <pre className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono overflow-x-auto text-gray-800 dark:text-gray-200">
                  {JSON.stringify(jwtDecoded.payload, null, 2)}
                </pre>
                <p className="text-[11px] text-gray-500">تاريخ الانتهاء (Exp): {jwtDecoded.expDate}</p>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 4: Password Generator */}
      {activeTab === 'password-generator' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="flex items-center justify-between p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700">
            <span className="text-base sm:text-lg font-mono font-bold text-gray-800 dark:text-gray-100 break-all select-all">
              {generatedPassword}
            </span>
            <div className="flex gap-2 shrink-0">
              <button onClick={generateNewPassword} className="p-2 text-gray-500 hover:text-emerald-600 rounded-xl hover:bg-gray-200 dark:hover:bg-gray-800">
                <RefreshCw className="w-4 h-4" />
              </button>
              <button onClick={() => copyToClipboard(generatedPassword)} className="px-3 py-1.5 bg-emerald-600 text-white rounded-xl text-xs font-bold flex items-center gap-1">
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'تم النسخ' : 'نسخ'}</span>
              </button>
            </div>
          </div>

          <div className="space-y-4">
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span>طول كلمة المرور: {passLength} حرف</span>
                <span className={passLength >= 16 ? 'text-emerald-600' : passLength >= 10 ? 'text-amber-600' : 'text-rose-600'}>
                  {passLength >= 16 ? 'قوية جداً' : passLength >= 10 ? 'متوسطة' : 'ضعيفة'}
                </span>
              </div>
              <input
                type="range"
                min="6"
                max="64"
                value={passLength}
                onChange={e => setPassLength(Number(e.target.value))}
                className="w-full accent-emerald-600"
              />
            </div>

            <div className="grid grid-cols-2 gap-3">
              {[
                { label: 'أحرف كبيرة (A-Z)', val: includeUpper, set: setIncludeUpper },
                { label: 'أحرف صغيرة (a-z)', val: includeLower, set: setIncludeLower },
                { label: 'أرقام (0-9)', val: includeNumbers, set: setIncludeNumbers },
                { label: 'رموز خاصة (!@#$)', val: includeSymbols, set: setIncludeSymbols }
              ].map((opt, i) => (
                <label key={i} className="flex items-center gap-2 p-3 bg-gray-50 dark:bg-gray-900 rounded-xl cursor-pointer text-xs font-bold">
                  <input
                    type="checkbox"
                    checked={opt.val}
                    onChange={e => opt.set(e.target.checked)}
                    className="accent-emerald-600 w-4 h-4 rounded"
                  />
                  <span>{opt.label}</span>
                </label>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: UUID Generator */}
      {activeTab === 'uuid-generator' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-5">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <label className="text-xs font-bold">العدد المطلوب:</label>
              <select
                value={uuidCount}
                onChange={e => setUuidCount(Number(e.target.value))}
                className="px-3 py-1.5 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-bold border border-gray-200 dark:border-gray-700"
              >
                {[1, 5, 10, 20, 50].map(n => (
                  <option key={n} value={n}>{n} UUID</option>
                ))}
              </select>
            </div>
            <button
              onClick={generateUUIDs}
              className="px-4 py-2 bg-emerald-600 text-white text-xs font-bold rounded-xl flex items-center gap-2 hover:bg-emerald-700"
            >
              <RefreshCw className="w-3.5 h-3.5" />
              <span>توليد جديد</span>
            </button>
          </div>

          <div className="space-y-2 max-h-[360px] overflow-y-auto">
            {uuidList.map((id, i) => (
              <div key={i} className="flex items-center justify-between p-3 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800 text-xs font-mono">
                <span className="text-gray-800 dark:text-gray-200">{id}</span>
                <button onClick={() => copyToClipboard(id)} className="p-1.5 text-gray-500 hover:text-emerald-600">
                  <Copy className="w-3.5 h-3.5" />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 6: QR Generator */}
      {activeTab === 'qr-generator' && (
        <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
          <div className="md:col-span-7 bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
            <label className="text-xs font-black text-gray-700 dark:text-gray-200 block">النص أو الرابط الخاص بالـ QR Code:</label>
            <textarea
              rows={4}
              value={qrText}
              onChange={e => setQrText(e.target.value)}
              className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 text-sm outline-none"
            />

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-xs font-bold text-gray-600 dark:text-gray-300 block mb-1">لون الرمز</label>
                <div className="flex items-center gap-2">
                  <input type="color" value={qrFgColor} onChange={e => setQrFgColor(e.target.value)} className="w-8 h-8 rounded-lg cursor-pointer" />
                  <span className="text-xs font-mono">{qrFgColor}</span>
                </div>
              </div>
              <div>
                <label className="text-xs font-bold text-gray-600 dark:text-gray-300 block mb-1">لون الخلفية</label>
                <div className="flex items-center gap-2">
                  <input type="color" value={qrBgColor} onChange={e => setQrBgColor(e.target.value)} className="w-8 h-8 rounded-lg cursor-pointer" />
                  <span className="text-xs font-mono">{qrBgColor}</span>
                </div>
              </div>
            </div>
          </div>

          <div className="md:col-span-5 bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 flex flex-col items-center justify-center space-y-4">
            {qrDataUrl ? (
              <>
                <img src={qrDataUrl} alt="Generated QR" className="w-48 h-48 rounded-xl shadow-md" />
                <a
                  href={qrDataUrl}
                  download="qrcode.png"
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2 transition-all"
                >
                  <Download className="w-4 h-4" />
                  <span>تنزيل صورة الرمز (PNG)</span>
                </a>
              </>
            ) : null}
          </div>
        </div>
      )}

      {/* Tab 7: QR Code Reader */}
      {activeTab === 'qr-reader' && (
        <div className="max-w-xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-5 text-center">
          <input ref={fileInputRef} type="file" accept="image/*" onChange={handleQrImageUpload} className="hidden" />
          <div
            onClick={() => fileInputRef.current?.click()}
            className="p-8 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-2xl cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/20 transition-all space-y-3"
          >
            <Scan className="w-10 h-10 text-emerald-600 mx-auto" />
            <h4 className="text-sm font-bold text-gray-800 dark:text-gray-200">اختر صورة أو اسحب رمز QR هنا لقراءته</h4>
            <p className="text-xs text-gray-500">يدعم كافة صيغ الصور الشائعة PNG, JPG, WebP</p>
          </div>

          {qrScanResult && (
            <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-xl border border-emerald-200 dark:border-emerald-800 text-right space-y-2">
              <span className="text-xs font-bold text-emerald-700 dark:text-emerald-300 block">محتوى الرمز المستخرج بنجاح:</span>
              <p className="text-xs font-mono text-gray-800 dark:text-gray-100 break-all p-2 bg-white dark:bg-gray-900 rounded-lg">{qrScanResult}</p>
              <button
                onClick={() => copyToClipboard(qrScanResult)}
                className="px-3 py-1.5 bg-emerald-600 text-white text-xs font-bold rounded-lg flex items-center gap-1 hover:bg-emerald-700"
              >
                <Copy className="w-3 h-3" />
                <span>نسخ المحتوى</span>
              </button>
            </div>
          )}

          {qrScanError && (
            <div className="p-4 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-200 dark:border-rose-800 text-rose-600 text-xs font-bold">
              {qrScanError}
            </div>
          )}
        </div>
      )}

      {/* Tab 8: JSON Suite */}
      {activeTab === 'json-suite' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-gray-700 dark:text-gray-200">JSON Input</label>
              {jsonError ? (
                <span className="text-[11px] font-bold text-rose-500 flex items-center gap-1">
                  <AlertCircle className="w-3 h-3" /> غير صالح
                </span>
              ) : (
                <span className="text-[11px] font-bold text-emerald-600 flex items-center gap-1">
                  <Check className="w-3 h-3" /> صالح Valid
                </span>
              )}
            </div>
            <textarea
              rows={12}
              value={jsonInput}
              onChange={e => setJsonInput(e.target.value)}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700 outline-none"
            />
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-gray-700 dark:text-gray-200">Formatted JSON</label>
              <button
                onClick={() => copyToClipboard(jsonFormatted)}
                className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 text-xs font-bold rounded-lg flex items-center gap-1"
              >
                <Copy className="w-3 h-3" />
                <span>نسخ</span>
              </button>
            </div>
            <textarea
              readOnly
              rows={12}
              value={jsonFormatted}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700"
            />
          </div>
        </div>
      )}

      {/* Tab 9: XML Formatter */}
      {activeTab === 'xml-formatter' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <label className="text-xs font-black text-gray-700 dark:text-gray-200 block">XML Input</label>
            <textarea
              rows={12}
              value={xmlInput}
              onChange={e => setXmlInput(e.target.value)}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700 outline-none"
            />
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-gray-700 dark:text-gray-200">Formatted XML</label>
              <button
                onClick={() => copyToClipboard(xmlFormatted)}
                className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 text-xs font-bold rounded-lg flex items-center gap-1"
              >
                <Copy className="w-3 h-3" />
                <span>نسخ</span>
              </button>
            </div>
            <textarea
              readOnly
              rows={12}
              value={xmlFormatted}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700"
            />
          </div>
        </div>
      )}

      {/* Tab 10: YAML ↔ JSON */}
      {activeTab === 'yaml-json' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <label className="text-xs font-black text-gray-700 dark:text-gray-200 block">YAML Input</label>
            <textarea
              rows={12}
              value={yamlInput}
              onChange={e => setYamlInput(e.target.value)}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700 outline-none"
            />
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-gray-700 dark:text-gray-200">Converted JSON</label>
              <button
                onClick={() => copyToClipboard(yamlToJsonOut)}
                className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 text-xs font-bold rounded-lg flex items-center gap-1"
              >
                <Copy className="w-3 h-3" />
                <span>نسخ JSON</span>
              </button>
            </div>
            <textarea
              readOnly
              rows={12}
              value={yamlToJsonOut}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700"
            />
          </div>
        </div>
      )}
    </div>
  );
}
