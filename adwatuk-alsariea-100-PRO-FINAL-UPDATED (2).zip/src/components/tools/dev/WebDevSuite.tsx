import React, { useState, useMemo, useEffect } from 'react';
import {
  Globe,
  Code,
  Terminal,
  Clock,
  Search,
  Copy,
  Check,
  Play,
  Layers,
  FileCode,
  Laptop,
  Wifi,
  Brackets,
  Calendar
} from 'lucide-react';

interface Props {
  defaultTab?:
    | 'url-parser'
    | 'http-headers'
    | 'user-agent'
    | 'ip-info'
    | 'code-minifier'
    | 'html-entities'
    | 'regex-tester'
    | 'timestamp-converter'
    | 'cron-generator';
}

export function WebDevSuite({ defaultTab = 'url-parser' }: Props) {
  const [activeTab, setActiveTab] = useState<string>(defaultTab);
  const [copied, setCopied] = useState(false);

  // URL Parser state
  const [inputUrl, setInputUrl] = useState('https://developer.mozilla.org/en-US/docs/Web/API?query=javascript&page=2#heading');

  // User-Agent state
  const [uaString, setUaString] = useState(typeof navigator !== 'undefined' ? navigator.userAgent : '');

  // Code Minifier state
  const [codeType, setCodeType] = useState<'html' | 'css' | 'js'>('css');
  const [rawCode, setRawCode] = useState(
    `/* Example CSS */\n.card {\n  display: flex;\n  padding: 20px;\n  background-color: #ffffff;\n  border-radius: 12px;\n}`
  );

  // HTML Entity state
  const [entityInput, setEntityInput] = useState('<div class="hero">مرحباً & أهلاً بكم! "Tools" 100%</div>');

  // Regex Tester state
  const [regexPattern, setRegexPattern] = useState('\\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\\.[A-Z|a-z]{2,}\\b');
  const [regexFlags, setRegexFlags] = useState('g');
  const [regexTestText, setRegexTestText] = useState('Contact us at info@example.com or support@company.org anytime.');

  // Timestamp Converter state
  const [timestampInput, setTimestampInput] = useState<number>(Math.floor(Date.now() / 1000));
  const [customDateInput, setCustomDateInput] = useState(new Date().toISOString().slice(0, 16));

  // Cron Generator state
  const [cronMinute, setCronMinute] = useState('*/15');
  const [cronHour, setCronHour] = useState('*');
  const [cronDayOfMonth, setCronDayOfMonth] = useState('*');
  const [cronMonth, setCronMonth] = useState('*');
  const [cronDayOfWeek, setCronDayOfWeek] = useState('*');

  // IP info state
  const [ipData, setIpData] = useState<any>({
    ip: '178.135.80.24',
    city: 'Riyadh',
    region: 'Riyadh Region',
    country: 'Saudi Arabia',
    countryCode: 'SA',
    loc: '24.7136,46.6753',
    org: 'STC Saudi Telecom Company',
    timezone: 'Asia/Riyadh'
  });
  const [loadingIp, setLoadingIp] = useState(false);

  useEffect(() => {
    // Try fetching real client IP
    fetch('https://ipapi.co/json/')
      .then(res => res.json())
      .then(data => {
        if (data && data.ip) setIpData(data);
      })
      .catch(() => {});
  }, []);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // URL Breakdown
  const parsedUrl = useMemo(() => {
    try {
      const url = new URL(inputUrl);
      const params: { key: string; value: string }[] = [];
      url.searchParams.forEach((value, key) => {
        params.push({ key, value });
      });
      const hostParts = url.hostname.split('.');
      const domain = hostParts.length >= 2 ? hostParts.slice(-2).join('.') : url.hostname;
      const subdomain = hostParts.length > 2 ? hostParts.slice(0, -2).join('.') : '';
      return {
        protocol: url.protocol,
        origin: url.origin,
        hostname: url.hostname,
        domain,
        subdomain: subdomain || 'لا يوجد',
        pathname: url.pathname,
        search: url.search,
        hash: url.hash || 'لا يوجد',
        params
      };
    } catch {
      return null;
    }
  }, [inputUrl]);

  // User-Agent Breakdown
  const parsedUA = useMemo(() => {
    const ua = uaString;
    let browser = 'Unknown Browser';
    let os = 'Unknown OS';
    let device = 'Desktop';

    if (/Windows/i.test(ua)) os = 'Windows';
    else if (/Macintosh|Mac OS X/i.test(ua)) os = 'macOS';
    else if (/Android/i.test(ua)) { os = 'Android'; device = 'Mobile'; }
    else if (/iPhone|iPad|iPod/i.test(ua)) { os = 'iOS'; device = 'Mobile/Tablet'; }
    else if (/Linux/i.test(ua)) os = 'Linux';

    if (/Edg/i.test(ua)) browser = 'Microsoft Edge';
    else if (/Chrome/i.test(ua) && !/Edg/i.test(ua)) browser = 'Google Chrome';
    else if (/Safari/i.test(ua) && !/Chrome/i.test(ua)) browser = 'Apple Safari';
    else if (/Firefox/i.test(ua)) browser = 'Mozilla Firefox';
    else if (/Opera|OPR/i.test(ua)) browser = 'Opera';

    return { browser, os, device, raw: ua };
  }, [uaString]);

  // Code Minifier / Formatter
  const minifiedCode = useMemo(() => {
    if (codeType === 'css') {
      return rawCode
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/\s+/g, ' ')
        .replace(/\s*([{}:;,])\s*/g, '$1')
        .replace(/;}/g, '}')
        .trim();
    } else if (codeType === 'html') {
      return rawCode
        .replace(/<!--[\s\S]*?-->/g, '')
        .replace(/\s+/g, ' ')
        .replace(/>\s+</g, '><')
        .trim();
    } else {
      return rawCode
        .replace(/\/\/.*$/gm, '')
        .replace(/\/\*[\s\S]*?\*\//g, '')
        .replace(/\s+/g, ' ')
        .trim();
    }
  }, [rawCode, codeType]);

  // HTML Entities
  const entityResults = useMemo(() => {
    const encoded = entityInput
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
    return { encoded };
  }, [entityInput]);

  // Regex Tester Results
  const regexMatches = useMemo(() => {
    try {
      const reg = new RegExp(regexPattern, regexFlags);
      const matches = [];
      let match;
      if (regexFlags.includes('g')) {
        while ((match = reg.exec(regexTestText)) !== null) {
          matches.push({ text: match[0], index: match.index });
          if (match.index === reg.lastIndex) reg.lastIndex++;
        }
      } else {
        match = reg.exec(regexTestText);
        if (match) matches.push({ text: match[0], index: match.index });
      }
      return { matches, error: '' };
    } catch (e: any) {
      return { matches: [], error: e.message };
    }
  }, [regexPattern, regexFlags, regexTestText]);

  // Timestamp Results
  const timestampDate = useMemo(() => {
    try {
      const d = new Date(timestampInput * 1000);
      return {
        iso: d.toISOString(),
        utc: d.toUTCString(),
        local: d.toLocaleString('ar-SA'),
        relative: `${Math.floor((Date.now() - d.getTime()) / (1000 * 60))} دقيقة مضت`
      };
    } catch {
      return null;
    }
  }, [timestampInput]);

  // Cron Expression Builder
  const cronString = `${cronMinute} ${cronHour} ${cronDayOfMonth} ${cronMonth} ${cronDayOfWeek}`;
  const cronExplanation = useMemo(() => {
    return `يعمل هذا الجدول: الدقيقة (${cronMinute})، الساعة (${cronHour})، يوم من الشهر (${cronDayOfMonth})، الشهر (${cronMonth})، ويوم من الأسبوع (${cronDayOfWeek}).`;
  }, [cronMinute, cronHour, cronDayOfMonth, cronMonth, cronDayOfWeek]);

  const tabs = [
    { id: 'url-parser', label: 'محلل URL والـ Domain', icon: Globe },
    { id: 'http-headers', label: 'HTTP Headers', icon: Layers },
    { id: 'user-agent', label: 'فاحص User-Agent', icon: Laptop },
    { id: 'ip-info', label: 'معلومات الـ IP', icon: Wifi },
    { id: 'code-minifier', label: 'ضغط الأكواد (Minifier)', icon: Code },
    { id: 'html-entities', label: 'HTML Entity Encoder', icon: Brackets },
    { id: 'regex-tester', label: 'فاحص Regex', icon: Search },
    { id: 'timestamp-converter', label: 'محول Unix Timestamp', icon: Clock },
    { id: 'cron-generator', label: 'مولد تعبيرات Cron', icon: Calendar }
  ];

  return (
    <div className="space-y-6" id="web-dev-suite">
      {/* Tabs bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-200 dark:scrollbar-thumb-gray-800">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/60 border border-gray-200/80 dark:border-gray-700/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Tab 1: URL Parser */}
      {activeTab === 'url-parser' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <label className="text-xs font-black text-gray-700 dark:text-gray-200 block">أدخل رابط URL للتحليل:</label>
            <input
              type="url"
              value={inputUrl}
              onChange={e => setInputUrl(e.target.value)}
              className="w-full p-3.5 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 text-sm font-mono outline-none"
            />
          </div>

          {parsedUrl ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                { label: 'Domain النطاق الرئيسي', val: parsedUrl.domain, color: 'text-emerald-600' },
                { label: 'Subdomain النطاق الفرعي', val: parsedUrl.subdomain, color: 'text-indigo-600' },
                { label: 'Hostname اسم المضيف', val: parsedUrl.hostname, color: 'text-blue-600' },
                { label: 'Protocol البروتوكول', val: parsedUrl.protocol, color: 'text-purple-600' },
                { label: 'Path المسار', val: parsedUrl.pathname, color: 'text-amber-600' },
                { label: 'Hash الإشارة المرجعية', val: parsedUrl.hash, color: 'text-rose-600' }
              ].map((item, i) => (
                <div key={i} className="p-4 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 flex items-center justify-between">
                  <div>
                    <span className="text-[11px] font-bold text-gray-400 block">{item.label}</span>
                    <span className={`text-xs font-mono font-bold ${item.color}`}>{item.val}</span>
                  </div>
                  <button onClick={() => copyToClipboard(item.val)} className="p-1.5 text-gray-400 hover:text-emerald-600">
                    <Copy className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}

              {parsedUrl.params.length > 0 && (
                <div className="md:col-span-2 bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
                  <span className="text-xs font-bold text-gray-700 dark:text-gray-200 block">معاملات الاستعلام (Query Parameters)</span>
                  <div className="divide-y divide-gray-100 dark:divide-gray-800 border border-gray-100 dark:border-gray-700 rounded-xl overflow-hidden">
                    {parsedUrl.params.map((p, i) => (
                      <div key={i} className="p-2.5 bg-gray-50 dark:bg-gray-900/50 flex items-center justify-between text-xs font-mono">
                        <span className="text-emerald-600 font-bold">{p.key}</span>
                        <span className="text-gray-700 dark:text-gray-300">{p.value}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>
          ) : (
            <div className="p-4 bg-rose-50 text-rose-600 text-xs font-bold rounded-xl">رابط URL غير صالح.</div>
          )}
        </div>
      )}

      {/* Tab 2: HTTP Headers Viewer */}
      {activeTab === 'http-headers' && (
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-5">
          <h3 className="text-sm font-bold text-gray-800 dark:text-gray-100">فاحص ترويسات الأمان واستجابات HTTP القياسية</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
            {[
              { name: 'Strict-Transport-Security (HSTS)', desc: 'يجبر المتصفح على استخدام اتصالات HTTPS المشفرة فقط.', recommended: 'max-age=31536000; includeSubDomains' },
              { name: 'Content-Security-Policy (CSP)', desc: 'يمنع هجمات XSS وحقن الأكواد الخبيثة.', recommended: "default-src 'self'" },
              { name: 'X-Frame-Options', desc: 'يحمي الموقع من هجمات Clickjacking وتضمين الـ iFrame.', recommended: 'DENY أو SAMEORIGIN' },
              { name: 'X-Content-Type-Options', desc: 'يمنع استنتاج نوع MIME الخاطئ من قبل المتصفح.', recommended: 'nosniff' },
              { name: 'Referrer-Policy', desc: 'يحدد كمية معلومات الإحالة المرسلة مع الطلبات.', recommended: 'strict-origin-when-cross-origin' },
              { name: 'Permissions-Policy', desc: 'يتحكم في صلاحيات الكاميرا والميكروفون والموقع الجغرافي.', recommended: 'camera=(), microphone=(), geolocation=()' }
            ].map((h, i) => (
              <div key={i} className="p-4 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 space-y-1.5">
                <span className="font-mono font-bold text-emerald-600 block">{h.name}</span>
                <p className="text-gray-600 dark:text-gray-400 text-[11px]">{h.desc}</p>
                <div className="p-2 bg-white dark:bg-gray-800 rounded-lg font-mono text-[11px] text-gray-700 dark:text-gray-300">
                  القيمة الموصى بها: <span className="text-indigo-600 dark:text-indigo-400">{h.recommended}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 3: User-Agent Parser */}
      {activeTab === 'user-agent' && (
        <div className="space-y-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <label className="text-xs font-black text-gray-700 dark:text-gray-200 block">سلسلة User-Agent الحالية للمتصفح:</label>
            <textarea
              rows={3}
              value={uaString}
              onChange={e => setUaString(e.target.value)}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border border-gray-200 dark:border-gray-700 outline-none"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div className="p-5 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 text-center space-y-1">
              <span className="text-xs font-bold text-gray-400 block">المتصفح Browser</span>
              <span className="text-base font-bold text-emerald-600">{parsedUA.browser}</span>
            </div>
            <div className="p-5 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 text-center space-y-1">
              <span className="text-xs font-bold text-gray-400 block">نظام التشغيل OS</span>
              <span className="text-base font-bold text-indigo-600">{parsedUA.os}</span>
            </div>
            <div className="p-5 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 text-center space-y-1">
              <span className="text-xs font-bold text-gray-400 block">نوع الجهاز Device</span>
              <span className="text-base font-bold text-amber-600">{parsedUA.device}</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: IP Info */}
      {activeTab === 'ip-info' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="text-center space-y-2">
            <span className="text-xs font-bold text-gray-400">عنوان IP العام للمتصل:</span>
            <h2 className="text-2xl sm:text-3xl font-mono font-black text-emerald-600">{ipData.ip}</h2>
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="p-3.5 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-700">
              <span className="text-gray-400 block mb-1">الدولة</span>
              <span className="font-bold text-gray-800 dark:text-gray-100">{ipData.country} ({ipData.countryCode})</span>
            </div>
            <div className="p-3.5 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-700">
              <span className="text-gray-400 block mb-1">المدينة والمنطقة</span>
              <span className="font-bold text-gray-800 dark:text-gray-100">{ipData.city}, {ipData.region}</span>
            </div>
            <div className="p-3.5 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-700">
              <span className="text-gray-400 block mb-1">مزود الخدمة (ISP/Org)</span>
              <span className="font-bold text-gray-800 dark:text-gray-100 truncate block">{ipData.org}</span>
            </div>
            <div className="p-3.5 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-700">
              <span className="text-gray-400 block mb-1">المنطقة الزمنية</span>
              <span className="font-bold text-gray-800 dark:text-gray-100">{ipData.timezone}</span>
            </div>
          </div>
        </div>
      )}

      {/* Tab 5: Code Minifier */}
      {activeTab === 'code-minifier' && (
        <div className="space-y-4">
          <div className="flex gap-2">
            {(['css', 'html', 'js'] as const).map(type => (
              <button
                key={type}
                onClick={() => {
                  setCodeType(type);
                  if (type === 'css') setRawCode(`.card {\n  display: flex;\n  margin: 10px;\n}`);
                  else if (type === 'html') setRawCode(`<div class="box">\n  <p>Hello World</p>\n</div>`);
                  else setRawCode(`function hello() {\n  const x = 10;\n  console.log(x);\n}`);
                }}
                className={`px-4 py-2 text-xs font-bold rounded-xl uppercase ${codeType === type ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
              >
                {type}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
              <label className="text-xs font-black text-gray-700 dark:text-gray-200 block">الكود الأصلي</label>
              <textarea
                rows={10}
                value={rawCode}
                onChange={e => setRawCode(e.target.value)}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700 outline-none"
              />
            </div>

            <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
              <div className="flex items-center justify-between">
                <label className="text-xs font-black text-gray-700 dark:text-gray-200">الكود المضغوط (Minified)</label>
                <button onClick={() => copyToClipboard(minifiedCode)} className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 text-xs font-bold rounded-lg flex items-center gap-1">
                  <Copy className="w-3.5 h-3.5" /> نسخ
                </button>
              </div>
              <textarea
                readOnly
                rows={10}
                value={minifiedCode}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700"
              />
            </div>
          </div>
        </div>
      )}

      {/* Tab 6: HTML Entities */}
      {activeTab === 'html-entities' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <label className="text-xs font-black text-gray-700 dark:text-gray-200 block">نص HTML العادي</label>
            <textarea
              rows={8}
              value={entityInput}
              onChange={e => setEntityInput(e.target.value)}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700 outline-none"
            />
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-gray-700 dark:text-gray-200">HTML Entities المشفرة</label>
              <button onClick={() => copyToClipboard(entityResults.encoded)} className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 text-xs font-bold rounded-lg flex items-center gap-1">
                <Copy className="w-3.5 h-3.5" /> نسخ
              </button>
            </div>
            <textarea
              readOnly
              rows={8}
              value={entityResults.encoded}
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700"
            />
          </div>
        </div>
      )}

      {/* Tab 7: Regex Tester */}
      {activeTab === 'regex-tester' && (
        <div className="space-y-5">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
            <div className="grid grid-cols-1 sm:grid-cols-12 gap-3">
              <div className="sm:col-span-9 space-y-1">
                <label className="text-xs font-bold block">التعبير النمطي (Regular Expression):</label>
                <input
                  type="text"
                  value={regexPattern}
                  onChange={e => setRegexPattern(e.target.value)}
                  className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border border-gray-200 dark:border-gray-700 outline-none"
                />
              </div>
              <div className="sm:col-span-3 space-y-1">
                <label className="text-xs font-bold block">الأعلام (Flags):</label>
                <input
                  type="text"
                  value={regexFlags}
                  onChange={e => setRegexFlags(e.target.value)}
                  placeholder="g, i, m"
                  className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border border-gray-200 dark:border-gray-700 outline-none"
                />
              </div>
            </div>

            <div className="space-y-1">
              <label className="text-xs font-bold block">نص الاختبار (Test String):</label>
              <textarea
                rows={5}
                value={regexTestText}
                onChange={e => setRegexTestText(e.target.value)}
                className="w-full p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-xs font-mono border border-gray-200 dark:border-gray-700 outline-none"
              />
            </div>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-600">
                نتائج التطابق ({regexMatches.matches.length} نتيجة)
              </span>
            </div>
            {regexMatches.matches.length > 0 ? (
              <div className="flex flex-wrap gap-2">
                {regexMatches.matches.map((m, i) => (
                  <span key={i} className="px-3 py-1.5 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-300 font-mono text-xs rounded-xl border border-emerald-200 dark:border-emerald-800">
                    {m.text}
                  </span>
                ))}
              </div>
            ) : (
              <div className="text-xs text-gray-400">لا يوجد تطابق.</div>
            )}
          </div>
        </div>
      )}

      {/* Tab 8: Timestamp Converter */}
      {activeTab === 'timestamp-converter' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="space-y-2">
            <label className="text-xs font-bold block">طابع الوقت Unix Timestamp (بالثواني):</label>
            <div className="flex gap-2">
              <input
                type="number"
                value={timestampInput}
                onChange={e => setTimestampInput(Number(e.target.value))}
                className="flex-1 p-3 bg-gray-50 dark:bg-gray-900 rounded-xl text-sm font-mono border border-gray-200 dark:border-gray-700 outline-none"
              />
              <button
                onClick={() => setTimestampInput(Math.floor(Date.now() / 1000))}
                className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold hover:bg-emerald-700"
              >
                الآن
              </button>
            </div>
          </div>

          {timestampDate && (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800">
                <span className="text-gray-400 block text-[11px] mb-1 font-sans">التوقيت المحلي</span>
                <span className="text-emerald-600 font-bold">{timestampDate.local}</span>
              </div>
              <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800">
                <span className="text-gray-400 block text-[11px] mb-1 font-sans">توقيت غرينتش UTC</span>
                <span className="text-indigo-600 font-bold">{timestampDate.utc}</span>
              </div>
              <div className="sm:col-span-2 p-3 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-100 dark:border-gray-800">
                <span className="text-gray-400 block text-[11px] mb-1 font-sans">صيغة ISO 8601</span>
                <span className="text-gray-700 dark:text-gray-300">{timestampDate.iso}</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Tab 9: Cron Generator */}
      {activeTab === 'cron-generator' && (
        <div className="max-w-2xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-6">
          <div className="p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 text-center space-y-2">
            <span className="text-xs font-bold text-gray-400 block">تعبير Cron الناتج:</span>
            <div className="text-2xl sm:text-3xl font-mono font-black text-emerald-600 tracking-wider">
              {cronString}
            </div>
            <p className="text-xs text-gray-600 dark:text-gray-400 font-sans">{cronExplanation}</p>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 gap-3 text-xs">
            <div>
              <label className="font-bold block mb-1">الدقيقة (0-59)</label>
              <input type="text" value={cronMinute} onChange={e => setCronMinute(e.target.value)} className="w-full p-2 bg-gray-50 dark:bg-gray-900 rounded-lg text-center font-mono border border-gray-200 dark:border-gray-700" />
            </div>
            <div>
              <label className="font-bold block mb-1">الساعة (0-23)</label>
              <input type="text" value={cronHour} onChange={e => setCronHour(e.target.value)} className="w-full p-2 bg-gray-50 dark:bg-gray-900 rounded-lg text-center font-mono border border-gray-200 dark:border-gray-700" />
            </div>
            <div>
              <label className="font-bold block mb-1">اليوم (1-31)</label>
              <input type="text" value={cronDayOfMonth} onChange={e => setCronDayOfMonth(e.target.value)} className="w-full p-2 bg-gray-50 dark:bg-gray-900 rounded-lg text-center font-mono border border-gray-200 dark:border-gray-700" />
            </div>
            <div>
              <label className="font-bold block mb-1">الشهر (1-12)</label>
              <input type="text" value={cronMonth} onChange={e => setCronMonth(e.target.value)} className="w-full p-2 bg-gray-50 dark:bg-gray-900 rounded-lg text-center font-mono border border-gray-200 dark:border-gray-700" />
            </div>
            <div className="col-span-2 sm:col-span-1">
              <label className="font-bold block mb-1">يوم الأسبوع (0-6)</label>
              <input type="text" value={cronDayOfWeek} onChange={e => setCronDayOfWeek(e.target.value)} className="w-full p-2 bg-gray-50 dark:bg-gray-900 rounded-lg text-center font-mono border border-gray-200 dark:border-gray-700" />
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
