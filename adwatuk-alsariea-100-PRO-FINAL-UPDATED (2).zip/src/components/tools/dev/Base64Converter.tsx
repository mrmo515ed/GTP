import React, { useState } from 'react';
import { Code2, Copy, CheckCircle2 } from 'lucide-react';

export function Base64Converter() {
  const [inputText, setInputText] = useState<string>('');
  const [mode, setMode] = useState<'base64-encode' | 'base64-decode' | 'url-encode' | 'url-decode'>('base64-encode');
  const [copied, setCopied] = useState(false);

  const processText = () => {
    if (!inputText) return '';
    try {
      switch (mode) {
        case 'base64-encode':
          // Using unescape & encodeURIComponent to handle Arabic/Unicode chars correctly
          return btoa(unescape(encodeURIComponent(inputText)));
        case 'base64-decode':
          return decodeURIComponent(escape(atob(inputText)));
        case 'url-encode':
          return encodeURIComponent(inputText);
        case 'url-decode':
          return decodeURIComponent(inputText);
        default:
          return '';
      }
    } catch (e) {
      return 'خطأ: الإدخال غير صالح لهذه العملية';
    }
  };

  const result = processText();

  const handleCopy = () => {
    if (!result || result.startsWith('خطأ:')) return;
    navigator.clipboard.writeText(result);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-gray-100 dark:bg-gray-800 p-1 rounded-xl flex flex-wrap gap-1">
        {[
          { id: 'base64-encode', label: 'تشفير Base64' },
          { id: 'base64-decode', label: 'فك تشفير Base64' },
          { id: 'url-encode', label: 'ترميز URL' },
          { id: 'url-decode', label: 'فك ترميز URL' },
        ].map((m) => (
          <button
            key={m.id}
            onClick={() => setMode(m.id as any)}
            className={`flex-1 min-w-[120px] py-2 px-2 text-sm font-bold rounded-lg transition ${
              mode === m.id
                ? 'bg-white dark:bg-gray-700 text-indigo-600 dark:text-indigo-400 shadow-xs'
                : 'text-gray-500 hover:text-gray-700 dark:hover:text-gray-300'
            }`}
          >
            {m.label}
          </button>
        ))}
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">أدخل النص أو الكود هنا</label>
        <textarea
          value={inputText}
          onChange={(e) => setInputText(e.target.value)}
          className="w-full px-4 py-4 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none resize-y min-h-[140px] font-mono text-left"
          placeholder="Type here..."
          dir="ltr"
        />
      </div>

      <div className="space-y-2">
        <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">النتيجة</label>
        <div className="relative">
          <textarea
            readOnly
            value={result}
            className={`w-full px-4 py-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-xl outline-none resize-y min-h-[140px] font-mono text-left ${result.startsWith('خطأ:') ? 'text-red-500' : 'text-gray-900 dark:text-gray-100'}`}
            placeholder="Result..."
            dir="ltr"
          />
          {result && !result.startsWith('خطأ:') && (
            <button
              onClick={handleCopy}
              className="absolute top-4 right-4 p-2 bg-white dark:bg-gray-800 text-gray-500 hover:text-indigo-600 dark:hover:text-indigo-400 border border-gray-200 dark:border-gray-700 rounded-lg shadow-xs transition"
              title="نسخ النتيجة"
            >
              {copied ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
