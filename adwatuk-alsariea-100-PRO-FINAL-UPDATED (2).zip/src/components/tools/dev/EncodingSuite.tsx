import React, { useState } from 'react';
import { Shield, RefreshCw, Copy, CheckCircle2, XCircle } from 'lucide-react';
import confetti from 'canvas-confetti';

type EncodingTab = 'base64-encode' | 'base64-decode' | 'url-encode' | 'url-decode' | 'html-encode' | 'html-decode';

export function EncodingSuite({ defaultTab = 'base64-encode' }: { defaultTab?: string }) {
  const [activeTab, setActiveTab] = useState<EncodingTab>(defaultTab as EncodingTab);
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const tabs: { id: EncodingTab; label: string; icon: any }[] = [
    { id: 'base64-encode', label: 'Base64 Encode', icon: Shield },
    { id: 'base64-decode', label: 'Base64 Decode', icon: Shield },
    { id: 'url-encode', label: 'URL Encode', icon: RefreshCw },
    { id: 'url-decode', label: 'URL Decode', icon: RefreshCw },
    { id: 'html-encode', label: 'HTML Encode', icon: Shield },
    { id: 'html-decode', label: 'HTML Decode', icon: Shield },
  ];

  const encodeHtmlEntity = (str: string) => {
    return str.replace(/[\u00A0-\u9999<>\&]/g, (i) => '&#'+i.charCodeAt(0)+';');
  };

  const decodeHtmlEntity = (str: string) => {
    return str.replace(/&#([0-9]{1,3});/gi, (match, numStr) => String.fromCharCode(parseInt(numStr, 10)));
  };

  const handleProcess = () => {
    setError(null);
    setSuccess(null);
    setOutput('');

    if (!input) {
      setError('الرجاء إدخال نص أولاً');
      return;
    }

    try {
      if (activeTab === 'base64-encode') {
        setOutput(btoa(unescape(encodeURIComponent(input))));
        setSuccess('تم التشفير إلى Base64 بنجاح');
      } else if (activeTab === 'base64-decode') {
        setOutput(decodeURIComponent(escape(atob(input))));
        setSuccess('تم فك التشفير من Base64 بنجاح');
      } else if (activeTab === 'url-encode') {
        setOutput(encodeURIComponent(input));
        setSuccess('تم تشفير URL بنجاح');
      } else if (activeTab === 'url-decode') {
        setOutput(decodeURIComponent(input));
        setSuccess('تم فك تشفير URL بنجاح');
      } else if (activeTab === 'html-encode') {
        setOutput(encodeHtmlEntity(input));
        setSuccess('تم ترميز HTML بنجاح');
      } else if (activeTab === 'html-decode') {
        // More robust decode
        const doc = new DOMParser().parseFromString(input, "text/html");
        setOutput(doc.documentElement.textContent || '');
        setSuccess('تم فك ترميز HTML بنجاح');
      }
      confetti({ particleCount: 30, spread: 50 });
    } catch (err: any) {
      setError('خطأ في المعالجة: تأكد من صحة المدخلات. ' + err.message);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setSuccess('تم النسخ إلى الحافظة');
    setTimeout(() => setSuccess(null), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-2 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => { setActiveTab(tab.id); setOutput(''); setError(null); setSuccess(null); }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-lg'
                : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-50'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span className="text-sm font-medium">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white">الإدخال</h3>
            <button onClick={() => setInput('')} className="text-sm text-red-500 hover:text-red-600">مسح</button>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full h-80 p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 text-left dir-ltr"
            placeholder="أدخل النص هنا..."
          />
          <button
            onClick={handleProcess}
            className="w-full mt-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-5 h-5" />
            <span>تنفيذ العملية</span>
          </button>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white">النتيجة</h3>
            <button onClick={handleCopy} className="p-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
              <Copy className="w-4 h-4" />
            </button>
          </div>
          
          {error && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg flex items-center gap-2 text-sm">
              <XCircle className="w-5 h-5" />
              {error}
            </div>
          )}
          
          {success && (
            <div className="mb-4 p-3 bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-lg flex items-center gap-2 text-sm">
              <CheckCircle2 className="w-5 h-5" />
              {success}
            </div>
          )}

          <textarea
            value={output}
            readOnly
            className="w-full h-80 p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 text-left dir-ltr"
            placeholder="ستظهر النتيجة هنا..."
          />
        </div>
      </div>
    </div>
  );
}
