import React, { useState, useEffect } from 'react';
import { ShieldCheck, Copy, Check, RefreshCw, KeyRound, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

export function PasswordGenerator() {
  const [length, setLength] = useState<number>(16);
  const [useUppercase, setUseUppercase] = useState(true);
  const [useLowercase, setUseLowercase] = useState(true);
  const [useNumbers, setUseNumbers] = useState(true);
  const [useSymbols, setUseSymbols] = useState(true);
  const [avoidAmbiguous, setAvoidAmbiguous] = useState(true); // avoid 0, O, l, 1, I

  const [password, setPassword] = useState('');
  const [copied, setCopied] = useState(false);

  const generatePassword = () => {
    let uppercaseChars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    let lowercaseChars = 'abcdefghijklmnopqrstuvwxyz';
    let numberChars = '0123456789';
    let symbolChars = '!@#$%^&*()_+-=[]{}|;:,.<>?';

    if (avoidAmbiguous) {
      uppercaseChars = uppercaseChars.replace(/[OI]/g, '');
      lowercaseChars = lowercaseChars.replace(/[l]/g, '');
      numberChars = numberChars.replace(/[01]/g, '');
    }

    let charPool = '';
    if (useUppercase) charPool += uppercaseChars;
    if (useLowercase) charPool += lowercaseChars;
    if (useNumbers) charPool += numberChars;
    if (useSymbols) charPool += symbolChars;

    if (!charPool) {
      setPassword('');
      return;
    }

    const array = new Uint32Array(length);
    window.crypto.getRandomValues(array);

    let result = '';
    for (let i = 0; i < length; i++) {
      result += charPool[array[i] % charPool.length];
    }
    setPassword(result);
  };

  useEffect(() => {
    generatePassword();
  }, [length, useUppercase, useLowercase, useNumbers, useSymbols, avoidAmbiguous]);

  const copyPassword = () => {
    if (!password) return;
    navigator.clipboard.writeText(password);
    setCopied(true);
    confetti({ particleCount: 35, spread: 50, origin: { y: 0.8 } });
    setTimeout(() => setCopied(false), 2000);
  };

  // Calculate strength
  const calculateStrength = () => {
    if (!password) return { score: 0, label: 'فارغ', color: 'bg-gray-300' };
    let score = 0;
    if (password.length >= 8) score += 1;
    if (password.length >= 14) score += 1;
    if (password.length >= 20) score += 1;
    if (useUppercase && useLowercase) score += 1;
    if (useNumbers) score += 1;
    if (useSymbols) score += 1;

    if (score <= 2) return { score: 25, label: 'ضعيفة', color: 'bg-rose-500', text: 'text-rose-500' };
    if (score <= 4) return { score: 60, label: 'متوسطة', color: 'bg-amber-500', text: 'text-amber-500' };
    if (score <= 5) return { score: 85, label: 'قوية جداً', color: 'bg-emerald-500', text: 'text-emerald-500' };
    return { score: 100, label: 'فائقة الأمان وغير قابلة للاختراق', color: 'bg-emerald-600', text: 'text-emerald-600' };
  };

  const strength = calculateStrength();

  return (
    <div className="space-y-6" id="password-generator-tool">
      {/* Password Result Display */}
      <div className="p-4 bg-gray-50 dark:bg-gray-800/80 rounded-2xl border border-gray-200 dark:border-gray-700 space-y-3">
        <div className="flex items-center gap-3">
          <input
            type="text"
            readOnly
            value={password}
            dir="ltr"
            className="flex-1 p-3 bg-white dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-800 font-mono text-base sm:text-lg font-bold text-gray-900 dark:text-gray-100 outline-none select-all"
          />
          <button
            onClick={generatePassword}
            className="p-3 bg-white dark:bg-gray-700 hover:bg-gray-100 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-600 rounded-xl transition"
            title="توليد كلمة مرور أخرى"
          >
            <RefreshCw className="w-5 h-5" />
          </button>
          <button
            onClick={copyPassword}
            id="btn-copy-generated-password"
            className="px-4 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl transition flex items-center gap-1.5 shadow-xs"
          >
            {copied ? <Check className="w-5 h-5 text-emerald-200" /> : <Copy className="w-5 h-5" />}
            <span className="hidden sm:inline">{copied ? 'تم النسخ' : 'نسخ'}</span>
          </button>
        </div>

        {/* Strength meter bar */}
        <div className="space-y-1.5 pt-1">
          <div className="flex justify-between text-xs font-semibold">
            <span className="text-gray-500">مستوى قوة كلمة المرور:</span>
            <span className={strength.text}>{strength.label}</span>
          </div>
          <div className="w-full h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className={`h-full ${strength.color} transition-all duration-300`}
              style={{ width: `${strength.score}%` }}
            />
          </div>
        </div>
      </div>

      {/* Generator Settings */}
      <div className="p-5 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-2xl space-y-4">
        {/* Length slider */}
        <div>
          <div className="flex justify-between text-xs font-bold text-gray-700 dark:text-gray-300 mb-1">
            <span>طول كلمة المرور:</span>
            <span className="font-mono text-emerald-600 dark:text-emerald-400 font-extrabold text-sm">
              {length} حرف
            </span>
          </div>
          <input
            type="range"
            min={6}
            max={64}
            value={length}
            onChange={(e) => setLength(Number(e.target.value))}
            className="w-full accent-emerald-600 cursor-pointer"
          />
        </div>

        {/* Checkboxes */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2">
          <label className="flex items-center gap-2 text-xs font-semibold text-gray-700 dark:text-gray-300 cursor-pointer">
            <input
              type="checkbox"
              checked={useUppercase}
              onChange={(e) => setUseUppercase(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded"
            />
            <span>أحرف كبيرة إنجليزية (A-Z)</span>
          </label>

          <label className="flex items-center gap-2 text-xs font-semibold text-gray-700 dark:text-gray-300 cursor-pointer">
            <input
              type="checkbox"
              checked={useLowercase}
              onChange={(e) => setUseLowercase(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded"
            />
            <span>أحرف صغيرة إنجليزية (a-z)</span>
          </label>

          <label className="flex items-center gap-2 text-xs font-semibold text-gray-700 dark:text-gray-300 cursor-pointer">
            <input
              type="checkbox"
              checked={useNumbers}
              onChange={(e) => setUseNumbers(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded"
            />
            <span>أرقام (0-9)</span>
          </label>

          <label className="flex items-center gap-2 text-xs font-semibold text-gray-700 dark:text-gray-300 cursor-pointer">
            <input
              type="checkbox"
              checked={useSymbols}
              onChange={(e) => setUseSymbols(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded"
            />
            <span>رموز خاصة (!@#$%^&*)</span>
          </label>

          <label className="flex items-center gap-2 text-xs font-semibold text-gray-700 dark:text-gray-300 cursor-pointer sm:col-span-2">
            <input
              type="checkbox"
              checked={avoidAmbiguous}
              onChange={(e) => setAvoidAmbiguous(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded"
            />
            <span>استبعاد الرموز المتشابهة والمحيرة (مثل: 0, O, l, 1, I)</span>
          </label>
        </div>
      </div>
    </div>
  );
}
