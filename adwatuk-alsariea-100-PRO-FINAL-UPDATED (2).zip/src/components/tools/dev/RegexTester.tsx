import React, { useState, useMemo } from 'react';
import { Code, CheckCircle2, AlertCircle } from 'lucide-react';

export function RegexTester() {
  const [pattern, setPattern] = useState('');
  const [flags, setFlags] = useState('g');
  const [testString, setTestString] = useState('Welcome to Adwatuk tool 2024! testing regex@test.com');

  const { matches, error } = useMemo(() => {
    if (!pattern) return { matches: [], error: null };
    
    try {
      const regex = new RegExp(pattern, flags);
      const str = testString;
      const matchesArr = [];
      let match;
      
      if (flags.includes('g')) {
        let maxLoops = 1000;
        while ((match = regex.exec(str)) !== null && maxLoops > 0) {
          matchesArr.push({
            index: match.index,
            value: match[0],
            length: match[0].length
          });
          // avoid infinite loop with empty matches
          if (match.index === regex.lastIndex) regex.lastIndex++;
          maxLoops--;
        }
      } else {
        match = regex.exec(str);
        if (match) {
          matchesArr.push({
            index: match.index,
            value: match[0],
            length: match[0].length
          });
        }
      }
      return { matches: matchesArr, error: null };
    } catch (e: any) {
      return { matches: [], error: e.message };
    }
  }, [pattern, flags, testString]);

  // Highlighting the matches in the textarea using a trick: background div with highlighted text under a transparent textarea
  // For simplicity here, we'll just show the matches in a list or styled div
  const getHighlightedText = () => {
    if (!pattern || error || matches.length === 0) return testString;

    let lastIndex = 0;
    const parts = [];

    matches.forEach((m, i) => {
      // Add non-matching part before this match
      if (m.index > lastIndex) {
        parts.push(<span key={`text-${i}`}>{testString.substring(lastIndex, m.index)}</span>);
      }
      // Add matching part
      parts.push(
        <span key={`match-${i}`} className="bg-amber-300 dark:bg-amber-900/60 text-amber-900 dark:text-amber-100 font-bold rounded-sm px-0.5">
          {m.value}
        </span>
      );
      lastIndex = m.index + m.length;
    });

    // Add remaining text
    if (lastIndex < testString.length) {
      parts.push(<span key="text-end">{testString.substring(lastIndex)}</span>);
    }

    return parts;
  };

  const handleFlagToggle = (flag: string) => {
    if (flags.includes(flag)) {
      setFlags(flags.replace(flag, ''));
    } else {
      setFlags(flags + flag);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-2xl flex items-start gap-3 border border-indigo-100 dark:border-indigo-800/30">
        <Code className="w-5 h-5 text-indigo-600 dark:text-indigo-400 mt-0.5 shrink-0" />
        <p className="text-sm text-indigo-800 dark:text-indigo-200 leading-relaxed">
          مختبر التعابير القياسية (Regex Tester): أداة مفيدة للمطورين لكتابة التعبيرات النمطية واختبارها فورياً على نصوص مخصصة لمعرفة أماكن التطابق (Matches) بدقة.
        </p>
      </div>

      <div className="space-y-4">
        {/* Pattern Input */}
        <div className="space-y-2">
          <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">التعبير القياسي (Regular Expression)</label>
          <div className="flex bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 focus-within:ring-2 focus-within:ring-indigo-500 overflow-hidden" dir="ltr">
            <div className="px-3 py-3 text-gray-500 font-mono text-lg font-bold">/</div>
            <input
              type="text"
              value={pattern}
              onChange={(e) => setPattern(e.target.value)}
              className="flex-1 px-2 py-3 bg-transparent outline-none font-mono text-lg text-indigo-600 dark:text-indigo-400 font-bold"
              placeholder="e.g. [0-9]+"
            />
            <div className="px-3 py-3 text-gray-500 font-mono text-lg font-bold border-r border-gray-200 dark:border-gray-700">/</div>
            <input
              type="text"
              value={flags}
              onChange={(e) => setFlags(e.target.value)}
              className="w-16 px-2 py-3 bg-transparent outline-none font-mono text-lg text-emerald-600 dark:text-emerald-400 font-bold text-center"
              placeholder="gmi"
            />
          </div>
          {error && (
            <div className="text-xs text-rose-500 mt-1 flex items-center gap-1">
              <AlertCircle className="w-3.5 h-3.5" />
              <span>{error}</span>
            </div>
          )}
        </div>

        {/* Quick Flags */}
        <div className="flex flex-wrap gap-2" dir="ltr">
          {[
            { id: 'g', label: 'Global' },
            { id: 'i', label: 'Case Insensitive' },
            { id: 'm', label: 'Multiline' }
          ].map(f => (
            <button
              key={f.id}
              onClick={() => handleFlagToggle(f.id)}
              className={`px-3 py-1.5 text-xs font-mono font-bold rounded-lg border transition ${
                flags.includes(f.id)
                  ? 'bg-indigo-600 text-white border-indigo-600'
                  : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-400 border-gray-200 dark:border-gray-700'
              }`}
            >
              {f.id} ({f.label})
            </button>
          ))}
        </div>

        {/* Test String Input */}
        <div className="space-y-2 pt-4 border-t border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between">
            <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">نص الاختبار (Test String)</label>
            <span className="text-xs font-bold text-gray-500 bg-gray-100 dark:bg-gray-800 px-2 py-1 rounded">
              {matches.length} {matches.length === 1 ? 'Match' : 'Matches'}
            </span>
          </div>
          
          <div className="relative">
            {/* Display layer for highlights */}
            <div 
              className="absolute inset-0 w-full p-4 whitespace-pre-wrap font-mono text-base break-words text-transparent pointer-events-none"
              dir="ltr"
            >
              {getHighlightedText()}
            </div>
            
            {/* Input layer */}
            <textarea
              value={testString}
              onChange={(e) => setTestString(e.target.value)}
              className="w-full p-4 bg-transparent border border-gray-200 dark:border-gray-700 rounded-xl outline-none focus:ring-2 focus:ring-indigo-500 resize-y min-h-[160px] font-mono text-base leading-relaxed text-gray-900 dark:text-gray-100 shadow-xs"
              dir="ltr"
              spellCheck={false}
            />
          </div>
        </div>
      </div>
    </div>
  );
}
