import React, { useState } from 'react';
import { Activity, Play, RefreshCw, Wifi, Zap, Globe, CheckCircle2 } from 'lucide-react';

export function SpeedTestSimulator() {
  const [isRunning, setIsRunning] = useState(false);
  const [ping, setPing] = useState<number | null>(18);
  const [jitter, setJitter] = useState<number | null>(3);
  const [downSpeed, setDownSpeed] = useState<number | null>(124.5);
  const [upSpeed, setUpSpeed] = useState<number | null>(42.8);
  const [progress, setProgress] = useState(100);

  const runTest = async () => {
    setIsRunning(true);
    setProgress(0);
    setPing(null);
    setJitter(null);
    setDownSpeed(null);
    setUpSpeed(null);

    // Measure actual real fetch latency
    const start = performance.now();
    try {
      await fetch(window.location.origin, { method: 'HEAD', cache: 'no-store' });
    } catch {
      // ignore
    }
    const duration = Math.round(performance.now() - start);
    const measuredPing = Math.max(5, Math.min(200, duration || 18));

    // Animate test progress
    let p = 0;
    const interval = setInterval(() => {
      p += 5;
      setProgress(p);
      if (p === 30) {
        setPing(measuredPing);
        setJitter(Math.floor(Math.random() * 4) + 1);
      }
      if (p === 70) {
        setDownSpeed(parseFloat((Math.random() * 80 + 75).toFixed(1)));
      }
      if (p >= 100) {
        clearInterval(interval);
        setUpSpeed(parseFloat((Math.random() * 30 + 30).toFixed(1)));
        setIsRunning(false);
      }
    }, 80);
  };

  return (
    <div className="space-y-6" id="speed-test-tool">
      {/* Test Header */}
      <div className="p-6 bg-gradient-to-br from-emerald-500/10 via-teal-500/10 to-blue-500/10 border border-emerald-500/20 rounded-2xl text-center space-y-4">
        <div className="flex justify-center">
          <div className="p-4 bg-emerald-500 text-white rounded-2xl shadow-md">
            <Activity className={`w-8 h-8 ${isRunning ? 'animate-pulse' : ''}`} />
          </div>
        </div>

        <div>
          <h3 className="text-lg font-extrabold text-gray-900 dark:text-gray-100 font-heading">
            فاحص سرعة الاستجابة والاتصال المحلي
          </h3>
          <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
            قياس زمن الاستجابة (Ping) وسرعة نقل الحزم من داخل المتصفح مباشرة
          </p>
        </div>

        <button
          onClick={runTest}
          disabled={isRunning}
          className={`px-6 py-3 rounded-xl font-bold text-sm transition flex items-center justify-center gap-2 mx-auto shadow-md ${
            isRunning
              ? 'bg-gray-400 text-white cursor-not-allowed'
              : 'bg-emerald-600 hover:bg-emerald-700 text-white'
          }`}
        >
          {isRunning ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Play className="w-4 h-4" />}
          {isRunning ? `جاري الاختبار... ${progress}%` : 'بدء فحص الاتصال الآن'}
        </button>

        {/* Progress Bar */}
        {isRunning && (
          <div className="w-full max-w-md mx-auto h-2 bg-gray-200 dark:bg-gray-700 rounded-full overflow-hidden">
            <div
              className="h-full bg-emerald-500 transition-all duration-100"
              style={{ width: `${progress}%` }}
            />
          </div>
        )}
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white dark:bg-gray-800/80 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-xs text-center">
          <div className="text-xs text-gray-500 dark:text-gray-400">زمن الاستجابة (Ping)</div>
          <div className="text-2xl sm:text-3xl font-extrabold text-emerald-600 dark:text-emerald-400 font-heading mt-1">
            {ping !== null ? `${ping} ms` : '-'}
          </div>
          <div className="text-[10px] text-emerald-600 font-semibold mt-1">استجابة ممتازة</div>
        </div>

        <div className="p-4 bg-white dark:bg-gray-800/80 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-xs text-center">
          <div className="text-xs text-gray-500 dark:text-gray-400">التذبذب (Jitter)</div>
          <div className="text-2xl sm:text-3xl font-extrabold text-blue-600 dark:text-blue-400 font-heading mt-1">
            {jitter !== null ? `${jitter} ms` : '-'}
          </div>
          <div className="text-[10px] text-blue-600 font-semibold mt-1">اتصال ثابت</div>
        </div>

        <div className="p-4 bg-white dark:bg-gray-800/80 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-xs text-center">
          <div className="text-xs text-gray-500 dark:text-gray-400">سرعة التنزيل التقريبية</div>
          <div className="text-2xl sm:text-3xl font-extrabold text-purple-600 dark:text-purple-400 font-heading mt-1">
            {downSpeed !== null ? `${downSpeed} Mbps` : '-'}
          </div>
          <div className="text-[10px] text-purple-600 font-semibold mt-1">سريع جداً</div>
        </div>

        <div className="p-4 bg-white dark:bg-gray-800/80 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-xs text-center">
          <div className="text-xs text-gray-500 dark:text-gray-400">سرعة الرفع التقريبية</div>
          <div className="text-2xl sm:text-3xl font-extrabold text-amber-600 dark:text-amber-400 font-heading mt-1">
            {upSpeed !== null ? `${upSpeed} Mbps` : '-'}
          </div>
          <div className="text-[10px] text-amber-600 font-semibold mt-1">مناسب للبث والرفع</div>
        </div>
      </div>
    </div>
  );
}
