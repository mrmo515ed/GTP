import React, { useState, useEffect } from 'react';
import { Clock, RefreshCw } from 'lucide-react';

export function UnixTimestamp() {
  const [currentTimestamp, setCurrentTimestamp] = useState<number>(Math.floor(Date.now() / 1000));
  const [inputTimestamp, setInputTimestamp] = useState<string>('');
  const [convertedDate, setConvertedDate] = useState<string>('');
  
  const [inputDate, setInputDate] = useState<string>('');
  const [convertedTimestamp, setConvertedTimestamp] = useState<string>('');

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTimestamp(Math.floor(Date.now() / 1000));
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const handleTimestampChange = (val: string) => {
    setInputTimestamp(val);
    const ts = parseInt(val, 10);
    if (!isNaN(ts)) {
      // Handle both seconds and milliseconds (heuristic)
      const date = new Date(ts > 10000000000 ? ts : ts * 1000);
      setConvertedDate(date.toLocaleString('ar-SA') + ' | ' + date.toLocaleString('en-US'));
    } else {
      setConvertedDate('');
    }
  };

  const handleDateChange = (val: string) => {
    setInputDate(val);
    const date = new Date(val);
    if (!isNaN(date.getTime())) {
      setConvertedTimestamp(Math.floor(date.getTime() / 1000).toString());
    } else {
      setConvertedTimestamp('');
    }
  };

  return (
    <div className="space-y-8">
      {/* Current Timestamp */}
      <div className="bg-indigo-50 dark:bg-indigo-900/20 p-6 rounded-2xl border border-indigo-100 dark:border-indigo-800/30 text-center">
        <p className="text-sm font-bold text-indigo-800 dark:text-indigo-200 mb-2">الطابع الزمني الحالي (Unix Epoch)</p>
        <div className="text-4xl md:text-5xl font-black text-indigo-600 dark:text-indigo-400 font-mono tracking-wider">
          {currentTimestamp}
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Timestamp to Date */}
        <div className="space-y-4 bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-200 dark:border-gray-700">
          <h3 className="font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <Clock className="w-5 h-5 text-indigo-500" />
            من طابع زمني إلى تاريخ
          </h3>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-gray-500">أدخل الطابع الزمني</label>
            <input
              type="number"
              value={inputTimestamp}
              onChange={(e) => handleTimestampChange(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none text-left font-mono"
              placeholder="e.g. 1672531200"
              dir="ltr"
            />
          </div>
          {convertedDate && (
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 text-sm font-mono text-center leading-relaxed">
              {convertedDate}
            </div>
          )}
        </div>

        {/* Date to Timestamp */}
        <div className="space-y-4 bg-white dark:bg-gray-800 p-5 rounded-2xl border border-gray-200 dark:border-gray-700">
          <h3 className="font-bold text-gray-900 dark:text-white flex items-center gap-2">
            <RefreshCw className="w-5 h-5 text-indigo-500" />
            من تاريخ إلى طابع زمني
          </h3>
          <div className="space-y-2">
            <label className="block text-xs font-bold text-gray-500">اختر التاريخ والوقت</label>
            <input
              type="datetime-local"
              value={inputDate}
              onChange={(e) => handleDateChange(e.target.value)}
              className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
            />
          </div>
          {convertedTimestamp && (
            <div className="p-3 bg-gray-50 dark:bg-gray-900 rounded-xl border border-gray-200 dark:border-gray-700 text-xl font-black text-center font-mono text-indigo-600 dark:text-indigo-400">
              {convertedTimestamp}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
