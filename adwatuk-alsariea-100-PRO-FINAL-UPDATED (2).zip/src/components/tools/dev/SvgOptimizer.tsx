import React, { useState } from 'react';
import { Code, Download, Copy, Check, Sparkles, Image as ImageIcon } from 'lucide-react';
import confetti from 'canvas-confetti';

export function SvgOptimizer() {
  const [svgCode, setSvgCode] = useState(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="96" height="96" fill="none" stroke="#10B981" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
  <polygon points="13 2 3 14 12 14 11 22 21 10 12 10 13 2"></polygon>
</svg>`);

  const [copied, setCopied] = useState(false);
  const [fillColor, setFillColor] = useState('#10B981');
  const [pngSize, setPngSize] = useState<number>(256);

  const handleCopy = () => {
    navigator.clipboard.writeText(svgCode);
    setCopied(true);
    confetti({ particleCount: 30, spread: 45, origin: { y: 0.8 } });
    setTimeout(() => setCopied(false), 2000);
  };

  const handleDownloadPng = () => {
    const svgBlob = new Blob([svgCode], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(svgBlob);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = pngSize;
      canvas.height = pngSize;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(img, 0, 0, pngSize, pngSize);
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);

      const a = document.createElement('a');
      a.download = 'exported-vector.png';
      a.href = canvas.toDataURL('image/png');
      a.click();
      confetti({ particleCount: 35, spread: 50, origin: { y: 0.8 } });
    };
    img.src = url;
  };

  return (
    <div className="space-y-6" id="svg-optimizer-tool">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Code editor */}
        <div className="md:col-span-7 space-y-2">
          <div className="flex items-center justify-between text-xs text-gray-500">
            <span className="font-bold text-gray-700 dark:text-gray-300">كود SVG المصدري:</span>
            <button
              onClick={handleCopy}
              className="text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1 font-semibold"
            >
              {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
              {copied ? 'تم النسخ' : 'نسخ الكود'}
            </button>
          </div>
          <textarea
            value={svgCode}
            onChange={(e) => setSvgCode(e.target.value)}
            rows={10}
            dir="ltr"
            className="w-full p-3.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 font-mono text-xs text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-emerald-500 outline-none leading-relaxed"
          />
        </div>

        {/* Live Preview & PNG Export */}
        <div className="md:col-span-5 space-y-4">
          <span className="text-xs font-bold text-gray-700 dark:text-gray-300 block">
            المعاينة الحية والتصدير:
          </span>

          <div
            className="h-44 rounded-2xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-800/80 flex items-center justify-center p-4 overflow-hidden"
            dangerouslySetInnerHTML={{ __html: svgCode }}
          />

          <div className="p-3.5 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-xl space-y-3">
            <div className="flex items-center justify-between text-xs">
              <span className="font-bold text-gray-700 dark:text-gray-300">أبعاد تصدير PNG:</span>
              <select
                value={pngSize}
                onChange={(e) => setPngSize(Number(e.target.value))}
                className="p-1.5 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-xs font-bold"
              >
                <option value={128}>128x128 px</option>
                <option value={256}>256x256 px</option>
                <option value={512}>512x512 px (HD)</option>
                <option value={1024}>1024x1024 px (4K Icon)</option>
              </select>
            </div>

            <button
              onClick={handleDownloadPng}
              className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs shadow-xs transition flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              تصدير كصورة PNG عالية الدقة
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
