import React, { useState } from 'react';
import { Code2, CheckCircle2, XCircle, Copy, Download, RefreshCw, FileText, FileSpreadsheet, FileJson, Brackets } from 'lucide-react';
import confetti from 'canvas-confetti';
import { xml2js } from 'xml-js';
import { stringify as yamlStringify } from 'yaml';
import Papa from 'papaparse';
import beautify from 'js-beautify';

type XmlTab = 'format' | 'validate' | 'minify' | 'to-json' | 'to-csv' | 'to-yaml' | 'escape' | 'unescape';

export function XmlToolsSuite({ defaultTab = 'format' }: { defaultTab?: string }) {
  const [activeTab, setActiveTab] = useState<XmlTab>(defaultTab as XmlTab);
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const tabs: { id: XmlTab; label: string; icon: any }[] = [
    { id: 'format', label: 'XML Formatter', icon: Code2 },
    { id: 'validate', label: 'XML Validator', icon: CheckCircle2 },
    { id: 'minify', label: 'XML Minifier', icon: RefreshCw },
    { id: 'to-json', label: 'XML to JSON', icon: FileJson },
    { id: 'to-csv', label: 'XML to CSV', icon: FileSpreadsheet },
    { id: 'to-yaml', label: 'XML to YAML', icon: FileText },
    { id: 'escape', label: 'XML Escape', icon: Brackets },
    { id: 'unescape', label: 'XML Unescape', icon: Brackets },
  ];

  const escapeXml = (unsafe: string) => {
    return unsafe.replace(/[<>&'"]/g, (c) => {
      switch (c) {
        case '<': return '&lt;';
        case '>': return '&gt;';
        case '&': return '&amp;';
        case '\'': return '&apos;';
        case '"': return '&quot;';
        default: return c;
      }
    });
  };

  const unescapeXml = (safe: string) => {
    return safe.replace(/&lt;|&gt;|&amp;|&apos;|&quot;/g, (c) => {
      switch (c) {
        case '&lt;': return '<';
        case '&gt;': return '>';
        case '&amp;': return '&';
        case '&apos;': return '\'';
        case '&quot;': return '"';
        default: return c;
      }
    });
  };

  const flattenObject = (ob: any) => {
    const toReturn: any = {};
    for (const i in ob) {
      if (!ob.hasOwnProperty(i)) continue;
      if (typeof ob[i] == 'object' && ob[i] !== null) {
        const flatObject = flattenObject(ob[i]);
        for (const x in flatObject) {
          if (!flatObject.hasOwnProperty(x)) continue;
          toReturn[i + '.' + x] = flatObject[x];
        }
      } else {
        toReturn[i] = ob[i];
      }
    }
    return toReturn;
  };

  const handleProcess = () => {
    setError(null);
    setSuccess(null);
    setOutput('');

    if (!input.trim()) {
      setError('الرجاء إدخال كود XML أولاً');
      return;
    }

    try {
      if (activeTab === 'escape') {
        setOutput(escapeXml(input));
        setSuccess('تم ترميز XML بنجاح');
        confetti({ particleCount: 30, spread: 50 });
        return;
      }
      if (activeTab === 'unescape') {
        setOutput(unescapeXml(input));
        setSuccess('تم فك ترميز XML بنجاح');
        confetti({ particleCount: 30, spread: 50 });
        return;
      }

      // Try parsing for validation and formatting
      let parsedObj: any = null;
      try {
        parsedObj = xml2js(input, { compact: true } as any);
      } catch (e: any) {
         throw new Error('خطأ في بناء XML: ' + e.message);
      }

      switch (activeTab) {
        case 'format':
          setOutput(beautify.html(input, { indent_size: 2, preserve_newlines: false }));
          setSuccess('تم التنسيق بنجاح');
          break;
        case 'validate':
          setOutput(beautify.html(input, { indent_size: 2, preserve_newlines: false }));
          setSuccess('كود XML صالح وخالٍ من الأخطاء ✅');
          break;
        case 'minify':
          setOutput(input.replace(/>\s+</g, '><').trim());
          setSuccess('تم تصغير الكود بنجاح');
          break;
        case 'to-json':
          setOutput(JSON.stringify(parsedObj, null, 2));
          setSuccess('تم التحويل إلى JSON بنجاح');
          break;
        case 'to-csv':
          let dataToCsv = parsedObj;
          
          // Attempt to find a suitable array to convert to CSV
          if (typeof dataToCsv === 'object') {
             const keys = Object.keys(dataToCsv);
             if (keys.length === 1) {
                 const root = dataToCsv[keys[0]];
                 const rootKeys = Object.keys(root);
                 if (rootKeys.length === 1 && Array.isArray(root[rootKeys[0]])) {
                     dataToCsv = root[rootKeys[0]];
                 } else if (Array.isArray(root)) {
                     dataToCsv = root;
                 }
             }
          }
          
          if (!Array.isArray(dataToCsv)) {
             // Try to flatten
             dataToCsv = [flattenObject(dataToCsv)];
          } else {
             dataToCsv = dataToCsv.map((item: any) => flattenObject(item));
          }
          
          const csv = Papa.unparse(dataToCsv);
          setOutput(csv);
          setSuccess('تم التحويل إلى CSV بنجاح');
          break;
        case 'to-yaml':
          const yaml = yamlStringify(parsedObj);
          setOutput(yaml);
          setSuccess('تم التحويل إلى YAML بنجاح');
          break;
      }
      confetti({ particleCount: 30, spread: 50 });
    } catch (err: any) {
      setError(err.message);
    }
  };

  const handleCopy = () => {
    if (!output && activeTab !== 'validate') return;
    navigator.clipboard.writeText(output);
    setSuccess('تم النسخ إلى الحافظة');
    setTimeout(() => setSuccess(null), 2000);
  };

  const handleDownload = () => {
    if (!output) return;
    const exts: Record<string, string> = {
      'format': 'xml', 'validate': 'xml', 'minify': 'xml',
      'to-json': 'json', 'to-csv': 'csv', 'to-yaml': 'yaml'
    };
    const ext = exts[activeTab] || 'txt';
    const blob = new Blob([output], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `result.${ext}`;
    a.click();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  };

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => { setActiveTab(tab.id); setOutput(''); setError(null); setSuccess(null); }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-lg'
                : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-50'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span className="text-sm font-medium">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white">الإدخال (XML)</h3>
            <button onClick={() => setInput('')} className="text-sm text-red-500 hover:text-red-600">مسح</button>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full h-96 p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-left dir-ltr"
            placeholder="الصق كود XML هنا..."
          />
          <button
            onClick={handleProcess}
            className="w-full mt-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-5 h-5" />
            <span>تنفيذ العملية</span>
          </button>
        </div>

        {/* Output */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white">النتيجة</h3>
            <div className="flex gap-2">
              <button onClick={handleCopy} className="p-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <Copy className="w-4 h-4" />
              </button>
              <button onClick={handleDownload} className="p-2 text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg">
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          {error && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg flex items-center gap-2 text-sm">
              <XCircle className="w-5 h-5" />
              {error}
            </div>
          )}
          
          {success && (
            <div className="mb-4 p-3 bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-lg flex items-center gap-2 text-sm">
              <CheckCircle2 className="w-5 h-5" />
              {success}
            </div>
          )}

          <textarea
            value={output}
            readOnly
            className="w-full h-96 p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-left dir-ltr"
            placeholder="ستظهر النتيجة هنا..."
          />
        </div>
      </div>
    </div>
  );
}
