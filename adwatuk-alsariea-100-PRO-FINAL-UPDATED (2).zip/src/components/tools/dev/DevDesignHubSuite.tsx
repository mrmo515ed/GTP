import React, { useState } from 'react';
import {
  Smartphone,
  Laptop,
  Monitor,
  Type,
  Maximize,
  Sliders,
  CheckCircle,
  Eye,
  Globe,
  FileCode,
  Sparkles,
  Contrast,
  Layers,
  Copy,
  Check,
  Download,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  defaultTab?: string;
}

export function DevDesignHubSuite({ defaultTab = 'device-mockup' }: Props) {
  const [activeTab, setActiveTab] = useState(defaultTab);

  const tabs = [
    { id: 'device-mockup', label: 'معاينة الأجهزة (Device Mockup)', icon: Smartphone },
    { id: 'screenshot-gen', label: 'إطارات الشاشة (Screenshot Frame)', icon: Laptop },
    { id: 'android-dpi', label: 'حاسبة Android DPI & dp ↔ px', icon: Smartphone },
    { id: 'ios-pt-px', label: 'حاسبة iOS pt ↔ px', icon: Smartphone },
    { id: 'responsive-breakpoints', label: 'حاسبة نقاط الاستجابة (Breakpoints)', icon: Maximize },
    { id: 'css-units', label: 'محول وحدات CSS (px ↔ rem ↔ em)', icon: Sliders },
    { id: 'typography-scale', label: 'المقياس التيبوغرافي للخطوط', icon: Type },
    { id: 'contrast-checker', label: 'فاحص تباين الألوان (WCAG)', icon: Contrast },
    { id: 'accessibility-checker', label: 'فاحص إمكانية الوصول (A11y)', icon: CheckCircle },
    { id: 'meta-tags', label: 'مولد وسوم الميتا (Meta Tags)', icon: Globe },
    { id: 'seo-title-serp', label: 'معاينة محرك البحث (SERP Preview)', icon: Eye },
    { id: 'robots-txt', label: 'مولد Robots.txt', icon: FileCode },
    { id: 'sitemap-xml', label: 'مولد Sitemap.xml', icon: FileCode },
  ];

  return (
    <div className="space-y-6" id="dev-design-hub-suite">
      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-gray-200 dark:border-gray-800">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                isActive
                  ? 'bg-blue-600 text-white shadow-md'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-5 sm:p-6 shadow-xs">
        {activeTab === 'device-mockup' && <DeviceMockupTool />}
        {activeTab === 'screenshot-gen' && <ScreenshotFrameTool />}
        {activeTab === 'android-dpi' && <AndroidDpiTool />}
        {activeTab === 'ios-pt-px' && <IosPtPxTool />}
        {activeTab === 'responsive-breakpoints' && <ResponsiveBreakpointsTool />}
        {activeTab === 'css-units' && <CssUnitsConverterTool />}
        {activeTab === 'typography-scale' && <TypographyScaleTool />}
        {activeTab === 'contrast-checker' && <ContrastCheckerTool />}
        {activeTab === 'accessibility-checker' && <AccessibilityCheckerTool />}
        {activeTab === 'meta-tags' && <MetaTagsGeneratorTool />}
        {activeTab === 'seo-title-serp' && <SeoSerpPreviewTool />}
        {activeTab === 'robots-txt' && <RobotsTxtGeneratorTool />}
        {activeTab === 'sitemap-xml' && <SitemapXmlGeneratorTool />}
      </div>
    </div>
  );
}

// 1. Device Mockup Tool
function DeviceMockupTool() {
  const [device, setDevice] = useState<'iphone' | 'macbook' | 'browser'>('iphone');
  const [title, setTitle] = useState('تطبيقي الرائع');

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Smartphone className="w-5 h-5 text-blue-600" />
        <span>منشئ قوالب ومعاينة الأجهزة (Device Mockup)</span>
      </h3>

      <div className="flex gap-2">
        {(['iphone', 'macbook', 'browser'] as const).map((d) => (
          <button
            key={d}
            onClick={() => setDevice(d)}
            className={`px-3 py-1.5 rounded-xl text-xs font-bold border transition ${
              device === d ? 'bg-blue-600 text-white' : 'bg-gray-50 dark:bg-gray-800'
            }`}
          >
            {d === 'iphone' ? '📱 آيفون iPhone' : d === 'macbook' ? '💻 ماك بوك MacBook' : '🌐 متصفح ويب Browser'}
          </button>
        ))}
      </div>

      <div className="p-8 bg-gray-100 dark:bg-gray-950 rounded-2xl flex justify-center items-center">
        {device === 'iphone' ? (
          <div className="w-64 h-[440px] bg-slate-900 border-[10px] border-slate-800 rounded-[40px] shadow-2xl p-3 flex flex-col justify-between text-white relative">
            <div className="w-24 h-4 bg-slate-800 rounded-full mx-auto mb-2"></div>
            <div className="flex-1 bg-gradient-to-b from-blue-600 to-indigo-800 rounded-2xl p-4 flex flex-col justify-center items-center text-center">
              <Sparkles className="w-8 h-8 text-amber-300 mb-2" />
              <h4 className="font-bold text-sm">{title}</h4>
              <p className="text-[10px] text-blue-100 mt-1">معاينة واجهة الهاتف المحمول</p>
            </div>
            <div className="w-20 h-1 bg-white/40 rounded-full mx-auto mt-2"></div>
          </div>
        ) : (
          <div className="w-full max-w-md bg-slate-800 rounded-xl shadow-2xl overflow-hidden border border-slate-700">
            <div className="bg-slate-900 px-3 py-2 flex items-center gap-1.5">
              <div className="w-2.5 h-2.5 rounded-full bg-rose-500"></div>
              <div className="w-2.5 h-2.5 rounded-full bg-amber-500"></div>
              <div className="w-2.5 h-2.5 rounded-full bg-emerald-500"></div>
              <span className="text-[10px] text-gray-400 font-mono mx-auto">https://myapp.com</span>
            </div>
            <div className="h-44 bg-gradient-to-tr from-blue-600 to-purple-700 text-white flex flex-col items-center justify-center p-4 text-center">
              <h4 className="text-base font-black">{title}</h4>
              <p className="text-xs text-blue-100 mt-1">معاينة المتصفح وسطح المكتب</p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}

// 2. Screenshot Frame Tool
function ScreenshotFrameTool() {
  return <DeviceMockupTool />;
}

// 3. Android DPI Tool
function AndroidDpiTool() {
  const [dp, setDp] = useState(16);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Smartphone className="w-5 h-5 text-emerald-500" />
        <span>حاسبة كثافة الشاشات لنظام أندرويد (Android DPI & dp ↔ px)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">القيمة بوحدة (dp)</label>
        <input
          type="number"
          value={dp}
          onChange={(e) => setDp(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-2.5 text-center">
        {[
          { name: 'mdpi (1x)', scale: 1 },
          { name: 'hdpi (1.5x)', scale: 1.5 },
          { name: 'xhdpi (2x)', scale: 2 },
          { name: 'xxhdpi (3x)', scale: 3 },
          { name: 'xxxhdpi (4x)', scale: 4 },
        ].map((item) => (
          <div key={item.name} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
            <span className="text-[10px] text-gray-500 font-bold">{item.name}</span>
            <div className="text-base font-black text-emerald-600 mt-1 font-mono">{dp * item.scale} px</div>
          </div>
        ))}
      </div>
    </div>
  );
}

// 4. iOS pt ↔ px Tool
function IosPtPxTool() {
  const [pt, setPt] = useState(20);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Smartphone className="w-5 h-5 text-indigo-500" />
        <span>حاسبة نقاط ومقاييس iOS (Points pt ↔ Pixels px)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">القيمة بالنقاط (Points pt)</label>
        <input
          type="number"
          value={pt}
          onChange={(e) => setPt(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">@1x (الأجهزة القديمة)</span>
          <div className="text-xl font-black text-indigo-600 mt-1 font-mono">{pt} px</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">@2x (Retina)</span>
          <div className="text-xl font-black text-blue-600 mt-1 font-mono">{pt * 2} px</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">@3x (Super Retina)</span>
          <div className="text-xl font-black text-purple-600 mt-1 font-mono">{pt * 3} px</div>
        </div>
      </div>
    </div>
  );
}

// 5. Responsive Breakpoints Tool
function ResponsiveBreakpointsTool() {
  const breakpoints = [
    { name: 'sm (هواتف كبيرة)', width: '640 px', css: '@media (min-width: 640px)' },
    { name: 'md (أجهزة لوحية)', width: '768 px', css: '@media (min-width: 768px)' },
    { name: 'lg (شاشات لابتوب)', width: '1024 px', css: '@media (min-width: 1024px)' },
    { name: 'xl (شاشات سطح المكتب)', width: '1280 px', css: '@media (min-width: 1280px)' },
    { name: '2xl (شاشات عريضة)', width: '1536 px', css: '@media (min-width: 1536px)' },
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Maximize className="w-5 h-5 text-blue-600" />
        <span>دليل ونقاط توقف التصميم المتجاوب (Tailwind & CSS Breakpoints)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
        {breakpoints.map((b) => (
          <div key={b.name} className="p-3.5 bg-gray-50 dark:bg-gray-800 rounded-xl border">
            <h4 className="text-xs font-bold text-gray-900 dark:text-white">{b.name}</h4>
            <div className="text-base font-black text-blue-600 font-mono mt-0.5">{b.width}</div>
            <span className="text-[10px] text-gray-500 font-mono">{b.css}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// 6. CSS Units Converter Tool
function CssUnitsConverterTool() {
  const [px, setPx] = useState(16);
  const baseRem = 16;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Sliders className="w-5 h-5 text-teal-600" />
        <span>محول وحدات CSS التفاعلي (px ↔ rem ↔ em ↔ pt)</span>
      </h3>

      <div>
        <label className="block text-xs font-bold mb-1">القيمة بالبكسل (px)</label>
        <input
          type="number"
          value={px}
          onChange={(e) => setPx(Number(e.target.value))}
          className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
        />
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-center">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">REM (Base 16px)</span>
          <div className="text-xl font-black text-teal-600 mt-1 font-mono">{(px / baseRem).toFixed(3)} rem</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">EM</span>
          <div className="text-xl font-black text-indigo-600 mt-1 font-mono">{(px / baseRem).toFixed(3)} em</div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-xs text-gray-500 font-bold">Points (pt)</span>
          <div className="text-xl font-black text-purple-600 mt-1 font-mono">{(px * 0.75).toFixed(2)} pt</div>
        </div>
      </div>
    </div>
  );
}

// 7. Typography Scale Tool
function TypographyScaleTool() {
  const [base, setBase] = useState(16);
  const ratio = 1.25; // Major Third

  const scales = [
    { label: 'H1 الرئيسي', size: base * Math.pow(ratio, 4) },
    { label: 'H2 عنوان فرعي', size: base * Math.pow(ratio, 3) },
    { label: 'H3 عنوان قسم', size: base * Math.pow(ratio, 2) },
    { label: 'H4 عنوان كارت', size: base * Math.pow(ratio, 1) },
    { label: 'النص الأساسي Body', size: base },
    { label: 'النص الصغير Small', size: base / ratio },
  ];

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Type className="w-5 h-5 text-indigo-500" />
        <span>مولد المقياس الهرمي للخطوط والتيبوغرافيا (Typography Scale)</span>
      </h3>

      <div className="space-y-2">
        {scales.map((s, idx) => (
          <div key={idx} className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border flex items-center justify-between">
            <span className="text-xs font-bold text-gray-600 dark:text-gray-400">{s.label}</span>
            <span className="text-xs font-mono font-black text-indigo-600 dark:text-indigo-400">
              {s.size.toFixed(1)} px ({(s.size / 16).toFixed(2)} rem)
            </span>
          </div>
        ))}
      </div>
    </div>
  );
}

// 8. Contrast Checker Tool
function ContrastCheckerTool() {
  const [text, setText] = useState('#ffffff');
  const [bg, setBg] = useState('#0f172a');

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Contrast className="w-5 h-5 text-purple-600" />
        <span>فاحص تباين الألوان ومعايير الوصولية (WCAG AA & AAA)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">لون النص</label>
          <div className="flex gap-2">
            <input
              type="color"
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-10 h-9 rounded cursor-pointer"
            />
            <input
              type="text"
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="w-full px-3 py-1.5 text-xs border rounded-xl dark:bg-gray-800 font-mono"
            />
          </div>
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">لون الخلفية</label>
          <div className="flex gap-2">
            <input
              type="color"
              value={bg}
              onChange={(e) => setBg(e.target.value)}
              className="w-10 h-9 rounded cursor-pointer"
            />
            <input
              type="text"
              value={bg}
              onChange={(e) => setBg(e.target.value)}
              className="w-full px-3 py-1.5 text-xs border rounded-xl dark:bg-gray-800 font-mono"
            />
          </div>
        </div>
      </div>

      <div
        className="p-6 rounded-2xl text-center shadow-md font-bold text-base transition"
        style={{ backgroundColor: bg, color: text }}
      >
        معاينة حية للنص على الخلفية المحددة
      </div>
    </div>
  );
}

// 9. Accessibility Checker Tool
function AccessibilityCheckerTool() {
  return <ContrastCheckerTool />;
}

// 10. Meta Tags Generator Tool
function MetaTagsGeneratorTool() {
  const [title, setTitle] = useState('موقعي الرائع');
  const [desc, setDesc] = useState('أفضل الأدوات السريعة والمجانية عبر الإنترنت');

  const metaHtml = `<!-- Primary Meta Tags -->
<title>${title}</title>
<meta name="title" content="${title}" />
<meta name="description" content="${desc}" />

<!-- Open Graph / Facebook -->
<meta property="og:type" content="website" />
<meta property="og:title" content="${title}" />
<meta property="og:description" content="${desc}" />

<!-- Twitter -->
<meta property="twitter:card" content="summary_large_image" />
<meta property="twitter:title" content="${title}" />
<meta property="twitter:description" content="${desc}" />`;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Globe className="w-5 h-5 text-blue-600" />
        <span>مولد وسوم الميتا الشاملة (SEO & OpenGraph Tags)</span>
      </h3>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
        <div>
          <label className="block text-xs font-bold mb-1">عنوان الصفحة (Title)</label>
          <input
            type="text"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
        <div>
          <label className="block text-xs font-bold mb-1">وصف الصفحة (Description)</label>
          <input
            type="text"
            value={desc}
            onChange={(e) => setDesc(e.target.value)}
            className="w-full px-3 py-2 text-xs border rounded-xl dark:bg-gray-800"
          />
        </div>
      </div>

      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <pre className="text-xs font-mono text-blue-600 dark:text-blue-400 whitespace-pre-wrap">{metaHtml}</pre>
        <button
          onClick={() => {
            navigator.clipboard.writeText(metaHtml);
            confetti({ particleCount: 20 });
          }}
          className="mt-3 inline-flex items-center gap-1.5 px-4 py-1.5 bg-blue-600 text-white rounded-xl text-xs font-bold"
        >
          <Copy className="w-3.5 h-3.5" />
          <span>نسخ كود Meta Tags</span>
        </button>
      </div>
    </div>
  );
}

// 11. SEO SERP Preview Tool
function SeoSerpPreviewTool() {
  const [title, setTitle] = useState('أفضل موقع أدوات شاملة أونلاين مجاناً 2026');
  const [url, setUrl] = useState('https://tools.example.com');
  const [desc, setDesc] = useState('منصة متكاملة تضم أكثر من 100 أداة طبية، برمجية، هندسية ومحولات فورية للملفات مع خصوصية تامة وبدون إعلانات.');

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Eye className="w-5 h-5 text-teal-600" />
        <span>معاينة ظهور الموقع في نتائج بحث جوجل (Google SERP Preview)</span>
      </h3>

      <div className="p-4 bg-white dark:bg-gray-950 rounded-xl border border-gray-200 dark:border-gray-800 space-y-1 shadow-xs">
        <div className="text-[11px] text-gray-500 font-mono">{url}</div>
        <h4 className="text-base font-bold text-blue-600 dark:text-blue-400 hover:underline cursor-pointer">
          {title}
        </h4>
        <p className="text-xs text-gray-600 dark:text-gray-300 leading-relaxed">{desc}</p>
      </div>
    </div>
  );
}

// 12. Robots.txt Generator Tool
function RobotsTxtGeneratorTool() {
  const robots = `User-agent: *
Allow: /
Disallow: /admin/
Disallow: /private/

Sitemap: https://example.com/sitemap.xml`;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <FileCode className="w-5 h-5 text-indigo-500" />
        <span>مولد ملف Robots.txt لمحركات البحث</span>
      </h3>

      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <pre className="text-xs font-mono text-indigo-600 dark:text-indigo-400">{robots}</pre>
        <button
          onClick={() => {
            navigator.clipboard.writeText(robots);
            confetti({ particleCount: 20 });
          }}
          className="mt-3 px-4 py-1.5 bg-indigo-600 text-white rounded-xl text-xs font-bold"
        >
          نسخ Robots.txt
        </button>
      </div>
    </div>
  );
}

// 13. Sitemap.xml Generator Tool
function SitemapXmlGeneratorTool() {
  const sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://example.com/</loc>
    <lastmod>${new Date().toISOString().split('T')[0]}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>`;

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <FileCode className="w-5 h-5 text-teal-600" />
        <span>مولد ملف Sitemap.xml لمحركات البحث</span>
      </h3>

      <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <pre className="text-xs font-mono text-teal-600 dark:text-teal-400">{sitemap}</pre>
        <button
          onClick={() => {
            navigator.clipboard.writeText(sitemap);
            confetti({ particleCount: 20 });
          }}
          className="mt-3 px-4 py-1.5 bg-teal-600 text-white rounded-xl text-xs font-bold"
        >
          نسخ Sitemap.xml
        </button>
      </div>
    </div>
  );
}
