import React, { useState } from 'react';
import { Copy, Trash2, Check, Sparkles, Minimize, CheckCircle, AlertCircle } from 'lucide-react';
import confetti from 'canvas-confetti';

export function JsonFormatter() {
  const [jsonInput, setJsonInput] = useState(`{
  "platform": "adwatuk-alsariea",
  "nameAr": "أدواتك السريعة",
  "version": 2.0,
  "privacy": "100% in-browser",
  "features": ["Image Compression", "Word Counter", "Unit Converters", "QR Generator"],
  "stats": {
    "totalTools": 25,
    "speedMs": 0,
    "isFree": true
  }
}`);

  const [jsonOutput, setJsonOutput] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const formatJson = (indent = 2) => {
    try {
      const parsed = JSON.parse(jsonInput);
      setJsonOutput(JSON.stringify(parsed, null, indent));
      setErrorMsg(null);
    } catch (err: any) {
      setErrorMsg(err.message || 'كود JSON غير صالح');
    }
  };

  const minifyJson = () => {
    try {
      const parsed = JSON.parse(jsonInput);
      setJsonOutput(JSON.stringify(parsed));
      setErrorMsg(null);
    } catch (err: any) {
      setErrorMsg(err.message || 'كود JSON غير صالح');
    }
  };

  const handleCopy = () => {
    const textToCopy = jsonOutput || jsonInput;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    confetti({ particleCount: 30, spread: 45, origin: { y: 0.8 } });
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6" id="json-formatter-tool">
      {/* Top Action Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200/60 dark:border-gray-700/60">
        <div className="flex flex-wrap gap-2">
          <button
            onClick={() => formatJson(2)}
            className="px-3 py-1.5 text-xs font-bold bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg transition flex items-center gap-1"
          >
            <Sparkles className="w-3.5 h-3.5" />
            تنسيق وترتيب (Format)
          </button>
          <button
            onClick={minifyJson}
            className="px-3 py-1.5 text-xs font-bold bg-white dark:bg-gray-700 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-600 hover:border-emerald-500 rounded-lg transition flex items-center gap-1"
          >
            <Minimize className="w-3.5 h-3.5" />
            ضغط الكود (Minify)
          </button>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopy}
            className="px-3 py-1.5 text-xs font-semibold text-emerald-700 dark:text-emerald-400 bg-emerald-50 dark:bg-emerald-950/40 rounded-lg hover:bg-emerald-100 transition flex items-center gap-1"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? 'تم النسخ' : 'نسخ الكود'}
          </button>
          <button
            onClick={() => {
              setJsonInput('');
              setJsonOutput('');
              setErrorMsg(null);
            }}
            className="text-xs text-rose-500 hover:underline flex items-center gap-1"
          >
            <Trash2 className="w-3 h-3" />
            مسح
          </button>
        </div>
      </div>

      {/* Validation status badge */}
      {errorMsg ? (
        <div className="p-3 bg-rose-50 dark:bg-rose-950/40 border border-rose-200 dark:border-rose-900 rounded-xl text-xs text-rose-700 dark:text-rose-300 flex items-center gap-2">
          <AlertCircle className="w-4 h-4 shrink-0" />
          <span>خطأ في بنية JSON: {errorMsg}</span>
        </div>
      ) : (
        <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/30 border border-emerald-200/60 dark:border-emerald-900/40 rounded-xl text-xs text-emerald-700 dark:text-emerald-300 flex items-center gap-2">
          <CheckCircle className="w-4 h-4 shrink-0" />
          <span>هيكل JSON صالح وسليم (Valid JSON)</span>
        </div>
      )}

      {/* Textarea Input / Output */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        <div className="space-y-2">
          <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
            أدخل كود JSON:
          </label>
          <textarea
            value={jsonInput}
            onChange={(e) => {
              setJsonInput(e.target.value);
              try {
                JSON.parse(e.target.value);
                setErrorMsg(null);
              } catch (err: any) {
                if (e.target.value.trim()) setErrorMsg(err.message);
              }
            }}
            rows={12}
            dir="ltr"
            className="w-full p-3.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 font-mono text-xs text-gray-900 dark:text-gray-100 focus:ring-2 focus:ring-emerald-500 outline-none leading-relaxed"
          />
        </div>

        <div className="space-y-2">
          <label className="block text-xs font-bold text-emerald-600 dark:text-emerald-400">
            النتيجة بعد التنسيق أو الضغط:
          </label>
          <textarea
            value={jsonOutput || jsonInput}
            readOnly
            rows={12}
            dir="ltr"
            className="w-full p-3.5 rounded-xl border border-emerald-200 dark:border-emerald-800 bg-emerald-50/20 dark:bg-gray-900 font-mono text-xs text-gray-900 dark:text-gray-100 outline-none leading-relaxed"
          />
        </div>
      </div>
    </div>
  );
}
