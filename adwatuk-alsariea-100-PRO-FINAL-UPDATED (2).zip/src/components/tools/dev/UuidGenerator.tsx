import React, { useState, useEffect } from 'react';
import { Fingerprint, Copy, RefreshCw, CheckCircle2 } from 'lucide-react';

export function UuidGenerator() {
  const [uuids, setUuids] = useState<string[]>([]);
  const [count, setCount] = useState<number>(5);
  const [copiedIndex, setCopiedIndex] = useState<number | null>(null);

  const generateUUID = () => {
    // Generate UUID v4
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
      const r = Math.random() * 16 | 0;
      const v = c === 'x' ? r : (r & 0x3 | 0x8);
      return v.toString(16);
    });
  };

  const generateBatch = () => {
    const newUuids = Array.from({ length: Math.min(count, 100) }, () => generateUUID());
    setUuids(newUuids);
    setCopiedIndex(null);
  };

  // Generate initial batch
  useEffect(() => {
    generateBatch();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleCopy = (text: string, index: number) => {
    navigator.clipboard.writeText(text);
    setCopiedIndex(index);
    setTimeout(() => {
      if (copiedIndex === index) setCopiedIndex(null);
    }, 2000);
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row gap-4 items-end">
        <div className="space-y-2 flex-1 w-full">
          <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">عدد المعرفات المطلوبة (بحد أقصى 100)</label>
          <input
            type="number"
            min="1"
            max="100"
            value={count}
            onChange={(e) => setCount(parseInt(e.target.value) || 1)}
            className="w-full px-4 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none"
          />
        </div>
        <button
          onClick={generateBatch}
          className="w-full sm:w-auto px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold flex items-center justify-center gap-2 transition shadow-xs"
        >
          <RefreshCw className="w-5 h-5" />
          <span>توليد من جديد</span>
        </button>
      </div>

      <div className="bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-2xl overflow-hidden">
        <ul className="divide-y divide-gray-200 dark:divide-gray-800">
          {uuids.map((uuid, i) => (
            <li key={i} className="p-4 flex items-center justify-between gap-4 hover:bg-white dark:hover:bg-gray-800 transition">
              <span className="font-mono text-sm sm:text-base text-gray-800 dark:text-gray-200 select-all" dir="ltr">
                {uuid}
              </span>
              <button
                onClick={() => handleCopy(uuid, i)}
                className="p-2 text-gray-400 hover:text-indigo-600 dark:hover:text-indigo-400 transition"
                title="نسخ"
              >
                {copiedIndex === i ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
              </button>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
