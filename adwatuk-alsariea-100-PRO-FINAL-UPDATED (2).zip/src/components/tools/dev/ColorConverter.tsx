import React, { useState, useEffect } from 'react';
import { Palette, Copy, CheckCircle2 } from 'lucide-react';

export function ColorConverter() {
  const [hex, setHex] = useState('#3b82f6');
  const [rgb, setRgb] = useState('rgb(59, 130, 246)');
  const [hsl, setHsl] = useState('hsl(217, 91%, 60%)');
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Helper to convert HEX to RGB
  const hexToRgb = (hex: string) => {
    let r = 0, g = 0, b = 0;
    if (hex.length === 4) {
      r = parseInt(hex[1] + hex[1], 16);
      g = parseInt(hex[2] + hex[2], 16);
      b = parseInt(hex[3] + hex[3], 16);
    } else if (hex.length === 7) {
      r = parseInt(hex.substring(1, 3), 16);
      g = parseInt(hex.substring(3, 5), 16);
      b = parseInt(hex.substring(5, 7), 16);
    }
    return { r, g, b };
  };

  // Helper to convert RGB to HSL
  const rgbToHsl = (r: number, g: number, b: number) => {
    r /= 255; g /= 255; b /= 255;
    const max = Math.max(r, g, b), min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return {
      h: Math.round(h * 360),
      s: Math.round(s * 100),
      l: Math.round(l * 100)
    };
  };

  // Handlers
  const handleHexChange = (val: string) => {
    setHex(val);
    setError(null);
    if (/^#([0-9A-Fa-f]{3}){1,2}$/.test(val)) {
      const { r, g, b } = hexToRgb(val);
      setRgb(`rgb(${r}, ${g}, ${b})`);
      const { h, s, l } = rgbToHsl(r, g, b);
      setHsl(`hsl(${h}, ${s}%, ${l}%)`);
    } else {
      setError('HEX غير صحيح');
    }
  };

  const handleCopy = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-2xl flex items-start gap-3 border border-indigo-100 dark:border-indigo-800/30">
        <Palette className="w-5 h-5 text-indigo-600 dark:text-indigo-400 mt-0.5 shrink-0" />
        <p className="text-sm text-indigo-800 dark:text-indigo-200 leading-relaxed">
          محول صيغ الألوان: يتيح لك تحويل قيم الألوان بين أشهر الصيغ المستخدمة في التصميم والبرمجة (HEX, RGB, HSL) مع إمكانية المعاينة المباشرة.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-start">
        {/* Color Preview Block */}
        <div className="space-y-4">
          <div 
            className="w-full h-48 rounded-2xl shadow-inner border border-gray-200 dark:border-gray-700 transition-colors"
            style={{ backgroundColor: error ? 'transparent' : hex }}
          ></div>
          <div className="flex justify-center">
            <input
              type="color"
              value={error ? '#ffffff' : hex}
              onChange={(e) => handleHexChange(e.target.value)}
              className="w-16 h-16 cursor-pointer rounded-full border-0 outline-none p-0 overflow-hidden"
              title="اختر لوناً باستخدام منتقي الألوان"
            />
          </div>
        </div>

        {/* Inputs */}
        <div className="space-y-4">
          
          <div className="space-y-2">
            <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">HEX</label>
            <div className="relative">
              <input
                type="text"
                value={hex}
                onChange={(e) => handleHexChange(e.target.value)}
                className={`w-full px-4 py-3 bg-white dark:bg-gray-800 border ${error ? 'border-rose-500' : 'border-gray-200 dark:border-gray-700'} rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none font-mono text-left font-bold`}
                dir="ltr"
              />
              <button
                onClick={() => handleCopy(hex, 'hex')}
                className="absolute top-2 right-2 p-1.5 text-gray-400 hover:text-indigo-500 bg-gray-50 dark:bg-gray-900 rounded-lg"
              >
                {copiedField === 'hex' ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
            {error && <span className="text-xs text-rose-500 font-bold">{error}</span>}
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">RGB</label>
            <div className="relative">
              <input
                type="text"
                value={rgb}
                readOnly
                className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl outline-none font-mono text-left font-bold text-gray-600 dark:text-gray-400"
                dir="ltr"
              />
              <button
                onClick={() => handleCopy(rgb, 'rgb')}
                className="absolute top-2 right-2 p-1.5 text-gray-400 hover:text-indigo-500 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg"
              >
                {copiedField === 'rgb' ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

          <div className="space-y-2">
            <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">HSL</label>
            <div className="relative">
              <input
                type="text"
                value={hsl}
                readOnly
                className="w-full px-4 py-3 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl outline-none font-mono text-left font-bold text-gray-600 dark:text-gray-400"
                dir="ltr"
              />
              <button
                onClick={() => handleCopy(hsl, 'hsl')}
                className="absolute top-2 right-2 p-1.5 text-gray-400 hover:text-indigo-500 bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-lg"
              >
                {copiedField === 'hsl' ? <CheckCircle2 className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              </button>
            </div>
          </div>

        </div>
      </div>
    </div>
  );
}
