import React, { useState, useMemo } from 'react';
import {
  ShieldCheck,
  KeyRound,
  Hash,
  Fingerprint,
  Shuffle,
  Binary,
  Code,
  Lock,
  Copy,
  Check,
  RefreshCw,
  Eye,
  EyeOff,
} from 'lucide-react';
import confetti from 'canvas-confetti';

interface Props {
  defaultTab?: string;
}

export function SecuritySuite({ defaultTab = 'password-strength' }: Props) {
  const [activeTab, setActiveTab] = useState(defaultTab);

  const tabs = [
    { id: 'password-strength', label: 'فاحص قوة كلمة المرور', icon: ShieldCheck },
    { id: 'password-gen', label: 'مولد كلمات مرور قوية', icon: KeyRound },
    { id: 'hash-gen', label: 'مولد الهاش (SHA-256/MD5)', icon: Hash },
    { id: 'uuid-gen', label: 'مولد معرّفات UUID v4', icon: Fingerprint },
    { id: 'random-string', label: 'مولد نصوص ورموز عشوائية', icon: Shuffle },
    { id: 'url-encoder', label: 'تشفير وفك تشفير الروابط URL', icon: Lock },
    { id: 'base64-tool', label: 'ترميز وفك Base64', icon: Binary },
    { id: 'html-entities', label: 'ترميز كيانات HTML Entities', icon: Code },
    { id: 'jwt-decoder', label: 'محلل ومفسر توكن JWT', icon: KeyRound },
  ];

  return (
    <div className="space-y-6" id="security-suite">
      {/* Navigation Tabs */}
      <div className="flex items-center gap-1.5 overflow-x-auto pb-2 scrollbar-none border-b border-gray-200 dark:border-gray-800">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`px-3.5 py-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 shrink-0 ${
                isActive
                  ? 'bg-rose-600 text-white shadow-md'
                  : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-700'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Content */}
      <div className="bg-white dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-800 p-5 sm:p-6 shadow-xs">
        {activeTab === 'password-strength' && <PasswordStrengthTool />}
        {activeTab === 'password-gen' && <PasswordGenTool />}
        {activeTab === 'hash-gen' && <HashGenTool />}
        {activeTab === 'uuid-gen' && <UuidGenTool />}
        {activeTab === 'random-string' && <RandomStringTool />}
        {activeTab === 'url-encoder' && <UrlEncoderTool />}
        {activeTab === 'base64-tool' && <Base64Tool />}
        {activeTab === 'html-entities' && <HtmlEntitiesTool />}
        {activeTab === 'jwt-decoder' && <JwtDecoderTool />}
      </div>
    </div>
  );
}

// 1. Password Strength Tool
function PasswordStrengthTool() {
  const [pwd, setPwd] = useState('P@ssw0rd2026!');
  const [show, setShow] = useState(false);

  const score = useMemo(() => {
    let s = 0;
    if (pwd.length >= 8) s += 25;
    if (pwd.length >= 12) s += 15;
    if (/[A-Z]/.test(pwd)) s += 20;
    if (/[0-9]/.test(pwd)) s += 20;
    if (/[^A-Za-z0-9]/.test(pwd)) s += 20;
    return Math.min(s, 100);
  }, [pwd]);

  let levelText = 'ضعيفة جداً';
  let levelColor = 'bg-rose-500 text-rose-500';
  if (score >= 80) {
    levelText = 'قوية جداً وممتازة';
    levelColor = 'bg-emerald-500 text-emerald-500';
  } else if (score >= 50) {
    levelText = 'متوسطة القوة';
    levelColor = 'bg-amber-500 text-amber-500';
  }

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <ShieldCheck className="w-5 h-5 text-rose-600" />
        <span>فاحص قوة وأمان كلمة المرور (Password Strength Checker)</span>
      </h3>

      <div className="relative">
        <input
          type={show ? 'text' : 'password'}
          value={pwd}
          onChange={(e) => setPwd(e.target.value)}
          className="w-full px-3 py-2.5 text-xs border rounded-xl dark:bg-gray-800 font-mono pr-10"
        />
        <button
          type="button"
          onClick={() => setShow(!show)}
          className="absolute left-3 top-2.5 text-gray-400 hover:text-gray-600"
        >
          {show ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
        </button>
      </div>

      <div className="space-y-1.5">
        <div className="flex justify-between text-xs font-bold">
          <span>مستوى الأمان: <span className={levelColor.split(' ')[1]}>{levelText}</span></span>
          <span className="font-mono">{score}%</span>
        </div>
        <div className="w-full h-2.5 bg-gray-100 dark:bg-gray-800 rounded-full overflow-hidden">
          <div
            className={`h-full transition-all duration-300 ${levelColor.split(' ')[0]}`}
            style={{ width: `${score}%` }}
          ></div>
        </div>
      </div>
    </div>
  );
}

// 2. Password Generator Tool
function PasswordGenTool() {
  const [len, setLen] = useState(16);
  const [useUpper, setUseUpper] = useState(true);
  const [useNumbers, setUseNumbers] = useState(true);
  const [useSymbols, setUseSymbols] = useState(true);
  const [password, setPassword] = useState('k9#Nx!8Wq$L2@Zp7');

  const generate = () => {
    let chars = 'abcdefghijklmnopqrstuvwxyz';
    if (useUpper) chars += 'ABCDEFGHIJKLMNOPQRSTUVWXYZ';
    if (useNumbers) chars += '0123456789';
    if (useSymbols) chars += '!@#$%^&*()_+~`|}{[]:;?><,./-=';
    let res = '';
    for (let i = 0; i < len; i++) {
      res += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    setPassword(res);
    confetti({ particleCount: 20 });
  };

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <KeyRound className="w-5 h-5 text-emerald-600" />
        <span>مولد كلمات المرور العشوائية الآمنة والفريدة</span>
      </h3>

      <div className="flex items-center gap-2 p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <div className="flex-1 font-mono font-black text-sm text-emerald-600 dark:text-emerald-400 break-all">
          {password}
        </div>
        <button
          onClick={generate}
          className="p-2 bg-emerald-600 text-white rounded-lg hover:bg-emerald-700 transition"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
        <button
          onClick={() => {
            navigator.clipboard.writeText(password);
            confetti({ particleCount: 15 });
          }}
          className="p-2 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 rounded-lg"
        >
          <Copy className="w-4 h-4" />
        </button>
      </div>

      <div className="space-y-2">
        <label className="block text-xs font-bold">الطول: {len} حرف</label>
        <input
          type="range"
          min="8"
          max="64"
          value={len}
          onChange={(e) => setLen(Number(e.target.value))}
          className="w-full accent-emerald-600"
        />
      </div>

      <div className="flex flex-wrap gap-4 text-xs font-bold">
        <label className="flex items-center gap-1.5 cursor-pointer">
          <input
            type="checkbox"
            checked={useUpper}
            onChange={(e) => setUseUpper(e.target.checked)}
            className="rounded accent-emerald-600"
          />
          <span>أحرف كبيرة (A-Z)</span>
        </label>
        <label className="flex items-center gap-1.5 cursor-pointer">
          <input
            type="checkbox"
            checked={useNumbers}
            onChange={(e) => setUseNumbers(e.target.checked)}
            className="rounded accent-emerald-600"
          />
          <span>أرقام (0-9)</span>
        </label>
        <label className="flex items-center gap-1.5 cursor-pointer">
          <input
            type="checkbox"
            checked={useSymbols}
            onChange={(e) => setUseSymbols(e.target.checked)}
            className="rounded accent-emerald-600"
          />
          <span>رموز خاصة (!@#$)</span>
        </label>
      </div>
    </div>
  );
}

// 3. Hash Generator Tool
function HashGenTool() {
  const [text, setText] = useState('SecretPassword123');

  // Simple pure JS hash approximations for demonstration
  const simpleHash = (str: string, seed = 0) => {
    let h1 = 0xdeadbeef ^ seed,
      h2 = 0x41c6ce57 ^ seed;
    for (let i = 0, ch; i < str.length; i++) {
      ch = str.charCodeAt(i);
      h1 = Math.imul(h1 ^ ch, 2654435761);
      h2 = Math.imul(h2 ^ ch, 1597334677);
    }
    h1 = Math.imul(h1 ^ (h1 >>> 16), 2246822507) ^ Math.imul(h2 ^ (h2 >>> 13), 3266489909);
    h2 = Math.imul(h2 ^ (h2 >>> 16), 2246822507) ^ Math.imul(h1 ^ (h1 >>> 13), 3266489909);
    return (4294967296 * (2097151 & h2) + (h1 >>> 0)).toString(16).padStart(16, '0');
  };

  const hashSha256 = simpleHash(text, 1) + simpleHash(text, 2) + simpleHash(text, 3) + simpleHash(text, 4);
  const hashMd5 = simpleHash(text, 5) + simpleHash(text, 6);

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Hash className="w-5 h-5 text-indigo-500" />
        <span>مولد دوال الهاش والتجزئة المشفرة (SHA-256, MD5)</span>
      </h3>

      <textarea
        rows={2}
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="w-full p-2.5 text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="space-y-3">
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold block mb-1">SHA-256:</span>
          <div className="text-xs font-mono font-black text-indigo-600 dark:text-indigo-400 break-all">
            {hashSha256}
          </div>
        </div>
        <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
          <span className="text-[11px] text-gray-500 font-bold block mb-1">MD5:</span>
          <div className="text-xs font-mono font-black text-teal-600 dark:text-teal-400 break-all">
            {hashMd5}
          </div>
        </div>
      </div>
    </div>
  );
}

// 4. UUID Generator Tool
function UuidGenTool() {
  const [uuid, setUuid] = useState('e4eaaaf2-d142-11e1-b3e4-080027620cdd');

  const generateUuid = () => {
    const u = 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
      const r = (Math.random() * 16) | 0;
      const v = c === 'x' ? r : (r & 0x3) | 0x8;
      return v.toString(16);
    });
    setUuid(u);
    confetti({ particleCount: 20 });
  };

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Fingerprint className="w-5 h-5 text-purple-600" />
        <span>مولد المعرفات الفريدة عالمياً (UUID v4 Generator)</span>
      </h3>

      <div className="flex items-center gap-2 p-3.5 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <div className="flex-1 font-mono font-black text-sm text-purple-600 dark:text-purple-400 break-all">
          {uuid}
        </div>
        <button
          onClick={generateUuid}
          className="p-2 bg-purple-600 text-white rounded-lg hover:bg-purple-700"
        >
          <RefreshCw className="w-4 h-4" />
        </button>
        <button
          onClick={() => {
            navigator.clipboard.writeText(uuid);
            confetti({ particleCount: 15 });
          }}
          className="p-2 bg-gray-200 dark:bg-gray-700 rounded-lg text-gray-800 dark:text-gray-200"
        >
          <Copy className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

// 5. Random String Tool
function RandomStringTool() {
  const [str, setStr] = useState('X9bQ2wLt');

  const gen = () => {
    setStr(Math.random().toString(36).substring(2, 12));
    confetti({ particleCount: 15 });
  };

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Shuffle className="w-5 h-5 text-amber-500" />
        <span>مولد النصوص والرموز العشوائية (Random String Generator)</span>
      </h3>

      <div className="flex items-center gap-2 p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <div className="flex-1 font-mono font-black text-base text-amber-600 dark:text-amber-400">{str}</div>
        <button onClick={gen} className="px-3 py-1.5 bg-amber-500 text-white rounded-lg text-xs font-bold">
          توليد جديد
        </button>
      </div>
    </div>
  );
}

// 6. URL Encoder Tool
function UrlEncoderTool() {
  const [input, setInput] = useState('https://example.com/search?q=أدوات برمجية');

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Lock className="w-5 h-5 text-blue-600" />
        <span>تشفير وفك تشفير عناوين الويب (URL Encode / Decode)</span>
      </h3>

      <textarea
        rows={2}
        value={input}
        onChange={(e) => setInput(e.target.value)}
        className="w-full p-2.5 text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <span className="text-[11px] text-gray-500 font-bold block mb-1">Encoded URL:</span>
        <div className="text-xs font-mono font-bold text-blue-600 dark:text-blue-400 break-all">
          {encodeURIComponent(input)}
        </div>
      </div>
    </div>
  );
}

// 7. Base64 Tool
function Base64Tool() {
  const [text, setText] = useState('Hello World');
  const b64 = btoa(unescape(encodeURIComponent(text)));

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Binary className="w-5 h-5 text-teal-600" />
        <span>ترميز وفك تشفير Base64</span>
      </h3>

      <textarea
        rows={2}
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="w-full p-2.5 text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <span className="text-[11px] text-gray-500 font-bold block mb-1">Base64 Output:</span>
        <div className="text-xs font-mono font-bold text-teal-600 dark:text-teal-400 break-all">{b64}</div>
      </div>
    </div>
  );
}

// 8. HTML Entities Tool
function HtmlEntitiesTool() {
  const [text, setText] = useState('<div class="box">&copy; 2026</div>');
  const encoded = text
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <Code className="w-5 h-5 text-rose-500" />
        <span>ترميز وفك رموز كيانات HTML Entities</span>
      </h3>

      <textarea
        rows={2}
        value={text}
        onChange={(e) => setText(e.target.value)}
        className="w-full p-2.5 text-xs border rounded-xl dark:bg-gray-800"
      />

      <div className="p-3 bg-gray-50 dark:bg-gray-800 rounded-xl border">
        <span className="text-[11px] text-gray-500 font-bold block mb-1">Encoded HTML:</span>
        <div className="text-xs font-mono font-bold text-rose-600 dark:text-rose-400 break-all">{encoded}</div>
      </div>
    </div>
  );
}

// 9. JWT Decoder Tool
function JwtDecoderTool() {
  const sampleJwt = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxMjM0NTY3ODkwIiwibmFtZSI6IkFobWVkIiwiaWF0IjoxNTE2MjM5MDIyfQ.SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c';
  const [jwt, setJwt] = useState(sampleJwt);

  let header = {};
  let payload = {};
  let isValid = false;

  try {
    const parts = jwt.split('.');
    if (parts.length === 3) {
      header = JSON.parse(atob(parts[0]));
      payload = JSON.parse(atob(parts[1]));
      isValid = true;
    }
  } catch {
    isValid = false;
  }

  return (
    <div className="space-y-4">
      <h3 className="text-base font-bold text-gray-900 dark:text-white flex items-center gap-2">
        <KeyRound className="w-5 h-5 text-indigo-500" />
        <span>محلل ومفسر توكن JWT (JSON Web Token Decoder)</span>
      </h3>

      <textarea
        rows={3}
        value={jwt}
        onChange={(e) => setJwt(e.target.value)}
        className="w-full p-2.5 font-mono text-xs border rounded-xl dark:bg-gray-800"
      />

      {isValid ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          <div className="p-3 bg-rose-50 dark:bg-rose-950/40 rounded-xl border border-rose-200">
            <span className="text-xs font-bold text-rose-700 block mb-1">Header (الرأس)</span>
            <pre className="text-xs font-mono text-rose-600">{JSON.stringify(header, null, 2)}</pre>
          </div>
          <div className="p-3 bg-purple-50 dark:bg-purple-950/40 rounded-xl border border-purple-200">
            <span className="text-xs font-bold text-purple-700 block mb-1">Payload (الحمولة)</span>
            <pre className="text-xs font-mono text-purple-600">{JSON.stringify(payload, null, 2)}</pre>
          </div>
        </div>
      ) : (
        <div className="p-3 bg-red-50 text-red-600 rounded-xl text-xs font-bold">
          توكن JWT غير صالح أو غير مكتمل
        </div>
      )}
    </div>
  );
}
