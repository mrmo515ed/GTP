import React, { useState } from 'react';
import { FileCode2, Copy, Trash2, CheckCircle2 } from 'lucide-react';

export function CssFormatter() {
  const [inputCss, setInputCss] = useState(`body {
background-color: #f3f4f6; color: #111827;
}
.card { margin: 10px; padding: 20px; border-radius: 8px; }`);
  
  const [outputCss, setOutputCss] = useState('');
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const formatCss = () => {
    try {
      let formatted = inputCss
        .replace(/\s+/g, ' ') // Replace multiple spaces with single space
        .replace(/{\s+/g, '{\n  ') // Add newline and indent after {
        .replace(/;\s+/g, ';\n  ') // Add newline and indent after ;
        .replace(/\s+}/g, '\n}') // Add newline before }
        .replace(/}\s+/g, '}\n\n') // Add double newline after }
        .replace(/:\s+/g, ': ') // Ensure single space after :
        .replace(/,\s+/g, ', '); // Ensure single space after ,

      // Simple cleanup for the last rule which might have an extra indent if it doesn't end with ;
      formatted = formatted.replace(/([^{;]+)\s*}/g, '$1\n}');

      setOutputCss(formatted);
      setError(null);
    } catch (err) {
      setError('تعذر تنسيق الكود. يرجى التأكد من صحة كود الـ CSS.');
    }
  };

  const minifyCss = () => {
    try {
      const minified = inputCss
        .replace(/\/\*[\s\S]*?\*\//g, '') // Remove comments
        .replace(/\s+/g, ' ') // Replace multiple spaces with single space
        .replace(/\s*([{};:,])\s*/g, '$1') // Remove spaces around {} ; : ,
        .replace(/;}/g, '}'); // Remove last semicolon before }

      setOutputCss(minified.trim());
      setError(null);
    } catch (err) {
      setError('تعذر ضغط الكود.');
    }
  };

  const handleCopy = () => {
    if (!outputCss) return;
    navigator.clipboard.writeText(outputCss);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="space-y-6">
      <div className="bg-indigo-50 dark:bg-indigo-900/20 p-4 rounded-2xl flex items-start gap-3 border border-indigo-100 dark:border-indigo-800/30">
        <FileCode2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400 mt-0.5 shrink-0" />
        <p className="text-sm text-indigo-800 dark:text-indigo-200 leading-relaxed">
          منسق وضاغط أكواد CSS: يساعدك في تحسين مقروئية الكود أو ضغطه (Minify) لتقليل حجم الملف وتريع تحميل صفحات الويب. معالجة سريعة وآمنة محلياً.
        </p>
      </div>

      <div className="space-y-2">
        <div className="flex items-center justify-between">
          <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">أدخل كود CSS هنا</label>
          <button
            onClick={() => setInputCss('')}
            className="text-xs flex items-center gap-1 text-rose-500 hover:text-rose-600 font-bold"
          >
            <Trash2 className="w-3.5 h-3.5" /> مسح
          </button>
        </div>
        <textarea
          value={inputCss}
          onChange={(e) => setInputCss(e.target.value)}
          className="w-full px-4 py-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 outline-none font-mono text-sm resize-y min-h-[160px]"
          dir="ltr"
          placeholder=".class { color: red; }"
        />
      </div>

      <div className="flex flex-wrap gap-3">
        <button
          onClick={formatCss}
          className="flex-1 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold transition shadow-xs"
        >
          تنسيق الكود (Format)
        </button>
        <button
          onClick={minifyCss}
          className="flex-1 py-3 bg-gray-800 dark:bg-gray-700 hover:bg-gray-900 dark:hover:bg-gray-600 text-white rounded-xl font-bold transition shadow-xs"
        >
          ضغط الكود (Minify)
        </button>
      </div>

      {error && (
        <div className="p-3 bg-rose-50 text-rose-600 rounded-xl text-sm font-bold border border-rose-100">
          {error}
        </div>
      )}

      {outputCss && (
        <div className="space-y-2 pt-4 border-t border-gray-100 dark:border-gray-800">
          <div className="flex items-center justify-between">
            <label className="block text-sm font-bold text-gray-700 dark:text-gray-300">النتيجة</label>
            <span className="text-xs text-gray-500 font-bold">
              الحجم: {new Blob([outputCss]).size} بايت
            </span>
          </div>
          <div className="relative">
            <textarea
              readOnly
              value={outputCss}
              className="w-full px-4 py-4 pr-12 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none font-mono text-sm resize-y min-h-[160px] text-gray-900 dark:text-gray-100"
              dir="ltr"
            />
            <button
              onClick={handleCopy}
              className="absolute top-4 right-4 p-2 bg-gray-100 dark:bg-gray-700 text-gray-500 hover:text-indigo-600 dark:hover:text-indigo-400 border border-gray-200 dark:border-gray-600 rounded-lg shadow-xs transition"
              title="نسخ النتيجة"
            >
              {copied ? <CheckCircle2 className="w-5 h-5 text-emerald-500" /> : <Copy className="w-5 h-5" />}
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
