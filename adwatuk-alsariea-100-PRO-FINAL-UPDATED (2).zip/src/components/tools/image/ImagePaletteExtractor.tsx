import React, { useState, useRef } from 'react';
import { Upload, Pipette, Copy, Check, Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

export function ImagePaletteExtractor() {
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [palette, setPalette] = useState<string[]>([]);
  const [copiedColor, setCopiedColor] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) return;
    const reader = new FileReader();
    reader.onload = (e) => {
      const src = e.target?.result as string;
      setImageSrc(src);
      extractColors(src);
    };
    reader.readAsDataURL(file);
  };

  const extractColors = (src: string) => {
    const img = new Image();
    img.src = src;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Sample a scaled down version for fast analysis
      const sampleSize = 50;
      canvas.width = sampleSize;
      canvas.height = sampleSize;
      ctx.drawImage(img, 0, 0, sampleSize, sampleSize);

      const imgData = ctx.getImageData(0, 0, sampleSize, sampleSize).data;
      const colorCounts: Record<string, number> = {};

      for (let i = 0; i < imgData.length; i += 4 * 4) {
        const r = Math.round(imgData[i] / 20) * 20;
        const g = Math.round(imgData[i + 1] / 20) * 20;
        const b = Math.round(imgData[i + 2] / 20) * 20;
        const a = imgData[i + 3];
        if (a > 128) {
          const hex = `#${((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).toUpperCase()}`;
          colorCounts[hex] = (colorCounts[hex] || 0) + 1;
        }
      }

      const sorted = Object.entries(colorCounts)
        .sort((a, b) => b[1] - a[1])
        .slice(0, 8)
        .map(([hex]) => hex);

      setPalette(sorted);
    };
  };

  const copyHex = (hex: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedColor(hex);
    confetti({ particleCount: 25, spread: 35, origin: { y: 0.8 } });
    setTimeout(() => setCopiedColor(null), 2000);
  };

  return (
    <div className="space-y-6" id="image-palette-extractor-tool">
      {!imageSrc ? (
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-emerald-300 dark:border-emerald-700/60 hover:border-emerald-500 rounded-2xl p-10 text-center cursor-pointer transition bg-emerald-50/20 dark:bg-emerald-950/10 flex flex-col items-center justify-center gap-3"
        >
          <div className="p-4 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 rounded-2xl">
            <Pipette className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-gray-800 dark:text-gray-200">
              ارفع صورة لاستخراج لوحة الألوان الرئيسية
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              تحليل مباشر وسريع لأكواد HEX المتناسقة من الصورة
            </p>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />
        </div>
      ) : (
        <div className="space-y-6">
          <div className="flex justify-between items-center">
            <span className="text-xs font-bold text-gray-700 dark:text-gray-300">
              الألوان المستخرجة من الصورة:
            </span>
            <button
              onClick={() => {
                setImageSrc(null);
                setPalette([]);
              }}
              className="text-xs text-rose-500 hover:underline"
            >
              اختيار صورة أخرى
            </button>
          </div>

          {/* Extracted Swatches */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {palette.map((hex, idx) => (
              <div
                key={idx}
                onClick={() => copyHex(hex)}
                className="p-3 bg-white dark:bg-gray-800 rounded-xl border border-gray-200 dark:border-gray-700 hover:border-emerald-500 cursor-pointer transition flex items-center gap-3 shadow-xs"
              >
                <div
                  className="w-10 h-10 rounded-lg shadow-inner border border-black/10 shrink-0"
                  style={{ backgroundColor: hex }}
                />
                <div className="flex-1 min-w-0">
                  <div className="font-mono text-xs font-bold text-gray-800 dark:text-gray-200 truncate">
                    {hex}
                  </div>
                  <div className="text-[10px] text-emerald-600 dark:text-emerald-400">
                    {copiedColor === hex ? 'تم النسخ!' : 'انقر للنسخ'}
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Image Display */}
          <div className="h-56 rounded-2xl border border-gray-200 dark:border-gray-700 overflow-hidden bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
            <img src={imageSrc} alt="Preview" className="max-h-full max-w-full object-contain" />
          </div>
        </div>
      )}
    </div>
  );
}
