import React, { useState, useRef } from 'react';
import { Image as ImageIcon, Code2, RefreshCw, Copy, Download, Settings, FileCode, CheckCircle2, XCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import beautify from 'js-beautify';

type SvgTab = 'format' | 'minify' | 'to-png' | 'to-jpg' | 'to-webp' | 'to-base64' | 'from-base64';

export function SvgToolsSuite({ defaultTab = 'format' }: { defaultTab?: string }) {
  const [activeTab, setActiveTab] = useState<SvgTab>(defaultTab as SvgTab);
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);
  const [svgWidth, setSvgWidth] = useState(512);
  const [svgHeight, setSvgHeight] = useState(512);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const tabs: { id: SvgTab; label: string; icon: any }[] = [
    { id: 'format', label: 'SVG Formatter', icon: Code2 },
    { id: 'minify', label: 'SVG Minifier', icon: RefreshCw },
    { id: 'to-png', label: 'SVG to PNG', icon: ImageIcon },
    { id: 'to-jpg', label: 'SVG to JPG', icon: ImageIcon },
    { id: 'to-webp', label: 'SVG to WebP', icon: ImageIcon },
    { id: 'to-base64', label: 'SVG to Base64', icon: FileCode },
    { id: 'from-base64', label: 'Base64 to SVG', icon: Code2 },
  ];

  const handleProcess = () => {
    setError(null);
    setSuccess(null);
    setOutput('');
    setPreviewUrl(null);

    if (!input.trim()) {
      setError('الرجاء إدخال الكود أولاً');
      return;
    }

    try {
      if (activeTab === 'format') {
        const formatted = beautify.html(input, { indent_size: 2 });
        setOutput(formatted);
        setPreviewUrl(`data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(formatted)))}`);
        setSuccess('تم تنسيق كود SVG بنجاح');
      } else if (activeTab === 'minify') {
        // Simple SVG minification
        let minified = input.replace(/>\s+</g, '><').replace(/<!--.*?-->/g, '').replace(/\n/g, '').replace(/\s+/g, ' ');
        setOutput(minified);
        setPreviewUrl(`data:image/svg+xml;base64,${btoa(unescape(encodeURIComponent(minified)))}`);
        setSuccess('تم ضغط كود SVG بنجاح');
      } else if (activeTab === 'to-base64') {
        const b64 = btoa(unescape(encodeURIComponent(input)));
        const dataUri = `data:image/svg+xml;base64,${b64}`;
        setOutput(dataUri);
        setPreviewUrl(dataUri);
        setSuccess('تم تحويل SVG إلى Base64');
      } else if (activeTab === 'from-base64') {
        let b64str = input;
        if (b64str.includes('base64,')) {
          b64str = b64str.split('base64,')[1];
        }
        const svgString = decodeURIComponent(escape(atob(b64str)));
        setOutput(svgString);
        setPreviewUrl(`data:image/svg+xml;base64,${b64str}`);
        setSuccess('تم تحويل Base64 إلى SVG');
      } else if (activeTab.startsWith('to-')) {
        const format = activeTab.replace('to-', '');
        convertSvgToImage(format);
        return; // async processing
      }
      
      confetti({ particleCount: 30, spread: 50 });
    } catch (err: any) {
      setError('خطأ في معالجة الكود: ' + err.message);
    }
  };

  const convertSvgToImage = (format: string) => {
    const svgData = input;
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const img = new Image();
    const blob = new Blob([svgData], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    
    img.onload = () => {
      canvas.width = svgWidth || img.width || 512;
      canvas.height = svgHeight || img.height || 512;
      
      if (format === 'jpg') {
         ctx.fillStyle = '#FFFFFF';
         ctx.fillRect(0, 0, canvas.width, canvas.height);
      } else {
         ctx.clearRect(0, 0, canvas.width, canvas.height);
      }
      
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      
      const mime = format === 'jpg' ? 'image/jpeg' : format === 'webp' ? 'image/webp' : 'image/png';
      const dataUrl = canvas.toDataURL(mime, 0.9);
      
      setPreviewUrl(dataUrl);
      setOutput(dataUrl); // For base64 copy
      setSuccess(`تم تحويل SVG إلى ${format.toUpperCase()} بنجاح`);
      window.setTimeout(() => URL.revokeObjectURL(url), 1000);
      confetti({ particleCount: 30, spread: 50 });
    };
    
    img.onerror = () => {
      setError('كود SVG غير صالح، تعذر التحويل');
    };
    
    img.src = url;
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setSuccess('تم النسخ إلى الحافظة');
    setTimeout(() => setSuccess(null), 2000);
  };

  const handleDownload = () => {
    if (!output) return;
    const a = document.createElement('a');
    
    if (activeTab.startsWith('to-') && activeTab !== 'to-base64') {
      const ext = activeTab.replace('to-', '');
      a.href = previewUrl!;
      a.download = `image.${ext}`;
    } else if (activeTab === 'to-base64') {
      const blob = new Blob([output], { type: 'text/plain' });
      a.href = URL.createObjectURL(blob);
      a.download = 'base64.txt';
    } else {
      const blob = new Blob([output], { type: 'image/svg+xml' });
      a.href = URL.createObjectURL(blob);
      a.download = 'vector.svg';
    }
    
    a.click();
    if (a.href.startsWith('blob:')) {
      window.setTimeout(() => URL.revokeObjectURL(a.href), 1000);
    }
  };

  return (
    <div className="space-y-6">
      <canvas ref={canvasRef} style={{ display: 'none' }}></canvas>
      
      {/* Tabs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => { setActiveTab(tab.id); setOutput(''); setError(null); setSuccess(null); setPreviewUrl(null); }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-lg'
                : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-50'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span className="text-sm font-medium">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white">الإدخال {activeTab === 'from-base64' ? '(Base64)' : '(SVG Code)'}</h3>
            <button onClick={() => setInput('')} className="text-sm text-red-500 hover:text-red-600">مسح</button>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full h-80 p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-left dir-ltr"
            placeholder={activeTab === 'from-base64' ? "الصق كود Base64 هنا..." : "الصق كود SVG هنا..."}
          />
          
          {['to-png', 'to-jpg', 'to-webp'].includes(activeTab) && (
            <div className="flex gap-4 mt-4">
               <div>
                  <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">العرض (px)</label>
                  <input type="number" value={svgWidth} onChange={e => setSvgWidth(Number(e.target.value))} className="w-full px-3 py-2 border border-gray-200 dark:border-gray-700 rounded-lg dark:bg-gray-900" />
               </div>
               <div>
                  <label className="block text-sm text-gray-600 dark:text-gray-400 mb-1">الارتفاع (px)</label>
                  <input type="number" value={svgHeight} onChange={e => setSvgHeight(Number(e.target.value))} className="w-full px-3 py-2 border border-gray-200 dark:border-gray-700 rounded-lg dark:bg-gray-900" />
               </div>
            </div>
          )}

          <button
            onClick={handleProcess}
            className="w-full mt-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-5 h-5" />
            <span>تنفيذ العملية</span>
          </button>
        </div>

        {/* Output */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700 flex flex-col">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white">النتيجة {['to-png', 'to-jpg', 'to-webp'].includes(activeTab) ? '(معاينة الصورة)' : '(الكود)'}</h3>
            <div className="flex gap-2">
              <button onClick={handleCopy} className="p-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg" title="نسخ الكود/Base64">
                <Copy className="w-4 h-4" />
              </button>
              <button onClick={handleDownload} className="p-2 text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg" title="تنزيل">
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          {error && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg flex items-center gap-2 text-sm">
              <XCircle className="w-5 h-5" />
              {error}
            </div>
          )}
          
          {success && (
            <div className="mb-4 p-3 bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-lg flex items-center gap-2 text-sm">
              <CheckCircle2 className="w-5 h-5" />
              {success}
            </div>
          )}

          {previewUrl && (
             <div className="mb-4 p-4 border border-dashed border-gray-300 dark:border-gray-600 rounded-xl flex items-center justify-center bg-gray-50/50 dark:bg-gray-900/50 min-h-[200px]">
                <img src={previewUrl} alt="SVG Preview" className="max-w-full max-h-[300px] object-contain" />
             </div>
          )}

          {!['to-png', 'to-jpg', 'to-webp'].includes(activeTab) && (
            <textarea
              value={output}
              readOnly
              className="flex-1 w-full min-h-[200px] p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-left dir-ltr"
              placeholder="ستظهر النتيجة هنا..."
            />
          )}
        </div>
      </div>
    </div>
  );
}
