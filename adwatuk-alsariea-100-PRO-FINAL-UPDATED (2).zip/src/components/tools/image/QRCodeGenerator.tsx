import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import { QrCode, Download, Copy, Check, Upload, Wifi, Link, Phone, Mail, Sparkles, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';

export function QRCodeGenerator() {
  const [type, setType] = useState<'url' | 'text' | 'wifi' | 'phone' | 'email'>('url');
  
  // Input fields
  const [url, setUrl] = useState('https://adwatuk-alsariea.netlify.app');
  const [plainText, setPlainText] = useState('مرحباً بك في منصة أدواتك السريعة!');
  const [wifiSsid, setWifiSsid] = useState('MyHomeWiFi');
  const [wifiPass, setWifiPass] = useState('12345678');
  const [wifiType, setWifiType] = useState('WPA');
  const [phone, setPhone] = useState('+966500000000');
  const [email, setEmail] = useState('info@example.com');

  // Customization
  const [fgColor, setFgColor] = useState('#059669'); // emerald
  const [bgColor, setBgColor] = useState('#FFFFFF');
  const [qrSize, setQrSize] = useState<number>(300);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState(false);

  const getQRContent = () => {
    switch (type) {
      case 'url':
        return url;
      case 'text':
        return plainText;
      case 'wifi':
        return `WIFI:S:${wifiSsid};T:${wifiType};P:${wifiPass};;`;
      case 'phone':
        return `tel:${phone}`;
      case 'email':
        return `mailto:${email}`;
      default:
        return url;
    }
  };

  useEffect(() => {
    const content = getQRContent();
    if (!content) return;

    QRCode.toDataURL(content, {
      width: qrSize,
      margin: 2,
      color: {
        dark: fgColor,
        light: bgColor,
      },
      errorCorrectionLevel: 'H',
    })
      .then((url) => setQrDataUrl(url))
      .catch((err) => console.error(err));
  }, [type, url, plainText, wifiSsid, wifiPass, wifiType, phone, email, fgColor, bgColor, qrSize]);

  const handleDownload = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `qrcode-${type}.png`;
    a.click();
    confetti({ particleCount: 35, spread: 50, origin: { y: 0.8 } });
  };

  const handleCopyImage = async () => {
    if (!qrDataUrl) return;
    try {
      const res = await fetch(qrDataUrl);
      const blob = await res.blob();
      await navigator.clipboard.write([
        new ClipboardItem({ 'image/png': blob })
      ]);
      setCopied(true);
      confetti({ particleCount: 25, spread: 40, origin: { y: 0.8 } });
      setTimeout(() => setCopied(false), 2000);
    } catch {
      // Fallback copy text
      navigator.clipboard.writeText(getQRContent());
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  return (
    <div className="space-y-6" id="qr-generator-tool">
      {/* Types Switcher */}
      <div className="flex flex-wrap gap-2 p-1.5 bg-gray-100 dark:bg-gray-800 rounded-xl">
        <button
          onClick={() => setType('url')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            type === 'url' ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs' : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Link className="w-3.5 h-3.5" />
          رابط موقع (URL)
        </button>
        <button
          onClick={() => setType('text')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            type === 'text' ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs' : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Sparkles className="w-3.5 h-3.5" />
          نص حر
        </button>
        <button
          onClick={() => setType('wifi')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            type === 'wifi' ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs' : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Wifi className="w-3.5 h-3.5" />
          شبكة واي فاي (Wi-Fi)
        </button>
        <button
          onClick={() => setType('phone')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            type === 'phone' ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs' : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Phone className="w-3.5 h-3.5" />
          رقم هاتف
        </button>
        <button
          onClick={() => setType('email')}
          className={`flex-1 py-2 px-3 text-xs font-bold rounded-lg transition flex items-center justify-center gap-1.5 ${
            type === 'email' ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-xs' : 'text-gray-600 dark:text-gray-400'
          }`}
        >
          <Mail className="w-3.5 h-3.5" />
          بريد إلكتروني
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-6">
        {/* Left Inputs & Colors */}
        <div className="md:col-span-7 space-y-4">
          {type === 'url' && (
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
                رابط الموقع الإلكتروني:
              </label>
              <input
                type="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                placeholder="https://example.com"
                dir="ltr"
                className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>
          )}

          {type === 'text' && (
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
                النص المراد تحويله إلى باركود:
              </label>
              <textarea
                value={plainText}
                onChange={(e) => setPlainText(e.target.value)}
                rows={3}
                className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 text-sm focus:ring-2 focus:ring-emerald-500 outline-none"
              />
            </div>
          )}

          {type === 'wifi' && (
            <div className="space-y-3 p-3.5 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200 dark:border-gray-700">
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">اسم الشبكة (SSID):</label>
                <input
                  type="text"
                  value={wifiSsid}
                  onChange={(e) => setWifiSsid(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm"
                />
              </div>
              <div>
                <label className="block text-xs font-semibold text-gray-700 dark:text-gray-300 mb-1">كلمة مرور الشبكة:</label>
                <input
                  type="text"
                  value={wifiPass}
                  onChange={(e) => setWifiPass(e.target.value)}
                  className="w-full p-2.5 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm"
                />
              </div>
            </div>
          )}

          {type === 'phone' && (
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">رقم الهاتف:</label>
              <input
                type="tel"
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                dir="ltr"
                className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm"
              />
            </div>
          )}

          {type === 'email' && (
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">البريد الإلكتروني:</label>
              <input
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                dir="ltr"
                className="w-full p-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-sm"
              />
            </div>
          )}

          {/* Color & Size Customization */}
          <div className="p-3.5 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-xl space-y-3">
            <span className="text-xs font-bold text-gray-700 dark:text-gray-300 block">تخصيص الألوان والمقاس:</span>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs text-gray-600 dark:text-gray-400 block mb-1">لون الرمز:</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={fgColor}
                    onChange={(e) => setFgColor(e.target.value)}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0"
                  />
                  <span className="text-xs font-mono text-gray-700 dark:text-gray-300">{fgColor}</span>
                </div>
              </div>

              <div>
                <label className="text-xs text-gray-600 dark:text-gray-400 block mb-1">لون الخلفية:</label>
                <div className="flex items-center gap-2">
                  <input
                    type="color"
                    value={bgColor}
                    onChange={(e) => setBgColor(e.target.value)}
                    className="w-8 h-8 rounded-lg cursor-pointer border-0"
                  />
                  <span className="text-xs font-mono text-gray-700 dark:text-gray-300">{bgColor}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Right QR Preview & Download */}
        <div className="md:col-span-5 flex flex-col items-center justify-center p-6 bg-gray-50 dark:bg-gray-800/60 rounded-2xl border border-gray-200 dark:border-gray-700 gap-4 text-center">
          <div className="p-3 bg-white rounded-2xl shadow-md inline-block">
            {qrDataUrl && (
              <img src={qrDataUrl} alt="Generated QR Code" className="w-48 h-48 sm:w-56 sm:h-56 object-contain" />
            )}
          </div>

          <div className="w-full flex flex-col gap-2">
            <button
              onClick={handleDownload}
              className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl text-xs sm:text-sm shadow-xs transition flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              تحميل الرمز بصيغة PNG
            </button>
            <button
              onClick={handleCopyImage}
              className="w-full py-2 px-4 bg-white dark:bg-gray-700 hover:bg-gray-100 text-gray-700 dark:text-gray-200 border border-gray-200 dark:border-gray-600 font-semibold rounded-xl text-xs transition flex items-center justify-center gap-2"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-500" /> : <Copy className="w-4 h-4" />}
              {copied ? 'تم النسخ!' : 'نسخ الصورة إلى الحافظة'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
