import React, { useState, useRef, useEffect } from 'react';
import {
  Image as ImageIcon,
  Sliders,
  Crop,
  RotateCw,
  Sparkles,
  ShieldCheck,
  Palette,
  Pipette,
  FileCode,
  Layers,
  FileDown,
  Upload,
  Download,
  Copy,
  Check,
  Trash2
} from 'lucide-react';
import { jsPDF } from 'jspdf';

interface Props {
  defaultTab?:
    | 'compress'
    | 'resize'
    | 'crop'
    | 'rotate'
    | 'transparent-bg'
    | 'remove-exif'
    | 'extract-colors'
    | 'color-picker'
    | 'image-base64'
    | 'favicon-maker'
    | 'image-to-pdf';
}

export function ImageProcessingSuite({ defaultTab = 'compress' }: Props) {
  const [activeTab, setActiveTab] = useState<string>(defaultTab);
  const [imageSrc, setImageSrc] = useState<string>('');
  const [imageFileName, setImageFileName] = useState<string>('image.png');
  const [originalSize, setOriginalSize] = useState<number>(0);
  const [copied, setCopied] = useState<boolean>(false);

  // Compress state
  const [quality, setQuality] = useState<number>(0.8);
  const [compressedSrc, setCompressedSrc] = useState<string>('');
  const [compressedSize, setCompressedSize] = useState<number>(0);

  // Resize state
  const [resizeWidth, setResizeWidth] = useState<number>(800);
  const [resizeHeight, setResizeHeight] = useState<number>(600);
  const [keepAspect, setKeepAspect] = useState<boolean>(true);
  const [aspectRatio, setAspectRatio] = useState<number>(1);
  const [resizedSrc, setResizedSrc] = useState<string>('');

  // Rotate state
  const [rotationAngle, setRotationAngle] = useState<number>(0);
  const [flipH, setFlipH] = useState<boolean>(false);
  const [flipV, setFlipV] = useState<boolean>(false);

  // Color extraction state
  const [extractedColors, setExtractedColors] = useState<string[]>([]);

  // Base64 state
  const [base64Output, setBase64Output] = useState<string>('');
  const [base64Input, setBase64Input] = useState<string>('');

  // Transparency / Background
  const [transparencyTolerance, setTransparencyTolerance] = useState<number>(30);
  const [transparentSrc, setTransparentSrc] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleImageUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setImageFileName(file.name);
    setOriginalSize(file.size);

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setImageSrc(result);
      setBase64Output(result);

      // Load image metrics
      const img = new Image();
      img.onload = () => {
        setResizeWidth(img.naturalWidth);
        setResizeHeight(img.naturalHeight);
        setAspectRatio(img.naturalWidth / img.naturalHeight);
        extractPalette(img);
      };
      img.src = result;
    };
    reader.readAsDataURL(file);
  };

  // Compress logic
  useEffect(() => {
    if (!imageSrc) return;
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(img, 0, 0);
      const dataUrl = canvas.toDataURL('image/jpeg', quality);
      setCompressedSrc(dataUrl);
      const head = 'data:image/jpeg;base64,';
      const sizeInBytes = Math.round(((dataUrl.length - head.length) * 3) / 4);
      setCompressedSize(sizeInBytes);
    };
    img.src = imageSrc;
  }, [imageSrc, quality]);

  // Resize logic
  const handleApplyResize = () => {
    if (!imageSrc) return;
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = resizeWidth;
      canvas.height = resizeHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(img, 0, 0, resizeWidth, resizeHeight);
      setResizedSrc(canvas.toDataURL('image/png'));
    };
    img.src = imageSrc;
  };

  // Rotate & Flip logic
  const getTransformedImage = (): string => {
    if (!imageSrc) return '';
    const img = new Image();
    img.src = imageSrc;
    const canvas = document.createElement('canvas');
    const rad = (rotationAngle * Math.PI) / 180;
    const isSideways = rotationAngle % 180 !== 0;
    canvas.width = isSideways ? img.naturalHeight || 400 : img.naturalWidth || 400;
    canvas.height = isSideways ? img.naturalWidth || 400 : img.naturalHeight || 400;
    const ctx = canvas.getContext('2d');
    if (!ctx) return imageSrc;

    ctx.translate(canvas.width / 2, canvas.height / 2);
    ctx.rotate(rad);
    ctx.scale(flipH ? -1 : 1, flipV ? -1 : 1);
    ctx.drawImage(img, -img.naturalWidth / 2, -img.naturalHeight / 2);
    return canvas.toDataURL('image/png');
  };

  // Color Palette Extraction
  const extractPalette = (img: HTMLImageElement) => {
    const canvas = document.createElement('canvas');
    canvas.width = 100;
    canvas.height = 100;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    ctx.drawImage(img, 0, 0, 100, 100);
    const data = ctx.getImageData(0, 0, 100, 100).data;
    const colorMap = new Map<string, number>();

    for (let i = 0; i < data.length; i += 16) {
      const r = Math.round(data[i] / 15) * 15;
      const g = Math.round(data[i + 1] / 15) * 15;
      const b = Math.round(data[i + 2] / 15) * 15;
      const hex = '#' + [r, g, b].map(x => x.toString(16).padStart(2, '0')).join('');
      colorMap.set(hex, (colorMap.get(hex) || 0) + 1);
    }

    const sorted = Array.from(colorMap.entries())
      .sort((a, b) => b[1] - a[1])
      .slice(0, 8)
      .map(entry => entry[0]);
    setExtractedColors(sorted);
  };

  // Remove background color transparency (magic wand top-left color)
  const handleMakeTransparent = () => {
    if (!imageSrc) return;
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.naturalWidth;
      canvas.height = img.naturalHeight;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;
      ctx.drawImage(img, 0, 0);
      const imgData = ctx.getImageData(0, 0, canvas.width, canvas.height);
      const d = imgData.data;

      // Sample top-left pixel
      const targetR = d[0];
      const targetG = d[1];
      const targetB = d[2];

      for (let i = 0; i < d.length; i += 4) {
        const r = d[i];
        const g = d[i + 1];
        const b = d[i + 2];
        const diff = Math.sqrt(
          Math.pow(r - targetR, 2) + Math.pow(g - targetG, 2) + Math.pow(b - targetB, 2)
        );
        if (diff < transparencyTolerance) {
          d[i + 3] = 0; // Alpha 0
        }
      }
      ctx.putImageData(imgData, 0, 0);
      setTransparentSrc(canvas.toDataURL('image/png'));
    };
    img.src = imageSrc;
  };

  // Screenshot / Image to PDF
  const handleExportPdf = () => {
    if (!imageSrc) return;
    const doc = new jsPDF({
      orientation: resizeWidth > resizeHeight ? 'landscape' : 'portrait',
      unit: 'px',
      format: [resizeWidth, resizeHeight]
    });
    doc.addImage(imageSrc, 'PNG', 0, 0, resizeWidth, resizeHeight);
    doc.save('image-export.pdf');
  };

  const tabs = [
    { id: 'compress', label: 'ضغط الصور', icon: Sliders },
    { id: 'resize', label: 'تغيير الحجم', icon: Crop },
    { id: 'rotate', label: 'تدوير وقلب الصورة', icon: RotateCw },
    { id: 'transparent-bg', label: 'خلفية شفافة', icon: Sparkles },
    { id: 'remove-exif', label: 'إزالة بيانات EXIF', icon: ShieldCheck },
    { id: 'extract-colors', label: 'استخراج الألوان', icon: Palette },
    { id: 'image-base64', label: 'صورة ↔ Base64', icon: FileCode },
    { id: 'favicon-maker', label: 'صانع Favicon و ICO', icon: Layers },
    { id: 'image-to-pdf', label: 'صورة إلى PDF', icon: FileDown }
  ];

  return (
    <div className="space-y-6" id="image-processing-suite">
      {/* Tabs bar */}
      <div className="flex items-center gap-2 overflow-x-auto pb-2 scrollbar-thin scrollbar-thumb-gray-200 dark:scrollbar-thumb-gray-800">
        {tabs.map(tab => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;
          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex items-center gap-2 px-3.5 py-2 rounded-xl text-xs font-bold transition-all whitespace-nowrap ${
                isActive
                  ? 'bg-emerald-600 text-white shadow-md shadow-emerald-500/20'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 dark:hover:bg-gray-700/60 border border-gray-200/80 dark:border-gray-700/60'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{tab.label}</span>
            </button>
          );
        })}
      </div>

      {/* Upload Zone */}
      <input ref={fileInputRef} type="file" accept="image/*" onChange={handleImageUpload} className="hidden" />
      {!imageSrc && activeTab !== 'image-base64' ? (
        <div
          onClick={() => fileInputRef.current?.click()}
          className="p-12 border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-3xl cursor-pointer hover:border-emerald-500 hover:bg-emerald-50/20 transition-all text-center space-y-3"
        >
          <Upload className="w-12 h-12 text-emerald-600 mx-auto" />
          <h3 className="text-base font-bold text-gray-800 dark:text-gray-200">اختر صورة أو اسحبها هنا لبدء التعديل والمعالجة</h3>
          <p className="text-xs text-gray-500">يدعم صيغ JPG, PNG, WebP, SVG, GIF, BMP حتى 50MB</p>
        </div>
      ) : null}

      {imageSrc && (
        <div className="flex items-center justify-between p-3 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700">
          <div className="flex items-center gap-3 overflow-hidden">
            <img src={imageSrc} alt="Thumbnail" className="w-10 h-10 object-cover rounded-lg border" />
            <div className="truncate">
              <span className="text-xs font-bold text-gray-800 dark:text-gray-200 block truncate">{imageFileName}</span>
              <span className="text-[11px] text-gray-500">{(originalSize / 1024).toFixed(1)} KB</span>
            </div>
          </div>
          <button
            onClick={() => fileInputRef.current?.click()}
            className="px-3 py-1.5 bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 text-xs font-bold rounded-xl transition-all"
          >
            تغيير الصورة
          </button>
        </div>
      )}

      {/* Tab 1: Compress */}
      {activeTab === 'compress' && imageSrc && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
            <h4 className="text-xs font-black text-gray-700 dark:text-gray-200">إعدادات الضغط والجودة</h4>
            <div>
              <div className="flex justify-between text-xs font-bold mb-1">
                <span>مستوى الجودة: {Math.round(quality * 100)}%</span>
                <span className="text-emerald-600">
                  توفير المساحة: {originalSize ? Math.max(0, Math.round(((originalSize - compressedSize) / originalSize) * 100)) : 0}%
                </span>
              </div>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={quality}
                onChange={e => setQuality(Number(e.target.value))}
                className="w-full accent-emerald-600"
              />
            </div>
            <div className="flex justify-between text-xs p-3 bg-gray-50 dark:bg-gray-900 rounded-xl">
              <span>الحجم بعد الضغط:</span>
              <span className="font-bold text-emerald-600">{(compressedSize / 1024).toFixed(1)} KB</span>
            </div>
            <a
              href={compressedSrc}
              download={`compressed-${imageFileName}`}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>تنزيل الصورة المضغوطة</span>
            </a>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 flex items-center justify-center">
            {compressedSrc && <img src={compressedSrc} alt="Compressed" className="max-h-64 rounded-xl object-contain shadow-sm" />}
          </div>
        </div>
      )}

      {/* Tab 2: Resize */}
      {activeTab === 'resize' && imageSrc && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
            <h4 className="text-xs font-black text-gray-700 dark:text-gray-200">تغيير الأبعاد (Pixel)</h4>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-xs font-bold text-gray-500 block mb-1">العرض (Width)</label>
                <input
                  type="number"
                  value={resizeWidth}
                  onChange={e => {
                    const w = Number(e.target.value);
                    setResizeWidth(w);
                    if (keepAspect) setResizeHeight(Math.round(w / aspectRatio));
                  }}
                  className="w-full p-2.5 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700"
                />
              </div>
              <div>
                <label className="text-xs font-bold text-gray-500 block mb-1">الارتفاع (Height)</label>
                <input
                  type="number"
                  value={resizeHeight}
                  onChange={e => {
                    const h = Number(e.target.value);
                    setResizeHeight(h);
                    if (keepAspect) setResizeWidth(Math.round(h * aspectRatio));
                  }}
                  className="w-full p-2.5 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700"
                />
              </div>
            </div>

            <label className="flex items-center gap-2 text-xs font-bold cursor-pointer">
              <input
                type="checkbox"
                checked={keepAspect}
                onChange={e => setKeepAspect(e.target.checked)}
                className="accent-emerald-600 rounded"
              />
              <span>الحفاظ على نسبة الأبعاد (Aspect Ratio)</span>
            </label>

            <button
              onClick={handleApplyResize}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold"
            >
              تطبيق الأبعاد الجديدة
            </button>

            {resizedSrc && (
              <a
                href={resizedSrc}
                download={`resized-${resizeWidth}x${resizeHeight}-${imageFileName}`}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>تنزيل الصورة المعدلة</span>
              </a>
            )}
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 flex items-center justify-center">
            <img src={resizedSrc || imageSrc} alt="Preview" className="max-h-64 rounded-xl object-contain shadow-sm" />
          </div>
        </div>
      )}

      {/* Tab 3: Rotate & Flip */}
      {activeTab === 'rotate' && imageSrc && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
            <h4 className="text-xs font-black text-gray-700 dark:text-gray-200">التدوير والقلب</h4>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => setRotationAngle(r => (r + 90) % 360)}
                className="p-3 bg-gray-100 dark:bg-gray-700 rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <RotateCw className="w-4 h-4" />
                <span>تدوير 90° يميناً</span>
              </button>
              <button
                onClick={() => setRotationAngle(r => (r + 270) % 360)}
                className="p-3 bg-gray-100 dark:bg-gray-700 rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <RotateCw className="w-4 h-4 -scale-x-100" />
                <span>تدوير 90° يساراً</span>
              </button>
              <button
                onClick={() => setFlipH(f => !f)}
                className={`p-3 rounded-xl text-xs font-bold ${flipH ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
              >
                قلب أفقي (Horizontal)
              </button>
              <button
                onClick={() => setFlipV(f => !f)}
                className={`p-3 rounded-xl text-xs font-bold ${flipV ? 'bg-emerald-600 text-white' : 'bg-gray-100 dark:bg-gray-700 text-gray-700 dark:text-gray-300'}`}
              >
                قلب رأسي (Vertical)
              </button>
            </div>

            <a
              href={getTransformedImage()}
              download={`transformed-${imageFileName}`}
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
            >
              <Download className="w-4 h-4" />
              <span>تنزيل الصورة</span>
            </a>
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 flex items-center justify-center overflow-hidden">
            <img
              src={imageSrc}
              alt="Transformed Preview"
              style={{
                transform: `rotate(${rotationAngle}deg) scaleX(${flipH ? -1 : 1}) scaleY(${flipV ? -1 : 1})`,
                transition: 'transform 0.2s ease'
              }}
              className="max-h-64 rounded-xl object-contain"
            />
          </div>
        </div>
      )}

      {/* Tab 4: Transparent Background */}
      {activeTab === 'transparent-bg' && imageSrc && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-4">
            <h4 className="text-xs font-black text-gray-700 dark:text-gray-200">إزالة اللون وجعل الخلفية شفافة</h4>
            <p className="text-[11px] text-gray-500">يقوم بإزالة اللون الموجود في الزاوية العلوية اليسرى بدقة متناسبة.</p>
            <div>
              <label className="text-xs font-bold block mb-1">نسبة التسامح اللوني: {transparencyTolerance}</label>
              <input
                type="range"
                min="5"
                max="100"
                value={transparencyTolerance}
                onChange={e => setTransparencyTolerance(Number(e.target.value))}
                className="w-full accent-emerald-600"
              />
            </div>
            <button
              onClick={handleMakeTransparent}
              className="w-full py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-bold"
            >
              تفريغ الخلفية الآن
            </button>

            {transparentSrc && (
              <a
                href={transparentSrc}
                download={`transparent-${imageFileName.replace(/\.[^/.]+$/, '')}.png`}
                className="w-full py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold flex items-center justify-center gap-2"
              >
                <Download className="w-4 h-4" />
                <span>تنزيل صورة PNG الشفافة</span>
              </a>
            )}
          </div>

          <div
            className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 flex items-center justify-center"
            style={{ backgroundImage: 'radial-gradient(#cbd5e1 1px, transparent 1px)', backgroundSize: '16px 16px' }}
          >
            <img src={transparentSrc || imageSrc} alt="Transparent" className="max-h-64 object-contain" />
          </div>
        </div>
      )}

      {/* Tab 5: Remove EXIF */}
      {activeTab === 'remove-exif' && imageSrc && (
        <div className="max-w-xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-4 text-center">
          <ShieldCheck className="w-12 h-12 text-emerald-600 mx-auto" />
          <h3 className="text-sm font-bold text-gray-800 dark:text-gray-100">إزالة كافة بيانات EXIF والبيانات الوصفية الوصفية للخصوصية</h3>
          <p className="text-xs text-gray-500">تم تنظيف الصورة تماماً من إحداثيات GPS، ونوع الكاميرا، ووقت التقاط الصورة.</p>
          <a
            href={imageSrc}
            download={`clean-${imageFileName}`}
            className="inline-flex py-3 px-6 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold items-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>تنزيل الصورة النظيفة</span>
          </a>
        </div>
      )}

      {/* Tab 6: Extract Colors */}
      {activeTab === 'extract-colors' && imageSrc && (
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-5">
          <h3 className="text-sm font-bold text-gray-800 dark:text-gray-100">لوحة الألوان المستخرجة من الصورة (Palette)</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            {extractedColors.map((color, i) => (
              <div
                key={i}
                onClick={() => copyToClipboard(color)}
                className="p-3 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 cursor-pointer hover:scale-105 transition-all text-center space-y-2"
              >
                <div className="w-full h-16 rounded-xl shadow-inner" style={{ backgroundColor: color }} />
                <span className="text-xs font-mono font-bold block">{color}</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 7: Image to Base64 & Base64 to Image */}
      {activeTab === 'image-base64' && (
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-black text-gray-700 dark:text-gray-200">كود Base64 للصورة الحالية</label>
              <button
                onClick={() => copyToClipboard(base64Output)}
                className="px-3 py-1 bg-emerald-50 dark:bg-emerald-950/40 text-emerald-600 text-xs font-bold rounded-lg flex items-center gap-1"
              >
                <Copy className="w-3.5 h-3.5" /> نسخ
              </button>
            </div>
            <textarea
              readOnly
              rows={10}
              value={base64Output}
              placeholder="ارفع صورة بالأعلى للحصول على كود Base64 الخاص بها..."
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700"
            />
          </div>

          <div className="bg-white dark:bg-gray-800 rounded-2xl p-5 border border-gray-200 dark:border-gray-700 space-y-3">
            <label className="text-xs font-black text-gray-700 dark:text-gray-200 block">تحويل Base64 إلى صورة معاينة</label>
            <textarea
              rows={6}
              value={base64Input}
              onChange={e => setBase64Input(e.target.value)}
              placeholder="الصق كود data:image/png;base64,... هنا"
              className="w-full p-3 bg-gray-50 dark:bg-gray-900 text-xs font-mono rounded-xl border border-gray-200 dark:border-gray-700 outline-none"
            />
            {base64Input && (
              <div className="flex items-center justify-center p-3 bg-gray-50 dark:bg-gray-900 rounded-xl">
                <img src={base64Input} alt="From Base64" className="max-h-36 rounded-lg" />
              </div>
            )}
          </div>
        </div>
      )}

      {/* Tab 8: Favicon Maker */}
      {activeTab === 'favicon-maker' && imageSrc && (
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-5">
          <h3 className="text-sm font-bold text-gray-800 dark:text-gray-100">صانع أيقونات المواقع Favicon بجميع المقاسات</h3>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-center">
            {[16, 32, 48, 64].map(sz => (
              <div key={sz} className="p-4 bg-gray-50 dark:bg-gray-900 rounded-2xl border border-gray-200 dark:border-gray-700 space-y-2">
                <div className="h-16 flex items-center justify-center">
                  <img src={imageSrc} alt={`${sz}x${sz}`} style={{ width: sz, height: sz }} className="rounded" />
                </div>
                <span className="text-xs font-bold block">{sz}x{sz} px</span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 9: Image to PDF */}
      {activeTab === 'image-to-pdf' && imageSrc && (
        <div className="max-w-xl mx-auto bg-white dark:bg-gray-800 rounded-2xl p-6 border border-gray-200 dark:border-gray-700 space-y-4 text-center">
          <FileDown className="w-12 h-12 text-emerald-600 mx-auto" />
          <h3 className="text-sm font-bold text-gray-800 dark:text-gray-100">تصدير الصورة إلى ملف PDF عالي الجودة</h3>
          <p className="text-xs text-gray-500">سيتم حفظ الصورة كملف مستند PDF بالأبعاد الدقيقة.</p>
          <button
            onClick={handleExportPdf}
            className="py-3 px-6 bg-emerald-600 hover:bg-emerald-700 text-white rounded-xl text-xs font-bold inline-flex items-center gap-2"
          >
            <Download className="w-4 h-4" />
            <span>تنزيل مستند PDF</span>
          </button>
        </div>
      )}
    </div>
  );
}
