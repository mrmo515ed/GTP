import React, { useState, useRef } from 'react';
import { Upload, Download, Repeat, Image as ImageIcon, Sparkles, Check } from 'lucide-react';
import confetti from 'canvas-confetti';

export function ImageConverter() {
  const [file, setFile] = useState<File | null>(null);
  const [imageSrc, setImageSrc] = useState<string | null>(null);
  const [targetFormat, setTargetFormat] = useState<'png' | 'jpeg' | 'webp' | 'bmp'>('webp');
  const [convertedData, setConvertedData] = useState<string | null>(null);
  const [isConverting, setIsConverting] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFile = (uploadedFile: File) => {
    if (!uploadedFile.type.startsWith('image/')) return;
    setFile(uploadedFile);
    const reader = new FileReader();
    reader.onload = (e) => {
      const src = e.target?.result as string;
      setImageSrc(src);
      performConversion(src, targetFormat);
    };
    reader.readAsDataURL(uploadedFile);
  };

  const performConversion = (src: string, fmt: 'png' | 'jpeg' | 'webp' | 'bmp') => {
    setIsConverting(true);
    const img = new Image();
    img.src = src;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = img.width;
      canvas.height = img.height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      if (fmt === 'jpeg' || fmt === 'bmp') {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, img.width, img.height);
      }

      ctx.drawImage(img, 0, 0);
      const mimeType = fmt === 'png' ? 'image/png' : fmt === 'jpeg' ? 'image/jpeg' : fmt === 'webp' ? 'image/webp' : 'image/png';
      const dataUrl = canvas.toDataURL(mimeType, 0.92);
      setConvertedData(dataUrl);
      setIsConverting(false);
    };
  };

  const handleFormatChange = (fmt: 'png' | 'jpeg' | 'webp' | 'bmp') => {
    setTargetFormat(fmt);
    if (imageSrc) {
      performConversion(imageSrc, fmt);
    }
  };

  const handleDownload = () => {
    if (!convertedData) return;
    const a = document.createElement('a');
    a.href = convertedData;
    const origName = file?.name.substring(0, file.name.lastIndexOf('.')) || 'converted-image';
    a.download = `${origName}.${targetFormat === 'jpeg' ? 'jpg' : targetFormat}`;
    a.click();
    confetti({ particleCount: 35, spread: 50, origin: { y: 0.8 } });
  };

  return (
    <div className="space-y-6" id="image-converter-tool">
      {!imageSrc ? (
        <div
          onClick={() => fileInputRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            if (e.dataTransfer.files?.[0]) handleFile(e.dataTransfer.files[0]);
          }}
          className="border-2 border-dashed border-emerald-300 dark:border-emerald-700/60 hover:border-emerald-500 rounded-2xl p-10 text-center cursor-pointer transition-all bg-emerald-50/20 dark:bg-emerald-950/10 flex flex-col items-center justify-center gap-3"
        >
          <div className="p-4 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 rounded-2xl">
            <Repeat className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-gray-800 dark:text-gray-200">
              اختر الصورة المراد تحويل صيغتها
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              يدعم التحويل بين PNG, JPG, WEBP, BMP بشكل فوري وبدون رفع للمخدم
            </p>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleFile(e.target.files[0])}
          />
        </div>
      ) : (
        <div className="space-y-5">
          {/* Format selection */}
          <div className="p-4 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-xl space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">
                اختر الصيغة المستهدفة للتحويل:
              </span>
              <button
                onClick={() => {
                  setImageSrc(null);
                  setConvertedData(null);
                }}
                className="text-xs text-rose-500 hover:underline"
              >
                تغيير الصورة
              </button>
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
              {(['webp', 'png', 'jpeg', 'bmp'] as const).map((fmt) => (
                <button
                  key={fmt}
                  onClick={() => handleFormatChange(fmt)}
                  className={`py-2 px-3 rounded-xl text-xs font-bold transition flex items-center justify-center gap-1.5 ${
                    targetFormat === fmt
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border border-gray-200 dark:border-gray-700 hover:border-emerald-400'
                  }`}
                >
                  {fmt.toUpperCase()}
                  {targetFormat === fmt && <Check className="w-3.5 h-3.5" />}
                </button>
              ))}
            </div>
          </div>

          {/* Preview Container */}
          <div className="h-64 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
            {convertedData && (
              <img
                src={convertedData}
                alt="Converted preview"
                className="max-h-full max-w-full object-contain"
              />
            )}
          </div>

          {/* Download button */}
          <div className="flex justify-end">
            <button
              onClick={handleDownload}
              className="w-full sm:w-auto px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md transition flex items-center justify-center gap-2"
            >
              <Download className="w-5 h-5" />
              تحميل بصيغة {targetFormat.toUpperCase()} الآن
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
