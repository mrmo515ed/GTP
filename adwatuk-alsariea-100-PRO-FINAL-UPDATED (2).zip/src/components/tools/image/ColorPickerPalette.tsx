import React, { useState } from 'react';
import { Copy, Check, Palette, Sparkles, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';

export function ColorPickerPalette() {
  const [hex, setHex] = useState('#10B981');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  // Convert HEX to RGB
  const hexToRgb = (hexStr: string) => {
    let clean = hexStr.replace('#', '');
    if (clean.length === 3) {
      clean = clean.split('').map((c) => c + c).join('');
    }
    const num = parseInt(clean, 16);
    return {
      r: (num >> 16) & 255,
      g: (num >> 8) & 255,
      b: num & 255,
    };
  };

  // Convert RGB to HSL
  const rgbToHsl = (r: number, g: number, b: number) => {
    r /= 255;
    g /= 255;
    b /= 255;
    const max = Math.max(r, g, b);
    const min = Math.min(r, g, b);
    let h = 0, s = 0, l = (max + min) / 2;

    if (max !== min) {
      const d = max - min;
      s = l > 0.5 ? d / (2 - max - min) : d / (max + min);
      switch (max) {
        case r: h = (g - b) / d + (g < b ? 6 : 0); break;
        case g: h = (b - r) / d + 2; break;
        case b: h = (r - g) / d + 4; break;
      }
      h /= 6;
    }
    return {
      h: Math.round(h * 360),
      s: Math.round(s * 100),
      l: Math.round(l * 100),
    };
  };

  const rgb = hexToRgb(hex);
  const hsl = rgbToHsl(rgb.r, rgb.g, rgb.b);

  const rgbString = `rgb(${rgb.r}, ${rgb.g}, ${rgb.b})`;
  const hslString = `hsl(${hsl.h}, ${hsl.s}%, ${hsl.l}%)`;

  const copy = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    confetti({ particleCount: 25, spread: 40, origin: { y: 0.8 } });
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const generateRandomColor = () => {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
      color += letters[Math.floor(Math.random() * 16)];
    }
    setHex(color);
  };

  // Harmonious shades
  const shades = [0.2, 0.4, 0.6, 0.8, 1, 1.2, 1.4].map((multiplier) => {
    const newL = Math.min(95, Math.max(5, Math.round(hsl.l * multiplier)));
    return `hsl(${hsl.h}, ${hsl.s}%, ${newL}%)`;
  });

  return (
    <div className="space-y-6" id="color-picker-tool">
      <div className="grid grid-cols-1 md:grid-cols-12 gap-6 items-center">
        {/* Left Color Visual & Inputs */}
        <div className="md:col-span-6 space-y-4">
          <div
            className="w-full h-36 rounded-2xl border border-gray-200 dark:border-gray-700 shadow-inner flex items-center justify-center transition-colors"
            style={{ backgroundColor: hex }}
          >
            <div className="px-4 py-1.5 rounded-full bg-black/40 backdrop-blur-md text-white font-mono font-bold text-sm">
              {hex.toUpperCase()}
            </div>
          </div>

          <div className="flex items-center gap-3">
            <input
              type="color"
              value={hex}
              onChange={(e) => setHex(e.target.value)}
              className="w-12 h-12 rounded-xl cursor-pointer border-0"
            />
            <input
              type="text"
              value={hex}
              onChange={(e) => setHex(e.target.value)}
              className="flex-1 p-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 font-mono text-sm font-bold uppercase"
            />
            <button
              onClick={generateRandomColor}
              className="px-3.5 py-2.5 bg-gray-100 dark:bg-gray-800 hover:bg-gray-200 dark:hover:bg-gray-700 rounded-xl text-xs font-semibold flex items-center gap-1.5 transition"
            >
              <RefreshCw className="w-4 h-4" />
              لون عشوائي
            </button>
          </div>
        </div>

        {/* Right Formats */}
        <div className="md:col-span-6 space-y-3">
          <div className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200 dark:border-gray-700 flex items-center justify-between">
            <div>
              <span className="text-xs text-gray-500 block">HEX:</span>
              <span className="font-mono text-sm font-bold text-gray-800 dark:text-gray-200">{hex.toUpperCase()}</span>
            </div>
            <button
              onClick={() => copy(hex.toUpperCase(), 'hex')}
              className="p-2 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition"
            >
              {copiedKey === 'hex' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          <div className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200 dark:border-gray-700 flex items-center justify-between">
            <div>
              <span className="text-xs text-gray-500 block">RGB:</span>
              <span className="font-mono text-sm font-bold text-gray-800 dark:text-gray-200">{rgbString}</span>
            </div>
            <button
              onClick={() => copy(rgbString, 'rgb')}
              className="p-2 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition"
            >
              {copiedKey === 'rgb' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>

          <div className="p-3 bg-gray-50 dark:bg-gray-800/60 rounded-xl border border-gray-200 dark:border-gray-700 flex items-center justify-between">
            <div>
              <span className="text-xs text-gray-500 block">HSL:</span>
              <span className="font-mono text-sm font-bold text-gray-800 dark:text-gray-200">{hslString}</span>
            </div>
            <button
              onClick={() => copy(hslString, 'hsl')}
              className="p-2 text-emerald-600 dark:text-emerald-400 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 rounded-lg transition"
            >
              {copiedKey === 'hsl' ? <Check className="w-4 h-4" /> : <Copy className="w-4 h-4" />}
            </button>
          </div>
        </div>
      </div>

      {/* Generated Shade Palette */}
      <div className="space-y-2 pt-2">
        <h4 className="text-xs font-bold text-gray-700 dark:text-gray-300">درجات وتدرجات اللون:</h4>
        <div className="grid grid-cols-7 gap-2">
          {shades.map((shade, i) => (
            <div
              key={i}
              onClick={() => copy(shade, `shade-${i}`)}
              className="h-16 rounded-xl cursor-pointer hover:scale-105 transition-all shadow-xs border border-black/10 flex items-end justify-center pb-1 text-[10px] font-mono text-white font-bold drop-shadow"
              style={{ backgroundColor: shade }}
              title="انقر لنسخ درجة اللون"
            >
              {copiedKey === `shade-${i}` ? '✓' : ''}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
