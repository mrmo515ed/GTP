import React, { useState, useEffect } from 'react';
import { Globe, MapPin, Monitor, Server, Activity, RefreshCw } from 'lucide-react';

interface IpData {
  ip: string;
  city?: string;
  region?: string;
  country_name?: string;
  org?: string;
  version?: string;
}

export function IpInfo() {
  const [ipData, setIpData] = useState<IpData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const fetchIp = async () => {
    setLoading(true);
    setError(false);
    try {
      // Primary: ipapi.co
      let data: any = null;
      try {
        const response = await fetch('https://ipapi.co/json/');
        if (response.ok) {
          data = await response.json();
        }
      } catch {
        // Fallback to ipwho.is or ipify
      }

      if (!data || !data.ip) {
        try {
          const res2 = await fetch('https://ipwho.is/');
          if (res2.ok) {
            const data2 = await res2.json();
            if (data2.success !== false) {
              data = {
                ip: data2.ip,
                city: data2.city,
                region: data2.region,
                country_name: data2.country,
                org: data2.connection?.isp || data2.connection?.org,
                version: data2.type
              };
            }
          }
        } catch {
          // Final fallback: ipify
          const res3 = await fetch('https://api.ipify.org?format=json');
          if (res3.ok) {
            const data3 = await res3.json();
            data = {
              ip: data3.ip,
              city: 'محلي / تم الكشف بنجاح',
              region: '',
              country_name: 'متصل بالإنترنت',
              org: 'مزود خدمة الإنترنت',
              version: 'IPv4'
            };
          }
        }
      }

      if (data && data.ip) {
        setIpData(data);
      } else {
        throw new Error('Could not fetch IP');
      }
    } catch (err) {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchIp();
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center bg-blue-50 dark:bg-blue-950/30 p-4 rounded-2xl border border-blue-100 dark:border-blue-900/50">
        <div className="flex gap-3 text-sm text-blue-800 dark:text-blue-300">
          <Globe className="w-5 h-5 shrink-0" />
          <p className="font-bold">كشف عنوان الـ IP الخاص بك ومعلومات الاتصال بالإنترنت.</p>
        </div>
        <button
          onClick={fetchIp}
          disabled={loading}
          className="p-2 bg-blue-100 hover:bg-blue-200 dark:bg-blue-900/50 dark:hover:bg-blue-800 rounded-lg transition disabled:opacity-50 text-blue-600 dark:text-blue-400"
        >
          <RefreshCw className={`w-4 h-4 ${loading ? 'animate-spin' : ''}`} />
        </button>
      </div>

      {loading ? (
        <div className="flex flex-col items-center justify-center py-12 space-y-4">
          <Activity className="w-10 h-10 text-blue-500 animate-pulse" />
          <p className="text-gray-500 font-bold">جاري كشف المعلومات...</p>
        </div>
      ) : error ? (
        <div className="text-center py-12 text-rose-500 font-bold bg-rose-50 dark:bg-rose-950/20 rounded-3xl border border-rose-100 dark:border-rose-900/30">
          حدث خطأ أثناء جلب المعلومات. ربما تستخدم أداة حجب الإعلانات أو VPN قوي.
        </div>
      ) : ipData ? (
        <div className="grid md:grid-cols-2 gap-6">
          <div className="bg-gradient-to-br from-gray-900 to-gray-800 rounded-3xl p-8 flex flex-col justify-center items-center text-center shadow-xl border border-gray-700">
            <h4 className="text-gray-400 font-bold mb-2">عنوان IP الخاص بك</h4>
            <div className="text-3xl sm:text-4xl font-extrabold font-mono text-white tracking-wider" dir="ltr">
              {ipData.ip}
            </div>
            <div className="mt-4 px-3 py-1 bg-gray-700 rounded-full text-xs font-bold text-gray-300 font-mono">
              IPv{ipData.version === 'IPv6' ? '6' : '4'}
            </div>
          </div>

          <div className="space-y-3">
            <InfoCard icon={<MapPin />} title="الموقع الجغرافي" value={`${ipData.city || 'غير معروف'}، ${ipData.region || ''}، ${ipData.country_name || ''}`} />
            <InfoCard icon={<Server />} title="مزود الخدمة (ISP)" value={ipData.org || 'غير معروف'} />
            <InfoCard icon={<Monitor />} title="المتصفح / النظام" value={navigator.userAgent.split(' ')[0]} />
          </div>
        </div>
      ) : null}
    </div>
  );
}

function InfoCard({ icon, title, value }: { icon: React.ReactElement, title: string, value: string }) {
  return (
    <div className="flex items-center gap-4 bg-gray-50 dark:bg-gray-800/50 p-4 rounded-2xl border border-gray-100 dark:border-gray-700">
      <div className="p-3 bg-white dark:bg-gray-900 rounded-xl text-blue-500 shadow-sm border border-gray-100 dark:border-gray-800">
        {React.cloneElement(icon, { className: 'w-5 h-5' } as React.HTMLAttributes<HTMLElement>)}
      </div>
      <div>
        <h4 className="text-xs font-bold text-gray-500 dark:text-gray-400 mb-1">{title}</h4>
        <p className="text-sm font-bold text-gray-900 dark:text-gray-100" dir="ltr">{value}</p>
      </div>
    </div>
  );
}
