import React, { useState } from 'react';
import { Shuffle, Trash2, ListPlus } from 'lucide-react';
import confetti from 'canvas-confetti';

export function RandomPicker() {
  const [items, setItems] = useState<string[]>(['أحمد', 'محمد', 'سارة', 'فاطمة', 'علي']);
  const [input, setInput] = useState('');
  const [winner, setWinner] = useState<string | null>(null);
  const [isPicking, setIsPicking] = useState(false);

  const addItem = (e: React.FormEvent) => {
    e.preventDefault();
    if (input.trim() && !items.includes(input.trim())) {
      setItems([...items, input.trim()]);
      setInput('');
      setWinner(null);
    }
  };

  const removeLast = () => {
    setItems(items.slice(0, -1));
    setWinner(null);
  };

  const clearAll = () => {
    setItems([]);
    setWinner(null);
  };

  const pickRandom = () => {
    if (items.length < 2) return;
    setIsPicking(true);
    setWinner(null);
    
    // Simulate thinking
    let count = 0;
    const interval = setInterval(() => {
      setWinner(items[Math.floor(Math.random() * items.length)]);
      count++;
      if (count > 20) {
        clearInterval(interval);
        const finalWinner = items[Math.floor(Math.random() * items.length)];
        setWinner(finalWinner);
        setIsPicking(false);
        confetti({
          particleCount: 100,
          spread: 70,
          origin: { y: 0.6 },
          colors: ['#3b82f6', '#10b981', '#f59e0b', '#ef4444']
        });
      }
    }, 100);
  };

  return (
    <div className="space-y-6">
      <div className="grid md:grid-cols-2 gap-6">
        <div className="space-y-4">
          <form onSubmit={addItem} className="flex gap-2">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="أدخل اسماً أو خياراً..."
              className="flex-1 px-4 py-3 rounded-xl border border-gray-200 dark:border-gray-700 bg-gray-50 dark:bg-gray-900 outline-none focus:border-indigo-500"
            />
            <button
              type="submit"
              disabled={!input.trim()}
              className="px-4 py-3 bg-indigo-600 text-white rounded-xl hover:bg-indigo-700 disabled:opacity-50 transition"
            >
              <ListPlus className="w-5 h-5" />
            </button>
          </form>

          <div className="bg-white dark:bg-gray-800 border border-gray-100 dark:border-gray-700 rounded-2xl overflow-hidden shadow-sm">
            <div className="p-3 border-b border-gray-100 dark:border-gray-700 flex justify-between items-center bg-gray-50 dark:bg-gray-900/50">
              <span className="font-bold text-sm text-gray-600 dark:text-gray-400">الخيارات ({items.length})</span>
              <button onClick={clearAll} className="text-xs text-rose-500 hover:underline flex items-center gap-1">
                <Trash2 className="w-3 h-3" /> مسح الكل
              </button>
            </div>
            <div className="max-h-60 overflow-y-auto p-2 flex flex-wrap gap-2">
              {items.map((item, idx) => (
                <div key={idx} className="bg-indigo-50 dark:bg-indigo-900/30 text-indigo-800 dark:text-indigo-300 px-3 py-1.5 rounded-lg text-sm font-bold flex items-center gap-2 border border-indigo-100 dark:border-indigo-800">
                  {item}
                  <button onClick={() => setItems(items.filter((_, i) => i !== idx))} className="text-indigo-400 hover:text-rose-500 transition">
                    &times;
                  </button>
                </div>
              ))}
              {items.length === 0 && (
                <div className="w-full text-center py-8 text-gray-400 text-sm">القائمة فارغة. أضف بعض الخيارات.</div>
              )}
            </div>
          </div>
        </div>

        <div className="flex flex-col space-y-4">
          <div className="flex-1 bg-gradient-to-br from-indigo-50 to-purple-50 dark:from-indigo-950/20 dark:to-purple-950/20 border border-indigo-100 dark:border-indigo-900/30 rounded-3xl p-8 flex flex-col items-center justify-center min-h-[200px]">
            {winner ? (
              <div className="text-center space-y-2">
                <h4 className="text-sm font-bold text-indigo-500 uppercase tracking-widest">{isPicking ? 'جاري الاختيار...' : 'الفائز هو'}</h4>
                <div className={`text-4xl md:text-5xl font-extrabold text-indigo-700 dark:text-indigo-400 ${isPicking ? 'animate-pulse' : 'scale-110 transition-transform'}`}>
                  {winner}
                </div>
              </div>
            ) : (
              <div className="text-gray-400 dark:text-gray-500 flex flex-col items-center gap-3">
                <Shuffle className="w-12 h-12 opacity-50" />
                <p className="text-sm font-bold">أضف خيارات واضغط على الزر أدناه</p>
              </div>
            )}
          </div>
          
          <button
            onClick={pickRandom}
            disabled={items.length < 2 || isPicking}
            className="w-full py-4 bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-300 dark:disabled:bg-gray-700 text-white font-bold text-lg rounded-2xl shadow-lg transition-all active:scale-95 flex justify-center items-center gap-2"
          >
            <Shuffle className="w-5 h-5" />
            اختيار عشوائي
          </button>
        </div>
      </div>
    </div>
  );
}
