import React, { useEffect, useState, useRef } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, Star, Share2, ShieldCheck, Target, ArrowRight, Home, Check, Folder } from 'lucide-react';
import { ALL_TOOLS, CATEGORIES } from '../../data/toolsData';
import { useSEO } from '../../hooks/useSEO';
import { ToolRenderer } from '../tools/ToolRenderer';
import { ToolErrorBoundary } from '../tools/ToolErrorBoundary';
import { CompactRelatedToolCard } from '../layout/CompactRelatedToolCard';
import { AdSlot } from '../ads/AdSlot';
import { AD_COOLDOWN_MS, INSTANT_TOOL_DELAY_MS, triggerToolActionAd } from '../../utils/adsterraManager';

interface ToolPageProps {
  favorites: string[];
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onToolUse: (id: string) => void;
}

// Only result-producing controls count as tool usage; tabs, navigation and settings do not.
const MEANINGFUL_ACTION_PATTERN = /تحويل|ضغط|حساب|احسب|إنشاء|توليد|تنزيل|تحميل|نسخ|استخراج|تحليل|معالجة|بدء|تشغيل|دمج|تقسيم|فك|حفظ|تصدير|إزالة|تحسين|convert|compress|calculate|generate|download|copy|extract|analy[sz]e|process|create|merge|split|export|save/i;

export function ToolPage({ favorites, onToggleFavorite, onToolUse }: ToolPageProps) {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const [copied, setCopied] = useState(false);
  
  const tool = ALL_TOOLS.find((t) => t.id === id);
  const isFavorite = id ? favorites.includes(id) : false;
  const categoryInfo = tool ? CATEGORIES.find((c) => c.id === tool.category) : null;
  const isInstantTool = tool?.badge === 'فوري';

  // Dynamic SEO & Search Engines Structured Data
  useSEO({
    title: tool ? `${tool.titleAr} | أونلاين مجاناً` : 'الأداة غير موجودة',
    description: tool?.descriptionAr || 'أداة مجانية وسريعة أونلاين في المتصفح بدون تسجيل وبدون رفع ملفات.',
    keywords: tool ? [...tool.tags, tool.titleAr, tool.titleEn, 'أدواتك السريعة', 'مجانا', 'أونلاين', 'محاكي', 'حاسبة'] : [],
    canonicalUrl: `https://adwatuk-alsariea.netlify.app/tool/${tool?.id || id}`,
    ogType: 'article',
    structuredData: tool ? [
      {
        '@context': 'https://schema.org',
        '@type': 'SoftwareApplication',
        'name': tool.titleAr,
        'alternateName': tool.titleEn,
        'description': tool.descriptionAr,
        'url': `https://adwatuk-alsariea.netlify.app/tool/${tool.id}`,
        'applicationCategory': tool.category === 'surgery-3d' || tool.category === 'health' ? 'MedicalApplication' : 'UtilitiesApplication',
        'operatingSystem': 'All',
        'browserRequirements': 'Requires JavaScript. Requires HTML5.',
        'offers': {
          '@type': 'Offer',
          'price': '0',
          'priceCurrency': 'USD'
        },
        'featureList': tool.tags.join(', ')
      },
      {
        '@context': 'https://schema.org',
        '@type': 'BreadcrumbList',
        'itemListElement': [
          {
            '@type': 'ListItem',
            'position': 1,
            'name': 'الرئيسية',
            'item': 'https://adwatuk-alsariea.netlify.app/'
          },
          ...(categoryInfo ? [{
            '@type': 'ListItem',
            'position': 2,
            'name': categoryInfo.nameAr,
            'item': `https://adwatuk-alsariea.netlify.app/category/${categoryInfo.id}`
          }] : []),
          {
            '@type': 'ListItem',
            'position': categoryInfo ? 3 : 2,
            'name': tool.titleAr,
            'item': `https://adwatuk-alsariea.netlify.app/tool/${tool.id}`
          }
        ]
      }
    ] : undefined
  });

  const toolContainerRef = useRef<HTMLDivElement>(null);
  const pendingActionRef = useRef(false);
  const onToolUseRef = useRef(onToolUse);
  useEffect(() => {
    onToolUseRef.current = onToolUse;
  }, [onToolUse]);

  useEffect(() => {
    window.scrollTo(0, 0);
    if (id && onToolUseRef.current) {
      onToolUseRef.current(id);
    }
  }, [id]);

  // Show the ad only when a real result is added, never when processing starts.
  useEffect(() => {
    pendingActionRef.current = false;
    const root = toolContainerRef.current;
    if (!root || !id) return;

    const successPattern = /اكتمل[^\n]{0,80}بنجاح|تم[^\n]{0,80}بنجاح|النتيجة جاهزة للتحميل|تم إنشاء[^\n]{0,80}بنجاح|تم توليد[^\n]{0,80}بنجاح/i;
    const finish = () => {
      if (!pendingActionRef.current) return;
      pendingActionRef.current = false;
      triggerToolActionAd(`tool_result:${id}`);
    };
    const observer = new MutationObserver(mutations => {
      if (!pendingActionRef.current) return;
      for (const mutation of mutations) {
        if (mutation.type === 'attributes') {
          const element = mutation.target as Element;
          if (element.matches?.('a[download][href], button') && /تحميل النتيجة|تنزيل.*نتيجة|تحميل.*ملف/i.test(element.textContent || '')) {
            finish();
            return;
          }
        }
        const changedText = mutation.type === 'characterData'
          ? mutation.target.textContent || ''
          : Array.from(mutation.addedNodes).map(node => node.textContent || '').join(' ');
        const addedResult = mutation.type === 'childList' && Array.from(mutation.addedNodes).some(node => {
          if (!(node instanceof Element)) return false;
          return node.matches('a[download][href]') || Boolean(node.querySelector('a[download][href]')) || /تحميل النتيجة|تنزيل جميع الملفات/.test(node.textContent || '');
        });
        if (addedResult || successPattern.test(changedText)) {
          finish();
          return;
        }
      }
    });
    observer.observe(root, { subtree: true, childList: true, characterData: true, attributes: true, attributeFilter: ['href', 'download'] });
    return () => observer.disconnect();
  }, [id]);

  // Instant-result tools show one ad cycle only after a full visible minute in that tool.
  useEffect(() => {
    if (!id || !isInstantTool) return;

    let remaining = INSTANT_TOOL_DELAY_MS;
    let startedAt = Date.now();
    let timer: number | undefined;

    const startTimer = () => {
      startedAt = Date.now();
      timer = window.setTimeout(() => {
        triggerToolActionAd(`instant_tool:${id}`);
        remaining = AD_COOLDOWN_MS;
        startTimer();
      }, remaining);
    };
    const pauseTimer = () => {
      if (timer) window.clearTimeout(timer);
      remaining = Math.max(0, remaining - (Date.now() - startedAt));
    };
    const handleVisibility = () => {
      if (document.visibilityState === 'hidden') pauseTimer();
      else startTimer();
    };

    if (document.visibilityState === 'visible') startTimer();
    document.addEventListener('visibilitychange', handleVisibility);
    return () => {
      if (timer) window.clearTimeout(timer);
      document.removeEventListener('visibilitychange', handleVisibility);
    };
  }, [id, isInstantTool]);

  const handleMeaningfulToolAction = (event: React.MouseEvent<HTMLDivElement>) => {
    if (!id) return;
    const target = event.target as HTMLElement;
    const control = target.closest<HTMLElement>('button, a[download], [role="button"], input[type="submit"]');
    if (!control || control.hasAttribute('disabled') || control.closest('[data-ad-ignore="true"]')) return;

    const label = [control.textContent, control.getAttribute('aria-label'), control.getAttribute('title')]
      .filter(Boolean)
      .join(' ')
      .trim();
    const isSubmit = control instanceof HTMLInputElement && control.type === 'submit';
    const isDownload = control instanceof HTMLAnchorElement && control.hasAttribute('download');

    if (isSubmit || isDownload || MEANINGFUL_ACTION_PATTERN.test(label)) {
      pendingActionRef.current = true;
      // Download/copy means the result already exists; other actions wait for a success mutation.
      if (isDownload || /تحميل النتيجة|تنزيل جميع الملفات|نسخ|copy result/i.test(label)) {
        window.setTimeout(() => {
          if (pendingActionRef.current) {
            pendingActionRef.current = false;
            triggerToolActionAd(`tool_result:${id}`);
          }
        }, 0);
      }
    }
  };

  const handleShareTool = async () => {
    // Canonical production URL as requested
    const siteUrl = `https://adwatuk-alsariea.netlify.app/tool/${tool?.id || id}`;
    
    // Copy the site URL to clipboard
    navigator.clipboard.writeText(siteUrl);
    setCopied(true);
    try {
      const confetti = (await import('canvas-confetti')).default;
      confetti({ particleCount: 30, spread: 50, origin: { y: 0.8 } });
    } catch {}
    setTimeout(() => setCopied(false), 3000);
  };

  const handleToolSelect = (selectedTool: typeof tool) => {
    if (selectedTool) {
      navigate(`/tool/${selectedTool.id}`);
    }
  };

  if (!tool) {
    return (
      <div className="py-32 text-center space-y-4">
        <h2 className="text-2xl font-bold font-heading">الأداة غير موجودة</h2>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition"
        >
          <Home className="w-4 h-4" />
          العودة للرئيسية
        </Link>
      </div>
    );
  }

  // Get related tools (same category, exclude current tool, up to 6 tools for compact square tiles)
  const relatedTools = ALL_TOOLS.filter((t) => t.category === tool.category && t.id !== tool.id).slice(0, 6);

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full space-y-6"
    >
      
      {/* Top Breadcrumb & Actions */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-white dark:bg-gray-900 p-4 sm:p-5 rounded-2xl border border-gray-200 dark:border-gray-800 shadow-xs">
        <div className="flex items-center gap-2.5 min-w-0 flex-wrap sm:flex-nowrap">
          <Link
            to="/"
            className="p-1.5 text-gray-500 hover:text-emerald-600 dark:text-gray-400 dark:hover:text-emerald-400 hover:bg-emerald-50/50 dark:hover:bg-gray-800 rounded-lg transition flex items-center gap-1 text-xs font-bold shrink-0"
            title="الرئيسية"
          >
            <Home className="w-3.5 h-3.5" />
            <span>الرئيسية</span>
          </Link>
          
          <ChevronRight className="w-3.5 h-3.5 text-gray-400 shrink-0" />

          {categoryInfo && (
            <>
              <Link
                to={`/category/${categoryInfo.id}`}
                className="p-1.5 text-gray-500 hover:text-emerald-600 dark:text-gray-400 dark:hover:text-emerald-400 hover:bg-emerald-50/50 dark:hover:bg-gray-800 rounded-lg transition flex items-center gap-1 text-xs font-bold shrink-0"
                title={`قسم ${categoryInfo.nameAr}`}
              >
                <Folder className="w-3.5 h-3.5 text-emerald-600 dark:text-emerald-400" />
                <span>{categoryInfo.nameAr}</span>
              </Link>
              <ChevronRight className="w-3.5 h-3.5 text-gray-400 shrink-0" />
            </>
          )}

          <div className="min-w-0">
            <div className="flex items-center gap-2">
              <h1 className="font-heading font-extrabold text-base sm:text-lg text-gray-900 dark:text-white truncate">
                {tool.titleAr}
              </h1>
              {tool.badge && (
                <span className="px-2 py-0.5 text-[10px] font-bold rounded-md bg-emerald-100 text-emerald-800 dark:bg-emerald-950 dark:text-emerald-300 hidden md:inline shrink-0">
                  {tool.badge}
                </span>
              )}
            </div>
          </div>
        </div>
        
        {/* Action buttons */}
        <div className="flex items-center gap-2 shrink-0 self-end sm:self-auto">
          <button
            onClick={(e) => onToggleFavorite(tool.id, e)}
            className={`p-2 rounded-xl transition flex items-center gap-1.5 text-xs font-bold ${
              isFavorite
                ? 'bg-amber-50 dark:bg-amber-950/50 text-amber-500 border border-amber-200 dark:border-amber-800/50'
                : 'text-gray-500 hover:text-amber-500 bg-gray-50 dark:bg-gray-800 hover:bg-amber-50/50'
            }`}
            title={isFavorite ? 'إزالة من المفضلة' : 'حفظ في المفضلة'}
          >
            <Star className={`w-4 h-4 ${isFavorite ? 'fill-current' : ''}`} />
            <span className="hidden md:inline">{isFavorite ? 'مفضلة' : 'حفظ'}</span>
          </button>

          <button
            onClick={handleShareTool}
            className={`px-3 py-2 rounded-xl transition flex items-center gap-1.5 text-xs font-bold ${
              copied
                ? 'bg-emerald-600 text-white shadow-xs'
                : 'text-gray-600 dark:text-gray-300 hover:text-emerald-600 bg-gray-50 dark:bg-gray-800 hover:bg-emerald-50/50 dark:hover:bg-gray-700'
            }`}
            title="نسخ ومشاركة الرابط"
          >
            {copied ? (
              <>
                <Check className="w-4 h-4" />
                <span>تم نسخ الرابط!</span>
              </>
            ) : (
              <>
                <Share2 className="w-4 h-4" />
                <span>مشاركة</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Copied Notification Toast Banner */}
      {copied && (
        <div className="p-3 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/60 text-emerald-800 dark:text-emerald-200 rounded-xl text-xs font-bold flex items-center justify-between shadow-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <Check className="w-4 h-4 text-emerald-600" />
            <span>تم نسخ رابط الأداة للمشاركة: <span className="font-mono underline" dir="ltr">https://adwatuk-alsariea.netlify.app/tool/{tool.id}</span></span>
          </div>
        </div>
      )}

      {/* Top In-Tool Ad Banner */}
      <AdSlot type="in-tool-top" slotId="3019283746" />

      {/* Main Tool Container */}
      <div
        ref={toolContainerRef}
        className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl shadow-xs overflow-hidden"
        onClickCapture={handleMeaningfulToolAction}
      >
        <div className="p-4 sm:p-8">
          <ToolErrorBoundary key={tool.id} toolName={tool.titleAr}>
            <ToolRenderer toolId={tool.id} />
          </ToolErrorBoundary>
        </div>
        {/* Privacy Footer */}
        <div className="px-6 py-4 bg-gray-50 dark:bg-gray-800/60 border-t border-gray-100 dark:border-gray-800 text-[11px] text-gray-500 dark:text-gray-400 flex flex-wrap items-center justify-between gap-2">
          <div className="flex items-center gap-1.5 text-emerald-600 dark:text-emerald-400 font-semibold">
            <ShieldCheck className="w-4 h-4" />
            <span>تتم معالجة البيانات بأمان محلياً في جهازك - لا نرسل بياناتك لأي خادم</span>
          </div>
          <span>منصة أدواتك السريعة</span>
        </div>
      </div>

      {/* Back to Home & Category Navigation Buttons */}
      <div className="flex flex-wrap items-center justify-center gap-3 pt-2">
        {categoryInfo && (
          <Link
            to={`/category/${categoryInfo.id}`}
            className="flex items-center gap-2 px-6 py-3 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 text-emerald-700 dark:text-emerald-300 rounded-xl font-bold hover:bg-emerald-100/70 transition-colors shadow-xs text-sm"
          >
            <Folder className="w-4 h-4" />
            <span>تصفح باقي أدوات ({categoryInfo.nameAr})</span>
          </Link>
        )}

        <Link
          to="/"
          className="flex items-center gap-2 px-6 py-3 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 rounded-xl font-bold hover:bg-gray-50 dark:hover:bg-gray-700/80 transition-colors shadow-xs text-sm"
        >
          <Home className="w-4 h-4" />
          <span>الخروج إلى الرئيسية (كافة الأقسام)</span>
        </Link>
      </div>

      {/* Related Tools Section - Compact Square Boxes */}
      {relatedTools.length > 0 && (
        <div className="pt-6 border-t border-gray-200 dark:border-gray-800">
          <div className="flex items-center justify-between mb-3.5">
            <h3 className="font-heading font-extrabold text-sm sm:text-base text-gray-900 dark:text-white flex items-center gap-2">
              <Folder className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>أدوات ذات صلة في قسم ({categoryInfo?.nameAr})</span>
            </h3>
            {categoryInfo && (
              <Link
                to={`/category/${categoryInfo.id}`}
                className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
              >
                <span>عرض الكل</span>
                <ArrowRight className="w-3 h-3" />
              </Link>
            )}
          </div>
          
          {/* Mini Compact Square Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-6 gap-2.5 sm:gap-3">
            {relatedTools.map((relatedTool) => (
              <CompactRelatedToolCard
                key={relatedTool.id}
                tool={relatedTool}
                onSelect={handleToolSelect}
              />
            ))}
          </div>
        </div>
      )}

      {/* Bottom In-Tool Ad Banner */}
      <AdSlot type="in-tool-bottom" slotId="8472910394" />
    </motion.div>
  );
}
