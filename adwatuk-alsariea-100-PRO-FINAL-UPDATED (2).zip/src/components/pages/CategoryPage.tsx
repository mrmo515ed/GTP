import React, { useMemo } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'motion/react';
import { ALL_TOOLS, CATEGORIES } from '../../data/toolsData';
import { ToolCategory, ToolDefinition } from '../../types';
import { useSEO } from '../../hooks/useSEO';
import { ToolCard } from '../layout/ToolCard';
import { AdSlot } from '../ads/AdSlot';
import { CategoryHeroBanner } from '../layout/CategoryHeroBanner';
import {
  ArrowRight,
  Home,
  Layers,
  Sparkles,
  SearchX,
  Type,
  Image as ImageIcon,
  Calculator,
  ArrowRightLeft,
  Code2,
  Stethoscope,
  GraduationCap,
  Compass,
  FileText,
  Star,
  Flame,
} from 'lucide-react';

interface CategoryPageProps {
  favorites: string[];
  onToggleFavorite: (id: string, e: React.MouseEvent) => void;
  onSelectTool: (tool: ToolDefinition) => void;
  searchQuery: string;
}

export function CategoryPage({
  favorites,
  onToggleFavorite,
  onSelectTool,
  searchQuery,
}: CategoryPageProps) {
  const { categoryId } = useParams<{ categoryId: string }>();
  const navigate = useNavigate();

  const category = CATEGORIES.find((c) => c.id === categoryId);

  // Dynamic SEO for Category Page
  useSEO({
    title: category ? `قسم ${category.nameAr} | أدوات أونلاين مجانية` : 'تصنيف الأدوات',
    description: category?.descriptionAr || 'استعرض حزمة أدوات مميزة وسريعة أونلاين في المتصفح.',
    canonicalUrl: `https://adwatuk-alsariea.netlify.app/category/${categoryId}`,
    ogType: 'website',
  });

  const getCategoryIcon = (id?: string) => {
    switch (id) {
      case 'text':
        return Type;
      case 'image':
        return ImageIcon;
      case 'calculators':
        return Calculator;
      case 'units':
        return ArrowRightLeft;
      case 'dev':
        return Code2;
      case 'health':
        return Stethoscope;
      case 'student':
        return GraduationCap;
      case 'discovery':
        return Compass;
      case 'engineering':
        return Compass;
      case 'pdf':
        return FileText;
      case 'favorites':
        return Star;
      case 'new':
        return Sparkles;
      case 'popular':
        return Flame;
      default:
        return Layers;
    }
  };

  const tools = useMemo(() => {
    if (!categoryId) return [];

    return ALL_TOOLS.filter((tool) => {
      // Category Match
      if (categoryId === 'favorites') {
        if (!favorites.includes(tool.id)) return false;
      } else if (categoryId === 'new') {
        if (tool.badge !== 'جديد') return false;
      } else if (categoryId === 'popular') {
        if (tool.badge !== 'شائع' && !tool.isPopular) return false;
      } else if (categoryId !== 'all' && tool.category !== categoryId) {
        return false;
      }

      // Search match
      if (searchQuery.trim()) {
        const q = searchQuery.toLowerCase().trim();
        const matchesTitle = tool.titleAr.toLowerCase().includes(q);
        const matchesDesc = tool.descriptionAr.toLowerCase().includes(q);
        const matchesKeywords =
          (tool.tags || []).some((k) => k.toLowerCase().includes(q)) ||
          (tool.keywords || []).some((k) => k.toLowerCase().includes(q));
        if (!matchesTitle && !matchesDesc && !matchesKeywords) {
          return false;
        }
      }

      return true;
    });
  }, [categoryId, favorites, searchQuery]);

  if (!category && categoryId !== 'new' && categoryId !== 'popular') {
    return (
      <div className="max-w-4xl mx-auto px-4 py-20 text-center space-y-4">
        <h2 className="text-2xl font-bold font-heading">القسم غير موجود</h2>
        <p className="text-sm text-gray-500">لم يتم العثور على هذا التصنيف</p>
        <Link
          to="/"
          className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-xl font-bold hover:bg-emerald-700 transition"
        >
          <Home className="w-4 h-4" />
          الرجوع للصفحة الرئيسية
        </Link>
      </div>
    );
  }

  const Icon = getCategoryIcon(categoryId);
  const categoryTitle =
    category?.nameAr || (categoryId === 'new' ? 'آخر الأدوات المضافة' : 'أعلى الأدوات استخداماً');
  const categoryDesc =
    category?.descriptionAr ||
    (categoryId === 'new'
      ? 'استعرض أحدث الأدوات والميزات التي تمت إضافتها للمنصة'
      : 'الأدوات الأكثر استخداماً وشهرة بين المستخدمين');

  // Other categories for quick navigation
  const otherCategories = CATEGORIES.filter(
    (c) => c.id !== 'all' && c.id !== categoryId && c.id !== 'favorites'
  );

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -15 }}
      transition={{ duration: 0.3, ease: 'easeOut' }}
      className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 w-full space-y-8"
    >
      
      {/* Category Header Banner with Return Button */}
      <CategoryHeroBanner
        categoryId={(categoryId as ToolCategory) || 'health'}
        toolsCount={tools.length}
        onBackToHome={() => navigate('/')}
        onSelectAnotherCategory={(cat) => navigate(`/category/${cat}`)}
      />

      {/* Category Top Banner */}
      <AdSlot type="top-leaderboard" className="my-2" label="إعلان مميز • إعلانات تدعم استمرارية المنصة" />

      {/* Tools Section Header & Filter Status */}
      <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 pt-2 border-b border-gray-200/60 dark:border-gray-800/60 pb-3">
        <div className="flex items-center gap-2 font-bold text-gray-800 dark:text-gray-200 text-sm">
          <Layers className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
          <span>الأدوات المتاحة داخل هذا القسم ({tools.length})</span>
        </div>
        
        <Link
          to="/"
          className="inline-flex items-center gap-1 text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline"
        >
          <Home className="w-3.5 h-3.5" />
          <span>الرئيسية</span>
        </Link>
      </div>

      {/* Tools Grid */}
      {tools.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
          {tools.map((tool) => (
            <ToolCard
              key={tool.id}
              tool={tool}
              isFavorite={favorites.includes(tool.id)}
              onToggleFavorite={onToggleFavorite}
              onSelect={onSelectTool}
            />
          ))}
        </div>
      ) : (
        <div className="py-20 text-center space-y-4 bg-white dark:bg-gray-900 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 p-8">
          <SearchX className="w-12 h-12 text-gray-400 mx-auto" />
          <h3 className="text-lg font-bold text-gray-800 dark:text-gray-200">
            لا توجد أدوات مطابقة في هذا القسم
          </h3>
          <p className="text-xs text-gray-500 max-w-sm mx-auto">
            يمكنك العودة إلى القائمة الرئيسية أو تصفح باقي الأقسام الأخرى.
          </p>
          <Link
            to="/"
            className="inline-flex items-center gap-2 px-5 py-2.5 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-emerald-700 transition"
          >
            <ArrowRight className="w-4 h-4" />
            الرجوع لكافة الأقسام
          </Link>
        </div>
      )}

      {/* Quick Navigation to other categories */}
      <div className="pt-8 border-t border-gray-200 dark:border-gray-800 space-y-6">
        {/* Category Bottom Banner */}
        <AdSlot type="in-tool-bottom" className="my-2" label="إعلان • استكشف المزيد من الأدوات" />

        <h3 className="text-base font-heading font-extrabold text-gray-900 dark:text-white">
          تصفح أقسام وتصنيفات أخرى
        </h3>
        <div className="flex flex-wrap gap-2">
          {otherCategories.map((cat) => {
            const CatIcon = getCategoryIcon(cat.id);
            const count = ALL_TOOLS.filter((t) => t.category === cat.id).length;
            return (
              <button
                key={cat.id}
                onClick={() => navigate(`/category/${cat.id}`)}
                className="px-4 py-2 bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 hover:border-emerald-500 dark:hover:border-emerald-500 rounded-xl text-xs font-bold text-gray-700 dark:text-gray-300 hover:text-emerald-600 dark:hover:text-emerald-400 transition-all flex items-center gap-2 shadow-xs"
              >
                <CatIcon className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                <span>{cat.nameAr}</span>
                <span className="text-[10px] text-gray-400 font-medium">({count})</span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Bottom Exit Button */}
      <div className="flex justify-center pt-6">
        <Link
          to="/"
          className="flex items-center gap-2 px-8 py-3.5 bg-white dark:bg-gray-800 border-2 border-emerald-600/30 hover:border-emerald-600 text-emerald-700 dark:text-emerald-400 rounded-2xl font-extrabold hover:bg-emerald-50 dark:hover:bg-gray-700/80 transition-all shadow-sm text-sm"
        >
          <Home className="w-5 h-5" />
          <span>الخروج إلى الصفحة الرئيسية</span>
        </Link>
      </div>

    </motion.div>
  );
}
