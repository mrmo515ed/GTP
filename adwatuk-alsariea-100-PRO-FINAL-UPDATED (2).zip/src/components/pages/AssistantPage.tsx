import React, { useState, useEffect, useRef } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { motion, AnimatePresence } from 'motion/react';
import { marked } from 'marked';
import { useSEO } from '../../hooks/useSEO';
import { AdSlot } from '../ads/AdSlot';
import {
  Bot,
  User,
  Sparkles,
  Send,
  RotateCcw,
  ArrowRight,
  ExternalLink,
  Sliders,
  Check,
  Search,
  Zap,
  HelpCircle,
  Clock,
  Heart,
  ChevronRight,
  MessageSquare,
  Wand2,
  Copy,
  Share2,
  Trash2,
  Terminal,
  Activity,
  Layers,
  Flame,
  Volume2,
  VolumeX,
  Code2,
  Cpu,
  Brain,
  Globe,
  Calculator,
  Stethoscope,
  Atom,
  RefreshCw,
  Maximize2,
  Minimize2,
  PanelRightClose,
  PanelRightOpen
} from 'lucide-react';
import { ALL_TOOLS, CATEGORIES } from '../../data/toolsData';
import { ToolDefinition } from '../../types';

interface ChatMessage {
  id: string;
  sender: 'user' | 'assistant';
  text: string;
  matchedTools?: ToolDefinition[];
  quickActions?: { label: string; action: string }[];
  calculationResult?: string;
  timestamp: string;
}

const INITIAL_MESSAGES: ChatMessage[] = [
  {
    id: 'msg-welcome',
    sender: 'assistant',
    text: `مرحباً بك في **الروبوت الذكي الخارق** لمنصة «أدواتك السريعة» 🤖✨!

أنا هنا للإجابة عن **أي سؤال يخطر على بالك في أي مجال**:
• 🧠 **العلوم، الطب، والجراحة 3D:** تشريح الأعضاء، التفاعلات الحيوية، وشرح العمليات.
• 🧮 **الرياضيات والحسابات:** حل المعادلات، حساب BMI، النسب المئوية، والتحويلات.
• 💻 **البرمجة والتطوير:** كتابة وتصحيح الأكواد، شرح الخوارزميات، وشرح قواعد البيانات.
• 🌐 **الثقافة العامة والإنتاجية:** ترجمة، تلخيص، وصياغة النصوص، وتوجيهك لأكثر من 160 أداة فورية.

بماذا ترغب أن نبدأ الآن؟`,
    quickActions: [
      { label: '🩺 محاكي جراحة القلب 3D', action: 'أريد أدوات الجراحة والتشريح ثلاثية الأبعاد 3D' },
      { label: '⚖️ احسب مؤشر كتلة الجسم BMI', action: 'احسب لي BMI لوزن 75 كجم وطول 178 سم' },
      { label: '🧬 ما هو جزيء ATP وكيف ينتج الطاقة؟', action: 'ما هو جزيء ATP وكيف ينتج الطاقة في الخلية؟' },
      { label: '💻 كود React لرفع وتحويل الصور', action: 'اكتب لي كود React كامل لرفع الصور وتحويل صيغتها' },
      { label: '🤖 كاشف نصوص الذكاء الاصطناعي', action: 'أريد أداة كشف النصوص المولدة بالذكاء الاصطناعي' }
    ],
    timestamp: 'الآن'
  }
];

const SUGGESTED_TOPICS = [
  {
    category: 'الطب والجراحة والتشريح 3D',
    icon: Stethoscope,
    color: 'text-rose-500 bg-rose-50 dark:bg-rose-950/40 border-rose-200 dark:border-rose-800',
    questions: [
      'أريد محاكي جراحة القلب المفتوح 3D',
      'ما هي جراحة استبدال مفصل الركبة TKA؟',
      'كيف تجرى جراحة استئصال المرارة بالمنظار؟',
      'اشرح تشريح فصوص الدماغ وجذع المخ بالتفصيل'
    ]
  },
  {
    category: 'الرياضيات والمعادلات والحسابات',
    icon: Calculator,
    color: 'text-amber-500 bg-amber-50 dark:bg-amber-950/40 border-amber-200 dark:border-amber-800',
    questions: [
      'احسب لي وزني المثالي لطول 170 سم',
      'كيف أحسب النسبة المئوية من مبلغ معين؟',
      'حل المعادلة التربيعية x^2 - 5x + 6 = 0',
      'حاسبة التخفيف الصيدلاني C1V1 = C2V2'
    ]
  },
  {
    category: 'البرمجة وتطوير البرمجيات',
    icon: Code2,
    color: 'text-indigo-500 bg-indigo-50 dark:bg-indigo-950/40 border-indigo-200 dark:border-indigo-800',
    questions: [
      'كيف يعمل خوارزمية البحث الثنائي Binary Search؟',
      'اكتب دالة بلغة JavaScript لتشفير النصوص Base64',
      'ما الفرق بين REST API و GraphQL؟',
      'كيف أحسن سرعة موقع React مع Vite و Tailwind؟'
    ]
  },
  {
    category: 'العلوم والكيمياء والفيزياء',
    icon: Atom,
    color: 'text-emerald-500 bg-emerald-50 dark:bg-emerald-950/40 border-emerald-200 dark:border-emerald-800',
    questions: [
      'ما هو دور الأدينوسين ثلاثي الفوسفات ATP؟',
      'اشرح قوانين نيوتن للحركة وتطبيقاتها',
      'كيف تتشكل الروابط التساهمية والأيونية؟',
      'ما هو التفاعل الإنزيمي في دورة كريبس؟'
    ]
  }
];

export function AssistantPage() {
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();
  const initialQuery = searchParams.get('q') || '';

  const [messages, setMessages] = useState<ChatMessage[]>(() => {
    try {
      const saved = localStorage.getItem('adwatuk_full_assistant_history');
      if (saved) return JSON.parse(saved);
    } catch {}
    return INITIAL_MESSAGES;
  });

  const [inputVal, setInputVal] = useState<string>(initialQuery);
  const [isTyping, setIsTyping] = useState<boolean>(false);
  const [responseDetailLevel, setResponseDetailLevel] = useState<'concise' | 'balanced' | 'detailed'>('balanced');
  const [copiedId, setCopiedId] = useState<string | null>(null);
  const [speakingId, setSpeakingId] = useState<string | null>(null);
  const [toolSearchQuery, setToolSearchQuery] = useState<string>('');
  const [isFullScreen, setIsFullScreen] = useState<boolean>(true);
  const [showSidebar, setShowSidebar] = useState<boolean>(false);

  // SEO & Structured Data for AI Assistant
  useSEO({
    title: 'المساعد الذكي وروبوت المحادثة الخارق | Gemini AI',
    description: 'شات بوت ومساعد ذكي متقدم للإجابة عن الاستفسارات العلمية والطبية والبرمجية وحل المعادلات واقتراح أدوات الموقع بدقة متناهية.',
    keywords: ['مساعد ذكي', 'روبوت محادثة', 'شات بوت', 'ذكاء اصطناعي', 'chatgpt', 'gemini', 'مساعد ادواتك السريعة', 'حل معادلات', 'طب 3d'],
    canonicalUrl: 'https://adwatuk-alsariea.netlify.app/assistant',
    ogType: 'website',
    structuredData: {
      '@context': 'https://schema.org',
      '@type': 'WebApplication',
      'name': 'المساعد الذكي وروبوت المحادثة الفوري',
      'description': 'صفحة محادثة ذكية متكاملة للإجابة عن الاستفسارات وحل المعادلات الحسابية والطبية.',
      'url': 'https://adwatuk-alsariea.netlify.app/assistant',
      'applicationCategory': 'UtilitiesApplication',
      'operatingSystem': 'All',
      'offers': {
        '@type': 'Offer',
        'price': '0',
        'priceCurrency': 'USD'
      }
    }
  });

  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLTextAreaElement>(null);

  // Configure marked options
  useEffect(() => {
    marked.setOptions({
      breaks: true,
      gfm: true
    });
  }, []);

  // Auto-save history
  useEffect(() => {
    try {
      localStorage.setItem('adwatuk_full_assistant_history', JSON.stringify(messages));
    } catch {}
  }, [messages]);

  // Scroll to bottom when messages update
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, isTyping]);

  // Auto send if provided in query string
  useEffect(() => {
    if (initialQuery && messages.length <= 1) {
      handleSendMessage(initialQuery);
    }
  }, []);

  // Stop speech when component unmounts
  useEffect(() => {
    return () => {
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
    };
  }, []);

  // Semantic Tool Matcher
  const findMatchingTools = (query: string): ToolDefinition[] => {
    const q = query.toLowerCase().trim();
    const matches: { tool: ToolDefinition; score: number }[] = [];

    ALL_TOOLS.forEach((tool) => {
      let score = 0;
      const title = tool.titleAr.toLowerCase();
      const titleEn = (tool.titleEn || '').toLowerCase();
      const desc = tool.descriptionAr.toLowerCase();
      const tags = (tool.tags || []).map((t) => t.toLowerCase());
      const keywords = (tool.keywords || []).map((k) => k.toLowerCase());

      if (title.includes(q)) score += 60;
      if (titleEn.includes(q)) score += 40;
      if (tags.some((t) => q.includes(t) || t.includes(q))) score += 35;
      if (keywords.some((k) => q.includes(k) || k.includes(q))) score += 25;
      if (desc.includes(q)) score += 15;

      // Specific intent boost
      if ((q.includes('ai') || q.includes('ذكاء') || q.includes('كشف')) && tool.id === 'ai-text-detector') score += 120;
      if ((q.includes('atp') || q.includes('كيمياء') || q.includes('تفاعل') || q.includes('حيوي')) && (tool.id === 'chemical-reactions-lab' || tool.id === 'biochem-lab' || tool.id === 'human-body-reactions')) score += 120;
      if ((q.includes('وزن') || q.includes('طول') || q.includes('bmi') || q.includes('كتلة')) && (tool.id === 'health-calculator' || tool.id === 'ideal-weight-calc')) score += 120;
      if ((q.includes('قلب') || q.includes('قسطرة') || q.includes('شريان')) && (tool.id === 'heart-surgery-3d' || tool.id === 'surgical-anatomy-3d-suite')) score += 120;
      if ((q.includes('مخ') || q.includes('دماغ') || q.includes('أعصاب')) && (tool.id === 'brain-surgery-3d' || tool.id === 'surgical-anatomy-3d-suite')) score += 120;
      if ((q.includes('عين') || q.includes('ليزك') || q.includes('مياه بيضاء')) && (tool.id === 'eye-surgery-3d' || tool.id === 'surgical-anatomy-3d-suite')) score += 120;
      if ((q.includes('ركبة') || q.includes('مفصل') || q.includes('غضروف')) && (tool.id === 'knee-replacement-3d' || tool.id === 'surgical-anatomy-3d-suite')) score += 120;
      if ((q.includes('مرارة') || q.includes('منظار') || q.includes('كبد')) && (tool.id === 'laparoscopy-cholecystectomy-3d' || tool.id === 'surgical-anatomy-3d-suite')) score += 120;
      if ((q.includes('عمود فقري') || q.includes('انزلاق') || q.includes('غضروفي') || q.includes('فقرات')) && (tool.id === 'spine-disc-surgery-3d' || tool.id === 'surgical-anatomy-3d-suite')) score += 120;
      if ((q.includes('pdf') || q.includes('بي دي اف')) && (tool.id === 'pdf-tools-suite' || tool.id === 'pdf-merger')) score += 90;
      if ((q.includes('صورة') || q.includes('ضغط') || q.includes('تحويل')) && (tool.id === 'image-compressor' || tool.id === 'image-converter')) score += 90;
      if ((q.includes('كود') || q.includes('برمجة') || q.includes('محرر')) && (tool.id === 'code-editor-suite' || tool.id === 'web-playground')) score += 90;

      if (score > 0) {
        matches.push({ tool, score });
      }
    });

    matches.sort((a, b) => b.score - a.score);
    return matches.slice(0, 4).map((m) => m.tool);
  };

  // Text-To-Speech Toggle
  const handleToggleSpeech = (msgId: string, rawText: string) => {
    if (!('speechSynthesis' in window)) return;

    if (speakingId === msgId) {
      window.speechSynthesis.cancel();
      setSpeakingId(null);
      return;
    }

    window.speechSynthesis.cancel();
    // Clean markdown symbols for natural speech
    const cleanText = rawText
      .replace(/[#*`_~>\[\]\(\)\$]/g, '')
      .replace(/https?:\/\/\S+/g, '')
      .slice(0, 600);

    const utterance = new SpeechSynthesisUtterance(cleanText);
    utterance.lang = 'ar-SA';
    utterance.rate = 1.0;
    utterance.pitch = 1.0;

    utterance.onend = () => setSpeakingId(null);
    utterance.onerror = () => setSpeakingId(null);

    setSpeakingId(msgId);
    window.speechSynthesis.speak(utterance);
  };

  // Chat Execution Logic (Calls server-side Gemini AI with local fallback)
  const handleSendMessage = async (textToSend?: string) => {
    const query = (textToSend || inputVal).trim();
    if (!query) return;

    const userMsg: ChatMessage = {
      id: `usr-${Date.now()}`,
      sender: 'user',
      text: query,
      timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputVal('');
    setIsTyping(true);

    const matchedTools = findMatchingTools(query);

    try {
      // Call Full-Stack Server API with Gemini 3.7 Flash
      const response = await fetch('/api/chat', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          message: query,
          history: messages.slice(-10).map((m) => ({ sender: m.sender, text: m.text })),
          detailLevel: responseDetailLevel
        })
      });

      if (response.ok) {
        const data = await response.json();
        const replyText = data.reply || 'تم استلام طلبك بنجاح.';

        const botMsg: ChatMessage = {
          id: `ast-${Date.now()}`,
          sender: 'assistant',
          text: replyText,
          matchedTools: matchedTools.length > 0 ? matchedTools : undefined,
          quickActions: [
            { label: '🩺 غرفة العمليات 3D', action: 'أريد أدوات الجراحة 3D' },
            { label: '⚖️ حاسبة السعرات والوزن', action: 'احسب لي وزني المثالي' },
            { label: '🧪 مختبر التفاعلات الكيميائية', action: 'ما هي أهم تفاعلات الكيمياء الحيوية؟' },
            { label: '📁 أدوات تعديل ودمج PDF', action: 'أريد أدوات تعديل ملفات PDF' }
          ],
          timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
        };

        setMessages((prev) => [...prev, botMsg]);
        setIsTyping(false);
        return;
      }
    } catch (e) {
      console.warn('Backend chat API failed, executing client fallback:', e);
    }

    // Local Intelligent Client Fallback
    setTimeout(() => {
      const qLower = query.toLowerCase();
      let responseText = '';
      let calcResult: string | undefined = undefined;

      // Check for BMI query
      const weightMatch = query.match(/(\d+(\.\d+)?)\s*(كجم|كغ|كيلو|kg|وزن)/i) || query.match(/وزن\s*(\d+(\.\d+)?)/i);
      const heightMatch = query.match(/(\d+(\.\d+)?)\s*(سم|cm|طول)/i) || query.match(/طول\s*(\d+(\.\d+)?)/i);

      if (weightMatch && heightMatch) {
        const weight = parseFloat(weightMatch[1]);
        const height = parseFloat(heightMatch[1]);
        const heightM = height > 3 ? height / 100 : height;
        if (weight > 0 && heightM > 0) {
          const bmi = (weight / (heightM * heightM)).toFixed(1);
          let category = '';
          let advice = '';
          const bmiNum = parseFloat(bmi);

          if (bmiNum < 18.5) {
            category = 'نقص في الوزن (Underweight)';
            advice = 'يُنصح بزيادة السعرات الحرارية الصحية وتناول وجبات متوازنة غنية بالبروتينات.';
          } else if (bmiNum < 25) {
            category = 'وزن طبيعي وصحي (Normal)';
            advice = 'ممتاز! وزنك مثالي ومناسب لطولك. حافظ على التغذية السليمة والنشاط الرياضي.';
          } else if (bmiNum < 30) {
            category = 'زيادة في الوزن (Overweight)';
            advice = 'يُفضل ممارسة رياضة معتدلة مثل المشي السريع 30 دقيقة يومياً وضبط السكريات والدهون.';
          } else {
            category = 'سمنة (Obese)';
            advice = 'يُوصى باستشارة أخصائي تغذية لوضع خطة غذائية متوازنة وممارسة التمارين الرياضية بانتظام.';
          }

          calcResult = `مؤشر كتلة الجسم (BMI): ${bmi} كجم/م²\nالتصنيف الصحي: ${category}`;
          responseText = `بناءً على المعطيات (الوزن: ${weight} كجم، الطول: ${height > 3 ? height + ' سم' : height * 100 + ' سم'}):\n\n📊 **النتيجة المحسوبة:**\n• مؤشر كتلة الجسم (BMI): **${bmi}** كجم/م²\n• التصنيف: **${category}**\n\n💡 **التوصية:**\n${advice}\n\nيمكنك استخدام أداة حاسبة الصحة والوزن المتخصصة للحصول على تقارير وافية عن نسبة الدهون واحتياج السعرات والماء.`;
        }
      } else if (qLower.includes('atp') || qLower.includes('طاقة') || qLower.includes('أدينوسين') || qLower.includes('ميتوكوندريا')) {
        responseText = `🧬 **ما هو جزيء ATP (Adenosine Triphosphate)؟**\n\nهو المركب الكيميائي الرئيسي الذي تستخدمه الخلايا لتخزين ونقل الطاقة الكيميائية اللازمة لكافة الوظائف الحيوية مثل انقباض العضلات، نقل الإشارات العصبية، والتفاعلات البنائية.\n\n⚡ **كيف يعمل وينتج الطاقة؟**\n1. يتكون الجزيء من قاعدة الأدينين + سكر الريبوز + 3 مجموعات فوسفات.\n2. الرابطة بين مجموعتي الفوسفات الثانية والثالثة رابطة عالية الطاقة ($~P$).\n3. عند حاجة الخلية للطاقة، يتم الحلمهة المائية: $\\text{ATP} + \\text{H}_2\\text{O} \\rightarrow \\text{ADP} + \\text{P}_i + 7.3\\text{ kcal/mol}$.\n4. يتم إعادة شحن ATP في **الميتوكوندريا** عبر التنفس الخلوي والفسفرة التأكسدية.`;
      } else if (
        qLower.includes('جراحة') ||
        qLower.includes('تشريح') ||
        qLower.includes('عمليات') ||
        qLower.includes('قلب') ||
        qLower.includes('مخ') ||
        qLower.includes('عين') ||
        qLower.includes('ركبة') ||
        qLower.includes('منظار') ||
        qLower.includes('عمود فقري')
      ) {
        responseText = `🏥 **غرفة العمليات الذكية والمجسمات التشريحية ثلاثية الأبعاد 3D:**\n\nتضم المنصة أحدث أطلس جراحي تفاعلي ثلاثي الأبعاد يمكنك من خلاله:\n• **جراحة القلب المفتوح والقسطرة:** استعراض الأذينين، البطينين، والشرايين التاجية ومحاكاة الدعامات.\n• **جراحة أورام المخ والتحفيز العميق (DBS):** استعراض فصوص المخ، وجذع الدماغ.\n• **جراحة العيون والليزك:** القرنية، العدسة والشبكية ومحاكاة إزالة المياه البيضاء.\n• **استبدال مفصل الركبة (TKA):** عظام الفخذ والساق والغضاريف ومحاكاة زراعة مفصل التيتانيوم.\n• **استئصال المرارة بالمنظار (Laparoscopy):** منافذ التروكار وكاميرا 4K ومثلث كالوت.\n• **جراحة العمود الفقري (Spine):** الفقرات القطنية L4-L5 وتحرير العصب وتثبيت المسامير التيتانيوم.`;
      } else {
        responseText = `شكراً لسؤالك حول **«${query}»** 💡!\n\nأنا هنا لمساعدتك في كل ما يتعلق بالإنتاجية، الحسابات، التحويلات، التشريح 3D، البرمجة، والكيمياء. يمكنك النقر على إحدى الأدوات المقترحة أدناه أو إخباري بما ترغب في إنجازه وسأوجهك فوراً!`;
      }

      const botMsg: ChatMessage = {
        id: `ast-${Date.now()}`,
        sender: 'assistant',
        text: responseText,
        matchedTools: matchedTools.length > 0 ? matchedTools : undefined,
        calculationResult: calcResult,
        quickActions: [
          { label: '🩺 غرفة العمليات 3D', action: 'أريد أدوات الجراحة 3D' },
          { label: '⚖️ حاسبة السعرات والوزن', action: 'احسب لي وزني المثالي' },
          { label: '🧪 مختبر التفاعلات الكيميائية', action: 'ما هي أهم تفاعلات الكيمياء الحيوية؟' },
          { label: '📁 أدوات تعديل ودمج PDF', action: 'أريد أدوات تعديل ملفات PDF' }
        ],
        timestamp: new Date().toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit' })
      };

      setMessages((prev) => [...prev, botMsg]);
      setIsTyping(false);
    }, 400);
  };

  const handleClearHistory = () => {
    if (window.confirm('هل أنت متأكد من رغبتك في مسح سجل المحادثة بالكامل؟')) {
      setMessages(INITIAL_MESSAGES);
      localStorage.removeItem('adwatuk_full_assistant_history');
      if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
      }
      setSpeakingId(null);
    }
  };

  const handleCopyMessage = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const filteredToolsList = ALL_TOOLS.filter((t) => {
    if (!toolSearchQuery) return true;
    const q = toolSearchQuery.toLowerCase();
    return (
      t.titleAr.toLowerCase().includes(q) ||
      t.descriptionAr.toLowerCase().includes(q) ||
      (t.tags || []).some((tag) => tag.toLowerCase().includes(q))
    );
  }).slice(0, 18);

  return (
    <div className={`flex flex-col bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-gray-100 ${isFullScreen ? 'h-screen overflow-hidden' : 'min-h-screen'}`}>
      {/* Top Page Header Bar */}
      <header className="sticky top-0 z-30 bg-white/95 dark:bg-gray-900/95 backdrop-blur-md border-b border-gray-200/80 dark:border-gray-800 shadow-2xs shrink-0">
        <div className="w-full max-w-(--breakpoint-2xl) mx-auto px-3 sm:px-6 h-16 flex items-center justify-between gap-3">
          <div className="flex items-center gap-2.5 sm:gap-3 min-w-0">
            <button
              onClick={() => navigate('/')}
              className="p-2 rounded-xl text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 transition flex items-center gap-1.5 text-xs font-bold shrink-0"
              title="العودة للرئيسية"
            >
              <ArrowRight className="w-5 h-5" />
              <span className="hidden sm:inline">الرئيسية</span>
            </button>

            <div className="h-6 w-px bg-gray-200 dark:bg-gray-800 hidden sm:block shrink-0" />

            <div className="flex items-center gap-2.5 min-w-0">
              <div className="w-9 h-9 rounded-2xl bg-gradient-to-tr from-emerald-600 via-teal-600 to-indigo-600 flex items-center justify-center text-white shadow-md shadow-emerald-500/20 shrink-0">
                <Bot className="w-5 h-5 animate-pulse" />
              </div>
              <div className="min-w-0">
                <div className="flex items-center gap-2">
                  <h1 className="font-heading font-black text-sm sm:text-base text-gray-900 dark:text-white truncate">
                    الروبوت الذكي الخارق
                  </h1>
                  <span className="hidden xs:inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 shrink-0">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-ping" />
                    Gemini 3.7
                  </span>
                </div>
                <p className="text-[11px] text-gray-500 dark:text-gray-400 hidden md:block truncate">
                  واجهة محادثة ذكية متكاملة وممتدة تملأ الشاشة
                </p>
              </div>
            </div>
          </div>

          {/* Top Actions */}
          <div className="flex items-center gap-1.5 sm:gap-2 shrink-0">
            {/* Detail mode switcher */}
            <div className="hidden sm:flex items-center gap-1 p-1 bg-gray-100 dark:bg-gray-800 rounded-xl text-xs font-semibold">
              <button
                onClick={() => setResponseDetailLevel('concise')}
                className={`px-2.5 py-1 rounded-lg transition ${
                  responseDetailLevel === 'concise'
                    ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-2xs font-bold'
                    : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
                }`}
              >
                موجز
              </button>
              <button
                onClick={() => setResponseDetailLevel('balanced')}
                className={`px-2.5 py-1 rounded-lg transition ${
                  responseDetailLevel === 'balanced'
                    ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-2xs font-bold'
                    : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
                }`}
              >
                متوازن
              </button>
              <button
                onClick={() => setResponseDetailLevel('detailed')}
                className={`px-2.5 py-1 rounded-lg transition ${
                  responseDetailLevel === 'detailed'
                    ? 'bg-white dark:bg-gray-700 text-emerald-600 dark:text-emerald-400 shadow-2xs font-bold'
                    : 'text-gray-500 hover:text-gray-800 dark:hover:text-gray-200'
                }`}
              >
                مفصل
              </button>
            </div>

            {/* Sidebar Toggle for Quick Tools */}
            <button
              onClick={() => setShowSidebar(!showSidebar)}
              className={`p-2 rounded-xl text-xs font-bold transition flex items-center gap-1.5 border ${
                showSidebar
                  ? 'bg-emerald-50 text-emerald-700 border-emerald-300 dark:bg-emerald-950/60 dark:text-emerald-300 dark:border-emerald-800'
                  : 'bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 border-gray-200 dark:border-gray-700 hover:bg-gray-50'
              }`}
              title={showSidebar ? 'إخفاء القائمة الجانبية' : 'عرض المواضيع والأدوات المقترحة'}
            >
              {showSidebar ? <PanelRightClose className="w-4 h-4" /> : <PanelRightOpen className="w-4 h-4" />}
              <span className="hidden lg:inline">{showSidebar ? 'إخفاء الأدوات' : 'أدوات مقترحة'}</span>
            </button>

            {/* Fullscreen view toggle */}
            <button
              onClick={() => setIsFullScreen(!isFullScreen)}
              className="p-2 rounded-xl text-gray-600 dark:text-gray-300 bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 hover:bg-gray-100 dark:hover:bg-gray-700 transition"
              title={isFullScreen ? 'تصغير العرض' : 'عرض ملء الشاشة'}
            >
              {isFullScreen ? <Minimize2 className="w-4 h-4" /> : <Maximize2 className="w-4 h-4" />}
            </button>

            <button
              onClick={handleClearHistory}
              className="p-2 rounded-xl text-gray-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/40 border border-gray-200 dark:border-gray-700 transition"
              title="مسح سجل المحادثة"
            >
              <Trash2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </header>

      {/* Top Banner on Assistant Page */}
      <div className="w-full max-w-(--breakpoint-2xl) mx-auto px-2 sm:px-4 shrink-0">
        <AdSlot type="top-leaderboard" className="my-1.5" label="إعلان مميز • يدعم استمرارية المساعد الذكي" />
      </div>

      {/* Main Full-Screen Layout */}
      <div className={`flex-1 w-full flex flex-col overflow-hidden ${isFullScreen ? 'h-[calc(100vh-140px)]' : 'min-h-[calc(100vh-140px)]'}`}>
        <div className="flex-1 w-full max-w-(--breakpoint-2xl) mx-auto px-2 sm:px-4 lg:px-6 py-2 sm:py-3 flex gap-4 overflow-hidden">
          
          {/* Main Chat Box - Stretches to fill full screen */}
          <div className="flex-1 flex flex-col bg-white dark:bg-gray-900 border border-gray-200/80 dark:border-gray-800 rounded-2xl sm:rounded-3xl shadow-sm overflow-hidden h-full">
            
            {/* Chat Messages Container */}
            <div className="flex-1 p-3 sm:p-6 overflow-y-auto space-y-5">
              <AnimatePresence initial={false}>
                {messages.map((msg) => {
                  const isAssistant = msg.sender === 'assistant';

                  return (
                    <motion.div
                      key={msg.id}
                      initial={{ opacity: 0, y: 8, scale: 0.99 }}
                      animate={{ opacity: 1, y: 0, scale: 1 }}
                      transition={{ duration: 0.2, ease: 'easeOut' }}
                      className={`flex gap-2.5 sm:gap-4 ${isAssistant ? 'justify-start' : 'justify-end flex-row-reverse'}`}
                    >
                      {/* Avatar */}
                      <div
                        className={`w-8 h-8 sm:w-9 sm:h-9 rounded-2xl flex items-center justify-center shrink-0 shadow-xs ${
                          isAssistant
                            ? 'bg-gradient-to-tr from-emerald-600 to-teal-500 text-white ring-2 ring-emerald-500/20'
                            : 'bg-gradient-to-tr from-indigo-600 to-purple-600 text-white ring-2 ring-indigo-500/20'
                        }`}
                      >
                        {isAssistant ? <Bot className="w-4 h-4 sm:w-5 sm:h-5" /> : <User className="w-4 h-4 sm:w-5 sm:h-5" />}
                      </div>

                      {/* Message Bubble Content */}
                      <div className={`max-w-[95%] sm:max-w-[85%] lg:max-w-[80%] flex flex-col ${isAssistant ? 'items-start' : 'items-end'}`}>
                        <div
                          className={`p-3.5 sm:p-5 rounded-2xl sm:rounded-3xl shadow-2xs text-sm leading-relaxed ${
                            isAssistant
                              ? 'bg-gray-100/90 dark:bg-gray-800/90 text-gray-900 dark:text-gray-100 rounded-tr-xs border border-gray-200/60 dark:border-gray-700/60'
                              : 'bg-emerald-600 text-white rounded-tl-xs font-medium'
                          }`}
                        >
                          {isAssistant ? (
                            <div
                              className="prose dark:prose-invert max-w-none text-sm sm:text-base space-y-2 prose-p:leading-relaxed prose-headings:font-bold prose-headings:text-emerald-700 dark:prose-headings:text-emerald-300 prose-pre:bg-gray-900 prose-pre:text-emerald-400 prose-pre:rounded-xl prose-code:text-emerald-600 dark:prose-code:text-emerald-300"
                              dangerouslySetInnerHTML={{ __html: marked.parse(msg.text, { async: false }) as string }}
                            />
                          ) : (
                            <div className="whitespace-pre-wrap text-sm sm:text-base">{msg.text}</div>
                          )}

                          {/* Calculation Result Highlight Box */}
                          {msg.calculationResult && (
                            <div className="mt-3 p-3 bg-emerald-50 dark:bg-emerald-950/60 border border-emerald-200 dark:border-emerald-800/80 rounded-xl text-emerald-800 dark:text-emerald-200 font-bold text-xs">
                              {msg.calculationResult}
                            </div>
                          )}
                        </div>

                        {/* Matched Tools Cards Carousel */}
                        {msg.matchedTools && msg.matchedTools.length > 0 && (
                          <div className="mt-3 w-full space-y-2">
                            <div className="flex items-center gap-1.5 text-xs font-bold text-gray-500 dark:text-gray-400 px-1">
                              <Wand2 className="w-3.5 h-3.5 text-emerald-600" />
                              <span>الأدوات المباشرة المقترحة:</span>
                            </div>
                            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                              {msg.matchedTools.map((tool) => (
                                <button
                                  key={tool.id}
                                  onClick={() => navigate(`/tool/${tool.id}`)}
                                  className="group flex items-start gap-2.5 p-2.5 bg-white dark:bg-gray-800 hover:bg-emerald-50/80 dark:hover:bg-emerald-950/40 border border-gray-200 dark:border-gray-700 hover:border-emerald-400 dark:hover:border-emerald-600 rounded-2xl text-right transition-all shadow-2xs hover:shadow-md"
                                >
                                  <div className="w-8 h-8 rounded-xl bg-emerald-100 dark:bg-emerald-950 text-emerald-600 dark:text-emerald-400 flex items-center justify-center shrink-0 group-hover:scale-105 transition-transform">
                                    <Zap className="w-4 h-4" />
                                  </div>
                                  <div className="flex-1 min-w-0">
                                    <div className="flex items-center justify-between gap-1">
                                      <h4 className="text-xs font-black text-gray-900 dark:text-white truncate group-hover:text-emerald-600 dark:group-hover:text-emerald-400">
                                        {tool.titleAr}
                                      </h4>
                                      <ExternalLink className="w-3.5 h-3.5 text-gray-400 group-hover:text-emerald-600 shrink-0" />
                                    </div>
                                    <p className="text-[11px] text-gray-500 dark:text-gray-400 line-clamp-2 mt-0.5">
                                      {tool.descriptionAr}
                                    </p>
                                  </div>
                                </button>
                              ))}
                            </div>
                          </div>
                        )}

                        {/* Quick Follow-up Actions */}
                        {msg.quickActions && msg.quickActions.length > 0 && (
                          <div className="flex flex-wrap gap-1.5 mt-2.5">
                            {msg.quickActions.map((qa, i) => (
                              <button
                                key={i}
                                onClick={() => handleSendMessage(qa.action)}
                                className="px-3 py-1 text-xs font-semibold bg-white dark:bg-gray-800 hover:bg-emerald-50 dark:hover:bg-emerald-950/60 text-gray-700 dark:text-gray-300 hover:text-emerald-600 dark:hover:text-emerald-400 border border-gray-200/80 dark:border-gray-700/80 hover:border-emerald-300 dark:hover:border-emerald-700 rounded-xl transition shadow-2xs active:scale-95"
                              >
                                {qa.label}
                              </button>
                            ))}
                          </div>
                        )}

                        {/* Footer / Copy / Voice / Timestamp */}
                        <div className="flex items-center gap-3 mt-1.5 px-1 text-[10px] text-gray-400">
                          <span>{msg.timestamp}</span>
                          {isAssistant && (
                            <>
                              <button
                                onClick={() => handleCopyMessage(msg.id, msg.text)}
                                className="hover:text-gray-600 dark:hover:text-gray-200 transition flex items-center gap-1"
                                title="نسخ الإجابة"
                              >
                                {copiedId === msg.id ? (
                                  <>
                                    <Check className="w-3 h-3 text-emerald-500" />
                                    <span className="text-emerald-500 font-bold">تم النسخ</span>
                                  </>
                                ) : (
                                  <>
                                    <Copy className="w-3 h-3" />
                                    <span>نسخ</span>
                                  </>
                                )}
                              </button>

                              {'speechSynthesis' in window && (
                                <button
                                  onClick={() => handleToggleSpeech(msg.id, msg.text)}
                                  className={`transition flex items-center gap-1 ${
                                    speakingId === msg.id ? 'text-emerald-600 font-bold' : 'hover:text-gray-600 dark:hover:text-gray-200'
                                  }`}
                                  title={speakingId === msg.id ? 'إيقاف القراءة الصوتية' : 'قراءة صوتية للإجابة'}
                                >
                                  {speakingId === msg.id ? (
                                    <>
                                      <VolumeX className="w-3.5 h-3.5 text-emerald-600 animate-pulse" />
                                      <span>إيقاف الصوت</span>
                                    </>
                                  ) : (
                                    <>
                                      <Volume2 className="w-3.5 h-3.5" />
                                      <span>استماع</span>
                                    </>
                                  )}
                                </button>
                              )}
                            </>
                          )}
                        </div>
                      </div>
                    </motion.div>
                  );
                })}
              </AnimatePresence>

              {/* Typing Indicator */}
              {isTyping && (
                <div className="flex gap-3 items-center">
                  <div className="w-8 h-8 sm:w-9 sm:h-9 rounded-2xl bg-emerald-600 text-white flex items-center justify-center">
                    <Bot className="w-4 h-4 sm:w-5 sm:h-5 animate-spin" />
                  </div>
                  <div className="p-3.5 bg-gray-100 dark:bg-gray-800 rounded-2xl rounded-tr-xs flex items-center gap-1.5 border border-gray-200 dark:border-gray-700">
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '0ms' }} />
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '150ms' }} />
                    <span className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce" style={{ animationDelay: '300ms' }} />
                    <span className="text-xs text-gray-500 dark:text-gray-400 mr-2 font-bold">جارٍ التفكير والإجابة...</span>
                  </div>
                </div>
              )}

              <div ref={messagesEndRef} />
            </div>

            {/* Sticky Input Area */}
            <div className="shrink-0 p-3 sm:p-4 bg-gray-50/95 dark:bg-gray-900/95 border-t border-gray-200 dark:border-gray-800">
              <div className="relative flex items-end gap-2 bg-white dark:bg-gray-800 rounded-2xl border border-gray-200 dark:border-gray-700 focus-within:border-emerald-500 focus-within:ring-2 focus-within:ring-emerald-500/20 shadow-inner transition p-2">
                <textarea
                  ref={inputRef}
                  value={inputVal}
                  onChange={(e) => setInputVal(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="اسألني أي شيء (طب، برمجة، حسابات، علوم، أو شروحات لأدوات الموقع)..."
                  rows={2}
                  className="flex-1 bg-transparent border-0 resize-none p-1.5 sm:p-2 text-sm text-gray-900 dark:text-gray-100 placeholder-gray-400 focus:outline-hidden"
                />
                <button
                  onClick={() => handleSendMessage()}
                  disabled={!inputVal.trim() || isTyping}
                  className="p-3 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-xl shadow-md shadow-emerald-500/20 disabled:opacity-40 disabled:cursor-not-allowed transition transform active:scale-95 shrink-0"
                  title="إرسال"
                >
                  <Send className="w-5 h-5" />
                </button>
              </div>
              <div className="flex items-center justify-between mt-2 px-1 text-[11px] text-gray-400">
                <span className="hidden sm:inline">اضغط Enter للإرسال، و Shift + Enter لسطر جديد</span>
                <span className="flex items-center gap-1 text-emerald-600 dark:text-emerald-400 font-bold">
                  <Brain className="w-3.5 h-3.5" />
                  ذكاء اصطناعي فائق (Gemini 3.7)
                </span>
              </div>
            </div>
          </div>

          {/* Collapsible Sidebar (Guides & Tools) */}
          {showSidebar && (
            <div className="w-80 lg:w-96 shrink-0 h-full overflow-y-auto space-y-4 hidden md:block">
              {/* Quick Topics Card */}
              <div className="bg-white dark:bg-gray-900 border border-gray-200/80 dark:border-gray-800 rounded-3xl p-4 shadow-sm space-y-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Sparkles className="w-4 h-4 text-amber-500" />
                    <h3 className="font-heading font-black text-sm text-gray-900 dark:text-white">
                      مواضيع مقترحة
                    </h3>
                  </div>
                </div>

                <div className="space-y-3">
                  {SUGGESTED_TOPICS.map((topic, idx) => {
                    const IconComponent = topic.icon;
                    return (
                      <div key={idx} className="space-y-1.5">
                        <div className="flex items-center gap-1.5">
                          <IconComponent className="w-3.5 h-3.5 text-gray-500" />
                          <span className={`px-2 py-0.5 text-[10px] font-black rounded-md border ${topic.color}`}>
                            {topic.category}
                          </span>
                        </div>
                        <div className="space-y-1">
                          {topic.questions.map((q, qIdx) => (
                            <button
                              key={qIdx}
                              onClick={() => handleSendMessage(q)}
                              className="w-full text-right p-1.5 text-xs text-gray-700 dark:text-gray-300 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 hover:text-emerald-600 dark:hover:text-emerald-400 rounded-xl transition flex items-center justify-between group"
                            >
                              <span className="truncate">{q}</span>
                              <ChevronRight className="w-3.5 h-3.5 text-gray-400 group-hover:text-emerald-600 shrink-0" />
                            </button>
                          ))}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>

              {/* Quick Search Tool Finder */}
              <div className="bg-white dark:bg-gray-900 border border-gray-200/80 dark:border-gray-800 rounded-3xl p-4 shadow-sm space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Search className="w-4 h-4 text-emerald-600" />
                    <h3 className="font-heading font-black text-sm text-gray-900 dark:text-white">
                      بحث الأدوات
                    </h3>
                  </div>
                  <span className="text-[10px] font-bold px-2 py-0.5 bg-gray-100 dark:bg-gray-800 rounded-md text-gray-500">
                    {ALL_TOOLS.length} أداة
                  </span>
                </div>

                <input
                  type="text"
                  value={toolSearchQuery}
                  onChange={(e) => setToolSearchQuery(e.target.value)}
                  placeholder="ابحث عن أداة..."
                  className="w-full px-3 py-1.5 text-xs bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl text-gray-900 dark:text-gray-100 placeholder-gray-400 focus:outline-hidden focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500"
                />

                <div className="space-y-1 max-h-48 overflow-y-auto pr-1">
                  {filteredToolsList.map((tool) => (
                    <button
                      key={tool.id}
                      onClick={() => navigate(`/tool/${tool.id}`)}
                      className="w-full flex items-center justify-between p-1.5 rounded-xl text-right hover:bg-gray-50 dark:hover:bg-gray-800/80 transition group border border-transparent hover:border-gray-200 dark:hover:border-gray-700"
                    >
                      <div className="flex items-center gap-2 min-w-0">
                        <div className="w-5 h-5 rounded-lg bg-emerald-100 dark:bg-emerald-950 text-emerald-600 flex items-center justify-center shrink-0 text-[9px] font-bold">
                          ⚡
                        </div>
                        <span className="text-xs font-bold text-gray-800 dark:text-gray-200 truncate group-hover:text-emerald-600">
                          {tool.titleAr}
                        </span>
                      </div>
                      <ExternalLink className="w-3 h-3 text-gray-400 group-hover:text-emerald-600 shrink-0" />
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

        </div>
      </div>

      {/* Bottom Banner on Assistant Page */}
      <div className="w-full max-w-(--breakpoint-2xl) mx-auto px-2 sm:px-4 shrink-0">
        <AdSlot type="in-tool-bottom" className="my-1.5" label="إعلان • استكشف المزيد من الأدوات" />
      </div>
    </div>
  );
}

