import { ToolDefinition, CategoryInfo } from '../types';

export const CATEGORIES: CategoryInfo[] = [
  { id: "home", nameAr: "الرئيسية", nameEn: "Home", icon: "Home", descriptionAr: "الأقسام المميزة والأدوات الأكثر استخداماً" },
  { id: "all", nameAr: "جميع الأقسام والأدوات", nameEn: "All Tools & Sections", icon: "LayoutGrid", descriptionAr: "دليل شامل يعرض كافة الأقسام والأدوات بالكامل في صفحة واحدة" },
  { id: "popular", nameAr: "الأكثر استخداماً", nameEn: "Most Popular", icon: "Flame", descriptionAr: "الأدوات الأكثر شعبية والأعلى طلباً" },
  { id: "surgery-3d", nameAr: "الجراحة وتشريح الأعضاء 3D", nameEn: "3D Surgery & Anatomy", icon: "HeartPulse", descriptionAr: "غرفة العمليات الذكية وجراحة الأعضاء والمفاصل ثلاثية الأبعاد" },
  { id: "health", nameAr: "الصحة والطب والكيمياء", nameEn: "Health & Medical", icon: "Stethoscope", descriptionAr: "حاسبات طبية، كيمياء حيوية، فصائل الدم وتوازن الأحماض" },
  { id: "calculators", nameAr: "الحاسبات والمالية", nameEn: "Calculators & Finance", icon: "Calculator", descriptionAr: "حسابات مالية، زكاة، قروض، ضرائب، ونسب مئوية" },
  { id: "text", nameAr: "معالجة النصوص", nameEn: "Text Tools", icon: "Type", descriptionAr: "تنسيق ومقارنة وعد النصوص وتحويل الصيغ" },
  { id: "image", nameAr: "الصور والوسائط", nameEn: "Image Tools", icon: "Image", descriptionAr: "تعديل، ضغط، استخراج ألوان، وتحويل صيغ الصور" },
  { id: "design", nameAr: "التصميم والألوان CSS", nameEn: "Design & CSS", icon: "Palette", descriptionAr: "أكواد الألوان، الظلال، تباين WCAG، والمخططات" },
  { id: "pdf", nameAr: "المستندات و PDF", nameEn: "Documents & PDF", icon: "FileText", descriptionAr: "تحويل ودمج وتقسيم ملفات PDF والمستندات" },
  { id: "data", nameAr: "البيانات والجداول", nameEn: "Data & Tables", icon: "Table", descriptionAr: "تحويل جداول Excel, CSV, SQL والرسوم البيانية" },
  { id: "time-date", nameAr: "الوقت والتقويم والتاريخ", nameEn: "Time & Calendar", icon: "Clock", descriptionAr: "ساعة إيقاف، بومودورو، تحويل هجري وميلادي وفوارق زمنية" },
  { id: "student", nameAr: "الطلاب والتعليم", nameEn: "Student & Education", icon: "GraduationCap", descriptionAr: "حساب المعدل التراكمي GPA، تفقيط الأرقام والقرعة" },
  { id: "social", nameAr: "السوشيال ميديا وصناع المحتوى", nameEn: "Social Media", icon: "Share2", descriptionAr: "توليد الهاشتاقات، البايو، مقاسات المنشورات واليوزرات" },
  { id: "units", nameAr: "محولات الوحدات والقياس", nameEn: "Units Converter", icon: "ArrowRightLeft", descriptionAr: "محولات قياس الطول، الوزن، الحرارة والسرعة" },
  { id: "currencies", nameAr: "العملات والصرف", nameEn: "Currencies", icon: "Coins", descriptionAr: "محول العملات العالمية والعملات الرقمية" },
  { id: "audio", nameAr: "الصوتيات", nameEn: "Audio Tools", icon: "Music", descriptionAr: "تحويل ملفات الصوت MP3, WAV, AAC وتقطيع الصوت" },
  { id: "video", nameAr: "الفيديو والمونتاج", nameEn: "Video Tools", icon: "Video", descriptionAr: "تحويل الفيديو واستخراج الصوت وصناعة GIF" },
  { id: "archives", nameAr: "الأرشيف وضغط الملفات", nameEn: "Archives & ZIP", icon: "Archive", descriptionAr: "ضغط وإنشاء وفك ملفات ZIP" },
  { id: "dev", nameAr: "أدوات المطورين والبرمجة", nameEn: "Developer Tools", icon: "TerminalSquare", descriptionAr: "أدوات برمجية، فحص الروابط، HTTP Headers، و Cron" },
  { id: "encoding", nameAr: "الترميز والتشفير والحماية", nameEn: "Encoding & Security", icon: "Shield", descriptionAr: "تشفير Base64، فك توكن JWT، وفحص كلمات المرور" },
  { id: "json", nameAr: "أدوات JSON", nameEn: "JSON Tools", icon: "Braces", descriptionAr: "تنسيق وتحقق وتحويل بيانات JSON" },
  { id: "xml", nameAr: "أدوات XML", nameEn: "XML Tools", icon: "FileCode2", descriptionAr: "تنسيق وتحقق وتحويل ملفات XML" },
  { id: "svg", nameAr: "أدوات SVG", nameEn: "SVG Tools", icon: "Vector", descriptionAr: "معالجة وتحسين وتحويل ملفات SVG" },
  { id: "engineering", nameAr: "الهندسة والرياضيات", nameEn: "Engineering & Math", icon: "Compass", descriptionAr: "حساب المثلثات والهندسة الرياضية المتقدمة" },
  { id: "discovery", nameAr: "الذكاء الاصطناعي والمساعد", nameEn: "AI & Discovery", icon: "Sparkles", descriptionAr: "المساعد الذكي وروبوت الدردشة الفوري" },
  { id: "misc", nameAr: "أدوات متنوعة", nameEn: "Miscellaneous", icon: "MoreHorizontal", descriptionAr: "مجموعة من الأدوات المتفرقة والألعاب" }
];

export const TOOLS_DATA: ToolDefinition[] = [
  { id: 'encoding-suite', titleAr: 'مجموعة أدوات الترميز', titleEn: 'Encoding Tools Hub', descriptionAr: 'تشفير وفك تشفير Base64، URL، HTML Entities', category: 'encoding', icon: 'Shield', tags: ['base64', 'url', 'html', 'encode', 'decode', 'security'] },

  { id: 'json-suite', titleAr: 'مجموعة أدوات JSON', titleEn: 'JSON Tools Hub', descriptionAr: 'تنسيق، تصغير، التحقق من الصحة وتحويل JSON إلى XML و CSV و YAML', category: 'json', icon: 'FileJson', tags: ['json', 'formatter', 'validator', 'csv', 'xml', 'yaml'] },
  { id: 'xml-suite', titleAr: 'مجموعة أدوات XML', titleEn: 'XML Tools Hub', descriptionAr: 'تنسيق، تصغير، التحقق من الصحة وتحويل XML', category: 'xml', icon: 'Code', tags: ['xml', 'formatter', 'validator'] },
  { id: 'svg-suite', titleAr: 'مجموعة أدوات SVG', titleEn: 'SVG Tools Hub', descriptionAr: 'تنسيق، تصغير، التحقق من الصحة وتحويل SVG', category: 'svg', icon: 'Image', tags: ['svg', 'formatter', 'validator', 'png', 'jpg'] },
  { id: 'sql-suite', titleAr: 'مجموعة أدوات SQL', titleEn: 'SQL Tools Hub', descriptionAr: 'تنسيق وتجميل وتصغير أكواد SQL', category: 'dev', icon: 'Database', tags: ['sql', 'formatter', 'minifier'] },
  { id: 'code-formatters', titleAr: 'منسقات الأكواد', titleEn: 'Code Formatters', descriptionAr: 'تنسيق وتصغير HTML, CSS, JavaScript', category: 'dev', icon: 'Code2', tags: ['html', 'css', 'javascript', 'formatter', 'minifier'] },

  {
    id: 'assistant',
    titleAr: 'المساعد الذكي وروبوت المحادثة الفوري',
    titleEn: 'AI Smart Assistant & Chatbot Hub',
    descriptionAr: 'صفحة محادثة ذكية متكاملة للإجابة عن الاستفسارات، حل المعادلات الحسابية والطبية، واقتراح الأدوات المناسبة والتنقل المباشر.',
    category: 'discovery',
    icon: 'Bot',
    tags: ['روبوت', 'مساعد', 'ذكاء اصطناعي', 'شات', 'محادثة', 'bot', 'ai', 'chat', 'assistant'],
    badge: 'ذكاء AI',
    isPopular: true,
    isNew: true
  },
  // 1. Text tools
  {
    id: 'word-counter',
    titleAr: 'عداد الكلمات والأحرف',
    titleEn: 'Word & Character Counter',
    descriptionAr: 'حساب عدد الكلمات والأحرف والأسطر والفقرات ووقت القراءة مع إحصائيات متقدمة.',
    category: 'text',
    icon: 'FileText',
    tags: ['كلمات', 'أحرف', 'نص', 'أسطر', 'قراءة', 'فقرات', 'count', 'words', 'characters'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'arabic-text-formatter',
    titleAr: 'منسق ومعالج النصوص العربية',
    titleEn: 'Arabic Text Formatter',
    descriptionAr: 'إزالة التشكيل، توحيد الهمزات (أ، إ، آ)، تصحيح الياء والتاء المربوطة وإزالة التطويل (ـ).',
    category: 'text',
    icon: 'Type',
    tags: ['تشكيل', 'همزات', 'تطويل', 'تنظيف النص', 'عربي', 'تنسيق', 'tashkeel', 'arabic'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'case-converter',
    titleAr: 'محول حالات الأحرف الإنجليزية',
    titleEn: 'Letter Case Converter',
    descriptionAr: 'تحويل النص إلى UPPERCASE, lowercase, Title Case, camelCase, snake_case وغيرها.',
    category: 'text',
    icon: 'CaseSensitive',
    tags: ['كبير', 'صغير', 'أحرف إنجليزية', 'uppercase', 'lowercase', 'camelcase'],
    badge: 'فوري'
  },
  {
    id: 'text-diff',
    titleAr: 'مقارنة النصوص واكتشاف الفروق',
    titleEn: 'Text Diff Checker',
    descriptionAr: 'مقارنة نصين جنباً إلى جنب وإبراز الإضافات والحذوفات والتعديلات بدقة.',
    category: 'text',
    icon: 'GitCompare',
    tags: ['مقارنة', 'فروقات', 'تصحيح', 'diff', 'compare'],
    badge: 'جديد'
  },
  {
    id: 'duplicate-remover',
    titleAr: 'حذف الأسطر المكررة وترتيبها',
    titleEn: 'Duplicate Line Remover',
    descriptionAr: 'إزالة الأسطر المكررة من القوائم مع إمكانية الترتيب الأبجدي وتصفية الأسطر الفارغة.',
    category: 'text',
    icon: 'ListFilter',
    tags: ['تكرار', 'حذف المكرر', 'ترتيب', 'فرز', 'قائمة', 'duplicate', 'sort'],
    badge: 'فوري'
  },
  {
    id: 'lorem-generator',
    titleAr: 'مولد النص البديل (لوريم إيبسوم)',
    titleEn: 'Lorem Ipsum Generator',
    descriptionAr: 'توليد نصوص تجريبية باللغة العربية الفصحى أو اللاتينية بعدد الفقرات أو الكلمات.',
    category: 'text',
    icon: 'BookOpen',
    tags: ['لوريم', 'نص بديل', 'فقرات تجريبية', 'تصميم', 'lorem ipsum', 'placeholder']
  },
  {
    id: 'hash-encoder',
    titleAr: 'التشفير والترميز (Base64 / MD5 / SHA)',
    titleEn: 'Hash & Encoder Generator',
    descriptionAr: 'توليد بصمات SHA-256 و MD5 وتشفير/فك تشفير Base64 وروابط URL بسهولة.',
    category: 'encoding',
    icon: 'Binary',
    tags: ['تشفير', 'هاش', 'base64', 'url encode', 'md5', 'sha256'],
    badge: 'مميز'
  },
  {
    id: 'text-to-speech',
    titleAr: 'القارئ الآلي وتحويل النص لصوت',
    titleEn: 'Text to Speech (TTS)',
    descriptionAr: 'تحويل النصوص المكتوبة إلى صوت منطوق باستخدام لغات وأصوات متعددة مع التحكم بالسرعة.',
    category: 'text',
    icon: 'Volume2',
    tags: ['صوت', 'قارئ', 'نص لصوت', 'tts', 'text to speech', 'voice'],
    badge: 'جديد'
  },

  // 2. Image & Design tools
  {
    id: 'image-compressor',
    titleAr: 'ضاغط الصور الفوري',
    titleEn: 'Image Compressor',
    descriptionAr: 'تقليل حجم صور JPG و PNG و WEBP بنسبة تصل إلى 90% مع الحفاظ على الجودة وداخل المتصفح.',
    category: 'image',
    icon: 'Minimize2',
    tags: ['ضغط صور', 'تصغير الحجم', 'جودة', 'compress', 'optimize', 'image'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'image-converter',
    titleAr: 'محول صيغ الصور',
    titleEn: 'Image Format Converter',
    descriptionAr: 'تحويل الصور بين صيغ PNG, JPG, WEBP, BMP و SVG بضغطة زر واحدة.',
    category: 'image',
    icon: 'Repeat',
    tags: ['تحويل صور', 'صيغة', 'png to jpg', 'webp', 'convert', 'format'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'qr-generator',
    titleAr: 'مولد وقارئ رموز QR Code',
    titleEn: 'QR Code Generator & Scanner',
    descriptionAr: 'إنشاء باركود واستجابة سريعة QR مخصص بالألوان وحجم مخصص مع إمكانية قراءة الرموز.',
    category: 'image',
    icon: 'QrCode',
    tags: ['باركود', 'كيو ار', 'qr code', 'scanner', 'barcode'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'color-picker-palette',
    titleAr: 'منتقي ومحول الألوان وتوليد التدرجات',
    titleEn: 'Color Picker & Palette Generator',
    descriptionAr: 'تحويل أكواد الألوان بين HEX و RGB و HSL واختبار التباين وتوليد لوحات متناسقة.',
    category: 'design',
    icon: 'Palette',
    tags: ['ألوان', 'hex', 'rgb', 'hsl', 'تدرج', 'لوحة ألوان', 'color picker', 'palette'],
    badge: 'مميز'
  },
  {
    id: 'image-palette-extractor',
    titleAr: 'استخراج الألوان من الصور',
    titleEn: 'Image Color Palette Extractor',
    descriptionAr: 'ارفع أي صورة لاستخراج درجات الألوان الرئيسية وتوليد أكواد HEX جاهزة للنسخ.',
    category: 'design',
    icon: 'Pipette',
    tags: ['استخراج ألوان', 'لوحة الصورة', 'تصميم', 'extract color', 'image palette']
  },

  // 3. Calculators
  {
    id: 'zakat-calculator',
    titleAr: 'حاسبة الزكاة الذكية',
    titleEn: 'Smart Zakat Calculator',
    descriptionAr: 'حساب زكاة المال والذهب والفضة وعروض التجارة بناءً على أسعار المعادن الحالية وتحديد النصاب.',
    category: 'calculators',
    icon: 'Calculator',
    tags: ['زكاة', 'مال', 'نصاب', 'ذهب', 'فضة', 'zakat', 'calculator'],
    badge: 'جديد'
  },
  {
    id: 'stopwatch-timer',
    titleAr: 'مؤقت وساعة إيقاف',
    titleEn: 'Stopwatch & Timer',
    descriptionAr: 'ساعة إيقاف دقيقة مع تسجيل الدورات، ومؤقت زمني تنازلي لتتبع الوقت وإدارة المهام.',
    category: 'time-date',
    icon: 'Timer',
    tags: ['مؤقت', 'ساعة', 'ايقاف', 'وقت', 'timer', 'stopwatch', 'clock'],
    badge: 'جديد'
  },
  {
    id: 'age-calculator',
    titleAr: 'حاسبة العمر الدقيقة والبرج',
    titleEn: 'Accurate Age & Zodiac Calculator',
    descriptionAr: 'احسب عمرك بالسنوات والشهور والأيام والساعات مع العد التنازلي ليوم ميلادك القادم.',
    category: 'calculators',
    icon: 'Calendar',
    tags: ['عمر', 'ميلاد', 'برج', 'هجري', 'ميلادي', 'age', 'birthday', 'zodiac'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'health-calculator',
    titleAr: 'حاسبة كتلة الجسم BMI والسعرات',
    titleEn: 'BMI & Calorie Health Calculator',
    descriptionAr: 'حساب مؤشر كتلة الجسم BMI، الوزن المثالي، السعرات اليومية BMR واحتياج الماء اليومي.',
    category: 'health',
    icon: 'HeartPulse',
    tags: ['وزن', 'طول', 'سعرات', 'كتلة الجسم', 'ماء', 'bmi', 'calories', 'health'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'pregnancy-calculator',
    titleAr: 'حاسبة موعد الولادة والحمل',
    titleEn: 'Pregnancy Due Date Calculator',
    descriptionAr: 'تتبع مراحل الحمل وحساب موعد الولادة المتوقع وتاريخ الإخصاب بدقة.',
    category: 'health',
    icon: 'Baby',
    tags: ['حمل', 'ولادة', 'طفل', 'أشهر الحمل', 'pregnancy', 'baby', 'due date'],
    badge: 'جديد'
  },
  {
    id: 'blood-type',
    titleAr: 'توافق فصائل الدم والتبرع',
    titleEn: 'Blood Type Compatibility',
    descriptionAr: 'معرفة الفصائل المتوافقة للتبرع واستقبال الدم لكل فصيلة.',
    category: 'health',
    icon: 'Droplet',
    tags: ['فصيلة دم', 'تبرع', 'نقل دم', 'blood', 'donate'],
    badge: 'جديد'
  },
  {
    id: 'gpa-calculator',
    titleAr: 'حاسبة المعدل التراكمي (GPA)',
    titleEn: 'GPA Calculator',
    descriptionAr: 'حساب المعدل الجامعي والمدرسي التراكمي والفصلي بناءً على الساعات والدرجات.',
    category: 'student',
    icon: 'GraduationCap',
    tags: ['معدل', 'جامعة', 'تراكمي', 'درجات', 'gpa', 'university', 'grades'],
    badge: 'شائع'
  },
  {
    id: 'pomodoro-timer',
    titleAr: 'مؤقت بومودورو للدراسة والعمل',
    titleEn: 'Pomodoro Timer',
    descriptionAr: 'زيادة التركيز باستخدام تقنية بومودورو عبر تقسيم وقت الدراسة إلى جلسات واستراحات.',
    category: 'time-date',
    icon: 'Timer',
    tags: ['بومودورو', 'مؤقت', 'دراسة', 'تركيز', 'pomodoro', 'study', 'focus'],
    badge: 'جديد'
  },
  {
    id: 'numbers-to-words',
    titleAr: 'تفقيط الأرقام',
    titleEn: 'Numbers to Words',
    descriptionAr: 'تحويل الأرقام إلى نصوص باللغة العربية (تفقيط) للمبالغ المالية وغيرها.',
    category: 'student',
    icon: 'WholeWord',
    tags: ['تفقيط', 'ارقام', 'نصوص', 'حروف', 'numbers', 'words'],
    badge: 'جديد'
  },
  {
    id: 'arabic-numerals',
    titleAr: 'محول الأرقام العربية',
    titleEn: 'Arabic Numerals Converter',
    descriptionAr: 'تحويل الأرقام الإنجليزية (123) إلى أرقام عربية/هندية (١٢٣) والعكس.',
    category: 'student',
    icon: 'Languages',
    tags: ['ارقام', 'عربية', 'هندية', 'انجليزية', 'numerals', 'arabic'],
    badge: 'جديد'
  },
  {
    id: 'ip-info',
    titleAr: 'كشف عنوان IP والموقع',
    titleEn: 'IP Address & Location',
    descriptionAr: 'معرفة عنوان IP الخاص بك ومزود خدمة الإنترنت ومعلومات الموقع الجغرافي.',
    category: 'misc',
    icon: 'Globe',
    tags: ['اي بي', 'موقع', 'انترنت', 'ip', 'network', 'location'],
    badge: 'جديد'
  },
  {
    id: 'random-picker',
    titleAr: 'عجلة الحظ والاختيار العشوائي',
    titleEn: 'Random Name Picker',
    descriptionAr: 'اختيار اسم أو خيار عشوائي من قائمة مدخلة، مفيد للقرعة والمسابقات.',
    category: 'student',
    icon: 'Shuffle',
    tags: ['عشوائي', 'قرعة', 'اختيار', 'حظ', 'random', 'picker', 'wheel'],
    badge: 'مميز'
  },
  {
    id: 'gradient-generator',
    titleAr: 'مولد التدرجات اللونية',
    titleEn: 'CSS Gradient Generator',
    descriptionAr: 'تصميم تدرجات لونية جذابة وتوليد أكواد CSS جاهزة للنسخ.',
    category: 'image',
    icon: 'Palette',
    tags: ['الوان', 'تدرج', 'css', 'gradient', 'color', 'design'],
    badge: 'جديد'
  },
  {
    id: 'financial-calculator',
    titleAr: 'حاسبة الخصم والضرائب والنسب المئوية',
    titleEn: 'Discount, VAT & Percentage Calculator',
    descriptionAr: 'حساب السعر بعد الخصم، ضريبة القيمة المضافة (VAT)، والنسب المئوية والأقساط الشهرية.',
    category: 'calculators',
    icon: 'Percent',
    tags: ['خصم', 'ضريبة', 'نسبة مئوية', 'قسط', 'discount', 'vat', 'tax', 'loan'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'installment-calculator',
    titleAr: 'حاسبة الأقساط والقروض',
    titleEn: 'Installment Calculator',
    descriptionAr: 'حساب القسط الشهري، إجمالي الفوائد، وتكلفة التمويل بدقة.',
    category: 'calculators',
    icon: 'Landmark',
    tags: ['اقساط', 'قروض', 'فوائد', 'تمويل', 'بنك', 'loan', 'installment'],
    badge: 'جديد'
  },
  {
    id: 'date-calculator',
    titleAr: 'حاسبة الفارق بين التواريخ والتقويم',
    titleEn: 'Date Difference & Hijri Converter',
    descriptionAr: 'حساب الفارق بالأيام بين تاريخين، إضافة أو طرح أيام، والتحويل بين الهجري والميلادي.',
    category: 'time-date',
    icon: 'Clock',
    tags: ['تاريخ', 'فارق أيام', 'تقويم', 'هجري', 'ميلادي', 'date', 'hijri', 'calendar']
  },

  // 4. Unit & Currency Converters
  {
    id: 'unit-converter',
    titleAr: 'محول الوحدات الشامل',
    titleEn: 'Universal Unit Converter',
    descriptionAr: 'محول شامل ومتقدم جداً يدعم 15 فئة عالمية (الطول، الوزن، المساحة، الحجم، الحرارة، الوقت، السرعة، البيانات، الضغط، الطاقة، الزوايا، وغيرها).',
    category: 'units',
    icon: 'Scale',
    tags: ['وحدات', 'طول', 'وزن', 'حرارة', 'بيانات', 'مساحة', 'حجم', 'طاقة', 'وقت', 'unit converter', 'metric', 'storage'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'currency-calculator',
    titleAr: 'محول العملات والعملات الرقمية',
    titleEn: 'Currency & Crypto Exchange Calculator',
    descriptionAr: 'تحويل سريع بين الريال، الدرهم، الجنيه، الدولار، اليورو، وباقي العملات العالمية.',
    category: 'currencies',
    icon: 'Coins',
    tags: ['عملات', 'دولار', 'ريال', 'درهم', 'جنيه', 'يورو', 'currency', 'exchange', 'usd', 'sar'],
    badge: 'فوري',
    isPopular: true
  },

  // 5. Developer & Security Tools
  {
    id: 'base64-converter',
    titleAr: 'محول Base64 و URL',
    titleEn: 'Base64 & URL Encoder',
    descriptionAr: 'ترميز وفك ترميز النصوص والبيانات بصيغة Base64 و URL Encode.',
    category: 'encoding',
    icon: 'Code2',
    tags: ['base64', 'url', 'encode', 'decode', 'ترميز', 'فك'],
    badge: 'جديد'
  },
  {
    id: 'uuid-generator',
    titleAr: 'مولد UUID',
    titleEn: 'UUID Generator',
    descriptionAr: 'توليد معرفات فريدة عالمياً (UUID v4) ونسخها بسهولة.',
    category: 'dev',
    icon: 'Fingerprint',
    tags: ['uuid', 'guid', 'generator', 'مولد', 'معرف'],
    badge: 'جديد'
  },
  {
    id: 'unix-timestamp',
    titleAr: 'محول الطابع الزمني (Unix)',
    titleEn: 'Unix Timestamp Converter',
    descriptionAr: 'تحويل الطابع الزمني (Epoch) إلى تاريخ مقروء والعكس.',
    category: 'time-date',
    icon: 'Clock',
    tags: ['unix', 'timestamp', 'epoch', 'time', 'تاريخ', 'وقت'],
    badge: 'جديد'
  },
  {
    id: 'base-converter',
    titleAr: 'محول أنظمة العد للأرقام',
    titleEn: 'Number Base Converter',
    descriptionAr: 'تحويل الأرقام فورا بين النظام العشري، الثنائي، الثماني، والسداسي عشر.',
    category: 'dev',
    icon: 'ArrowRightLeft',
    tags: ['تحويل ارقام', 'ثنائي', 'سداسي عشر', 'عشري', 'base', 'hex', 'binary'],
    badge: 'جديد'
  },
  {
    id: 'password-generator',
    titleAr: 'مولد كلمات المرور الآمنة واختبار القوة',
    titleEn: 'Strong Password Generator & Tester',
    descriptionAr: 'توليد كلمات سر قوية غير قابلة للاختراق مع فحص قوة الكلمة ونسبة الأمان.',
    category: 'encoding',
    icon: 'ShieldCheck',
    tags: ['كلمة سر', 'أمان', 'توليد باسورد', 'قوة الباسورد', 'password', 'security'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'json-formatter',
    titleAr: 'منسق وفاحص ملفات JSON',
    titleEn: 'JSON Formatter & Validator',
    descriptionAr: 'تنسيق وترتيب كود JSON، تصحيح الأخطاء، وضغط البيانات (Minify) بمرونة وسرعة.',
    category: 'json',
    icon: 'FileCode',
    tags: ['json', 'تنسيق json', 'فحص كود', 'formatter', 'validator', 'minify'],
    badge: 'مميز'
  },
  {
    id: 'svg-optimizer',
    titleAr: 'مستعرض ومحسن أكواد SVG',
    titleEn: 'SVG Viewer & PNG Exporter',
    descriptionAr: 'معاينة أكواد SVG فورا، تعديل الأبعاد والألوان، وتصدير الأيقونة بصيغة PNG عالية الدقة.',
    category: 'svg',
    icon: 'Code',
    tags: ['svg', 'ايقونات', 'ناقلات', 'تصدير png', 'svg viewer', 'vector']
  },
  {
    id: 'speed-test-simulator',
    titleAr: 'فاحص استجابة الشبكة والاتصال',
    titleEn: 'Network Ping & Connection Tester',
    descriptionAr: 'اختبار سرعة زمن الاستجابة (Ping) وحالة الات بالإنترنت واستقرار الشبكة في المتصفح.',
    category: 'dev',
    icon: 'Activity',
    tags: ['سرعة', 'بينج', 'انترنت', 'شبكة', 'ping', 'latency', 'speed test']
  },
  {
    id: 'pdf-merger',
    titleAr: 'دمج ملفات PDF',
    titleEn: 'PDF Merger',
    descriptionAr: 'دمج عدة ملفات PDF في ملف واحد بسهولة وسرعة داخل المتصفح دون رفعها لأي سيرفر.',
    category: 'documents',
    icon: 'Files',
    tags: ['pdf', 'دمج', 'مستندات', 'ملفات', 'merge'],
    badge: 'جديد'
  },
  {
    id: 'triangle-solver',
    titleAr: 'حاسبة المثلثات والهندسة',
    titleEn: 'Triangle Solver',
    descriptionAr: 'حساب زوايا وأضلاع ومساحة ومحيط المثلث بناءً على المعطيات (مثل نظرية فيثاغورس وغيرها).',
    category: 'engineering',
    icon: 'Triangle',
    tags: ['مثلث', 'هندسة', 'فيثاغورس', 'زوايا', 'اضلاع', 'triangle', 'geometry'],
    badge: 'جديد'
  },
  {
    id: 'regex-tester',
    titleAr: 'مختبر التعابير القياسية',
    titleEn: 'Regex Tester',
    descriptionAr: 'كتابة واختبار التعابير القياسية (Regular Expressions) على نصوص معينة مع إبراز التطابقات.',
    category: 'dev',
    icon: 'Search',
    tags: ['regex', 'تعبيرات', 'نصوص', 'برمجة', 'اختبار'],
    badge: 'جديد'
  },
  {
    id: 'css-formatter',
    titleAr: 'منسق وضغط أكواد CSS',
    titleEn: 'CSS Formatter & Minifier',
    descriptionAr: 'تنسيق أكواد CSS لتصبح مقروءة أو ضغطها (Minify) لتقليل حجمها وسرعة تحميل الموقع.',
    category: 'dev',
    icon: 'FileCode2',
    tags: ['css', 'تنسيق', 'ضغط', 'minify', 'formatter'],
    badge: 'جديد'
  },
  {
    id: 'color-converter',
    titleAr: 'محول صيغ الألوان',
    titleEn: 'Color Converter',
    descriptionAr: 'تحويل الألوان بين HEX, RGB, HSL مع معاينة اللون فورا.',
    category: 'design',
    icon: 'Palette',
    tags: ['الوان', 'hex', 'rgb', 'hsl', 'color', 'converter'],
    badge: 'جديد'
  },
  // 1. Text Converters
  {
    id: 'text-converter-suite',
    titleAr: 'محول النصوص الشامل (PDF, Word, Markdown, HTML, JSON)',
    titleEn: 'Universal Text & Code Converter',
    descriptionAr: 'تحويل النصوص بين PDF, Word DOCX, TXT, HTML, Markdown, JSON, XML, CSV فورا.',
    category: 'text',
    icon: 'FileText',
    tags: ['تحويل نصوص', 'pdf', 'word', 'html', 'markdown', 'json', 'xml', 'csv', 'converter'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'text-to-pdf',
    titleAr: 'تحويل النص إلى PDF',
    titleEn: 'Text to PDF Converter',
    descriptionAr: 'تحويل النصوص والفقرات إلى مستندات PDF منسقة للطباعة مع دعم الخطوط والهوامش.',
    category: 'pdf',
    icon: 'FileText',
    tags: ['نص الى pdf', 'طباعة', 'مستند', 'pdf', 'text to pdf'],
    badge: 'شائع'
  },
  {
    id: 'text-to-word',
    titleAr: 'تحويل النص إلى Word (DOCX)',
    titleEn: 'Text to Word Converter',
    descriptionAr: 'تصدير النصوص المكتوبة إلى ملف وورد Microsoft Word DOCX قابل للتعديل.',
    category: 'pdf',
    icon: 'FileType',
    tags: ['نص الى وورد', 'word', 'docx', 'doc', 'مستندات'],
    badge: 'مميز'
  },
  {
    id: 'markdown-to-html',
    titleAr: 'تحويل Markdown ↔ HTML',
    titleEn: 'Markdown to HTML Converter',
    descriptionAr: 'تحويل فوري متبادل بين لغة الماركداون وشيفرات الـ HTML مع معاينة حية.',
    category: 'text',
    icon: 'FileCode',
    tags: ['markdown', 'html', 'تحويل ماركداون', 'md to html'],
    badge: 'جديد'
  },
  {
    id: 'json-to-csv',
    titleAr: 'تحويل JSON ↔ CSV',
    titleEn: 'JSON to CSV Converter',
    descriptionAr: 'تحويل مصفوفات وبيانات JSON إلى جداول CSV والعكس بدقة عالية.',
    category: 'data',
    icon: 'Table',
    tags: ['json to csv', 'csv to json', 'بيانات', 'جداول', 'تحويل'],
    badge: 'شائع'
  },

  // 2. Image Converters
  {
    id: 'image-converter-suite',
    titleAr: 'محول صيغ الصور الشامل (JPG, PNG, WebP, SVG, ICO)',
    titleEn: 'Universal Image Converter Suite',
    descriptionAr: 'تحويل جميع صيغ الصور بجودة كاملة، تغيير الأبعاد، التحويل لـ PDF و Base64 وأيقونات ICO.',
    category: 'image',
    icon: 'Image',
    tags: ['تحويل صور', 'jpg', 'png', 'webp', 'svg', 'ico', 'base64', 'image converter'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'jpg-to-png',
    titleAr: 'تحويل JPG ↔ PNG',
    titleEn: 'JPG to PNG Converter',
    descriptionAr: 'تحويل الصور بين JPG و PNG مع دعم الشفافية وضبط الجودة.',
    category: 'image',
    icon: 'Image',
    tags: ['jpg', 'png', 'تحويل صيغ', 'صور'],
    badge: 'فوري'
  },
  {
    id: 'image-to-pdf',
    titleAr: 'تحويل الصور إلى PDF',
    titleEn: 'Image to PDF Converter',
    descriptionAr: 'تجميع الصور بصيغ JPG, PNG, WebP وتحويلها إلى مستند PDF واحد.',
    category: 'pdf',
    icon: 'FileText',
    tags: ['صور الى pdf', 'تجميع صور', 'مستند pdf', 'image to pdf'],
    badge: 'شائع'
  },
  {
    id: 'svg-to-png',
    titleAr: 'تحويل SVG إلى PNG',
    titleEn: 'SVG to PNG Converter',
    descriptionAr: 'تحويل رسومات وأيقونات الفيكتور SVG إلى صور PNG نقطية عالية الدقة.',
    category: 'svg',
    icon: 'Image',
    tags: ['svg to png', 'فيكتور', 'ايقونات', 'ناقلات'],
    badge: 'جديد'
  },
  {
    id: 'ico-converter',
    titleAr: 'صانع أيقونات المواقع (ICO / Favicon)',
    titleEn: 'Favicon & ICO Converter',
    descriptionAr: 'تحويل أي صورة إلى أيقونة موقع مفضلة Favicon بصيغة ICO وبأبعاد قياسية متعددة.',
    category: 'image',
    icon: 'Layers',
    tags: ['ico', 'favicon', 'ايقونة موقع', 'رمز مفضلة'],
    badge: 'مميز'
  },

  // 3. Document Converters
  {
    id: 'document-converter',
    titleAr: 'محول المستندات والمكتبات الشامل',
    titleEn: 'Universal Document Converter',
    descriptionAr: 'تحويل ملفات Word, PDF, Excel, PowerPoint, TXT, HTML واستخراج النصوص بسهولة.',
    category: 'pdf',
    icon: 'FileType',
    tags: ['مستندات', 'word', 'pdf', 'excel', 'powerpoint', 'txt', 'html', 'documents'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'word-to-pdf',
    titleAr: 'تحويل Word إلى PDF',
    titleEn: 'Word to PDF Converter',
    descriptionAr: 'تحويل ملفات مايكروسوفت وورد DOCX إلى ملفات PDF جاهزة للمشاركة والطباعة.',
    category: 'pdf',
    icon: 'FileType',
    tags: ['وورد الى pdf', 'word to pdf', 'docx to pdf', 'مستندات'],
    badge: 'شائع'
  },
  {
    id: 'pdf-to-word',
    titleAr: 'تحويل PDF إلى Word',
    titleEn: 'PDF to Word Converter',
    descriptionAr: 'استخراج محتوى ونصوص ملفات PDF وتصديرها كمستند Word قابل للتعديل.',
    category: 'pdf',
    icon: 'FileType',
    tags: ['pdf to word', 'تعديل pdf', 'استخراج نصوص'],
    badge: 'مميز'
  },

  // 4. Data & Table Converters
  {
    id: 'data-table-converter',
    titleAr: 'محول الجداول والبيانات وقواعد البيانات (Excel, CSV, SQL)',
    titleEn: 'Data Table & SQL Converter',
    descriptionAr: 'تحويل جداول إكسل XLSX إلى CSV، JSON، وتوليد أوامر وقواعد بيانات SQL فورا.',
    category: 'data',
    icon: 'Table',
    tags: ['excel', 'csv', 'sql', 'json', 'جداول', 'بيانات', 'قواعد بيانات'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'excel-to-csv',
    titleAr: 'تحويل Excel ↔ CSV',
    titleEn: 'Excel to CSV Converter',
    descriptionAr: 'تحويل مصنفات وجداول إكسل XLSX / XLS إلى ملفات CSV والعكس.',
    category: 'data',
    icon: 'FileSpreadsheet',
    tags: ['excel to csv', 'csv to excel', 'اكسل', 'جداول'],
    badge: 'فوري'
  },
  {
    id: 'csv-to-sql',
    titleAr: 'تحويل CSV إلى أوامر SQL',
    titleEn: 'CSV to SQL Query Generator',
    descriptionAr: 'توليد استعلامات CREATE TABLE و INSERT INTO من ملفات وجداول CSV.',
    category: 'data',
    icon: 'Database',
    tags: ['csv to sql', 'قواعد بيانات', 'mysql', 'postgres', 'sqlite'],
    badge: 'مميز'
  },

  // 5. Audio Converters
  {
    id: 'audio-converter-suite',
    titleAr: 'محول الصوتيات والملفات الصوتية الشامل (MP3, WAV, AAC, OGG, FLAC)',
    titleEn: 'Universal Audio Converter Suite',
    descriptionAr: 'تحويل صيغ الصوت بجودة نقية، تعديل الترددات، استخراج المسارات وحفظها فورا.',
    category: 'audio',
    icon: 'Music',
    tags: ['تحويل صوت', 'mp3', 'wav', 'aac', 'ogg', 'flac', 'm4a', 'audio converter'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'mp3-to-wav',
    titleAr: 'تحويل MP3 ↔ WAV',
    titleEn: 'MP3 to WAV Converter',
    descriptionAr: 'تحويل ملفات MP3 إلى صيغة WAV عالية الدقة غير المضغوطة والعكس.',
    category: 'audio',
    icon: 'Music',
    tags: ['mp3 to wav', 'wav to mp3', 'صوتيات', 'تحويل صوت'],
    badge: 'فوري'
  },
  {
    id: 'm4a-to-mp3',
    titleAr: 'تحويل M4A إلى MP3',
    titleEn: 'M4A to MP3 Converter',
    descriptionAr: 'تحويل تسجيلات الآيفون والأجهزة الذكية من صيغة M4A إلى صيغة MP3 المتوافقة.',
    category: 'audio',
    icon: 'Radio',
    tags: ['m4a to mp3', 'تسجيلات', 'ايفون', 'صوتيات'],
    badge: 'مميز'
  },

  // 6. Video Converters
  {
    id: 'video-converter-suite',
    titleAr: 'محول الفيديو والوسائط الشامل (MP4, WebM, MOV, GIF, MP3)',
    titleEn: 'Universal Video Converter Suite',
    descriptionAr: 'تحويل صيغ الفيديو، استخراج الصوت MP3 من المقاطع، وصناعة صور GIF متحركة.',
    category: 'video',
    icon: 'Video',
    tags: ['تحويل فيديو', 'mp4', 'webm', 'mov', 'avi', 'gif', 'استخراج صوت', 'video converter'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'video-to-mp3',
    titleAr: 'استخراج الصوت من الفيديو (Video → MP3)',
    titleEn: 'Extract Audio from Video',
    descriptionAr: 'فصل واستخراج المسار الصوتي النقي من مقاطع الفيديو بصيغة MP3 قابلة للتشغيل.',
    category: 'audio',
    icon: 'Music',
    tags: ['فيديو الى صوت', 'video to mp3', 'استخراج صوت', 'mp4 to mp3'],
    badge: 'شائع'
  },
  {
    id: 'video-to-gif',
    titleAr: 'تحويل الفيديو إلى GIF متحرك',
    titleEn: 'Video to Animated GIF',
    descriptionAr: 'تحويل لقطات من مقاطع الفيديو إلى صور متحركة GIF خفيفة وسريعة المشاركة.',
    category: 'video',
    icon: 'Film',
    tags: ['فيديو الى gif', 'صور متحركة', 'video to gif', 'متحرك'],
    badge: 'مميز'
  },

  // 7. Archive & File Compressors
  {
    id: 'archive-converter-suite',
    titleAr: 'أدوات ضغط وفك وتقسيم الملفات (ZIP, Merge, Split)',
    titleEn: 'Universal Archive & Compression Suite',
    descriptionAr: 'إنشاء ملفات ZIP مضغوطة، فك ضغط الأرشيف، دمج عدة ملفات، وتجزئة الملفات الكبيرة.',
    category: 'archives',
    icon: 'Archive',
    tags: ['zip', 'فك ضغط', 'ضغط ملفات', 'دمج ملفات', 'تقسيم ملفات', 'archive'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'create-zip',
    titleAr: 'إنشاء ملف ZIP مضغوط',
    titleEn: 'Create ZIP Archive',
    descriptionAr: 'تجميع وضغط عدة ملفات ومستندات في أرشيف ZIP واحد لتوفير المساحة وسهولة الإرسال.',
    category: 'archives',
    icon: 'FolderArchive',
    tags: ['انشاء zip', 'ضغط ملفات', 'تجميع ملفات', 'zip maker'],
    badge: 'فوري'
  },
  {
    id: 'extract-zip',
    titleAr: 'فك ضغط ملفات ZIP عبر المتصفح',
    titleEn: 'Unzip & Extract Files Online',
    descriptionAr: 'استخراج ملفات الأرشيف المضغوطة واستعراض محتوياتها وتنزيلها بدون برامج خارجية.',
    category: 'archives',
    icon: 'Archive',
    tags: ['فك ضغط', 'unzip', 'استخراج ملفات', 'مضغوط'],
    badge: 'فوري'
  },

  // 8. Time & Date Converters
  {
    id: 'time-date-suite',
    titleAr: 'محولات الوقت والتاريخ والتقويم الشاملة',
    titleEn: 'Universal Time, Date & Hijri Suite',
    descriptionAr: 'تحويل التقويم الهجري والميلادي، طابع يونكس Unix، وفروق التوقيت بين عواصم العالم.',
    category: 'time-date',
    icon: 'Clock',
    tags: ['وقت', 'تاريخ', 'هجري', 'ميلادي', 'unix', 'مناطق زمنية', 'ساعات', 'دقائق'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'hijri-gregorian',
    titleAr: 'تحويل التاريخ الهجري ↔ الميلادي',
    titleEn: 'Hijri to Gregorian Converter',
    descriptionAr: 'تحويل التاريخ الهجري إلى ميلادي والعكس بدقة متناهية وفق تقويم أم القرى.',
    category: 'time-date',
    icon: 'Calendar',
    tags: ['هجري', 'ميلادي', 'تقويم ام القرى', 'تحويل تاريخ'],
    badge: 'شائع'
  },
  {
    id: 'timezone-converter',
    titleAr: 'محول المناطق الزمنية العالمية',
    titleEn: 'World Timezone Converter',
    descriptionAr: 'حساب فارق التوقيت والتحويل بين UTC وتوقيت مكة والقاهرة وعواصم العالم.',
    category: 'time-date',
    icon: 'Globe',
    tags: ['توقيت عالمي', 'مناطق زمنية', 'utc', 'gmt', 'فارق توقيت'],
    badge: 'مميز'
  },

  // 9. Developer Tools
  {
    id: 'dev-converter-suite',
    titleAr: 'محولات تقنية وبرمجية للمطورين',
    titleEn: 'Developer Converter Suite',
    descriptionAr: 'تحويل أنظمة العد، أكواد الألوان، تشفير وفك روابط URL، رموز HTML واليونيكود.',
    category: 'dev',
    icon: 'Code2',
    tags: ['انظمة عد', 'الوان', 'url encode', 'base64', 'html entities', 'unicode', 'dev tools'],
    badge: 'شائع',
    isPopular: true
  },

  // 10. Advanced Text Processing Suite & Tools
  {
    id: 'text-processing-suite',
    titleAr: 'حزمة معالجة النصوص الذكية المتقدمة',
    titleEn: 'Advanced Text Processing Suite',
    descriptionAr: 'حذف التكرار، تنظيف المسافات، عكس النصوص، استخراج الروابط والإيميلات، ومقارنة النصوص.',
    category: 'text',
    icon: 'Sparkles',
    tags: ['معالجة نصوص', 'مسافات', 'عكس', 'روابط', 'ايميلات', 'مقارنة', 'لوريم'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'remove-spaces',
    titleAr: 'إزالة المسافات الزائدة وتنظيف الأسطر',
    titleEn: 'Remove Extra Spaces',
    descriptionAr: 'تنظيف المسافات المزدوجة والفارغة بين الكلمات وفي نهايات الأسطر بضغطة زر.',
    category: 'text',
    icon: 'ListFilter',
    tags: ['مسافات', 'تنظيف', 'فراغات'],
    badge: 'فوري'
  },
  {
    id: 'text-reverse',
    titleAr: 'عكس النص والحروف والكلمات',
    titleEn: 'Reverse Text',
    descriptionAr: 'عكس ترتيب الحروف والكلمات والأسطر بالكامل للمبرمجين والمصممين.',
    category: 'text',
    icon: 'RotateCcw',
    tags: ['عكس', 'reverse', 'حروف'],
    badge: 'فوري'
  },
  {
    id: 'extract-urls',
    titleAr: 'استخراج كافة الروابط من النص',
    titleEn: 'Extract URLs from Text',
    descriptionAr: 'استخراج وتجميع كافة عناوين المواقع والروابط الإلكترونية في قائمة واحدة قابلة للنسخ.',
    category: 'text',
    icon: 'Link',
    tags: ['روابط', 'استخراج روابط', 'urls', 'links'],
    badge: 'فوري'
  },
  {
    id: 'extract-emails',
    titleAr: 'استخراج البريد الإلكتروني من النص',
    titleEn: 'Extract Emails from Text',
    descriptionAr: 'مسح واستخراج كافة عناوين الإيميلات من النصوص الطويلة والمقالات.',
    category: 'text',
    icon: 'Mail',
    tags: ['ايميل', 'بريد الكتروني', 'emails'],
    badge: 'فوري'
  },
  {
    id: 'text-sorter',
    titleAr: 'ترتيب وفرز الأسطر أبجدياً',
    titleEn: 'Alphabetical Text Sorter',
    descriptionAr: 'ترتيب قوائم النصوص تصاعدياً وتنازلياً أو حسب طول السطر بدقة.',
    category: 'text',
    icon: 'ListFilter',
    tags: ['ترتيب', 'فرز', 'ابجدي', 'sort'],
    badge: 'فوري'
  },
  {
    id: 'merge-lines',
    titleAr: 'دمج الأسطر بفواصل مخصصة',
    titleEn: 'Merge Lines',
    descriptionAr: 'دمج وتجميع أسطر النصوص المتفرقة في سطر واحد مع اختيار رمز الفاصل.',
    category: 'text',
    icon: 'ArrowUpDown',
    tags: ['دمج اسطر', 'تجميع', 'merge lines'],
    badge: 'فوري'
  },
  {
    id: 'split-lines',
    titleAr: 'تقسيم وتجزئة النصوص',
    titleEn: 'Split Text & Lines',
    descriptionAr: 'تقسيم النصوص الطويلة إلى أسطر متعددة بناءً على فواصل أو رموز محددة.',
    category: 'text',
    icon: 'Split',
    tags: ['تقسيم', 'تجزئة', 'split text'],
    badge: 'فوري'
  },

  // 11. Security & Data Suite & Tools
  {
    id: 'security-data-suite',
    titleAr: 'أدوات التشفير والبيانات والحماية',
    titleEn: 'Security & Data Tools Suite',
    descriptionAr: 'توليد MD5, SHA-256، فك تشفير JWT، قارئ وصانع QR، ومولد كلمات المرور.',
    category: 'encoding',
    icon: 'Shield',
    tags: ['تشفير', 'jwt', 'hash', 'qr', 'password', 'uuid', 'yaml', 'xml'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'jwt-decoder',
    titleAr: 'محلل ومفسر توكن JWT Decoder',
    titleEn: 'JWT Token Decoder',
    descriptionAr: 'فك تشفير وفحص ترويسة وبيانات توكنات JWT والتحقق من صلاحيتها محلياً.',
    category: 'encoding',
    icon: 'Key',
    tags: ['jwt', 'token', 'decoder', 'auth'],
    badge: 'فوري'
  },
  {
    id: 'qr-reader',
    titleAr: 'قارئ ومستخرج رمز QR من الصور',
    titleEn: 'QR Code Reader / Scanner',
    descriptionAr: 'قراءة وفحص أي صورة رمز استجابة سريعة واستخراج الرابط أو النص المضمن.',
    category: 'dev',
    icon: 'Scan',
    tags: ['قراءة qr', 'فحص qr', 'qr reader', 'scanner'],
    badge: 'فوري'
  },
  {
    id: 'xml-formatter',
    titleAr: 'منسق وملون أكواد XML',
    titleEn: 'XML Formatter & Beautifier',
    descriptionAr: 'تنسيق وترتيب أكواد XML مع التباعد والترميز النظيف تلقائياً.',
    category: 'xml',
    icon: 'Code',
    tags: ['xml', 'xml formatter', 'تنسيق xml'],
    badge: 'فوري'
  },
  {
    id: 'yaml-json-converter',
    titleAr: 'محول صيغ YAML ↔ JSON',
    titleEn: 'YAML ↔ JSON Converter',
    descriptionAr: 'التحويل المتبادل بين ملفات وبنى YAML و JSON بدقة متناهية للمطورين.',
    category: 'json',
    icon: 'FileCode',
    tags: ['yaml to json', 'json to yaml', 'محول yaml'],
    badge: 'فوري'
  },

  // 12. Web & Developer Suite & Tools
  {
    id: 'web-dev-suite',
    titleAr: 'أدوات المطورين والويب المتقدمة',
    titleEn: 'Web & Developer Suite',
    descriptionAr: 'محلل الروابط URL، فاحص الترويسات HTTP، ضاغط الأكواد، ومولد تعابير Cron.',
    category: 'dev',
    icon: 'Globe',
    tags: ['web tools', 'url parser', 'user agent', 'http headers', 'minifier', 'cron', 'regex'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'url-parser',
    titleAr: 'محلل ومفكك الروابط URL Parser',
    titleEn: 'URL Parser & Domain Extractor',
    descriptionAr: 'تفكيك الرابط إلى البروتوكول، النطاق، المسار، واستخراج متغيرات الاستعلام Query Params.',
    category: 'dev',
    icon: 'Compass',
    tags: ['url parser', 'domain', 'query params', 'تحليل رابط'],
    badge: 'فوري'
  },
  {
    id: 'http-headers',
    titleAr: 'فاحص ومولد ترويسات HTTP Headers',
    titleEn: 'HTTP Headers Inspector',
    descriptionAr: 'استعراض ترويسات الطلبات والأمان وشرح أهميتها البرمجية للمطورين.',
    category: 'dev',
    icon: 'Layers',
    tags: ['http headers', 'security headers', 'ترويسات'],
    badge: 'فوري'
  },
  {
    id: 'user-agent-parser',
    titleAr: 'محلل وكاشف المتصفح User-Agent',
    titleEn: 'User-Agent Parser',
    descriptionAr: 'كشف اسم المتصفح، نظام التشغيل، ونوع الجهاز من خلال سلسلة المعرف.',
    category: 'dev',
    icon: 'Cpu',
    tags: ['user agent', 'browser detect', 'كشف متصفح'],
    badge: 'فوري'
  },
  {
    id: 'code-minifier',
    titleAr: 'ضاغط ومقلص أكواد HTML, CSS, JS',
    titleEn: 'Code Minifier (HTML/CSS/JS)',
    descriptionAr: 'ضغط ملفات وأكواد الويب وحذف المسافات لتقليل حجم التحميل وتسريع المواقع.',
    category: 'dev',
    icon: 'Code2',
    tags: ['minify', 'css minifier', 'js minifier', 'html minifier', 'ضغط كود'],
    badge: 'فوري'
  },
  {
    id: 'cron-generator',
    titleAr: 'مولد ومفسر تعابير Cron Generator',
    titleEn: 'Cron Expression Generator',
    descriptionAr: 'إنشاء وفهم توقيت المهام المجدولة Cron مع شرح باللغة العربية بدقة.',
    category: 'dev',
    icon: 'Clock',
    tags: ['cron', 'cron generator', 'مهام مجدولة', 'توقيت'],
    badge: 'مميز'
  },

  // 13. Image Processing Advanced Suite & Tools
  {
    id: 'image-processing-suite',
    titleAr: 'حزمة معالجة وتعديل الصور الشاملة',
    titleEn: 'Advanced Image Processing Suite',
    descriptionAr: 'ضغط الصور، تغيير المقاسات، تدوير، جعل الخلفية شفافة، استخراج الألوان، وصنع الأيقونات.',
    category: 'image',
    icon: 'Image',
    tags: ['صور', 'ضغط صور', 'تغيير مقاس', 'شفافية', 'ايقونات', 'exif', 'favicon'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'image-resizer',
    titleAr: 'تغيير مقاسات وأبعاد الصور بدقة',
    titleEn: 'Image Resizer',
    descriptionAr: 'تغيير العرض والارتفاع للصور مع الحفاظ التلقائي على نسبة الأبعاد وجودة العرض.',
    category: 'image',
    icon: 'Maximize2',
    tags: ['تغيير مقاس صورة', 'تصغير صورة', 'تكبير صورة', 'image resize'],
    badge: 'فوري'
  },
  {
    id: 'transparent-bg',
    titleAr: 'تحويل خلفية الصور إلى شفافة PNG',
    titleEn: 'Transparent Background Creator',
    descriptionAr: 'إزالة اللون الأبيض أو الخلفية الأحادية وتحويلها إلى شفافية فورية.',
    category: 'image',
    icon: 'Scissors',
    tags: ['خلفية شفافة', 'transparent png', 'حذف خلفية'],
    badge: 'فوري'
  },
  {
    id: 'remove-exif',
    titleAr: 'حذف بيانات EXIF والموقع من الصور',
    titleEn: 'Remove EXIF Metadata',
    descriptionAr: 'تنظيف بيانات الكاميرا وموقع التصوير الجغرافي لحماية خصوصيتك قبل نشر الصور.',
    category: 'image',
    icon: 'Shield',
    tags: ['حذف exif', 'بيانات الصورة', 'خصوصية', 'remove exif'],
    badge: 'فوري'
  },
  {
    id: 'favicon-maker',
    titleAr: 'صانع أيقونة المواقع Favicon Maker',
    titleEn: 'Favicon Maker',
    descriptionAr: 'تحويل أي صورة أو شعار إلى حزمة أيقونات للمواقع بكافة المقاسات القياسية.',
    category: 'image',
    icon: 'Layout',
    tags: ['favicon', 'ايقونة موقع', 'شعار', 'favicon generator'],
    badge: 'مميز'
  },

  // 14. PDF Tools Advanced Suite
  {
    id: 'pdf-tools-suite',
    titleAr: 'حزمة أدوات PDF الاحترافية',
    titleEn: 'Advanced PDF Tools Suite',
    descriptionAr: 'دمج ملفات PDF، تقسيم المستندات، إضافة علامة مائية، تدوير وضغط ملفات PDF.',
    category: 'pdf',
    icon: 'FileText',
    tags: ['pdf', 'دمج pdf', 'تقسيم pdf', 'علامة مائية', 'تدوير pdf', 'ضغط pdf'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'pdf-merge-adv',
    titleAr: 'دمج ملفات PDF المتعددة في ملف واحد',
    titleEn: 'Merge PDF Files',
    descriptionAr: 'تجميع عدة مستندات PDF في ملف موحد بسهولة وسرعة وأمان عبر المتصفح.',
    category: 'pdf',
    icon: 'Merge',
    tags: ['دمج pdf', 'تجميع pdf', 'merge pdf'],
    badge: 'فوري'
  },
  {
    id: 'pdf-split-adv',
    titleAr: 'تقسيم واستخراج صفحات من PDF',
    titleEn: 'Split PDF Pages',
    descriptionAr: 'استخراج نطاق صفحات محددة من مستند PDF وتنزيلها كملف منفصل.',
    category: 'pdf',
    icon: 'Split',
    tags: ['تقسيم pdf', 'استخراج صفحات', 'split pdf'],
    badge: 'فوري'
  },
  {
    id: 'pdf-watermark',
    titleAr: 'إضافة علامة مائية لمستندات PDF',
    titleEn: 'Add Watermark to PDF',
    descriptionAr: 'حماية وتوثيق حقوق مستنداتك بإضافة نصوص وعلامات مائية شفافة على كل الصفحات.',
    category: 'pdf',
    icon: 'Stamp',
    tags: ['علامة مائية', 'watermark pdf', 'حماية مستند'],
    badge: 'فوري'
  },

  // 15. Design Suite & Tools
  {
    id: 'design-suite',
    titleAr: 'حزمة أدوات التصميم و CSS الاحترافية',
    titleEn: 'Design & CSS Tools Suite',
    descriptionAr: 'مولد التدرجات، لوحات الألوان، فاحص التباين، ومولد ظلال وحواف CSS.',
    category: 'design',
    icon: 'Palette',
    tags: ['تصميم', 'css', 'box shadow', 'border radius', 'contrast', 'gradient', 'palette'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'contrast-checker',
    titleAr: 'فاحص تباين الألوان ومعايير WCAG',
    titleEn: 'Color Contrast Checker (WCAG)',
    descriptionAr: 'فحص التباين اللوني بين النص والخلفية لضمان سهولة القراءة وتوافق إمكانية الوصول.',
    category: 'design',
    icon: 'Eye',
    tags: ['تباين الوان', 'wcag', 'contrast checker', 'سهولة قراءة'],
    badge: 'فوري'
  },
  {
    id: 'box-shadow-gen',
    titleAr: 'مولد ظلال الصناديق Box Shadow Generator',
    titleEn: 'CSS Box Shadow Generator',
    descriptionAr: 'تصميم ظلال CSS ثلاثية الأبعاد وناعمة بالمعاينة المباشرة ونسخ الكود فوراً.',
    category: 'design',
    icon: 'Layers',
    tags: ['ظلال', 'box shadow', 'css shadow', 'تصميم واجهات'],
    badge: 'فوري'
  },
  {
    id: 'border-radius-gen',
    titleAr: 'مولد انحناء الحواف Border Radius Generator',
    titleEn: 'CSS Border Radius Generator',
    descriptionAr: 'تصميم زوايا وأشكال عضوية مخصصة بالحواف الدائرية ونسخ كود CSS.',
    category: 'design',
    icon: 'Sliders',
    tags: ['حواف دائرية', 'border radius', 'css radius'],
    badge: 'فوري'
  },

  // 16. Social Media Suite & Tools
  {
    id: 'social-suite',
    titleAr: 'حزمة أدوات السوشيال ميديا وصناع المحتوى',
    titleEn: 'Social Media & Creator Suite',
    descriptionAr: 'توليد الهاشتاقات، مقاسات منشورات السوشيال، صانع البايو واليوزرات، وقص الصور.',
    category: 'social',
    icon: 'Share2',
    tags: ['سوشيال ميديا', 'هاشتاقات', 'بايو', 'يوزرات', 'مقاسات صور', 'انستغرام', 'تويتر', 'تيك توك'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'hashtag-generator',
    titleAr: 'مولد الهاشتاقات الذكي للمنشورات',
    titleEn: 'Hashtag Generator',
    descriptionAr: 'توليد حزم هاشتاقات شائعة وتفاعلية لمواضيع التقنية والتسويق والتصميم والرياضة.',
    category: 'social',
    icon: 'Hash',
    tags: ['هاشتاقات', 'وسوم', 'hashtags', 'انستغرام', 'تيك توك'],
    badge: 'فوري'
  },
  {
    id: 'bio-generator',
    titleAr: 'صانع ومولد البايو Bio Generator',
    titleEn: 'Social Media Bio Generator',
    descriptionAr: 'توليد نماذج بايو وسير ذاتية احترافية وجذابة لحسابات انستغرام وتويتر ولينكد إن.',
    category: 'social',
    icon: 'UserCheck',
    tags: ['بايو', 'bio', 'سيرة ذاتية', 'انستغرام'],
    badge: 'فوري'
  },
  {
    id: 'username-generator',
    titleAr: 'مولد أسماء المستخدمين واليوزرات',
    titleEn: 'Username Generator',
    descriptionAr: 'توليد اقتراحات يوزرات مميزة وجذابة لحسابات الألعاب والتواصل الاجتماعي.',
    category: 'social',
    icon: 'AtSign',
    tags: ['يوزرات', 'اسم مستخدم', 'usernames'],
    badge: 'فوري'
  },
  {
    id: 'social-resizer',
    titleAr: 'دليل ومحول مقاسات السوشيال ميديا',
    titleEn: 'Social Media Image Resizer',
    descriptionAr: 'قص وتحجيم الصور فورياً لأبعاد المنشورات والقصص والغلاف لكافة المنصات.',
    category: 'social',
    icon: 'Crop',
    tags: ['مقاسات سوشيال', 'ستوري', 'بوست', 'انستغرام', 'يوتيوب'],
    badge: 'مميز'
  },

  // 17. Calculators Suite & Tools
  {
    id: 'calculators-suite',
    titleAr: 'حزمة الحاسبات المالية والرياضية الشاملة',
    titleEn: 'Calculators & Math Suite',
    descriptionAr: 'حساب النسبة المئوية، الخصم، ضريبة القيمة المضافة، هامش الربح، ومؤشر كتلة الجسم.',
    category: 'calculators',
    icon: 'Calculator',
    tags: ['حاسبة', 'نسبة مئوية', 'خصم', 'ضريبة', 'ربح', 'قروض', 'bmi', 'كتلة الجسم'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'percentage-calc',
    titleAr: 'حاسبة النسبة المئوية الدقيقة',
    titleEn: 'Percentage Calculator',
    descriptionAr: 'حساب نسبة القيمة من الإجمالي، أو الزيادة والنقصان المئوي بدقة وفورية.',
    category: 'calculators',
    icon: 'Percent',
    tags: ['نسبة مئوية', 'حساب نسبة', 'percentage'],
    badge: 'فوري'
  },
  {
    id: 'discount-calc',
    titleAr: 'حاسبة الخصومات والتخفيضات',
    titleEn: 'Discount Calculator',
    descriptionAr: 'معرفة السعر بعد الخصم ومقدار المبلغ الموفر أثناء التسوق والعروض.',
    category: 'calculators',
    icon: 'DollarSign',
    tags: ['خصم', 'تخفيضات', 'توفير', 'discount'],
    badge: 'فوري'
  },
  {
    id: 'vat-calc',
    titleAr: 'حاسبة ضريبة القيمة المضافة (VAT)',
    titleEn: 'VAT / Tax Calculator',
    descriptionAr: 'حساب الضريبة المضافة الشاملة وغير الشاملة للنسب 15% أو 5% أو نسب مخصصة.',
    category: 'calculators',
    icon: 'Percent',
    tags: ['ضريبة', 'القيمة المضافة', 'vat', 'ضريبة 15%'],
    badge: 'فوري'
  },
  {
    id: 'profit-margin-calc',
    titleAr: 'حاسبة هامش الربح وعائد الاستثمار',
    titleEn: 'Profit Margin Calculator',
    descriptionAr: 'حساب صافي الأرباح وهامش الربح المئوي والمارك اب (Markup) للتجار والمتاجر.',
    category: 'calculators',
    icon: 'TrendingUp',
    tags: ['هامش ربح', 'صافي ربح', 'markup', 'تجارة'],
    badge: 'فوري'
  },
  {
    id: 'bmi-calc',
    titleAr: 'حاسبة مؤشر كتلة الجسم (BMI)',
    titleEn: 'BMI Health Calculator',
    descriptionAr: 'معرفة الوزن المثالي وتصنيف كتلة الجسم والتوصيات الصحية المناسبة.',
    category: 'calculators',
    icon: 'Activity',
    tags: ['bmi', 'كتلة الجسم', 'وزن مثالي', 'صحة'],
    badge: 'فوري'
  },
  {
    id: 'medical-tools-suite',
    titleAr: 'حزمة الأدوات الطبية والصحية المتخصصة',
    titleEn: 'Medical & Clinical Tools Suite',
    descriptionAr: '17 أداة طبية وسريرية: حاسبة BMI، السعرات، الجرعات، الحمل، الغازات والوحدات المخبرية، المعجم والاختصارات.',
    category: 'health',
    icon: 'Stethoscope',
    tags: ['طبي', 'أدوية', 'جرعات', 'ضغط دم', 'نبض', 'حمل', 'اختصارات طبية', 'مصطلحات', 'تقرير طبي'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'engineering-math-suite',
    titleAr: 'حزمة الهندسة والرياضيات المتقدمة',
    titleEn: 'Engineering & Geometry Math Suite',
    descriptionAr: 'حاسبات المساحة، الحجوم، المحيطات، فيثاغورس، المثلثات، الدائرة، المخروط، النسب، الكسور، والوحدات الهندسية.',
    category: 'engineering',
    icon: 'Compass',
    tags: ['هندسة', 'مساحة', 'حجم', 'محيط', 'فيثاغورس', 'مثلث', 'دائرة', 'أسطوانة', 'مخروط', 'كسور', 'إحصاء'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'diagrams-design-suite',
    titleAr: 'حزمة المخططات والرسومات والتصميم',
    titleEn: 'Diagrams & Design Visualizer Suite',
    descriptionAr: 'بناء Flowchart، Mermaid، ER Diagram، Mind Map، Sitemap، Wireframe، وقوالب الشعار والسوشيال ميديا.',
    category: 'design',
    icon: 'Layers',
    tags: ['مخطط', 'flowchart', 'mermaid', 'خريطة ذهنية', 'سيرة', 'sitemap', 'wireframe', 'أيقونة', 'سوشيال ميديا'],
    badge: 'جديد',
    isPopular: true
  },
  {
    id: 'data-tools-suite',
    titleAr: 'حزمة أدوات البيانات والرسوم البيانية',
    titleEn: 'Data & Charts Interactive Suite',
    descriptionAr: 'جدول بيانات صغير، مولد الرسوم البيانية، مستعرض ومحلل CSV، شجرة JSON، وإحصائيات النصوص.',
    category: 'data',
    icon: 'Table',
    tags: ['بيانات', 'جدول', 'رسوم بيانية', 'charts', 'csv', 'json', 'تكرار', 'إحصائيات'],
    badge: 'جديد',
    isPopular: true
  },
  {
    id: 'dev-design-hub',
    titleAr: 'مركز أدوات المطورين والمصممين',
    titleEn: 'Developer & UI/UX Design Hub',
    descriptionAr: 'معاينة الأجهزة Mockup، إطارات الشاشة، Android DPI، iOS pt، نقاط الاستجابة، وحدات CSS، ومولد وسوم الميتا.',
    category: 'dev',
    icon: 'Smartphone',
    tags: ['موك اب', 'mockup', 'android dpi', 'ios pt', 'breakpoints', 'css rem', 'wcag', 'meta tags', 'seo'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'mega-converters-suite',
    titleAr: 'المحول الشامل لكافة الوحدات والنصوص',
    titleEn: 'Mega Universal Converters Suite',
    descriptionAr: 'محول حالات النصوص، الثنائي، ASCII، قواعد الأرقام، الأرقام الرومانية، التفقيط، وكافة وحدات الطول والوزن والحرارة.',
    category: 'units',
    icon: 'Scale',
    tags: ['محول', 'وحدات', 'نصوص', 'ثنائي', 'أرقام رومانية', 'تفقيط', 'أطوال', 'أوزان', 'حرارة', 'طاقة'],
    badge: 'مميز',
    isPopular: true
  },
  {
    id: 'security-suite',
    titleAr: 'حزمة أدوات الأمن والتشفير والخصوصية',
    titleEn: 'Security, Crypto & Privacy Suite',
    descriptionAr: 'فاحص كلمات المرور، مولد الهاش (SHA/MD5)، UUID v4، ترميز الروابط وBase64، ومحلل JWT.',
    category: 'encoding',
    icon: 'ShieldCheck',
    tags: ['أمان', 'تشفير', 'كلمات مرور', 'هاش', 'sha256', 'md5', 'uuid', 'jwt', 'base64'],
    badge: 'جديد',
    isPopular: true
  },
  {
    id: 'daily-calculators-hub',
    titleAr: 'مركز الحاسبات اليومية والشخصية',
    titleEn: 'Daily Calculators & Utilities Hub',
    descriptionAr: 'حاسبة العمر التفصيلية، الفرق بين التواريخ، النسبة المئوية، الخصومات، الضريبة، القروض، وساعة الإيقاف.',
    category: 'calculators',
    icon: 'Calendar',
    tags: ['حاسبة يومية', 'عمر', 'تاريخ', 'خصم', 'ضريبة', 'قسط', 'ساعة إيقاف', 'قرعة'],
    badge: 'شائع',
    isPopular: true
  },
  {
    id: 'surgical-anatomy-3d-suite',
    titleAr: 'غرفة العمليات وجراحة وتشريح الأعضاء 3D (Smart OR)',
    titleEn: '3D Smart Operating Room & Surgical Anatomy Atlas',
    descriptionAr: 'محاكاة حية متقدمة لغرفة العمليات الجراحية المعقمة ومجسمات ثلاثية الأبعاد تفاعلية: القلب، المخ، العيون، استبدال الركبة، استئصال المرارة بالمنظار، وتثبيت العمود الفقري مع شاشة المؤشرات الحيوية للتخدير وطاولة الأدوات الجراحية.',
    category: 'surgery-3d',
    icon: 'Activity',
    tags: ['3D', 'جراحة', 'جراحة قلب', 'جراحة القلب', 'قلب', 'دماغ', 'مخ', 'عيون', 'ليزك', 'قسطرة', 'تشريح', 'أعصاب', 'طب', 'عمليات', 'ركبة', 'منظار', 'عمود فقري', 'تخدير', 'operating room', 'surgical anatomy'],
    badge: '3D مميز',
    isNew: true,
    isPopular: true
  },
  {
    id: 'heart-surgery-3d',
    titleAr: 'تشريح وجراحة القلب المفتوح والقسطرة 3D',
    titleEn: '3D Heart Anatomy & Cardiac Surgery Simulator',
    descriptionAr: 'مجسم قلب ثلاثي الأبعاد ينبض حياً، استعراض البطينات والشرايين التاجية ومحاكاة عمليات القلب المفتوح والقسطرة وتركيب الدعامات.',
    category: 'surgery-3d',
    icon: 'HeartPulse',
    tags: ['قلب 3D', 'جراحة قلب', 'جراحة القلب', 'عملية قلب', 'قسطرة', 'قسطرة القلب', 'شرايين تاجية', 'أورطي', 'دعامة', 'قلب مفتوح', 'تشريح القلب', 'cardiac surgery', 'heart surgery', 'أمراض القلب'],
    badge: '3D جديد',
    isNew: true
  },
  {
    id: 'brain-neurosurgery-3d',
    titleAr: 'تشريح وجراحة المخ والأعصاب 3D',
    titleEn: '3D Brain Anatomy & Neurosurgery Simulator',
    descriptionAr: 'استكشاف فصوص المخ (الجبهي، الجداري، الصدغي، القذالي)، المخيخ وجذع الدماغ ومحاكاة جراحات الأورام والتحفيز العميق DBS.',
    category: 'surgery-3d',
    icon: 'Brain',
    tags: ['دماغ 3D', 'مخ', 'أعصاب', 'فصوص المخ', 'أورام الدماغ', 'DBS', 'بضع القحف'],
    badge: '3D جديد',
    isNew: true
  },
  {
    id: 'lungs-surgery-3d',
    titleAr: 'جراحة وتشريح الرئتين والجهاز التنفسي 3D',
    titleEn: 'Thoracic Surgery & 3D Lungs Anatomy',
    descriptionAr: 'مجسم ثلاثي الأبعاد تفاعلي للرئتين وقصبة الهواء، والشعب الهوائية مع محاكاة التنفس وجراحات المنظار الصدري.',
    category: 'surgery-3d',
    icon: 'Activity',
    tags: ['رئة 3D', 'جهاز تنفسي', 'قصبة هوائية', 'شعب هوائية', 'جراحة صدر', 'منظار صدري'],
    badge: '3D جديد',
    isNew: true
  },
  {
    id: 'eye-surgery-3d',
    titleAr: 'تشريح وجراحة العيون والبصريات 3D',
    titleEn: '3D Eye Anatomy & Ophthalmic Surgery Simulator',
    descriptionAr: 'مجسم ثلاثي الأبعاد لطبقات العين (القرنية، القزحية، العدسة، الشبكية، والعصب البصري) مع محاكاة جراحات الليزك والمياه البيضاء.',
    category: 'surgery-3d',
    icon: 'Eye',
    tags: ['عين 3D', 'ليزك', 'مياه بيضاء', 'قرنية', 'شبكية', 'عصب بصري', 'جراحة عيون'],
    badge: '3D جديد',
    isNew: true
  },
  {
    id: 'knee-replacement-3d',
    titleAr: 'جراحة واستبدال مفصل الركبة بالكامل 3D (TKA)',
    titleEn: '3D Total Knee Arthroplasty & Orthopedic Surgery',
    descriptionAr: 'مجسم ثلاثي الأبعاد تفاعلي لعظام الفخذ والساق والغضاريف مع محاكاة خطوات استبدال المفصل التالف بمفصل تيتانيوم وبوليثيلين وترميم الأربطة.',
    category: 'surgery-3d',
    icon: 'Scissors',
    tags: ['ركبة', 'عظام', 'مفصل', 'تيتانيوم', 'استبدال الركبة', 'غضروف', 'رباط صليبي', 'جراحة عظام', '3D'],
    badge: '3D جديد',
    isNew: true
  },
  {
    id: 'laparoscopy-cholecystectomy-3d',
    titleAr: 'الجراحة المنظارية للبطن واستئصال المرارة 3D',
    titleEn: '3D Laparoscopic Cholecystectomy & Hepatic Anatomy',
    descriptionAr: 'محاكاة جراحية ثلاثية الأبعاد لمنافذ التروكار وكاميرا المنظار 4K لكشف الكبد والقنوات الصفراوية واستئصال المرارة بدبابيس الليغاكليب.',
    category: 'surgery-3d',
    icon: 'Video',
    tags: ['منظار', 'مرارة', 'كبد', 'تروكار', 'حصوات', 'كالوت', 'جراحة مناظير', 'بطن', '3D'],
    badge: '3D جديد',
    isNew: true
  },
  {
    id: 'spine-disc-surgery-3d',
    titleAr: 'جراحة العمود الفقري والانزلاق الغضروفي 3D',
    titleEn: '3D Spine Surgery & Lumbar Disc Decompression',
    descriptionAr: 'مجسم ثلاثي الأبعاد تفاعلي للفقرات القطنية L4-L5 والأعصاب المضغوطة ومحاكاة إزالة الغضروف المجهرية وتثبيت الفقرات بمسامير وشرائح التيتانيوم.',
    category: 'surgery-3d',
    icon: 'Activity',
    tags: ['عمود فقري', 'انزلاق غضروفي', 'فقرات', 'عرق النسا', 'تثبيت الفقرات', 'أعصاب', 'تيتانيوم', '3D'],
    badge: '3D جديد',
    isNew: true
  },
  {
    id: 'chemical-reactions-lab',
    titleAr: 'مختبر التفاعلات الكيميائية والجدول الدوري الطبي',
    titleEn: 'Interactive Clinical Chemistry & Medical Periodic Lab',
    descriptionAr: 'محاكي تفاعلي حي للتفاعلات الكيميائية الطبية والصيدلانية، كيمياء الدم والمعدة، جدول دوري سريري، حاسبة pH وتخفيف المحاليل والمولارية.',
    category: 'health',
    icon: 'FlaskConical',
    tags: ['كيمياء', 'تفاعلات كيميائية', 'جدول دوري', 'pH', 'حموضة الدم', 'محاليل', 'صيدلة', 'مولارية', 'تخفيف', 'تفاعلات طبية', 'مختبر'],
    badge: 'جديد',
    isNew: true,
    isPopular: true
  },
  {
    id: 'human-body-reactions',
    titleAr: 'تفاعلات جسم الإنسان الكيميائية الحيوية والأيضية',
    titleEn: 'Human Body Biochemical & Metabolic Reactions Simulator',
    descriptionAr: 'محاكاة حيوية للتفاعلات الكيميائية داخل أعضاء وخلايا الجسم: التنفس الخلوي وإنتاج ATP، حمض اللاكتيك في العضلات، دورة اليوريا بالكبد، تخليق الدوبامين والسيروتونين بالدماغ، أكسيد النيتريك للشرايين، تخثر الدم والميلانين.',
    category: 'health',
    icon: 'Dna',
    tags: ['تفاعلات الجسم', 'كيمياء حيوية', 'ATP', 'تنفس خلوي', 'لاكتيك', 'دورة اليوريا', 'كبد', 'دوبامين', 'سيروتونين', 'أكسيد النيتريك', 'تجلط الدم', 'هضم', 'ميلانين', 'بيوكيمياء'],
    badge: 'جديد',
    isNew: true,
    isPopular: true
  },
  {
    id: 'ai-text-detector',
    titleAr: 'كاشف النص الذكي (AI Text Detector)',
    titleEn: 'AI Text Detector & Statistical Pattern Analyzer',
    descriptionAr: 'تحليل لغوي وإحصائي متقدم للكشف عن احتمالية توليد النصوص بالذكاء الاصطناعي، فحص الحيرة، تنوع المفردات، والعبارات النمطية مع تظليل الجمل بدقة.',
    category: 'text',
    icon: 'Bot',
    tags: ['كاشف AI', 'ذكاء اصطناعي', 'نص ذكاء اصطناعي', 'تحليل نصوص', 'كشف شات جي بي تي', 'ChatGPT detector', 'فحص المحتوى', 'أصالة النص', 'كاشف الذكاء الاصطناعي'],
    badge: 'جديد',
    isNew: true,
    isPopular: true
  },
  {
    id: 'biochem-lab',
    titleAr: 'مختبر الكيمياء الحيوية وتفاعلات جسم الإنسان (BioChem Lab)',
    titleEn: 'Interactive Human Biochemistry & Organ Pathways Lab 3D',
    descriptionAr: 'مختبر بيوكيميائي تفاعلي شامل: مسار التنفس الخلوي وإنتاج ATP، كيمياء الهضم، نقل الغازات وتأثير بوهر، جهد الفعل والدوبامين، انقباض العضلات، شلال تخثر الدم، DNA إلى بروتين، محاكي حركية الإنزيمات (Michaelis-Menten)، وطاولة التجارب ثلاثية الأبعاد.',
    category: 'health',
    icon: 'Dna',
    tags: ['كيمياء حيوية', 'تفاعلات الجسم', 'ATP', 'ميتوكوندريا', 'دورة كريبس', 'إنزيمات', 'دوبامين', 'تخثر الدم', 'هضم', 'ريبوسوم', 'DNA', 'تأثير بوهر', 'Michaelis-Menten', 'مختبر حيوي'],
    badge: 'جديد',
    isNew: true,
    isPopular: true
  },
  {
    id: 'ph-blood-calculator',
    titleAr: 'حاسبة pH وتوازن حموضة وقلوية الدم',
    titleEn: 'Blood pH & Acid-Base Balance Calculator',
    descriptionAr: 'حساب الرقم الهيدروجيني pH، pOH، وتركيز أيونات الهيدروجين مع التفسير السريري للحماض والقلاء التنفسي والأيضي.',
    category: 'health',
    icon: 'Sparkles',
    tags: ['pH', 'حموضة الدم', 'حماض', 'قلاء', 'هندرسون', 'بيكربونات', 'تحاليل'],
    badge: 'جديد',
    isNew: true
  },
  {
    id: 'dilution-calculator',
    titleAr: 'حاسبة التخفيف الصيدلاني (C₁V₁ = C₂V₂)',
    titleEn: 'Pharmaceutical Solution Dilution Calculator',
    descriptionAr: 'حساب كمية المحلول المركز وحجم الماء المقطر المعقم المطلوب إضافته لتحضير المحاليل الطبية بدقة متناهية.',
    category: 'health',
    icon: 'RotateCcw',
    tags: ['تخفيف', 'محاليل', 'صيدلة', 'تركيز', 'كحول', 'مطهر', 'C1V1'],
    badge: 'جديد',
    isNew: true
  }
];

export const ALL_TOOLS = TOOLS_DATA;
