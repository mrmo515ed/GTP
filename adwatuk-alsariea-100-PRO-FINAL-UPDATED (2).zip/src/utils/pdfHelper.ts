import html2canvas from 'html2canvas';
import { jsPDF } from 'jspdf';
import { validateBlobSignature } from './fileSignatures';

export interface GeneratePdfOptions {
  filename?: string;
  title?: string;
  margin?: number;
  orientation?: 'portrait' | 'landscape';
  format?: string;
  onProgress?: (percent: number, status: string) => void;
}

/**
 * Robust, client-side HTML to PDF converter with 100% Arabic typography & RTL support.
 */
export async function convertHtmlToPdfBlob(
  htmlContent: string,
  options: GeneratePdfOptions = {}
): Promise<{ blob: Blob; url: string }> {
  const {
    filename = 'document.pdf',
    title = 'مستند',
    margin = 12,
    orientation = 'portrait',
    format = 'a4',
    onProgress
  } = options;

  onProgress?.(10, 'جاري تجهيز النص والخطوط العربية...');

  // Create isolated sandbox element in DOM for html2canvas rendering
  const container = document.createElement('div');
  container.id = 'pdf-render-sandbox-' + Date.now();
  // Keep the render sandbox inside the drawable viewport. Very large negative
  // coordinates produce blank canvases in several Android browsers.
  container.style.position = 'absolute';
  container.style.top = `${window.scrollY}px`;
  container.style.left = '0';
  container.style.pointerEvents = 'none';
  container.style.width = orientation === 'portrait' ? '794px' : '1122px'; // Standard A4 px at 96 DPI
  container.style.padding = '36px 40px';
  container.style.background = '#ffffff';
  container.style.color = '#111827';
  container.style.direction = 'rtl';
  container.style.textAlign = 'right';
  container.style.fontFamily = "'Alexandria', 'Cairo', 'Segoe UI', Tahoma, Arial, sans-serif";
  container.style.fontSize = '14px';
  container.style.lineHeight = '1.7';
  container.style.boxSizing = 'border-box';
  // Keep it above page layers while capturing; negative z-index produced white PDFs on Android.
  container.style.zIndex = '2147483646';

  // Inject content with printable styles
  container.innerHTML = `
    <style>
      #${container.id} * {
        box-sizing: border-box;
        font-family: 'Alexandria', 'Cairo', 'Segoe UI', Tahoma, Arial, sans-serif !important;
      }
      #${container.id} h1, #${container.id} h2, #${container.id} h3 {
        color: #0f172a;
        margin-top: 14px;
        margin-bottom: 10px;
        font-weight: bold;
      }
      #${container.id} p {
        margin-bottom: 12px;
        text-align: justify;
        line-height: 1.8;
      }
      #${container.id} table {
        width: 100%;
        border-collapse: collapse;
        margin: 16px 0;
        font-size: 12px;
      }
      #${container.id} th, #${container.id} td {
        border: 1px solid #cbd5e1;
        padding: 8px 10px;
        text-align: right;
      }
      #${container.id} th {
        background-color: #f1f5f9;
        font-weight: bold;
      }
      #${container.id} pre, #${container.id} code {
        direction: ltr;
        text-align: left;
        background-color: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        padding: 8px 12px;
        font-family: monospace !important;
        font-size: 12px;
        white-space: pre-wrap;
      }
    </style>
    <div class="pdf-content-wrapper" dir="rtl">
      ${htmlContent}
    </div>
  `;

  document.body.appendChild(container);

  try {
    onProgress?.(25, 'جاري تحميل الخطوط والصور...');
    if ('fonts' in document) await document.fonts.ready;
    const images = Array.from(container.querySelectorAll('img'));
    await Promise.all(images.map(async image => {
      try {
        if (!image.complete) await image.decode();
      } catch {}
    }));

    onProgress?.(35, 'جاري التقاط المحتوى والتحقق من أنه غير فارغ...');

    onProgress?.(50, 'جاري رسم المحتوى بدقة عالية...');
    const canvas = await html2canvas(container, {
      scale: 2,
      useCORS: true,
      allowTaint: false,
      backgroundColor: '#ffffff',
      logging: false,
      scrollX: 0,
      scrollY: -window.scrollY,
      windowWidth: Math.max(container.scrollWidth, 794),
      windowHeight: Math.max(container.scrollHeight, 1123),
    });
    if (!canvas || canvas.width < 2 || canvas.height < 2) {
      throw new Error('فشل رسم محتوى PDF');
    }

    // Reject a white/transparent result instead of downloading a blank PDF.
    const context = canvas.getContext('2d', { willReadFrequently: true });
    if (!context) throw new Error('تعذر فحص محتوى PDF');
    const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data;
    let nonWhiteSamples = 0;
    const pixelStep = Math.max(4, Math.floor((canvas.width * canvas.height) / 25000)) * 4;
    for (let index = 0; index < pixels.length; index += pixelStep) {
      if (pixels[index + 3] > 10 && (pixels[index] < 245 || pixels[index + 1] < 245 || pixels[index + 2] < 245)) {
        nonWhiteSamples++;
        if (nonWhiteSamples > 8) break;
      }
    }
    if (nonWhiteSamples <= 8) throw new Error('تم منع تنزيل صفحة PDF بيضاء؛ حاول إدخال محتوى أوضح');

    onProgress?.(70, 'جاري تقسيم المحتوى إلى صفحات PDF...');
    const pdf = new jsPDF({ unit: 'mm', format, orientation });
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const printableWidth = pageWidth - margin * 2;
    const printableHeight = pageHeight - margin * 2;
    const sourcePageHeight = Math.max(1, Math.floor((printableHeight * canvas.width) / printableWidth));
    let sourceY = 0;
    let pageNumber = 0;

    while (sourceY < canvas.height) {
      const sliceHeight = Math.min(sourcePageHeight, canvas.height - sourceY);
      const pageCanvas = document.createElement('canvas');
      pageCanvas.width = canvas.width;
      pageCanvas.height = sliceHeight;
      const pageContext = pageCanvas.getContext('2d');
      if (!pageContext) throw new Error('تعذر تقسيم صفحات PDF');
      pageContext.fillStyle = '#ffffff';
      pageContext.fillRect(0, 0, pageCanvas.width, pageCanvas.height);
      pageContext.drawImage(canvas, 0, sourceY, canvas.width, sliceHeight, 0, 0, canvas.width, sliceHeight);
      const renderedHeight = (sliceHeight * printableWidth) / canvas.width;
      if (pageNumber > 0) pdf.addPage(format, orientation);
      pdf.addImage(pageCanvas.toDataURL('image/jpeg', 0.94), 'JPEG', margin, margin, printableWidth, renderedHeight, undefined, 'FAST');
      sourceY += sliceHeight;
      pageNumber++;
      onProgress?.(70 + Math.min(22, Math.round((sourceY / canvas.height) * 22)), `جاري إنشاء الصفحة ${pageNumber}...`);
    }

    const pdfBlob = pdf.output('blob');
    if (pdfBlob.size < 500) throw new Error('ملف PDF الناتج فارغ');
    await validateBlobSignature(pdfBlob, 'pdf');

    onProgress?.(95, 'جاري تجهيز رابط التحميل...');
    const url = URL.createObjectURL(pdfBlob);

    onProgress?.(100, 'اكتمل إنشاء المستند بنجاح!');
    return { blob: pdfBlob, url };
  } finally {
    // Cleanup DOM element
    if (document.body.contains(container)) {
      document.body.removeChild(container);
    }
  }
}
