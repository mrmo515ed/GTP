const ascii = (bytes: Uint8Array, start: number, length: number) =>
  String.fromCharCode(...bytes.slice(start, start + length));

export function hasExpectedSignature(bytes: Uint8Array, extension: string): boolean {
  const ext = extension.toLowerCase().replace(/^\./, '');
  if (bytes.byteLength < 4) return false;
  switch (ext) {
    case 'pdf': return ascii(bytes, 0, 5) === '%PDF-';
    case 'zip':
    case 'docx':
    case 'xlsx':
    case 'pptx': return bytes[0] === 0x50 && bytes[1] === 0x4b;
    case 'mp3': return ascii(bytes, 0, 3) === 'ID3' || (bytes[0] === 0xff && (bytes[1] & 0xe0) === 0xe0);
    case 'wav': return ascii(bytes, 0, 4) === 'RIFF' && ascii(bytes, 8, 4) === 'WAVE';
    case 'ogg': return ascii(bytes, 0, 4) === 'OggS';
    case 'flac': return ascii(bytes, 0, 4) === 'fLaC';
    case 'gif': return ascii(bytes, 0, 4) === 'GIF8';
    case 'webm': return bytes[0] === 0x1a && bytes[1] === 0x45 && bytes[2] === 0xdf && bytes[3] === 0xa3;
    case 'mp4': return bytes.byteLength > 12 && ascii(bytes, 4, 4) === 'ftyp';
    case 'ico': return bytes[0] === 0 && bytes[1] === 0 && bytes[2] === 1 && bytes[3] === 0;
    case 'png': return bytes[0] === 0x89 && ascii(bytes, 1, 3) === 'PNG';
    case 'jpg':
    case 'jpeg': return bytes[0] === 0xff && bytes[1] === 0xd8;
    default: return bytes.byteLength > 0;
  }
}

export async function validateBlobSignature(blob: Blob, extension: string): Promise<void> {
  const bytes = new Uint8Array(await blob.slice(0, 32).arrayBuffer());
  if (!hasExpectedSignature(bytes, extension)) {
    throw new Error(`صيغة الملف الناتج لا تطابق الامتداد .${extension}`);
  }
}
