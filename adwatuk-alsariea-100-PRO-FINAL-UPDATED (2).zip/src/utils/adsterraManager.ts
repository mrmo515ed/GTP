// Adsterra Integration & respectful centralized ad scheduler
// All four units are preserved, while entry popups and repeated ads are prevented.

export const ADSTERRA_CONFIG = {
  BANNER_KEY: 'e3aa8d523298c476b533f7044524797b',
  BANNER_SCRIPT_URL: 'https://movementssubscriptionobjection.com/e3aa8d523298c476b533f7044524797b/invoke.js',
  SMARTLINK_URL: 'https://movementssubscriptionobjection.com/stuqqi8sc?key=7684bf7e86a6c9e96b2548082cf6992b',
  SOCIAL_BAR_URL: 'https://movementssubscriptionobjection.com/ce/fc/f6/cefcf6000cb0970c117e93ad02873974.js',
  POPUNDER_URL: 'https://movementssubscriptionobjection.com/d1/b5/2d/d1b52d2a12ea105a1d4de4194083ed6b.js',
  BANNER_WIDTH: 728,
  BANNER_HEIGHT: 90,
  SITE_CANONICAL_URL: 'https://adwatuk-alsariea.netlify.app'
} as const;

const LAST_ACTION_AD_TIME_KEY = 'adwatuk_last_action_ad_time';
const SOCIAL_BAR_SESSION_KEY = 'adwatuk_social_bar_loaded';
const POPUNDER_SESSION_KEY = 'adwatuk_popunder_loaded';

// One monetized tool event at most every five minutes across the whole website.
export const AD_COOLDOWN_MS = 5 * 60 * 1000;
export const INSTANT_TOOL_DELAY_MS = 60 * 1000;

let socialBarInjected = false;
let popunderInjected = false;

function injectExternalScript(src: string, id: string): void {
  if (document.getElementById(id)) return;
  const script = document.createElement('script');
  script.id = id;
  script.type = 'text/javascript';
  script.async = true;
  script.src = src;
  script.referrerPolicy = 'strict-origin-when-cross-origin';
  document.body.appendChild(script);
}

function enableSocialBarOncePerSession(): void {
  try {
    if (socialBarInjected || sessionStorage.getItem(SOCIAL_BAR_SESSION_KEY) === '1') return;
    socialBarInjected = true;
    sessionStorage.setItem(SOCIAL_BAR_SESSION_KEY, '1');
    injectExternalScript(ADSTERRA_CONFIG.SOCIAL_BAR_URL, 'adwatuk-social-bar-script');
  } catch {
    if (!socialBarInjected) {
      socialBarInjected = true;
      injectExternalScript(ADSTERRA_CONFIG.SOCIAL_BAR_URL, 'adwatuk-social-bar-script');
    }
  }
}

function enablePopunderOncePerSession(): void {
  try {
    if (popunderInjected || sessionStorage.getItem(POPUNDER_SESSION_KEY) === '1') return;
    popunderInjected = true;
    sessionStorage.setItem(POPUNDER_SESSION_KEY, '1');
    injectExternalScript(ADSTERRA_CONFIG.POPUNDER_URL, 'adwatuk-popunder-script');
  } catch {
    if (!popunderInjected) {
      popunderInjected = true;
      injectExternalScript(ADSTERRA_CONFIG.POPUNDER_URL, 'adwatuk-popunder-script');
    }
  }
}

/**
 * Explicit support action only. Smart Link is never opened on initial entry or silently.
 */
export function triggerSupportSiteAd(): void {
  const newWindow = window.open(ADSTERRA_CONFIG.SMARTLINK_URL, '_blank', 'noopener,noreferrer');
  if (newWindow) newWindow.opener = null;
}

/**
 * Called after a meaningful tool action, or after one minute inside an instant-result tool.
 * Returns true only when an ad cycle was actually allowed by the global five-minute cooldown.
 */
export function triggerToolActionAd(actionName: string = 'use_tool'): boolean {
  try {
    const now = Date.now();
    const lastTime = Number.parseInt(localStorage.getItem(LAST_ACTION_AD_TIME_KEY) || '0', 10);

    if (now - lastTime < AD_COOLDOWN_MS) return false;
    localStorage.setItem(LAST_ACTION_AD_TIME_KEY, String(now));

    // These units are enabled only after genuine engagement, never on page entry.
    enableSocialBarOncePerSession();
    enablePopunderOncePerSession();

    // The visible in-site banner is centralized and remains closable/minimizable.
    window.dispatchEvent(new CustomEvent('adwatuk_tool_action_executed', {
      detail: { action: actionName, timestamp: now }
    }));
    return true;
  } catch {
    return false;
  }
}

/** Generate isolated HTML iframe markup for the official responsive 728x90 banner. */
export function getAdsterraBannerIframeHtml(): string {
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
      * { box-sizing: border-box; margin: 0; padding: 0; }
      html, body { width: 100%; height: 100%; overflow: hidden; background: transparent; }
      body { display: flex; justify-content: center; align-items: center; }
      #ad-wrapper { display: flex; justify-content: center; align-items: center; width: 728px; height: 90px; }
    </style>
  </head>
  <body>
    <div id="ad-wrapper">
      <script type="text/javascript">
        atOptions = {
          'key' : '${ADSTERRA_CONFIG.BANNER_KEY}',
          'format' : 'iframe',
          'height' : ${ADSTERRA_CONFIG.BANNER_HEIGHT},
          'width' : ${ADSTERRA_CONFIG.BANNER_WIDTH},
          'params' : {}
        };
      </script>
      <script type="text/javascript" src="${ADSTERRA_CONFIG.BANNER_SCRIPT_URL}"></script>
    </div>
  </body>
</html>`;
}
