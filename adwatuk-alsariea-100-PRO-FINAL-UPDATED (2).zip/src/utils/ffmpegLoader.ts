import { FFmpeg } from '@ffmpeg/ffmpeg';
import { toBlobURL } from '@ffmpeg/util';

const CDN_BASE = 'https://unpkg.com/@ffmpeg/core@0.12.10/dist/esm';
let ffmpegInstance: FFmpeg | null = null;
let loadingPromise: Promise<FFmpeg> | null = null;

async function loadFromLocal(ffmpeg: FFmpeg): Promise<void> {
  const origin = window.location.origin;
  await ffmpeg.load({
    classWorkerURL: `${origin}/vendor/ffmpeg-worker/worker.js`,
    coreURL: `${origin}/vendor/ffmpeg/ffmpeg-core.js`,
    wasmURL: `${origin}/vendor/ffmpeg/ffmpeg-core.wasm`,
  });
}

async function loadFromCdn(ffmpeg: FFmpeg): Promise<void> {
  await ffmpeg.load({
    classWorkerURL: `${window.location.origin}/vendor/ffmpeg-worker/worker.js`,
    coreURL: await toBlobURL(`${CDN_BASE}/ffmpeg-core.js`, 'text/javascript'),
    wasmURL: await toBlobURL(`${CDN_BASE}/ffmpeg-core.wasm`, 'application/wasm'),
  });
}

/** Shared, local-first FFmpeg engine with an external fallback. */
export function getFFmpeg(): Promise<FFmpeg> {
  if (ffmpegInstance?.loaded) return Promise.resolve(ffmpegInstance);
  if (loadingPromise) return loadingPromise;

  loadingPromise = (async () => {
    let ffmpeg = new FFmpeg();
    try {
      await loadFromLocal(ffmpeg);
    } catch (localError) {
      console.warn('Local FFmpeg failed; using the external fallback.', localError);
      try { ffmpeg.terminate(); } catch {}
      ffmpeg = new FFmpeg();
      await loadFromCdn(ffmpeg);
    }
    ffmpegInstance = ffmpeg;
    return ffmpeg;
  })().finally(() => {
    loadingPromise = null;
  });

  return loadingPromise;
}

export function safeMediaFileName(originalName: string, prefix = 'input'): string {
  const extension = originalName.includes('.')
    ? originalName.split('.').pop()!.toLowerCase().replace(/[^a-z0-9]/g, '')
    : 'bin';
  return `${prefix}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}.${extension || 'bin'}`;
}

export async function deleteFFmpegFiles(ffmpeg: FFmpeg, ...names: string[]): Promise<void> {
  await Promise.all(names.filter(Boolean).map(async name => {
    try { await ffmpeg.deleteFile(name); } catch {}
  }));
}
