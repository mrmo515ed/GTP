export interface IcoPngEntry {
  size: number;
  bytes: Uint8Array;
}

/** Packs PNG images into a standards-compliant ICO container. */
export function packPngImagesAsIco(entries: IcoPngEntry[]): Uint8Array {
  if (!entries.length) throw new Error('لا توجد صور لإنشاء ICO');
  const directorySize = 6 + entries.length * 16;
  const totalSize = directorySize + entries.reduce((sum, entry) => sum + entry.bytes.byteLength, 0);
  const output = new Uint8Array(totalSize);
  const view = new DataView(output.buffer);
  view.setUint16(0, 0, true);
  view.setUint16(2, 1, true);
  view.setUint16(4, entries.length, true);
  let dataOffset = directorySize;

  entries.forEach((item, index) => {
    if (item.size < 1 || item.size > 256 || item.bytes.byteLength < 8) {
      throw new Error('بيانات صورة ICO غير صالحة');
    }
    const entry = 6 + index * 16;
    output[entry] = item.size === 256 ? 0 : item.size;
    output[entry + 1] = item.size === 256 ? 0 : item.size;
    output[entry + 2] = 0;
    output[entry + 3] = 0;
    view.setUint16(entry + 4, 1, true);
    view.setUint16(entry + 6, 32, true);
    view.setUint32(entry + 8, item.bytes.byteLength, true);
    view.setUint32(entry + 12, dataOffset, true);
    output.set(item.bytes, dataOffset);
    dataOffset += item.bytes.byteLength;
  });
  return output;
}
