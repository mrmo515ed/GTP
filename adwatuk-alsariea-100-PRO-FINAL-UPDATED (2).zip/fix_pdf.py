import re

with open('src/components/tools/converters/TextConverterSuite.tsx', 'r') as f:
    content = f.read()

# Make sure html2pdf is imported
if "import html2pdf from 'html2pdf.js';" not in content:
    content = content.replace("import { jsPDF } from 'jspdf';", "import { jsPDF } from 'jspdf';\nimport html2pdf from 'html2pdf.js';")
    if "import html2pdf" not in content:
        # just in case jspdf wasn't imported (wait, the code had new jsPDF, let's see how it was imported)
        content = "import html2pdf from 'html2pdf.js';\n" + content

old_pdf_code = """      try {
        const doc = new jsPDF({
          orientation: 'portrait',
          unit: 'mm',
          format: 'a4',
        });
        // Use standard margins
        const margin = pageMargin;
        const pageWidth = doc.internal.pageSize.getWidth();
        const maxLineWidth = pageWidth - margin * 2;
        doc.setFontSize(fontSize);
        const splitText = doc.splitTextToSize(inputText, maxLineWidth);
        
        let cursorY = margin + 10;
        const pageHeight = doc.internal.pageSize.getHeight();
        splitText.forEach((line: string) => {
          if (cursorY + 10 > pageHeight - margin) {
            doc.addPage();
            cursorY = margin + 10;
          }
          doc.text(line, margin, cursorY);
          cursorY += (fontSize * 0.4) + 3;
        });
        doc.save(`${fileName}.pdf`);
        confetti({ particleCount: 30, spread: 50, origin: { y: 0.8 } });
      } catch (err: any) {
        alert('تعذر إنشاء ملف PDF: ' + err.message);
      }"""

new_pdf_code = """      try {
        // Use html2pdf.js to properly render Arabic text and fonts
        const element = document.createElement('div');
        element.innerHTML = inputText.split('\\n').map(p => `<p style="margin-bottom: 8px;">${p}</p>`).join('');
        element.style.fontFamily = "'Cairo', 'Alexandria', system-ui, sans-serif";
        element.style.fontSize = `${fontSize}px`;
        element.style.lineHeight = '1.8';
        element.style.direction = 'rtl';
        element.style.textAlign = 'right';
        element.style.color = '#000000';
        element.style.padding = `${pageMargin}mm`;
        element.style.width = '100%';
        element.style.maxWidth = '800px'; // roughly A4 width at screen res
        element.style.background = '#ffffff';
        element.style.whiteSpace = 'pre-wrap';
        element.style.wordWrap = 'break-word';
        
        // Hide it but append it to body to render correctly
        element.style.position = 'absolute';
        element.style.left = '-9999px';
        document.body.appendChild(element);

        const opt = {
          margin:       0, // margin handled via padding
          filename:     `${fileName}.pdf`,
          image:        { type: 'jpeg', quality: 0.98 },
          html2canvas:  { scale: 2, useCORS: true },
          jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };

        html2pdf().set(opt).from(element).save().then(() => {
          document.body.removeChild(element);
          confetti({ particleCount: 30, spread: 50, origin: { y: 0.8 } });
        });
      } catch (err: any) {
        alert('تعذر إنشاء ملف PDF: ' + err.message);
      }"""

content = content.replace(old_pdf_code, new_pdf_code)

with open('src/components/tools/converters/TextConverterSuite.tsx', 'w') as f:
    f.write(content)
