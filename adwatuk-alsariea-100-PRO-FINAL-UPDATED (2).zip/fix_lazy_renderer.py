import re

with open('src/components/tools/ToolRenderer.tsx', 'r') as f:
    content = f.read()

content = content.replace("import React, { lazy, Suspense } from 'react';", "import React, { lazy, Suspense } from 'react';\nimport { lazyWithRetry } from '../../utils/lazyWithRetry';")

content = content.replace("lazy(() =>", "lazyWithRetry(() =>")

with open('src/components/tools/ToolRenderer.tsx', 'w') as f:
    f.write(content)
