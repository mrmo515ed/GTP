[![Netlify Status](https://api.netlify.com/api/v1/badges/9c2a1025-f79b-433e-8179-99b7b0cc7bfd/deploy-status)](https://app.netlify.com/projects/adwatuk-alsariea/deploys)


<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/a3c3eba3-ec40-42b5-9086-16a0d7f87b6f

## Run Locally

**Prerequisites:**  Node.js


1. Install dependencies:
   `npm install`
2. Set the `GEMINI_API_KEY` in [.env.local](.env.local) to your Gemini API key
3. Run the app:
   `npm run dev`
