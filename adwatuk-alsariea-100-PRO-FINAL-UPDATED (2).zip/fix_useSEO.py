import re

with open('src/hooks/useSEO.ts', 'r') as f:
    content = f.read()

content = content.replace("}: SEOProps) {", "}: SEOProps = {}) {")

with open('src/hooks/useSEO.ts', 'w') as f:
    f.write(content)
