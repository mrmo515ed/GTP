import wasmURL from '@ffmpeg/core/wasm?url';
console.log(wasmURL);
