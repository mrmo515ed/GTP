import re

with open('src/components/tools/converters/ArchiveConverter.tsx', 'r') as f:
    content = f.read()

state_addition = r"""  const [zipName, setZipName] = useState('archive');
  const [convertedResultUrl, setConvertedResultUrl] = useState<string | null>(null);
  const [convertedResultName, setConvertedResultName] = useState<string>('');
"""
content = re.sub(r"  const \[zipName, setZipName\] = useState\('archive'\);", state_addition, content)


new_handlers = r"""  const handleCreateZip = async () => {
    if (filesToZip.length === 0) {
      alert('الرجاء إضافة ملفات لضغطها');
      return;
    }

    setIsProcessing(true);
    setConvertedResultUrl(null);
    setConvertedResultName('');
    try {
      const zip = new JSZip();
      filesToZip.forEach(file => {
        zip.file(file.name, file);
      });

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      setConvertedResultUrl(url);
      setConvertedResultName(`${zipName || 'archive'}.zip`);

      confetti({ particleCount: 35, spread: 60 });
    } catch (err: any) {
      alert('خطأ أثناء إنشاء ملف ZIP: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (convertedResultUrl && convertedResultName) {
      const a = document.createElement('a');
      a.href = convertedResultUrl;
      a.download = convertedResultName;
      a.click();
    }
  };
"""

old_func_pattern = re.compile(r"  const handleCreateZip = async \(\) => \{.*?(?=\n  const removeFileToZip =)", re.DOTALL)
content = old_func_pattern.sub(new_handlers, content)

buttons_replace = r"""        {/* Action Buttons */}
        {currentMode !== 'extract-zip' && (
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
            <button
              onClick={() => {
                if (currentMode === 'create-zip') handleCreateZip();
              }}
              disabled={(currentMode === 'create-zip' && filesToZip.length === 0) || isProcessing}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-indigo-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5"
            >
              {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
              <span>معالجة وضغط</span>
            </button>
            
            {convertedResultUrl && (
              <button
                onClick={handleDownload}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-emerald-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5 animate-in fade-in zoom-in"
              >
                <Download className="w-4 h-4" />
                <span>تحميل الملف المضغوط</span>
              </button>
            )}
          </div>
        )}"""

content = re.sub(r"        \{\/\* Action Button \*\/}.*?<\/div>\n        \)}", buttons_replace.replace('\\', '\\\\'), content, flags=re.DOTALL)

with open('src/components/tools/converters/ArchiveConverter.tsx', 'w') as f:
    f.write(content)
