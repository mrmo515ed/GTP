import fs from 'fs';
import { ALL_TOOLS } from '../src/data/toolsData';

const tools = ALL_TOOLS.map(t => ({
  id: t.id,
  category: t.category,
  titleAr: t.titleAr
}));

console.log(JSON.stringify(tools, null, 2));
