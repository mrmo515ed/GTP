import fs from 'fs';

const path = 'src/components/tools/ToolRenderer.tsx';
let content = fs.readFileSync(path, 'utf8');

if (!content.includes("import { JsonToolsSuite }")) {
  content = content.replace(
    "import { UniversalImageConverter } from './image/UniversalImageConverter';",
    "import { UniversalImageConverter } from './image/UniversalImageConverter';\nimport { JsonToolsSuite } from './dev/JsonToolsSuite';"
  );
  
  content = content.replace(
    "case 'json-formatter':",
    "case 'json-formatter':\n    case 'json-suite':\n    case 'json-validator':\n    case 'json-minifier':\n    case 'json-to-xml':\n    case 'json-to-csv':\n    case 'json-to-yaml':\n      return <JsonToolsSuite defaultTab={toolId.replace('json-', '')} />;"
  );
  
  fs.writeFileSync(path, content);
  console.log('Patched ToolRenderer.tsx');
}
