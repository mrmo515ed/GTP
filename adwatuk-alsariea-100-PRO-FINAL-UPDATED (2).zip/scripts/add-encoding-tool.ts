import fs from 'fs';

const dataPath = 'src/data/toolsData.ts';
let content = fs.readFileSync(dataPath, 'utf8');

const encodingTool = `
  { id: 'encoding-suite', titleAr: 'مجموعة أدوات الترميز', titleEn: 'Encoding Tools Hub', descriptionAr: 'تشفير وفك تشفير Base64، URL، HTML Entities', category: 'encoding', icon: 'Shield', tags: ['base64', 'url', 'html', 'encode', 'decode', 'security'] },
`;

if (!content.includes("'encoding-suite'")) {
  content = content.replace("export const TOOLS_DATA: ToolDefinition[] = [", "export const TOOLS_DATA: ToolDefinition[] = [" + encodingTool);
  fs.writeFileSync(dataPath, content);
  console.log('Added encoding suite to toolsData.ts');
}
