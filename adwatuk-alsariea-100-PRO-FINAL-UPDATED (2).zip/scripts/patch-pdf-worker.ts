import fs from 'fs';
const path = 'src/components/tools/converters/DocumentConverter.tsx';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  "pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;",
  "pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.mjs`;"
);

fs.writeFileSync(path, content);
console.log('Patched workerSrc');
