import fs from 'fs';
const path = 'src/components/tools/ToolRenderer.tsx';
let content = fs.readFileSync(path, 'utf8');
if (!content.includes("import { SqlToolsSuite }")) {
  content = content.replace(
    "import { SvgToolsSuite } from './image/SvgToolsSuite';",
    "import { SvgToolsSuite } from './image/SvgToolsSuite';\nimport { SqlToolsSuite } from './dev/SqlToolsSuite';"
  );
  content = content.replace(
    "case 'base64-to-svg':\n      return <SvgToolsSuite defaultTab={toolId.replace('svg-', '') === 'base64-to-svg' ? 'from-base64' : toolId.replace('svg-', '')} />;",
    "case 'base64-to-svg':\n      return <SvgToolsSuite defaultTab={toolId.replace('svg-', '') === 'base64-to-svg' ? 'from-base64' : toolId.replace('svg-', '')} />;\n    case 'sql-suite':\n    case 'sql-formatter':\n    case 'sql-minifier':\n      return <SqlToolsSuite defaultTab={toolId.replace('sql-', '')} />;"
  );
  fs.writeFileSync(path, content);
  console.log('Patched ToolRenderer.tsx for SQL');
}
