import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import JSZip from 'jszip';
import { PDFDocument } from 'pdf-lib';
import * as XLSX from 'xlsx';
import { Document, Packer, Paragraph } from 'docx';
import { ALL_TOOLS } from '../src/data/toolsData';
import { hasExpectedSignature } from '../src/utils/fileSignatures';
import { packPngImagesAsIco } from '../src/utils/icoEncoder';

const here = path.dirname(fileURLToPath(import.meta.url));
const root = path.resolve(here, '..');
const results: { name: string; ok: boolean; detail: string }[] = [];
const check = (name: string, ok: boolean, detail: string) => results.push({ name, ok, detail });

const renderer = fs.readFileSync(path.join(root, 'src/components/tools/ToolRenderer.tsx'), 'utf8');
const cases = [...renderer.matchAll(/case\s+['"]([^'"]+)['"]\s*:/g)].map(match => match[1]);
const duplicateCases = [...new Set(cases.filter((value, index) => cases.indexOf(value) !== index))];
const missing = ALL_TOOLS.map(tool => tool.id).filter(id => !cases.includes(id));
check('145 tool definitions', ALL_TOOLS.length === 145 && new Set(ALL_TOOLS.map(t => t.id)).size === 145, `${ALL_TOOLS.length} tools`);
check('All tools have renderer cases', missing.length === 0, missing.join(', ') || '0 missing');
check('No duplicate renderer cases', duplicateCases.length === 0, duplicateCases.join(', ') || '0 duplicates');

const ffmpegCore = fs.readFileSync(path.join(root, 'public/vendor/ffmpeg/ffmpeg-core.js'));
const ffmpegWasm = fs.readFileSync(path.join(root, 'public/vendor/ffmpeg/ffmpeg-core.wasm'));
const ffmpegWorker = fs.readFileSync(path.join(root, 'public/vendor/ffmpeg-worker/worker.js'));
const pdfWorker = fs.readFileSync(path.join(root, 'public/vendor/pdf/pdf.worker.min.mjs'));
check('Local FFmpeg core', ffmpegCore.length > 50_000, `${ffmpegCore.length} bytes`);
check('Local FFmpeg WASM', ffmpegWasm.subarray(0, 4).equals(Buffer.from([0, 97, 115, 109])), `${ffmpegWasm.length} bytes, wasm signature`);
check('Local FFmpeg class worker', ffmpegWorker.includes(Buffer.from('FFMessageType')), `${ffmpegWorker.length} bytes`);
check('Local PDF worker', pdfWorker.length > 500_000, `${pdfWorker.length} bytes`);

const pdf = await PDFDocument.create();
pdf.addPage(); pdf.addPage();
const pdfBytes = await pdf.save();
const readPdf = await PDFDocument.load(pdfBytes);
check('PDF generate/read', hasExpectedSignature(pdfBytes, 'pdf') && readPdf.getPageCount() === 2, `${pdfBytes.length} bytes, 2 pages`);

const zip = new JSZip(); zip.file('result.txt', 'verified-result');
const zipBytes = await zip.generateAsync({ type: 'uint8array' });
const zipRead = await JSZip.loadAsync(zipBytes);
check('ZIP create/extract', hasExpectedSignature(zipBytes, 'zip') && await zipRead.file('result.txt')!.async('string') === 'verified-result', `${zipBytes.length} bytes`);

const sheet = XLSX.utils.json_to_sheet([{ name: 'اختبار', value: 145 }]);
const workbook = XLSX.utils.book_new(); XLSX.utils.book_append_sheet(workbook, sheet, 'Data');
const xlsxBytes = XLSX.write(workbook, { type: 'buffer', bookType: 'xlsx' });
check('XLSX generate', hasExpectedSignature(xlsxBytes, 'xlsx'), `${xlsxBytes.length} bytes`);

const docx = new Document({ sections: [{ children: [new Paragraph('اختبار عربي')] }] });
const docxBytes = await Packer.toBuffer(docx);
check('DOCX generate', hasExpectedSignature(docxBytes, 'docx'), `${docxBytes.length} bytes`);

const fakePng = new Uint8Array([0x89, 0x50, 0x4e, 0x47, 13, 10, 26, 10]);
const icoBytes = packPngImagesAsIco([{ size: 16, bytes: fakePng }, { size: 256, bytes: fakePng }]);
check('ICO container/signature', hasExpectedSignature(icoBytes, 'ico') && new DataView(icoBytes.buffer).getUint16(4, true) === 2, `${icoBytes.length} bytes, 2 images`);

for (const result of results) console.log(`${result.ok ? 'PASS' : 'FAIL'} | ${result.name} | ${result.detail}`);
if (results.some(result => !result.ok)) process.exit(1);
