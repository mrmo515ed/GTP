import fs from 'fs';

const path = 'src/components/tools/converters/VideoConverter.tsx';
let content = fs.readFileSync(path, 'utf8');

// Replace the GIF ffmpeg command with one that uses gifDuration and gifFps
content = content.replace(
  "command.push('-vf', 'fps=15,scale=480:-1:flags=lanczos,split[s0][s1];[s0]palettegen[p];[s1][p]paletteuse', '-loop', '0');",
  "command.push('-t', gifDuration.toString(), '-vf', `fps=${gifFps},scale=320:-1:flags=lanczos,split[s0][s1];[s0]palettegen=stats_mode=diff[p];[s1][p]paletteuse=dither=bayer:bayer_scale=5`, '-loop', '0');"
);

// Add the controls to the UI under the video player if the mode is video-to-gif
const controlsUI = `
        {/* Settings for GIF */}
        {currentMode === 'video-to-gif' && selectedFile && (
          <div className="flex gap-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-gray-200 dark:border-gray-700">
            <div className="flex-1">
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-2">مدة الـ GIF (ثواني) - أقصى حد يفضل 10 ثواني</label>
              <input type="range" min="1" max="15" value={gifDuration} onChange={(e) => setGifDuration(parseInt(e.target.value))} className="w-full accent-emerald-600" />
              <div className="text-center text-xs mt-1 text-emerald-600 font-bold">{gifDuration} ثانية</div>
            </div>
            <div className="flex-1">
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-2">عدد الإطارات (FPS) - الجودة</label>
              <input type="range" min="5" max="24" value={gifFps} onChange={(e) => setGifFps(parseInt(e.target.value))} className="w-full accent-emerald-600" />
              <div className="text-center text-xs mt-1 text-emerald-600 font-bold">{gifFps} إطار/ثانية</div>
            </div>
          </div>
        )}
`;

content = content.replace(
  "{/* Action Buttons */}",
  controlsUI + "\n        {/* Action Buttons */}"
);

fs.writeFileSync(path, content);
console.log('Patched VideoConverter.tsx');
