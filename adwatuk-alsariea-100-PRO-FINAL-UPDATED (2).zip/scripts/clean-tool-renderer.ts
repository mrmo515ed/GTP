import fs from 'fs';

const path = 'src/components/tools/ToolRenderer.tsx';
let content = fs.readFileSync(path, 'utf8');

// I will just remove the specific old cases that are duplicated

const toRemove = [
  "case 'json-formatter':\\s*return <JsonFormatter />;?",
  "case 'svg-optimizer':\\s*return <SvgOptimizer />;?",
  "case 'css-formatter':\\s*return <CssFormatter />;?",
  "case 'xml-formatter':\\s*return <SecurityDataSuite defaultTab=\"xml-formatter\" />;?",
  "case 'yaml-json-converter':\\s*return <SecurityDataSuite defaultTab=\"yaml-json\" />;?",
  "case 'json-suite':\\s*return <SecurityDataSuite defaultTab=\"json-suite\" />;?"
];

toRemove.forEach(regexStr => {
  const regex = new RegExp(regexStr, 'g');
  content = content.replace(regex, '');
});

// Since my patch scripts might have injected duplicates, let's also remove duplicate cases
// A generic way is to ensure we don't have multiple case 'foo': ... case 'foo':
// But actually, the warning is because the `case` was already in the massive list below.
// Let's remove the ones from the massive list if they exist there.

fs.writeFileSync(path, content);
console.log('Cleaned ToolRenderer.tsx');
