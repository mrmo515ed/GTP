import fs from 'fs';

const path = 'src/components/tools/ToolRenderer.tsx';
let content = fs.readFileSync(path, 'utf8');

if (!content.includes("import { XmlToolsSuite }")) {
  content = content.replace(
    "import { JsonToolsSuite } from './dev/JsonToolsSuite';",
    "import { JsonToolsSuite } from './dev/JsonToolsSuite';\nimport { XmlToolsSuite } from './dev/XmlToolsSuite';"
  );
  
  content = content.replace(
    "case 'json-to-yaml':\n      return <JsonToolsSuite defaultTab={toolId.replace('json-', '')} />;",
    "case 'json-to-yaml':\n      return <JsonToolsSuite defaultTab={toolId.replace('json-', '')} />;\n    case 'xml-suite':\n    case 'xml-formatter':\n    case 'xml-validator':\n    case 'xml-minifier':\n    case 'xml-to-json':\n    case 'xml-to-csv':\n    case 'xml-to-yaml':\n    case 'xml-escape':\n    case 'xml-unescape':\n      return <XmlToolsSuite defaultTab={toolId.replace('xml-', '')} />;"
  );
  
  fs.writeFileSync(path, content);
  console.log('Patched ToolRenderer.tsx for XML');
}
