import fs from 'fs';

const dataPath = 'src/data/toolsData.ts';
let content = fs.readFileSync(dataPath, 'utf8');

const mapping: Record<string, string> = {
  'data': 'dev',
  'audio': 'converters',
  'video': 'converters',
  'archives': 'documents',
  'currencies': 'misc',
  'time-date': 'converters',
  'calculators': 'misc',
  'surgery-3d': 'misc',
  'health': 'misc',
  'student': 'misc',
  'discovery': 'misc',
  'engineering': 'misc',
  'pdf': 'documents',
  'design': 'image',
  'social': 'misc',
  'favorites': 'favorites',
};

// I will use regex to replace category string if it matches
for (const [oldCat, newCat] of Object.entries(mapping)) {
  const regex = new RegExp(`category:\\s*'${oldCat}'`, 'g');
  content = content.replace(regex, `category: '${newCat}'`);
}

// Ensure 'encoding' category gets populated with security stuff
content = content.replace(/category:\s*'dev',\s*(icon:\s*'(Shield|Key)'|tags:.*?('security'|'hash'|'base64'))/g, (match) => {
  return match.replace(/category:\s*'dev'/, `category: 'encoding'`);
});

fs.writeFileSync(dataPath, content);
console.log('Categories remapped in toolsData.ts');
