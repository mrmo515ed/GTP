import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { ALL_TOOLS } from '../src/data/toolsData';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const rendererFile = fs.readFileSync(path.join(__dirname, '../src/components/tools/ToolRenderer.tsx'), 'utf8');

const missing: string[] = [];

for (const tool of ALL_TOOLS) {
  const caseRegex = new RegExp(`case\\s+['"\`]${tool.id}['"\`]`);
  if (!caseRegex.test(rendererFile)) {
    missing.push(tool.id);
  }
}

console.log(`Total tools in data: ${ALL_TOOLS.length}`);
console.log(`Missing in ToolRenderer: ${missing.length}`);
if (missing.length > 0) {
  console.log('Missing tool IDs:', missing);
} else {
  console.log('✅ ALL 100% OF TOOLS ARE FULLY MAPPED IN ToolRenderer!');
}
