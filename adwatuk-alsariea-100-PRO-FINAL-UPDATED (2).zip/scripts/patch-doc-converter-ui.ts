import fs from 'fs';
const path = 'src/components/tools/converters/DocumentConverter.tsx';
let content = fs.readFileSync(path, 'utf8');

// Add state variables
content = content.replace(
  "const [extractedContent, setExtractedContent] = useState<string>('');",
  "const [extractedContent, setExtractedContent] = useState<string>('');\n  const [error, setError] = useState<string | null>(null);\n  const [success, setSuccess] = useState<boolean>(false);"
);

// Reset states
content = content.replace(
  "setExtractedContent('');",
  "setExtractedContent('');\n    setError(null);\n    setSuccess(false);"
);

content = content.replace(
  "setIsProcessing(true);\n    setConvertedResultUrls([]);",
  "setIsProcessing(true);\n    setConvertedResultUrls([]);\n    setError(null);\n    setSuccess(false);"
);

// Set success states
content = content.replace(
  /confetti\(\{ particleCount: 30, spread: 50 \}\);/g,
  "setSuccess(true);\n        confetti({ particleCount: 30, spread: 50 });"
);

// Update error handling
content = content.replace(
  "alert('حدث خطأ أثناء المعالجة: ' + err.message);",
  "console.error(err);\n      setError(err.message || 'حدث خطأ أثناء المعالجة.');"
);

// Update UI
const oldUI = `            <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
              <button
                onClick={handleConvert}
                disabled={isProcessing}
                className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white px-8 py-3 rounded-xl font-bold transition-all flex items-center gap-2"
              >
                {isProcessing ? <RefreshCw className="w-5 h-5 animate-spin" /> : <RefreshCw className="w-5 h-5" />}
                <span>{isProcessing ? 'جاري المعالجة والتحويل...' : 'تحويل الملف الآن'}</span>
              </button>
              
              {convertedResultUrls.length > 0 && (
                <button
                  onClick={handleDownloadAll}
                  className="bg-green-500 hover:bg-green-600 text-white px-8 py-3 rounded-xl font-bold transition-all flex items-center gap-2"
                >
                  <Download className="w-5 h-5" />
                  <span>تنزيل النتائج</span>
                </button>
              )}
            </div>`;

const newUI = `            <div className="flex flex-wrap items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
              
              {error && (
                <div className="mr-auto p-2.5 px-4 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800 rounded-xl text-sm font-bold flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></span>
                  خطأ: {error}
                </div>
              )}
              
              {success && convertedResultUrls.length > 0 && (
                <div className="mr-auto p-2.5 px-4 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-xl text-sm font-bold flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-emerald-600"></div>
                  تم التحويل بنجاح!
                </div>
              )}

              <button
                onClick={handleConvert}
                disabled={isProcessing}
                className="bg-indigo-600 hover:bg-indigo-700 disabled:bg-gray-400 disabled:cursor-not-allowed text-white px-8 py-3 rounded-xl font-bold transition-all flex items-center gap-2"
              >
                {isProcessing ? <RefreshCw className="w-5 h-5 animate-spin" /> : <RefreshCw className="w-5 h-5" />}
                <span>{isProcessing ? 'جاري المعالجة...' : 'تحويل الملف الآن'}</span>
              </button>
              
              {convertedResultUrls.length > 0 && (
                <button
                  onClick={handleDownloadAll}
                  className="bg-emerald-500 hover:bg-emerald-600 text-white px-8 py-3 rounded-xl font-bold transition-all flex items-center gap-2"
                >
                  <Download className="w-5 h-5" />
                  <span>تنزيل النتائج</span>
                </button>
              )}
            </div>`;

content = content.replace(oldUI, newUI);

fs.writeFileSync(path, content);
console.log('Patched DocumentConverter UI');
