import fs from 'fs';
const path = 'src/components/layout/Navbar.tsx';
let content = fs.readFileSync(path, 'utf8');

content = content.replace(
  "url: window.location.href,",
  "url: 'https://adwatuk-alsariea.netlify.app',"
);
content = content.replace(
  "navigator.clipboard.writeText(window.location.href);",
  "navigator.clipboard.writeText('https://adwatuk-alsariea.netlify.app');"
);

fs.writeFileSync(path, content);
console.log('Patched Navbar.tsx');
