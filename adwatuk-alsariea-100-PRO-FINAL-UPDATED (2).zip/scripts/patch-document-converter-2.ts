import fs from 'fs';
const path = 'src/components/tools/converters/DocumentConverter.tsx';
let content = fs.readFileSync(path, 'utf8');

const oldTxtToPdf = `      else if (currentMode === 'txt-to-pdf' || currentMode === 'html-to-pdf') {
        const text = await selectedFile.text();
        const doc = new jsPDF();
        
        if (currentMode === 'html-to-pdf') {
          await doc.html(text, { callback: function (doc) { 
             const blob = doc.output('blob');
             setConvertedResultUrls([{ url: URL.createObjectURL(blob), name: \`\${fileName}.pdf\` }]);
             confetti({ particleCount: 30, spread: 50 });
          }, x: 10, y: 10, width: 180, windowWidth: 800 });
          return;
        } else {
          doc.text(doc.splitTextToSize(text, 180), 10, 10);
          const blob = doc.output('blob');
          setConvertedResultUrls([{ url: URL.createObjectURL(blob), name: \`\${fileName}.pdf\` }]);
          confetti({ particleCount: 30, spread: 50 });
        }
      }`;

const newTxtToPdf = `      else if (currentMode === 'txt-to-pdf' || currentMode === 'html-to-pdf') {
        const text = await selectedFile.text();
        let html = '';
        if (currentMode === 'html-to-pdf') {
          html = text;
        } else {
          html = \`<div dir="auto" style="font-family: sans-serif; padding: 40px; white-space: pre-wrap; font-size: 14px; color: #000;">\${text}</div>\`;
        }
        
        const opt = {
          margin:       10,
          filename:     \`\${fileName}.pdf\`,
          image:        { type: 'jpeg', quality: 0.98 },
          html2canvas:  { scale: 2, useCORS: true },
          jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };
        const pdfBlob = await html2pdf().set(opt).from(html).outputPdf('blob');
        
        setConvertedResultUrls([{ url: URL.createObjectURL(pdfBlob), name: \`\${fileName}.pdf\` }]);
        confetti({ particleCount: 30, spread: 50 });
      }`;

content = content.replace(oldTxtToPdf, newTxtToPdf);

// Also remove jsPDF from imports entirely since we don't need it.
content = content.replace("import jsPDF from 'jspdf';", "");

fs.writeFileSync(path, content);
console.log('Patched DocumentConverter.tsx txt-to-pdf successfully');
