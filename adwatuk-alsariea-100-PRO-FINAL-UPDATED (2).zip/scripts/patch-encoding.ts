import fs from 'fs';
const path = 'src/components/tools/ToolRenderer.tsx';
let content = fs.readFileSync(path, 'utf8');
if (!content.includes("import { EncodingSuite }")) {
  content = content.replace(
    "import { CodeToolsSuite } from './dev/CodeToolsSuite';",
    "import { CodeToolsSuite } from './dev/CodeToolsSuite';\nimport { EncodingSuite } from './dev/EncodingSuite';"
  );
  content = content.replace(
    "case 'js-minifier':\n      return <CodeToolsSuite defaultTab={toolId.includes('html') ? toolId.replace('-formatter', '-format').replace('-minifier', '-minify') : toolId.includes('css') ? toolId.replace('-formatter', '-format').replace('-minifier', '-minify') : toolId.includes('js') ? toolId.replace('-formatter', '-format').replace('-minifier', '-minify') : 'html-format'} />;",
    "case 'js-minifier':\n      return <CodeToolsSuite defaultTab={toolId.includes('html') ? toolId.replace('-formatter', '-format').replace('-minifier', '-minify') : toolId.includes('css') ? toolId.replace('-formatter', '-format').replace('-minifier', '-minify') : toolId.includes('js') ? toolId.replace('-formatter', '-format').replace('-minifier', '-minify') : 'html-format'} />;\n    case 'encoding-suite':\n    case 'base64-encode':\n    case 'base64-decode':\n    case 'url-encode':\n    case 'url-decode':\n    case 'html-encode':\n    case 'html-decode':\n      return <EncodingSuite defaultTab={toolId.replace('encoding-suite', 'base64-encode')} />;"
  );
  fs.writeFileSync(path, content);
  console.log('Patched ToolRenderer.tsx for Encoding');
}
