import fs from 'fs';

const suites = {
  'src/components/tools/dev/JsonToolsSuite.tsx': `export function JsonToolsSuite() { return <div>JsonToolsSuite</div>; }`,
  'src/components/tools/dev/XmlToolsSuite.tsx': `export function XmlToolsSuite() { return <div>XmlToolsSuite</div>; }`,
  'src/components/tools/dev/SqlToolsSuite.tsx': `export function SqlToolsSuite() { return <div>SqlToolsSuite</div>; }`,
  'src/components/tools/dev/CodeToolsSuite.tsx': `export function CodeToolsSuite() { return <div>CodeToolsSuite</div>; }`,
  'src/components/tools/dev/EncodingSuite.tsx': `export function EncodingSuite() { return <div>EncodingSuite</div>; }`,
  'src/components/tools/image/SvgToolsSuite.tsx': `export function SvgToolsSuite() { return <div>SvgToolsSuite</div>; }`,
};

for (const [file, content] of Object.entries(suites)) {
  if (!fs.existsSync(file)) {
    fs.writeFileSync(file, content);
  }
}
