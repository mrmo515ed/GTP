import fs from 'fs';
const path = 'src/components/tools/ToolRenderer.tsx';
let content = fs.readFileSync(path, 'utf8');
if (!content.includes("import { CodeToolsSuite }")) {
  content = content.replace(
    "import { SqlToolsSuite } from './dev/SqlToolsSuite';",
    "import { SqlToolsSuite } from './dev/SqlToolsSuite';\nimport { CodeToolsSuite } from './dev/CodeToolsSuite';"
  );
  content = content.replace(
    "case 'sql-minifier':\n      return <SqlToolsSuite defaultTab={toolId.replace('sql-', '')} />;",
    "case 'sql-minifier':\n      return <SqlToolsSuite defaultTab={toolId.replace('sql-', '')} />;\n    case 'code-formatters':\n    case 'html-formatter':\n    case 'html-minifier':\n    case 'css-formatter':\n    case 'css-minifier':\n    case 'js-formatter':\n    case 'js-minifier':\n      return <CodeToolsSuite defaultTab={toolId.includes('html') ? toolId.replace('-formatter', '-format').replace('-minifier', '-minify') : toolId.includes('css') ? toolId.replace('-formatter', '-format').replace('-minifier', '-minify') : toolId.includes('js') ? toolId.replace('-formatter', '-format').replace('-minifier', '-minify') : 'html-format'} />;"
  );
  fs.writeFileSync(path, content);
  console.log('Patched ToolRenderer.tsx for Code');
}
