import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { ALL_TOOLS, CATEGORIES } from '../src/data/toolsData';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const distDir = path.join(__dirname, '../dist');
const templatePath = path.join(distDir, 'index.html');

const BASE_URL = 'https://adwatuk-alsariea.netlify.app';
const DEFAULT_IMAGE = `${BASE_URL}/og-image.jpg`;

export function generateStaticPages() {
  if (!fs.existsSync(templatePath)) {
    console.warn('dist/index.html not found, skipping prerender page generation.');
    return;
  }

  const baseHtml = fs.readFileSync(templatePath, 'utf8');

  // Helper to replace or inject meta tags cleanly
  function createPageHtml(options: {
    title: string;
    description: string;
    url: string;
    image?: string;
    keywords?: string[];
    structuredData?: any;
  }) {
    let html = baseHtml;
    const { title, description, url, image = DEFAULT_IMAGE, keywords = [], structuredData } = options;

    // Replace <title>
    html = html.replace(/<title>.*?<\/title>/i, `<title>${title}</title>`);

    // Replace description
    html = html.replace(/<meta\s+name="description"\s+content=".*?"\s*\/?>/i, `<meta name="description" content="${description}" />`);

    // Replace og tags
    html = html.replace(/<meta\s+property="og:title"\s+content=".*?"\s*\/?>/i, `<meta property="og:title" content="${title}" />`);
    html = html.replace(/<meta\s+property="og:description"\s+content=".*?"\s*\/?>/i, `<meta property="og:description" content="${description}" />`);
    html = html.replace(/<meta\s+property="og:url"\s+content=".*?"\s*\/?>/i, `<meta property="og:url" content="${url}" />`);
    html = html.replace(/<meta\s+property="og:image"\s+content=".*?"\s*\/?>/i, `<meta property="og:image" content="${image}" />`);

    // Replace twitter tags
    html = html.replace(/<meta\s+name="twitter:title"\s+content=".*?"\s*\/?>/i, `<meta name="twitter:title" content="${title}" />`);
    html = html.replace(/<meta\s+name="twitter:description"\s+content=".*?"\s*\/?>/i, `<meta name="twitter:description" content="${description}" />`);
    html = html.replace(/<meta\s+name="twitter:image"\s+content=".*?"\s*\/?>/i, `<meta name="twitter:image" content="${image}" />`);

    // Add keywords if available
    if (keywords.length > 0) {
      const kwTag = `<meta name="keywords" content="${keywords.join(', ')}" />`;
      if (html.includes('name="keywords"')) {
        html = html.replace(/<meta\s+name="keywords"\s+content=".*?"\s*\/?>/i, kwTag);
      } else {
        html = html.replace('</head>', `  ${kwTag}\n</head>`);
      }
    }

    // Add canonical link
    const canonicalTag = `<link rel="canonical" href="${url}" />`;
    if (html.includes('rel="canonical"')) {
      html = html.replace(/<link\s+rel="canonical"\s+href=".*?"\s*\/?>/i, canonicalTag);
    } else {
      html = html.replace('</head>', `  ${canonicalTag}\n</head>`);
    }

    // Add Structured Data
    if (structuredData) {
      const jsonLd = `<script type="application/ld+json">\n${JSON.stringify(structuredData, null, 2)}\n</script>`;
      html = html.replace('</head>', `  ${jsonLd}\n</head>`);
    }

    return html;
  }

  // 1. Generate for Assistant
  const assistantDir = path.join(distDir, 'assistant');
  fs.mkdirSync(assistantDir, { recursive: true });
  const assistantHtml = createPageHtml({
    title: 'المساعد الذكي الخارق | روبوت محادثة فوري Gemini AI | أدواتك السريعة',
    description: 'روبوت محادثة ومساعد ذكي مدعوم بأحدث تقنيات الذكاء الاصطناعي للإجابة عن الأسئلة الطبية، الرياضية، البرمجية، وحل المعادلات مباشرة.',
    url: `${BASE_URL}/assistant`,
    keywords: ['مساعد ذكي', 'شات بوت', 'ذكاء اصطناعي', 'chatgpt', 'gemini 3.7', 'روبوت محادثة', 'أدواتك السريعة'],
    structuredData: {
      '@context': 'https://schema.org',
      '@type': 'SoftwareApplication',
      'name': 'المساعد الذكي الخارق',
      'description': 'روبوت محادثة ومساعد ذكي فوري.',
      'url': `${BASE_URL}/assistant`,
      'applicationCategory': 'UtilitiesApplication',
      'offers': { '@type': 'Offer', 'price': '0', 'priceCurrency': 'USD' }
    }
  });
  fs.writeFileSync(path.join(assistantDir, 'index.html'), assistantHtml, 'utf8');

  // 2. Generate for each Category
  for (const cat of CATEGORIES) {
    if (cat.id === 'all' || cat.id === 'popular' || cat.id === 'favorites') continue;
    const catDir = path.join(distDir, 'category', cat.id);
    fs.mkdirSync(catDir, { recursive: true });
    const catHtml = createPageHtml({
      title: `قسم ${cat.nameAr} - أدوات أونلاين مجانية وسريعة | أدواتك السريعة`,
      description: `${cat.descriptionAr} - استمتع بأدوات متطورة ومجانية 100% تعمل مباشرة في المتصفح.`,
      url: `${BASE_URL}/category/${cat.id}`,
      keywords: [cat.nameAr, cat.nameEn, 'أدوات مجانية', 'أدوات أونلاين', 'أدواتك السريعة']
    });
    fs.writeFileSync(path.join(catDir, 'index.html'), catHtml, 'utf8');
  }

  // 3. Generate for EACH Tool (all 150+ tools!)
  let toolCount = 0;
  for (const tool of ALL_TOOLS) {
    const toolDir = path.join(distDir, 'tool', tool.id);
    fs.mkdirSync(toolDir, { recursive: true });
    const categoryObj = CATEGORIES.find(c => c.id === tool.category);

    const toolHtml = createPageHtml({
      title: `${tool.titleAr} (${tool.titleEn}) - أداة أونلاين مجانية وسريعة | أدواتك السريعة`,
      description: `${tool.descriptionAr} - أداة مجانية 100% تعمل على المتصفح مباشرة بدون تسجيل وبدون برامج.`,
      url: `${BASE_URL}/tool/${tool.id}`,
      keywords: [...tool.tags, tool.titleAr, tool.titleEn, 'أدواتك السريعة', 'مجاني', 'أونلاين'],
      structuredData: {
        '@context': 'https://schema.org',
        '@type': 'SoftwareApplication',
        'name': tool.titleAr,
        'alternateName': tool.titleEn,
        'description': tool.descriptionAr,
        'url': `${BASE_URL}/tool/${tool.id}`,
        'applicationCategory': tool.category === 'surgery-3d' || tool.category === 'health' ? 'MedicalApplication' : 'UtilitiesApplication',
        'operatingSystem': 'All',
        'offers': {
          '@type': 'Offer',
          'price': '0',
          'priceCurrency': 'USD'
        }
      }
    });

    fs.writeFileSync(path.join(toolDir, 'index.html'), toolHtml, 'utf8');
    toolCount++;
  }

  console.log(`✅ Successfully generated ${toolCount} tool HTML pages + category pages + assistant with custom WhatsApp/Telegram/Facebook preview cards!`);
}

generateStaticPages();
