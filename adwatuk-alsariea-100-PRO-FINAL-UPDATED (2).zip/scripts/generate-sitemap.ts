import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { ALL_TOOLS, CATEGORIES } from '../src/data/toolsData';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const publicDir = path.join(__dirname, '../public');

const BASE_URL = 'https://adwatuk-alsariea.netlify.app';
const currentDate = new Date().toISOString().split('T')[0];

export function generateSitemap() {
  let sitemap = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9"
        xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://www.sitemaps.org/schemas/sitemap/0.9 http://www.sitemaps.org/schemas/sitemap/0.9/sitemap.xsd">

  <!-- Main Homepage -->
  <url>
    <loc>${BASE_URL}/</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>daily</changefreq>
    <priority>1.0</priority>
  </url>

  <!-- AI Smart Assistant -->
  <url>
    <loc>${BASE_URL}/assistant</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>daily</changefreq>
    <priority>0.95</priority>
  </url>
`;

  // Categories
  for (const cat of CATEGORIES) {
    if (cat.id === 'all' || cat.id === 'popular' || cat.id === 'favorites') continue;
    sitemap += `
  <url>
    <loc>${BASE_URL}/category/${cat.id}</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>0.85</priority>
  </url>`;
  }

  // All Tools (100% of the tools!)
  for (const tool of ALL_TOOLS) {
    const is3DOrMedical = tool.category === 'surgery-3d' || tool.category === 'health' || tool.isPopular || tool.isNew;
    const priority = is3DOrMedical ? '0.90' : '0.80';

    sitemap += `
  <url>
    <loc>${BASE_URL}/tool/${tool.id}</loc>
    <lastmod>${currentDate}</lastmod>
    <changefreq>weekly</changefreq>
    <priority>${priority}</priority>
  </url>`;
  }

  sitemap += `
</urlset>
`;

  fs.writeFileSync(path.join(publicDir, 'sitemap.xml'), sitemap.trim() + '\n', 'utf8');
  console.log(`✅ Generated sitemap.xml with ${ALL_TOOLS.length} tools and ${CATEGORIES.length} categories!`);
}

generateSitemap();
