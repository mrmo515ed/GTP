import fs from 'fs';

const dataPath = 'src/data/toolsData.ts';
let content = fs.readFileSync(dataPath, 'utf8');

// I need to add new tools to the tools array. I will inject them at the end.
const newTools = `
  { id: 'json-suite', titleAr: 'مجموعة أدوات JSON', titleEn: 'JSON Tools Hub', descriptionAr: 'تنسيق، تصغير، التحقق من الصحة وتحويل JSON إلى XML و CSV و YAML', category: 'json', icon: 'FileJson', tags: ['json', 'formatter', 'validator', 'csv', 'xml', 'yaml'] },
  { id: 'xml-suite', titleAr: 'مجموعة أدوات XML', titleEn: 'XML Tools Hub', descriptionAr: 'تنسيق، تصغير، التحقق من الصحة وتحويل XML', category: 'xml', icon: 'Code', tags: ['xml', 'formatter', 'validator'] },
  { id: 'svg-suite', titleAr: 'مجموعة أدوات SVG', titleEn: 'SVG Tools Hub', descriptionAr: 'تنسيق، تصغير، التحقق من الصحة وتحويل SVG', category: 'svg', icon: 'Image', tags: ['svg', 'formatter', 'validator', 'png', 'jpg'] },
  { id: 'sql-suite', titleAr: 'مجموعة أدوات SQL', titleEn: 'SQL Tools Hub', descriptionAr: 'تنسيق وتجميل وتصغير أكواد SQL', category: 'dev', icon: 'Database', tags: ['sql', 'formatter', 'minifier'] },
  { id: 'code-formatters', titleAr: 'منسقات الأكواد', titleEn: 'Code Formatters', descriptionAr: 'تنسيق وتصغير HTML, CSS, JavaScript', category: 'dev', icon: 'Code2', tags: ['html', 'css', 'javascript', 'formatter', 'minifier'] },
`;

if (!content.includes("'json-suite'")) {
  content = content.replace("export const TOOLS_DATA: ToolDefinition[] = [", "export const TOOLS_DATA: ToolDefinition[] = [" + newTools);
}

// Update Categories
const newCategories = `export const CATEGORIES: CategoryInfo[] = [
  { id: 'all', nameAr: 'جميع الأدوات ⭐', nameEn: 'All Tools', icon: 'LayoutGrid', descriptionAr: 'استعرض كافة الأدوات' },
  { id: 'popular', nameAr: 'الأكثر استخداماً 🔥', nameEn: 'Most Popular', icon: 'Flame', descriptionAr: 'الأدوات الأكثر شعبية' },
  { id: 'dev', nameAr: 'أدوات المطورين 🧑‍💻', nameEn: 'Developer Tools', icon: 'TerminalSquare', descriptionAr: 'أدوات برمجية، تنسيق أكواد، تحويل بيانات' },
  { id: 'svg', nameAr: 'أدوات SVG', nameEn: 'SVG Tools', icon: 'Vector', descriptionAr: 'معالجة وتحويل رسوميات المتجهات SVG' },
  { id: 'xml', nameAr: 'أدوات XML', nameEn: 'XML Tools', icon: 'FileCode2', descriptionAr: 'تنسيق، تحقق، وتحويل ملفات XML' },
  { id: 'json', nameAr: 'أدوات JSON', nameEn: 'JSON Tools', icon: 'Braces', descriptionAr: 'تنسيق، تحقق، وتحويل بيانات JSON' },
  { id: 'image', nameAr: 'الصور', nameEn: 'Images', icon: 'Image', descriptionAr: 'تعديل، ضغط، وتحويل الصور' },
  { id: 'documents', nameAr: 'الملفات والمستندات', nameEn: 'Documents & Files', icon: 'FileText', descriptionAr: 'تحويل ومعالجة ملفات PDF والمستندات' },
  { id: 'text', nameAr: 'النصوص', nameEn: 'Text', icon: 'Type', descriptionAr: 'تنسيق ومقارنة وعد النصوص' },
  { id: 'converters', nameAr: 'التحويلات', nameEn: 'Converters', icon: 'RefreshCw', descriptionAr: 'تحويل بين الصيغ والوحدات المختلفة' },
  { id: 'units', nameAr: 'محولات الوحدات', nameEn: 'Units', icon: 'Scale', descriptionAr: 'محولات القياس والأوزان' },
  { id: 'encoding', nameAr: 'الترميز والتشفير', nameEn: 'Encoding & Security', icon: 'Shield', descriptionAr: 'تشفير وفك تشفير البيانات، Base64، URL' },
  { id: 'misc', nameAr: 'أدوات متنوعة', nameEn: 'Miscellaneous', icon: 'MoreHorizontal', descriptionAr: 'مجموعة من الأدوات المتفرقة' }
];`;

content = content.replace(/export const CATEGORIES: CategoryInfo\[\] = \[[\s\S]*?\];/, newCategories);

fs.writeFileSync(dataPath, content);
console.log('Updated toolsData.ts Categories and Tools');
