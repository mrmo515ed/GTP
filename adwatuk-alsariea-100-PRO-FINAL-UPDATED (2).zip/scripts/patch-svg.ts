import fs from 'fs';

const path = 'src/components/tools/ToolRenderer.tsx';
let content = fs.readFileSync(path, 'utf8');

if (!content.includes("import { SvgToolsSuite }")) {
  content = content.replace(
    "import { XmlToolsSuite } from './dev/XmlToolsSuite';",
    "import { XmlToolsSuite } from './dev/XmlToolsSuite';\nimport { SvgToolsSuite } from './image/SvgToolsSuite';"
  );
  
  content = content.replace(
    "case 'xml-unescape':\n      return <XmlToolsSuite defaultTab={toolId.replace('xml-', '')} />;",
    "case 'xml-unescape':\n      return <XmlToolsSuite defaultTab={toolId.replace('xml-', '')} />;\n    case 'svg-suite':\n    case 'svg-formatter':\n    case 'svg-validator':\n    case 'svg-minifier':\n    case 'svg-optimizer':\n    case 'svg-to-png':\n    case 'svg-to-jpg':\n    case 'svg-to-webp':\n    case 'svg-to-base64':\n    case 'base64-to-svg':\n      return <SvgToolsSuite defaultTab={toolId.replace('svg-', '') === 'base64-to-svg' ? 'from-base64' : toolId.replace('svg-', '')} />;"
  );
  
  fs.writeFileSync(path, content);
  console.log('Patched ToolRenderer.tsx for SVG');
}
