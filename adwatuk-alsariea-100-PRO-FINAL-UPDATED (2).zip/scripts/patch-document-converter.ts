import fs from 'fs';
const path = 'src/components/tools/converters/DocumentConverter.tsx';
let content = fs.readFileSync(path, 'utf8');

// replace jsPDF with html2pdf
content = content.replace("import jsPDF from 'jspdf';", "import html2pdf from 'html2pdf.js';\n// import jsPDF from 'jspdf';");

// update Word to PDF logic
content = content.replace(
`      else if (currentMode === 'word-to-pdf') {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const result = await mammoth.extractRawText({ arrayBuffer });
        const doc = new jsPDF();
        doc.text(doc.splitTextToSize(result.value, 180), 10, 10);
        const blob = doc.output('blob');
        setConvertedResultUrls([{ url: URL.createObjectURL(blob), name: \`\${fileName}.pdf\` }]);
        confetti({ particleCount: 30, spread: 50 });
      }`,
`      else if (currentMode === 'word-to-pdf') {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const result = await mammoth.convertToHtml({ arrayBuffer });
        const html = \`<div dir="auto" style="font-family: sans-serif; padding: 40px; color: #000; font-size: 16px; line-height: 1.6;">\${result.value}</div>\`;
        
        const opt = {
          margin:       10,
          filename:     \`\${fileName}.pdf\`,
          image:        { type: 'jpeg', quality: 0.98 },
          html2canvas:  { scale: 2 },
          jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };
        const pdfBlob = await html2pdf().set(opt).from(html).outputPdf('blob');
        
        setConvertedResultUrls([{ url: URL.createObjectURL(pdfBlob), name: \`\${fileName}.pdf\` }]);
        confetti({ particleCount: 30, spread: 50 });
      }`
);

// update TXT to PDF and HTML to PDF
content = content.replace(
`      else if (currentMode === 'txt-to-pdf' || currentMode === 'html-to-pdf') {
        const text = await selectedFile.text();
        const doc = new jsPDF();
        
        if (currentMode === 'html-to-pdf') {
          await doc.html(text, { callback: function (doc) { 
             const blob = doc.output('blob');
             setConvertedResultUrls([{ url: URL.createObjectURL(blob), name: \`\${fileName}.pdf\` }]);
             confetti({ particleCount: 30, spread: 50 });
          }, x: 10, y: 10, width: 180, windowWidth: 800 });
          return;
        } else {
          doc.text(doc.splitTextToSize(text, 180), 10, 10);
          const blob = doc.output('blob');
          setConvertedResultUrls([{ url: URL.createObjectURL(blob), name: \`\${fileName}.pdf\` }]);
          confetti({ particleCount: 30, spread: 50 });
        }
      }`,
`      else if (currentMode === 'txt-to-pdf' || currentMode === 'html-to-pdf') {
        const text = await selectedFile.text();
        let html = '';
        if (currentMode === 'html-to-pdf') {
          html = text;
        } else {
          html = \`<div dir="auto" style="font-family: sans-serif; padding: 40px; white-space: pre-wrap; font-size: 14px; color: #000;">\${text}</div>\`;
        }
        
        const opt = {
          margin:       10,
          filename:     \`\${fileName}.pdf\`,
          image:        { type: 'jpeg', quality: 0.98 },
          html2canvas:  { scale: 2, useCORS: true },
          jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };
        const pdfBlob = await html2pdf().set(opt).from(html).outputPdf('blob');
        
        setConvertedResultUrls([{ url: URL.createObjectURL(pdfBlob), name: \`\${fileName}.pdf\` }]);
        confetti({ particleCount: 30, spread: 50 });
      }`
);

// update Excel to PDF logic
content = content.replace(
`      else if (currentMode === 'excel-to-pdf') {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const json = XLSX.utils.sheet_to_json(worksheet, { header: 1 }) as any[][];
        
        const doc = new jsPDF();
        let y = 10;
        json.forEach((row) => {
           const rowText = row.join(' | ');
           doc.text(doc.splitTextToSize(rowText, 180), 10, y);
           y += 10;
           if (y > 280) {
             doc.addPage();
             y = 10;
           }
        });
        const blob = doc.output('blob');
        setConvertedResultUrls([{ url: URL.createObjectURL(blob), name: \`\${fileName}.pdf\` }]);
        confetti({ particleCount: 30, spread: 50 });
      }`,
`      else if (currentMode === 'excel-to-pdf') {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const workbook = XLSX.read(arrayBuffer, { type: 'array' });
        const firstSheetName = workbook.SheetNames[0];
        const worksheet = workbook.Sheets[firstSheetName];
        const htmlTable = XLSX.utils.sheet_to_html(worksheet);
        
        const html = \`
          <div dir="auto" style="font-family: sans-serif; padding: 20px;">
            <style>
              table { width: 100%; border-collapse: collapse; }
              td, th { border: 1px solid #ddd; padding: 8px; font-size: 12px; }
            </style>
            \${htmlTable}
          </div>
        \`;
        
        const opt = {
          margin:       10,
          filename:     \`\${fileName}.pdf\`,
          image:        { type: 'jpeg', quality: 0.98 },
          html2canvas:  { scale: 2 },
          jsPDF:        { unit: 'mm', format: 'a4', orientation: 'portrait' }
        };
        const pdfBlob = await html2pdf().set(opt).from(html).outputPdf('blob');
        
        setConvertedResultUrls([{ url: URL.createObjectURL(pdfBlob), name: \`\${fileName}.pdf\` }]);
        confetti({ particleCount: 30, spread: 50 });
      }`
);

fs.writeFileSync(path, content);
console.log('Patched DocumentConverter.tsx successfully');
