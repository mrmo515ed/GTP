import React, { useState } from 'react';
import { Heart, Sparkles, X, CheckCircle2, Gift, ExternalLink, Play } from 'lucide-react';
import { getAdsterraBannerIframeHtml, triggerSupportSiteAd } from '../../utils/adsterraManager';

export function SupportAdButton() {
  const [isOpen, setIsOpen] = useState(false);
  const [hasWatched, setHasWatched] = useState(false);

  const adIframeHtml = getAdsterraBannerIframeHtml();

  const handleOpen = () => {
    // Open only the in-site banner. The Smart Link remains an explicit second choice.
    setIsOpen(true);
    
    // After 5 seconds of viewing, mark as rewarded/supported
    setTimeout(() => {
      setHasWatched(true);
    }, 5000);
  };

  const handleDirectClick = () => {
    setHasWatched(true);
    triggerSupportSiteAd();
  };

  return (
    <>
      {/* Support Button Card in Footer / Bottom */}
      <div className="w-full max-w-xl mx-auto my-6 px-4">
        <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-emerald-500/10 via-teal-500/10 to-emerald-500/10 dark:from-emerald-950/40 dark:via-teal-950/40 dark:to-emerald-950/40 border border-emerald-500/20 dark:border-emerald-500/30 p-4 sm:p-5 text-center backdrop-blur-xs">
          <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="flex items-center gap-3 text-right">
              <div className="w-11 h-11 rounded-xl overflow-hidden bg-gray-900 border border-emerald-500/40 shrink-0 shadow-md shadow-emerald-500/20">
                <img src="/logo-96.webp" alt="شعار أدواتك السريعة" width="48" height="48" loading="lazy" decoding="async" className="w-full h-full object-cover" />
              </div>
              <div>
                <h4 className="text-sm font-bold text-gray-900 dark:text-white flex items-center gap-1.5">
                  <span>ادعم استمرارية الموقع مجاناً</span>
                  <Sparkles className="w-3.5 h-3.5 text-amber-500 animate-spin" />
                </h4>
                <p className="text-xs text-gray-600 dark:text-gray-400">
                  مشاهدة إعلان واحد تساعدنا في إبقاء أكثر من 140 أداة ومحاكي مجانية 100%
                </p>
              </div>
            </div>

            <button
              onClick={handleOpen}
              className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-600 hover:to-teal-700 text-white text-xs font-bold shadow-lg shadow-emerald-500/25 hover:shadow-emerald-500/40 transition-all transform active:scale-95 flex items-center justify-center gap-2 shrink-0 cursor-pointer"
            >
              <Gift className="w-4 h-4 text-amber-300" />
              <span>شاهد إعلان لدعم الموقع 💖</span>
            </button>
          </div>
        </div>
      </div>

      {/* Support Ad Modal */}
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm animate-in fade-in duration-200">
          <div 
            className="relative w-full max-w-2xl bg-white dark:bg-gray-900 rounded-2xl shadow-2xl border border-gray-100 dark:border-gray-800 overflow-hidden flex flex-col p-4 sm:p-6"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close Button */}
            <button
              onClick={() => setIsOpen(false)}
              className="absolute top-3 left-3 p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-200 rounded-full hover:bg-gray-100 dark:hover:bg-gray-800 transition"
              title="إغلاق"
            >
              <X className="w-5 h-5" />
            </button>

            {/* Header */}
            <div className="text-center space-y-1.5 mb-4">
              <div className="w-14 h-14 mx-auto rounded-2xl overflow-hidden bg-gray-900 border-2 border-emerald-500/40 shadow-lg shadow-emerald-500/20 mb-2">
                <img src="/logo-96.webp" alt="شعار أدواتك السريعة" width="48" height="48" loading="lazy" decoding="async" className="w-full h-full object-cover" />
              </div>
              <h3 className="text-base sm:text-lg font-black text-gray-900 dark:text-white">
                شكراً لدعمك مجتمع "أدواتك السريعة" 🌟
              </h3>
              <p className="text-xs text-gray-500 dark:text-gray-400 max-w-md mx-auto">
                شفرة الإعلان الرسمية تعمل الآن لدعم سيرفرات الموقع واستمراريته مجاناً.
              </p>
            </div>

            {/* Ad Container */}
            <div className="w-full flex flex-col items-center justify-center bg-gray-50 dark:bg-gray-950/60 rounded-xl p-3 border border-gray-200/80 dark:border-gray-800 min-h-[110px] overflow-hidden">
              <div className="text-[10px] text-gray-400 font-mono mb-2">شفرة الإعلان الداعم • Adsterra Official Script</div>
              <div className="w-full flex justify-center items-center overflow-x-auto">
                <iframe
                  srcDoc={adIframeHtml}
                  width="728"
                  height="90"
                  frameBorder="0"
                  scrolling="no"
                  style={{ display: 'block', border: 'none', background: 'transparent' }}
                  title="Support Adsterra Script/Banner"
                />
              </div>
            </div>

            {/* Action buttons */}
            <div className="mt-4 flex flex-col sm:flex-row items-center justify-between gap-3 pt-3 border-t border-gray-100 dark:border-gray-800">
              <div className="flex items-center gap-1.5 text-xs text-emerald-600 dark:text-emerald-400 font-bold">
                <CheckCircle2 className="w-4 h-4" />
                <span>{hasWatched ? 'تم تسجيل مشاهدة الإعلان والدعم! شكراً لك 💖' : 'جاري تشغيل شفرة الإعلان لدعم الموقع...'}</span>
              </div>
              
              <div className="flex items-center gap-2 w-full sm:w-auto">
                <button
                  onClick={handleDirectClick}
                  className="flex-1 sm:flex-none px-3.5 py-1.5 text-xs font-bold rounded-lg bg-emerald-500 hover:bg-emerald-600 text-white flex items-center justify-center gap-1.5 shadow-sm transition"
                >
                  <ExternalLink className="w-3.5 h-3.5" />
                  <span>فتح رابط الشفرة الإعلانية</span>
                </button>

                <button
                  onClick={() => setIsOpen(false)}
                  className="px-3.5 py-1.5 text-xs font-bold rounded-lg bg-gray-100 hover:bg-gray-200 dark:bg-gray-800 dark:hover:bg-gray-700 text-gray-700 dark:text-gray-200 transition"
                >
                  إغلاق
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
