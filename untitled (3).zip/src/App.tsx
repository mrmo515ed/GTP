import React, { useState, useEffect, useMemo, useCallback, lazy, Suspense } from 'react';
import { lazyWithRetry } from './utils/lazyWithRetry';
import { Routes, Route, useNavigate, useLocation } from 'react-router-dom';
import { ErrorBoundary } from './components/common/ErrorBoundary';
import { motion, AnimatePresence } from 'motion/react';
import { ALL_TOOLS, CATEGORIES } from './data/toolsData';
import { ToolDefinition, ToolCategory } from './types';
import { useSEO } from './hooks/useSEO';

// Always loaded core layout components
import { Navbar } from './components/layout/Navbar';
import { HeroSection } from './components/layout/HeroSection';
import { CategoryNav } from './components/layout/CategoryNav';
import { CategoryGrid } from './components/layout/CategoryGrid';
import { ToolCard } from './components/layout/ToolCard';
import { Footer } from './components/layout/Footer';
import { BottomNav } from './components/layout/BottomNav';
import { ProfessionalToolsSlider } from './components/layout/ProfessionalToolsSlider';
import { NetlifyDomainBanner } from './components/layout/NetlifyDomainBanner';
import { AdSlot } from './components/ads/AdSlot';
import { AdOverlay } from './components/ads/AdOverlay';
import { CategoryHeroBanner } from './components/layout/CategoryHeroBanner';
import { QuickToolsFloatingButton } from './components/layout/QuickToolsFloatingButton';
import { LoadingFallback } from './components/layout/LoadingFallback';
import { triggerToolActionAd } from './utils/adsterraManager';

import { Sparkles, Layers, SearchX, Flame, ArrowRight, Home, Grid } from 'lucide-react';

// Dynamically split pages (loaded on demand via React.lazy)
const ToolPage = lazyWithRetry(() => import('./components/pages/ToolPage').then(m => ({ default: m.ToolPage })));
const CategoryPage = lazyWithRetry(() => import('./components/pages/CategoryPage').then(m => ({ default: m.CategoryPage })));
const AssistantPage = lazyWithRetry(() => import('./components/pages/AssistantPage').then(m => ({ default: m.AssistantPage })));

// Dynamically split secondary views
const DiscoveryView = lazyWithRetry(() => import('./components/layout/DiscoveryView').then(m => ({ default: m.DiscoveryView })));
const PopularView = lazyWithRetry(() => import('./components/layout/PopularView').then(m => ({ default: m.PopularView })));
const NewToolsView = lazyWithRetry(() => import('./components/layout/NewToolsView').then(m => ({ default: m.NewToolsView })));
const AllToolsAndCategoriesView = lazyWithRetry(() => import('./components/layout/AllToolsAndCategoriesView').then(m => ({ default: m.AllToolsAndCategoriesView })));

// Dynamically split interactive modals
const QuickSearchModal = lazyWithRetry(() => import('./components/layout/QuickSearchModal').then(m => ({ default: m.QuickSearchModal })));
const AboutModal = lazyWithRetry(() => import('./components/layout/AboutModal').then(m => ({ default: m.AboutModal })));
const QuickToolsAssistantModal = lazyWithRetry(() => import('./components/layout/QuickToolsAssistantModal').then(m => ({ default: m.QuickToolsAssistantModal })));
const MoreModal = lazyWithRetry(() => import('./components/layout/MoreModal').then(m => ({ default: m.MoreModal })));
const PWAInstallModal = lazyWithRetry(() => import('./components/layout/PWAInstallModal').then(m => ({ default: m.PWAInstallModal })));

export function App() {
  const navigate = useNavigate();
  const location = useLocation();

  // Global Homepage SEO & Structured Data
  useSEO(
    location.pathname === '/'
      ? {
          title: 'أدواتك السريعة | منصة أدوات مجانية وسريعة 100% في المتصفح',
          description: 'أكثر من 150 أداة ومحاكي احترافي: جراحة وتشريح 3D، تحويل الصور، معالجة PDF، حاسبات مالية وطبية، روبوت ذكي والمزيد!',
          keywords: ['أدواتك السريعة', 'أدوات أونلاين', 'جراحة 3D', 'جراحة قلب', 'محول صور', 'pdf', 'حاسبة عمر', 'ذكاء اصطناعي'],
          canonicalUrl: 'https://adwatuk-alsariea.netlify.app/',
          ogType: 'website',
          structuredData: [
            {
              '@context': 'https://schema.org',
              '@type': 'WebSite',
              'name': 'أدواتك السريعة',
              'url': 'https://adwatuk-alsariea.netlify.app/',
              'potentialAction': {
                '@type': 'SearchAction',
                'target': {
                  '@type': 'EntryPoint',
                  'urlTemplate': 'https://adwatuk-alsariea.netlify.app/?q={search_term_string}'
                },
                'query-input': 'required name=search_term_string'
              }
            },
            {
              '@context': 'https://schema.org',
              '@type': 'Organization',
              'name': 'أدواتك السريعة',
              'url': 'https://adwatuk-alsariea.netlify.app/',
              'logo': 'https://adwatuk-alsariea.netlify.app/icon-512.jpg'
            }
          ]
        }
      : undefined
  );

  const [activeCategory, setActiveCategory] = useState<ToolCategory>('home');
  const [searchQuery, setSearchQuery] = useState('');
  const [favorites, setFavorites] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('quicktools_favorites');
      return saved ? JSON.parse(saved) : ['3d-surgery-simulator', 'universal-image-converter', 'mega-converters-suite', 'age-calculator'];
    } catch {
      return ['3d-surgery-simulator', 'universal-image-converter', 'mega-converters-suite', 'age-calculator'];
    }
  });

  const [darkMode, setDarkMode] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('quicktools_theme');
      if (saved) return saved === 'dark';
      return window.matchMedia('(prefers-color-scheme: dark)').matches;
    } catch {
      return false;
    }
  });

  const [isSearchModalOpen, setIsSearchModalOpen] = useState(false);
  const [isAboutModalOpen, setIsAboutModalOpen] = useState(false);
  const [isAssistantModalOpen, setIsAssistantModalOpen] = useState(false);
  const [isMoreModalOpen, setIsMoreModalOpen] = useState(false);
  
  const [toolUsage, setToolUsage] = useState<Record<string, number>>(() => {
    try {
      const saved = localStorage.getItem('quicktools_usage');
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  // Toggle Dark Mode
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('quicktools_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('quicktools_theme', 'light');
    }
  }, [darkMode]);

  // Sync Favorites to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('quicktools_favorites', JSON.stringify(favorites));
    } catch {}
  }, [favorites]);

  // Sync Tool Usage to LocalStorage
  useEffect(() => {
    try {
      localStorage.setItem('quicktools_usage', JSON.stringify(toolUsage));
    } catch {}
  }, [toolUsage]);

  // Track Tool Use
  const handleToolUse = useCallback((toolId: string) => {
    setToolUsage(prev => ({
      ...prev,
      [toolId]: (prev[toolId] || 0) + 1
    }));
  }, []);

  // Keyboard shortcut for search (Cmd+K / Ctrl+K)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'k') {
        e.preventDefault();
        setIsSearchModalOpen(prev => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  // Toggle Favorite
  const toggleFavorite = useCallback((id: string) => {
    setFavorites(prev =>
      prev.includes(id) ? prev.filter(item => item !== id) : [...prev, id]
    );
  }, []);

  // Select Tool Navigation
  const handleToolSelect = useCallback((tool: ToolDefinition) => {
    navigate(`/tool/${tool.id}`);
  }, [navigate]);

  // Filter tools based on search and category
  const filteredTools = useMemo(() => {
    return ALL_TOOLS.filter(tool => {
      const matchesSearch = searchQuery.trim() === '' || 
        tool.titleAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tool.titleEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tool.descriptionAr.toLowerCase().includes(searchQuery.toLowerCase()) ||
        tool.tags.some(tag => tag.toLowerCase().includes(searchQuery.toLowerCase()));

      if (activeCategory === 'home') {
        return matchesSearch;
      }
      if (activeCategory === 'all' || activeCategory === 'popular' || activeCategory === 'new' || activeCategory === 'discovery') {
        return matchesSearch;
      }
      if (activeCategory === 'favorites') {
        return matchesSearch && favorites.includes(tool.id);
      }
      return matchesSearch && tool.category === activeCategory;
    });
  }, [searchQuery, activeCategory, favorites]);

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-950 text-gray-900 dark:text-gray-100 font-sans transition-colors duration-200 selection:bg-emerald-500 selection:text-white pb-16 md:pb-0">
      
      {/* Official Domain Announcement Banner */}
      <NetlifyDomainBanner />

      {/* Top Main Navbar */}
      <Navbar
        darkMode={darkMode}
        setDarkMode={setDarkMode}
        onOpenSearch={() => setIsSearchModalOpen(true)}
        favoritesCount={favorites.length}
        onSelectCategory={(cat) => {
          setActiveCategory(cat);
          if (location.pathname !== '/') {
            navigate('/');
          }
        }}
        activeCategory={activeCategory}
        onHomeClick={() => {
          setActiveCategory('home');
          setSearchQuery('');
          if (location.pathname !== '/') {
            navigate('/');
          }
        }}
        onOpenAbout={() => setIsAboutModalOpen(true)}
      />

            <ErrorBoundary>
        <Routes>
        <Route path="/" element={
          <>
            {/* Hero Header with Search (Shown strictly for Home view only) */}
            {activeCategory === 'home' && (
              <HeroSection
                searchQuery={searchQuery}
                setSearchQuery={setSearchQuery}
                totalToolsCount={ALL_TOOLS.length}
              />
            )}

            {/* Main Content Area */}
            <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
              
              {/* Top Home Leaderboard Banner */}
              <AdSlot type="top-leaderboard" className="my-2" label="إعلان مميز • يدعم مجانية واستمرارية المنصة" />

              {/* Category Tabs (Shown exclusively on Home page) */}
              {activeCategory === 'home' && (
                <div className="space-y-4">
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                    <CategoryNav
                      activeCategory={activeCategory}
                      onSelectCategory={(cat) => {
                        setActiveCategory(cat);
                        setSearchQuery('');
                        window.scrollTo({ top: 380, behavior: 'smooth' });
                      }}
                      favoritesCount={favorites.length}
                    />
                  </div>
                </div>
              )}

              {/* Dynamic View Sections */}
              <AnimatePresence mode="wait">
                {/* Discovery / Random Picker View */}
                {activeCategory === 'discovery' && (
                  <motion.div
                    key="view-discovery"
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -16 }}
                    transition={{ duration: 0.28, ease: 'easeOut' }}
                  >
                    <Suspense fallback={<LoadingFallback message="جاري تجهيز صفحة الاستكشاف..." />}>
                      <DiscoveryView
                        onSelectCategory={(cat) => {
                          setActiveCategory(cat);
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        onSelectTool={handleToolSelect}
                        favorites={favorites}
                        onToggleFavorite={toggleFavorite}
                      />
                    </Suspense>
                  </motion.div>
                )}

                {/* Popular View */}
                {activeCategory === 'popular' && (
                  <motion.div
                    key="view-popular"
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -16 }}
                    transition={{ duration: 0.28, ease: 'easeOut' }}
                  >
                    <Suspense fallback={<LoadingFallback message="جاري تحميل الأدوات الشائعة..." />}>
                      <PopularView
                        tools={filteredTools}
                        favorites={favorites}
                        onToggleFavorite={toggleFavorite}
                        onSelectTool={handleToolSelect}
                        onBack={() => {
                          setActiveCategory('all');
                          setSearchQuery('');
                        }}
                      />
                    </Suspense>
                  </motion.div>
                )}

                {/* New Tools View */}
                {activeCategory === 'new' && (
                  <motion.div
                    key="view-new"
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -16 }}
                    transition={{ duration: 0.28, ease: 'easeOut' }}
                  >
                    <Suspense fallback={<LoadingFallback message="جاري تحميل أحدث الأدوات..." />}>
                      <NewToolsView
                        tools={filteredTools}
                        favorites={favorites}
                        onToggleFavorite={toggleFavorite}
                        onSelectTool={handleToolSelect}
                        onBack={() => {
                          setActiveCategory('all');
                          setSearchQuery('');
                        }}
                      />
                    </Suspense>
                  </motion.div>
                )}

                {/* 2. When a Specific Category or Filter is Selected */}
                {activeCategory !== 'all' && activeCategory !== 'home' && activeCategory !== 'discovery' && activeCategory !== 'popular' && activeCategory !== 'new' && (
                  <motion.div
                    key={`view-category-${activeCategory}`}
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -16 }}
                    transition={{ duration: 0.28, ease: 'easeOut' }}
                    className="space-y-6"
                  >
                    {/* Distinctive Category Hero Banner with Specific Color Theme, Badges & Exit Button */}
                    <CategoryHeroBanner
                      categoryId={activeCategory}
                      toolsCount={filteredTools.length}
                      onBackToHome={() => {
                        setActiveCategory('home');
                        setSearchQuery('');
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                      onSelectAnotherCategory={(cat) => {
                        setActiveCategory(cat);
                        window.scrollTo({ top: 0, behavior: 'smooth' });
                      }}
                    />

                    {/* Filtered Category Tools Grid */}
                    <div className="space-y-4 pt-2">
                      <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 pb-2 border-b border-gray-200/60 dark:border-gray-800/60">
                        <div className="flex items-center gap-2 font-bold text-gray-800 dark:text-gray-200">
                          <Layers className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                          <span>أدوات القسم ({filteredTools.length})</span>
                        </div>
                      </div>

                      {filteredTools.length > 0 ? (
                        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
                          {filteredTools.map((tool) => (
                            <ToolCard
                              key={tool.id}
                              tool={tool}
                              isFavorite={favorites.includes(tool.id)}
                              onToggleFavorite={toggleFavorite}
                              onSelect={handleToolSelect}
                            />
                          ))}
                        </div>
                      ) : (
                        <div className="py-20 text-center space-y-3 bg-white dark:bg-gray-900 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 p-8">
                          <div className="w-12 h-12 rounded-2xl bg-emerald-50 dark:bg-emerald-950/50 text-emerald-600 dark:text-emerald-400 flex items-center justify-center mx-auto">
                            <Sparkles className="w-6 h-6" />
                          </div>
                          <h3 className="text-base font-bold text-gray-800 dark:text-gray-200">
                            {activeCategory === 'favorites'
                              ? 'قائمة المفضلة فارغة حالياً'
                              : 'لا توجد أدوات متوفرة في هذا القسم حالياً'}
                          </h3>
                          <p className="text-xs text-gray-500 max-w-sm mx-auto">
                            {activeCategory === 'favorites'
                              ? 'انقر على أيقونة النجمة بجانب أي أداة لإضافتها إلى قائمتك المفضلة والوصول السريع إليها.'
                              : 'يتم إضافة أدوات جديدة باستمرار لهذا القسم.'}
                          </p>
                          <button
                            onClick={() => {
                              setActiveCategory('home');
                              setSearchQuery('');
                            }}
                            className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-emerald-700 transition"
                          >
                            عرض الرئيسية
                          </button>
                        </div>
                      )}
                    </div>
                  </motion.div>
                )}

                {/* 3. Search Results Overlay (When User Types a Search Query) */}
                {searchQuery.trim() !== '' && (
                  <motion.div
                    key="view-search-results"
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -16 }}
                    transition={{ duration: 0.28, ease: 'easeOut' }}
                    className="space-y-4"
                  >
                    <div className="flex items-center justify-between text-xs text-gray-500 dark:text-gray-400 pb-2 border-b border-gray-200/60 dark:border-gray-800/60">
                      <div className="flex items-center gap-2 font-bold text-gray-800 dark:text-gray-200">
                        <Layers className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
                        <span>نتائج البحث عن &quot;{searchQuery}&quot; ({filteredTools.length})</span>
                      </div>

                      <button
                        onClick={() => setSearchQuery('')}
                        className="text-emerald-600 dark:text-emerald-400 hover:underline font-bold text-xs"
                      >
                        إلغاء البحث وإظهار الأقسام
                      </button>
                    </div>

                    {filteredTools.length > 0 ? (
                      <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 sm:gap-5">
                        {filteredTools.map((tool) => (
                          <ToolCard
                            key={tool.id}
                            tool={tool}
                            isFavorite={favorites.includes(tool.id)}
                            onToggleFavorite={toggleFavorite}
                            onSelect={handleToolSelect}
                          />
                        ))}
                      </div>
                    ) : (
                      <div className="py-20 text-center space-y-3 bg-white dark:bg-gray-900 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 p-8">
                        <SearchX className="w-10 h-10 text-gray-400 mx-auto" />
                        <h3 className="text-base font-bold text-gray-800 dark:text-gray-200">
                          لم نجد أي أداة تطابق &quot;{searchQuery}&quot;
                        </h3>
                        <p className="text-xs text-gray-500 max-w-sm mx-auto">
                          جرب البحث بكلمات عامة أو تصفح الأقسام الرئيسية مباشرة.
                        </p>
                        <button
                          onClick={() => {
                            setSearchQuery('');
                            setActiveCategory('home');
                          }}
                          className="px-4 py-2 bg-emerald-600 text-white rounded-xl text-xs font-bold shadow-xs hover:bg-emerald-700 transition"
                        >
                          عرض الرئيسية
                        </button>
                      </div>
                    )}
                  </motion.div>
                )}

                {/* 4. الرئيسية (Home) - يظهر فيه الأقسام كبطاقات أنيقة تفتح الأدوات عند النقر عليها */}
                {activeCategory === 'home' && !searchQuery && (
                  <motion.div
                    key="view-home-featured"
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -16 }}
                    transition={{ duration: 0.28, ease: 'easeOut' }}
                    className="space-y-8"
                  >
                    <ProfessionalToolsSlider />

                    {/* Middle Feed Banner */}
                    <AdSlot type="in-feed" className="my-6" label="إعلان • استكشف خدمات وأدوات مقترحة" />

                    {/* Category Grid Cards - Clean Categories Directory */}
                    <CategoryGrid
                      onSelectCategory={(cat) => {
                        setActiveCategory(cat);
                        window.scrollTo({ top: 380, behavior: 'smooth' });
                      }}
                    />
                  </motion.div>
                )}

                {/* 5. الكل (All) - صفحة كاملة وشاملة لجميع الأقسام والـ 145 أداة مع كافة مكملاتها */}
                {activeCategory === 'all' && !searchQuery && (
                  <motion.div
                    key="view-all-directory-full"
                    initial={{ opacity: 0, y: 16 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0, y: -16 }}
                    transition={{ duration: 0.28, ease: 'easeOut' }}
                    className="space-y-8"
                  >
                    <Suspense fallback={<LoadingFallback message="جاري تحميل دليل الأدوات الشامل..." />}>
                      <AllToolsAndCategoriesView
                        onSelectCategory={(cat) => {
                          setActiveCategory(cat);
                          window.scrollTo({ top: 0, behavior: 'smooth' });
                        }}
                        onSelectTool={handleToolSelect}
                        favorites={favorites}
                        onToggleFavorite={toggleFavorite}
                      />
                    </Suspense>
                  </motion.div>
                )}
              </AnimatePresence>
            </main>
          </>
        } />
        
        {/* Dedicated Category Route */}
        <Route path="/category/:categoryId" element={
          <main className="flex-1 w-full">
            <Suspense fallback={<LoadingFallback message="جاري تحميل القسم..." />}>
              <CategoryPage
                favorites={favorites}
                onToggleFavorite={toggleFavorite}
                onSelectTool={handleToolSelect}
                searchQuery={searchQuery}
              />
            </Suspense>
          </main>
        } />
        
        <Route path="/tool/:id" element={
          <main className="flex-1 w-full">
            <Suspense fallback={<LoadingFallback message="جاري تجهيز الأداة..." />}>
              <ToolPage 
                favorites={favorites} 
                onToggleFavorite={toggleFavorite} 
                onToolUse={handleToolUse}
              />
            </Suspense>
          </main>
        } />

        {/* Dedicated Standalone AI Assistant Page */}
        <Route path="/assistant" element={
          <main className="flex-1 w-full">
            <Suspense fallback={<LoadingFallback message="جاري تجهيز المساعد الذكي..." />}>
              <AssistantPage />
            </Suspense>
          </main>
        } />
        <Route path="/chat" element={
          <main className="flex-1 w-full">
            <Suspense fallback={<LoadingFallback message="جاري تجهيز المساعد الذكي..." />}>
              <AssistantPage />
            </Suspense>
          </main>
        } />
        <Route path="/ai-assistant" element={
          <main className="flex-1 w-full">
            <Suspense fallback={<LoadingFallback message="جاري تجهيز المساعد الذكي..." />}>
              <AssistantPage />
            </Suspense>
          </main>
        } />
        <Route path="*" element={
          <main className="flex-1 max-w-7xl w-full mx-auto px-4 py-20 text-center">
            <h2 className="text-3xl font-bold text-gray-900 dark:text-white mb-4">404 - الصفحة غير موجودة</h2>
            <p className="text-gray-500 mb-8">عذراً، لم نتمكن من العثور على الصفحة التي تبحث عنها.</p>
            <button onClick={() => window.location.href = '/'} className="px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold">العودة للرئيسية</button>
          </main>
        } />
              </Routes>
      </ErrorBoundary>
      
      {/* Footer */}
      <Footer />

      {/* Bottom Mobile Navigation */}
      <BottomNav 
        activeCategory={activeCategory} 
        onSelectCategory={(cat) => setActiveCategory(cat)} 
        onOpenMore={() => setIsMoreModalOpen(true)} 
      />

      {/* Cmd+K Quick Search Spotlight Modal (Lazy loaded when opened) */}
      {isSearchModalOpen && (
        <Suspense fallback={null}>
          <QuickSearchModal
            isOpen={isSearchModalOpen}
            onClose={() => setIsSearchModalOpen(false)}
            onSelectTool={handleToolSelect}
          />
        </Suspense>
      )}

      {/* About Us Modal (Lazy loaded when opened) */}
      {isAboutModalOpen && (
        <Suspense fallback={null}>
          <AboutModal
            isOpen={isAboutModalOpen}
            onClose={() => setIsAboutModalOpen(false)}
          />
        </Suspense>
      )}

      {/* Smart Quick Tools Floating Button (Navigates to dedicated assistant page) */}
      {location.pathname !== '/assistant' && location.pathname !== '/chat' && location.pathname !== '/ai-assistant' && (
        <QuickToolsFloatingButton onClick={() => navigate('/assistant')} />
      )}

      {/* Smart Quick Tools Assistant Chat Modal */}
      {isAssistantModalOpen && (
        <Suspense fallback={null}>
          <QuickToolsAssistantModal
            isOpen={isAssistantModalOpen}
            onClose={() => setIsAssistantModalOpen(false)}
            onSelectTool={handleToolSelect}
          />
        </Suspense>
      )}

      {/* More Settings & Statistics Drawer */}
      {isMoreModalOpen && (
        <Suspense fallback={null}>
          <MoreModal
            isOpen={isMoreModalOpen}
            onClose={() => setIsMoreModalOpen(false)}
            darkMode={darkMode}
            setDarkMode={setDarkMode}
            onOpenAbout={() => {
              setIsMoreModalOpen(false);
              setIsAboutModalOpen(true);
            }}
            onSelectCategory={(cat) => setActiveCategory(cat)}
            toolUsage={toolUsage}
            onSelectTool={(toolId) => navigate(`/tool/${toolId}`)}
          />
        </Suspense>
      )}

      {/* PWA Direct Web App Installation Modal */}
      <Suspense fallback={null}>
        <PWAInstallModal />
      </Suspense>

      {/* Floating Smart Action Ad Overlay (Triggers only when using tools, never on initial entry) */}
      <AdOverlay />
    </div>
  );
}

export default App;
