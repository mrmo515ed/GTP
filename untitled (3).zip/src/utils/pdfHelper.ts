import html2pdf from 'html2pdf.js';

export interface GeneratePdfOptions {
  filename?: string;
  title?: string;
  margin?: number;
  orientation?: 'portrait' | 'landscape';
  format?: string;
  onProgress?: (percent: number, status: string) => void;
}

/**
 * Robust, client-side HTML to PDF converter with 100% Arabic typography & RTL support.
 */
export async function convertHtmlToPdfBlob(
  htmlContent: string,
  options: GeneratePdfOptions = {}
): Promise<{ blob: Blob; url: string }> {
  const {
    filename = 'document.pdf',
    title = 'مستند',
    margin = 12,
    orientation = 'portrait',
    format = 'a4',
    onProgress
  } = options;

  onProgress?.(10, 'جاري تجهيز النص والخطوط العربية...');

  // Create isolated sandbox element in DOM for html2canvas rendering
  const container = document.createElement('div');
  container.id = 'pdf-render-sandbox-' + Date.now();
  container.style.position = 'fixed';
  container.style.top = '-99999px';
  container.style.left = '-99999px';
  container.style.width = orientation === 'portrait' ? '794px' : '1122px'; // Standard A4 px at 96 DPI
  container.style.padding = '36px 40px';
  container.style.background = '#ffffff';
  container.style.color = '#111827';
  container.style.direction = 'rtl';
  container.style.textAlign = 'right';
  container.style.fontFamily = "'Alexandria', 'Cairo', 'Segoe UI', Tahoma, Arial, sans-serif";
  container.style.fontSize = '14px';
  container.style.lineHeight = '1.7';
  container.style.boxSizing = 'border-box';
  container.style.zIndex = '-9999';

  // Inject content with printable styles
  container.innerHTML = `
    <style>
      #${container.id} * {
        box-sizing: border-box;
        font-family: 'Alexandria', 'Cairo', 'Segoe UI', Tahoma, Arial, sans-serif !important;
      }
      #${container.id} h1, #${container.id} h2, #${container.id} h3 {
        color: #0f172a;
        margin-top: 14px;
        margin-bottom: 10px;
        font-weight: bold;
      }
      #${container.id} p {
        margin-bottom: 12px;
        text-align: justify;
        line-height: 1.8;
      }
      #${container.id} table {
        width: 100%;
        border-collapse: collapse;
        margin: 16px 0;
        font-size: 12px;
      }
      #${container.id} th, #${container.id} td {
        border: 1px solid #cbd5e1;
        padding: 8px 10px;
        text-align: right;
      }
      #${container.id} th {
        background-color: #f1f5f9;
        font-weight: bold;
      }
      #${container.id} pre, #${container.id} code {
        direction: ltr;
        text-align: left;
        background-color: #f8fafc;
        border: 1px solid #e2e8f0;
        border-radius: 6px;
        padding: 8px 12px;
        font-family: monospace !important;
        font-size: 12px;
        white-space: pre-wrap;
      }
    </style>
    <div class="pdf-content-wrapper" dir="rtl">
      ${htmlContent}
    </div>
  `;

  document.body.appendChild(container);

  try {
    onProgress?.(30, 'جاري التقاط المحتوى وتحويله لرسوم متجهة...');

    const opt = {
      margin: margin,
      filename: filename.endsWith('.pdf') ? filename : `${filename}.pdf`,
      image: { type: 'jpeg' as const, quality: 0.98 },
      html2canvas: {
        scale: 2,
        useCORS: true,
        logging: false,
        letterRendering: true,
        scrollX: 0,
        scrollY: 0
      },
      jsPDF: {
        unit: 'mm',
        format: format,
        orientation: orientation
      },
      pagebreak: { mode: ['avoid-all', 'css', 'legacy'] }
    };

    onProgress?.(65, 'جاري بناء صفحات PDF النهائية...');

    // Generate PDF blob
    const worker = (html2pdf() as any).set(opt).from(container);
    const pdfBlob: Blob = await worker.output('blob');

    onProgress?.(95, 'جاري تجهيز رابط التحميل...');
    const url = URL.createObjectURL(pdfBlob);

    onProgress?.(100, 'اكتمل إنشاء المستند بنجاح!');
    return { blob: pdfBlob, url };
  } finally {
    // Cleanup DOM element
    if (document.body.contains(container)) {
      document.body.removeChild(container);
    }
  }
}
