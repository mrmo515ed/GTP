// Adsterra Integration & Smart Action Ad Manager for https://adwatuk-alsariea.netlify.app

export const ADSTERRA_CONFIG = {
  BANNER_KEY: 'e3aa8d523298c476b533f7044524797b',
  BANNER_SCRIPT_URL: 'https://movementssubscriptionobjection.com/e3aa8d523298c476b533f7044524797b/invoke.js',
  SMARTLINK_URL: 'https://movementssubscriptionobjection.com/stuqqi8sc?key=7684bf7e86a6c9e96b2548082cf6992b',
  SOCIAL_BAR_URL: 'https://movementssubscriptionobjection.com/ce/fc/f6/cefcf6000cb0970c117e93ad02873974.js',
  POPUNDER_URL: 'https://movementssubscriptionobjection.com/d1/b5/2d/d1b52d2a12ea105a1d4de4194083ed6b.js',
  BANNER_WIDTH: 728,
  BANNER_HEIGHT: 90,
  SITE_CANONICAL_URL: 'https://adwatuk-alsariea.netlify.app'
};

// Storage keys
const ACTION_COUNT_KEY = 'adwatuk_action_count';
const LAST_ACTION_AD_TIME_KEY = 'adwatuk_last_action_ad_time';

// Cooldown between action ads in milliseconds (5 minutes as requested)
const AD_COOLDOWN_MS = 5 * 60 * 1000;
// Trigger ad after every N meaningful tool actions
const ACTIONS_INTERVAL = 1;

let scriptsInjected = false;

function injectIntrusiveAds() {
  if (scriptsInjected) return;
  scriptsInjected = true;

  // Inject Social Bar
  const socialScript = document.createElement('script');
  socialScript.type = 'text/javascript';
  socialScript.src = ADSTERRA_CONFIG.SOCIAL_BAR_URL;
  document.body.appendChild(socialScript);

  // Inject Popunder
  const popunderScript = document.createElement('script');
  popunderScript.type = 'text/javascript';
  popunderScript.src = ADSTERRA_CONFIG.POPUNDER_URL;
  document.body.appendChild(popunderScript);
}

export function triggerSupportSiteAd() {
  // Directly open Smart Link in new tab
  window.open(ADSTERRA_CONFIG.SMARTLINK_URL, '_blank');
  
  // Also inject Social Bar and Popunder as a bonus
  injectIntrusiveAds();
  
  // Dispatch event for overlay banner
  window.dispatchEvent(new CustomEvent('adwatuk_tool_action_executed', {
    detail: { action: 'support_click', count: 1 }
  }));
}

/**
 * Triggered when a user performs a key action inside any tool (convert, calculate, download, copy, generate)
 * Ensures NO annoying popups on initial site entry, but rewards engagement smoothly upon tool execution.
 */
export function triggerToolActionAd(actionName: string = 'use_tool'): boolean {
  try {
    const now = Date.now();
    const lastTime = parseInt(localStorage.getItem(LAST_ACTION_AD_TIME_KEY) || '0', 10);
    const currentCount = parseInt(localStorage.getItem(ACTION_COUNT_KEY) || '0', 10) + 1;
    
    localStorage.setItem(ACTION_COUNT_KEY, currentCount.toString());

    // Check if cooldown has passed and threshold is met
    if (now - lastTime > AD_COOLDOWN_MS && (currentCount % ACTIONS_INTERVAL === 0 || currentCount === 2)) {
      localStorage.setItem(LAST_ACTION_AD_TIME_KEY, now.toString());
      
      // Inject Popunder and Social Bar on tool action
      injectIntrusiveAds();
      
      // Open Smart Link in background (Popunder-like behavior)
      const newWin = window.open(ADSTERRA_CONFIG.SMARTLINK_URL, '_blank');
      if (newWin) {
        newWin.blur();
        window.focus();
      }

      // We can dispatch a custom event for in-app awareness or trigger action link
      window.dispatchEvent(new CustomEvent('adwatuk_tool_action_executed', {
        detail: { action: actionName, count: currentCount }
      }));

      return true;
    }
  } catch {
    // Graceful fallback if localStorage is restricted
  }
  return false;
}

/**
 * Generate isolated HTML iframe markup for Adsterra 728x90 banner
 */
export function getAdsterraBannerIframeHtml(): string {
  return `<!DOCTYPE html>
<html lang="ar" dir="rtl">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <style>
      * { box-sizing: border-box; margin: 0; padding: 0; }
      body {
        margin: 0;
        padding: 0;
        display: flex;
        justify-content: center;
        align-items: center;
        background: transparent;
        overflow: hidden;
        width: 100%;
        height: 100%;
      }
      #ad-wrapper {
        display: flex;
        justify-content: center;
        align-items: center;
        width: 728px;
        height: 90px;
      }
    </style>
  </head>
  <body>
    <div id="ad-wrapper">
      <script type="text/javascript">
        atOptions = {
          'key' : '${ADSTERRA_CONFIG.BANNER_KEY}',
          'format' : 'iframe',
          'height' : ${ADSTERRA_CONFIG.BANNER_HEIGHT},
          'width' : ${ADSTERRA_CONFIG.BANNER_WIDTH},
          'params' : {}
        };
      </script>
      <script type="text/javascript" src="${ADSTERRA_CONFIG.BANNER_SCRIPT_URL}"></script>
    </div>
  </body>
</html>`;
}
