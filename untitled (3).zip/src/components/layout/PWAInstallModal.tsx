import React, { useState, useEffect } from 'react';
import { Download, Smartphone, Check, X, Laptop, Sparkles, ShieldCheck } from 'lucide-react';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed' }>;
}

export function PWAInstallModal() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isOpen, setIsOpen] = useState(false);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isDownloading, setIsDownloading] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState(false);

  useEffect(() => {
    // Check if already installed
    if (window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true) {
      setIsInstalled(true);
      return;
    }

    const handleBeforeInstall = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
      // If user hasn't dismissed it previously
      const hasDismissed = localStorage.getItem('adwatuk_install_prompt_dismissed');
      if (!hasDismissed) {
        // Show after 3 seconds of navigation
        const timer = setTimeout(() => setIsOpen(true), 3000);
        return () => clearTimeout(timer);
      }
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstall);

    // Custom trigger from navbar or more menu
    const handleTriggerPrompt = () => {
      setIsOpen(true);
    };
    window.addEventListener('adwatuk_trigger_install', handleTriggerPrompt);

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstall);
      window.removeEventListener('adwatuk_trigger_install', handleTriggerPrompt);
    };
  }, []);

  const handleInstallClick = async () => {
    if (deferredPrompt) {
      try {
        setIsDownloading(true);
        await deferredPrompt.prompt();
        const choice = await deferredPrompt.userChoice;
        setIsDownloading(false);
        if (choice.outcome === 'accepted') {
          setDownloadSuccess(true);
          setIsInstalled(true);
          setTimeout(() => setIsOpen(false), 2000);
        }
        setDeferredPrompt(null);
      } catch (err) {
        setIsDownloading(false);
      }
    } else {
      // Manual instructions for iOS / Chrome / Desktop
      setIsDownloading(true);
      setTimeout(() => {
        setIsDownloading(false);
        setDownloadSuccess(true);
      }, 1200);
    }
  };

  const handleClose = (neverShowAgain = false) => {
    setIsOpen(false);
    if (neverShowAgain) {
      localStorage.setItem('adwatuk_install_prompt_dismissed', 'true');
    }
  };

  if (!isOpen || isInstalled) return null;

  const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) && !(window as any).MSStream;

  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-3 sm:p-4 bg-black/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div 
        className="w-full max-w-md bg-white dark:bg-gray-900 rounded-3xl shadow-2xl border border-emerald-500/30 overflow-hidden text-right"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="relative bg-gradient-to-r from-emerald-600 to-teal-700 p-5 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-white/10 backdrop-blur-md border border-white/20 p-1 flex items-center justify-center shadow-lg">
              <img src="/icon-512.jpg" alt="أدواتك السريعة" className="w-full h-full object-cover rounded-xl" />
            </div>
            <div>
              <h3 className="text-base font-black flex items-center gap-1.5">
                <span>تثبيت تطبيق أدواتك السريعة</span>
                <Sparkles className="w-4 h-4 text-amber-300" />
              </h3>
              <p className="text-xs text-emerald-100 font-medium">استخدام فوري وسريع 100% بدون إنترنت</p>
            </div>
          </div>
          
          <button 
            onClick={() => handleClose(false)}
            className="w-8 h-8 rounded-full bg-white/10 hover:bg-white/20 flex items-center justify-center text-white transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Content */}
        <div className="p-5 space-y-4">
          <div className="space-y-2">
            <div className="flex items-center gap-2 text-xs font-bold text-gray-700 dark:text-gray-200">
              <Check className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>وصول سريع لأكثر من 145 أداة من شاشتك الرئيسية مباشرة</span>
            </div>
            <div className="flex items-center gap-2 text-xs font-bold text-gray-700 dark:text-gray-200">
              <Check className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>يعمل بدون اتصال بالإنترنت (Offline Mode)</span>
            </div>
            <div className="flex items-center gap-2 text-xs font-bold text-gray-700 dark:text-gray-200">
              <ShieldCheck className="w-4 h-4 text-emerald-500 shrink-0" />
              <span>لا يستهلك مساحة تخزين (تطبيق ويب فوري وخفيف جداً)</span>
            </div>
          </div>

          {/* iOS Special instructions */}
          {isIOS && (
            <div className="bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 rounded-2xl p-3 text-xs text-emerald-900 dark:text-emerald-200 space-y-1">
              <p className="font-black">على هواتف آيفون (iOS):</p>
              <p>1. اضغط على زر المشاركة <span className="font-bold">⎋</span> في متصفح سفاري بالأسفل.</p>
              <p>2. اختر <span className="font-bold">&quot;إضافة إلى الشاشة الرئيسية (Add to Home Screen)&quot;</span>.</p>
            </div>
          )}

          {/* Action Buttons */}
          <div className="pt-2 space-y-2">
            {!isIOS ? (
              <button
                onClick={handleInstallClick}
                disabled={isDownloading}
                className="w-full py-3.5 px-4 bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-700 hover:to-teal-700 text-white rounded-2xl font-black text-sm shadow-lg shadow-emerald-500/25 flex items-center justify-center gap-2 transition active:scale-98 cursor-pointer disabled:opacity-75"
              >
                {isDownloading ? (
                  <span className="flex items-center gap-2">
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                    <span>جاري التثبيت على جهازك...</span>
                  </span>
                ) : downloadSuccess ? (
                  <span className="flex items-center gap-2">
                    <Check className="w-5 h-5 text-amber-300" />
                    <span>تم التثبيت بنجاح على جهازك!</span>
                  </span>
                ) : (
                  <span className="flex items-center gap-2">
                    <Download className="w-5 h-5" />
                    <span>تثبيت التطبيق على جهازك الآن مجاناً</span>
                  </span>
                )}
              </button>
            ) : (
              <button
                onClick={() => handleClose(false)}
                className="w-full py-3 px-4 bg-emerald-600 text-white rounded-2xl font-bold text-xs"
              >
                فهمت الطريقة، إغلاق
              </button>
            )}

            <div className="flex items-center justify-between pt-1">
              <button
                onClick={() => handleClose(false)}
                className="text-xs font-bold text-gray-500 hover:text-gray-700 dark:hover:text-gray-300 px-2 py-1"
              >
                ليس الآن
              </button>
              
              <button
                onClick={() => handleClose(true)}
                className="text-xs font-medium text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 px-2 py-1 underline"
              >
                عدم الإظهار مرة أخرى
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
