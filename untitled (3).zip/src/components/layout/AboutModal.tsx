import React from 'react';
import { X, Info, Heart, Shield, Zap } from 'lucide-react';

interface AboutModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export function AboutModal({ isOpen, onClose }: AboutModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 sm:p-6 md:p-12 bg-gray-950/40 backdrop-blur-sm">
      <div 
        className="fixed inset-0"
        onClick={onClose}
        aria-hidden="true"
      />
      <div className="bg-white dark:bg-gray-900 w-full max-w-2xl rounded-3xl shadow-2xl relative flex flex-col max-h-full overflow-hidden border border-gray-100 dark:border-gray-800 transform transition-all">
        {/* Header */}
        <div className="flex items-center justify-between p-4 sm:p-5 border-b border-gray-100 dark:border-gray-800/80 bg-gray-50/50 dark:bg-gray-900/50">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl overflow-hidden bg-gray-900 border border-emerald-500/30 shadow-xs flex items-center justify-center shrink-0">
              <img src="/icon-512.jpg" alt="شعار المنصة" className="w-full h-full object-cover" />
            </div>
            <div>
              <h2 className="text-base font-bold text-gray-900 dark:text-white">عن المنصة</h2>
              <p className="text-xs text-gray-500">أدواتك السريعة - Your Quick Tools</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 flex items-center justify-center rounded-full text-gray-500 hover:bg-gray-200 dark:hover:bg-gray-800 transition"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 sm:p-8 overflow-y-auto space-y-8">
          <section className="text-center space-y-4">
            <h3 className="text-xl font-extrabold text-gray-900 dark:text-white">
              منصة عربية شاملة لأدواتك اليومية
            </h3>
            <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-400 max-w-lg mx-auto">
              أدواتك السريعة هي منصة مجانية تهدف إلى تقديم مجموعة واسعة من الأدوات المفيدة للمستخدمين العرب في مجالات متنوعة، من معالجة النصوص وتنسيقها إلى أدوات التصميم والصور والحاسبات المتخصصة.
            </p>
          </section>

          <div className="grid sm:grid-cols-3 gap-4">
            <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-2xl border border-gray-100 dark:border-gray-700/50 text-center space-y-2">
              <div className="w-10 h-10 mx-auto bg-blue-100 dark:bg-blue-900/30 text-blue-600 dark:text-blue-400 rounded-xl flex items-center justify-center">
                <Shield className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-gray-900 dark:text-white text-sm">خصوصية 100%</h4>
              <p className="text-xs text-gray-500">جميع الأدوات تعمل مباشرة في متصفحك دون إرسال بياناتك لأي خوادم خارجية.</p>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-2xl border border-gray-100 dark:border-gray-700/50 text-center space-y-2">
              <div className="w-10 h-10 mx-auto bg-emerald-100 dark:bg-emerald-900/30 text-emerald-600 dark:text-emerald-400 rounded-xl flex items-center justify-center">
                <Zap className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-gray-900 dark:text-white text-sm">سرعة فائقة</h4>
              <p className="text-xs text-gray-500">أدوات فورية الاستجابة مصممة لتسهيل عملك وإنجاز مهامك في ثوانٍ معدودة.</p>
            </div>
            <div className="bg-gray-50 dark:bg-gray-800/50 p-4 rounded-2xl border border-gray-100 dark:border-gray-700/50 text-center space-y-2">
              <div className="w-10 h-10 mx-auto bg-rose-100 dark:bg-rose-900/30 text-rose-600 dark:text-rose-400 rounded-xl flex items-center justify-center">
                <Heart className="w-5 h-5" />
              </div>
              <h4 className="font-bold text-gray-900 dark:text-white text-sm">مجانية بالكامل</h4>
              <p className="text-xs text-gray-500">مشروع مفتوح يهدف لخدمة وإثراء المحتوى والمستخدم العربي مجاناً.</p>
            </div>
          </div>

          <section className="space-y-4">
            <h4 className="font-bold text-gray-900 dark:text-white text-sm border-b border-gray-100 dark:border-gray-800 pb-2">
              تاريخ المنصة ورسالتها
            </h4>
            <p className="text-sm leading-relaxed text-gray-600 dark:text-gray-400">
              بدأت المنصة كفكرة لتجميع الأدوات المبعثرة التي يحتاجها مطورو الويب وصناع المحتوى والمستخدمون العاديون يومياً في مكان واحد وبواجهة عربية أنيقة وسهلة الاستخدام. رسالتنا هي تمكين المستخدم العربي بأدوات تقنية موثوقة وعالية الجودة تحترم خصوصيته وتوفر وقته.
            </p>
          </section>

          <section className="space-y-4">
            <h4 className="font-bold text-gray-900 dark:text-white text-sm border-b border-gray-100 dark:border-gray-800 pb-2">
              تواصل مع المطور
            </h4>
            <div className="flex flex-col gap-4 text-sm text-gray-600 dark:text-gray-400">
              <p>تم تطوير هذه المنصة بواسطة <strong>@mr_mo515ed</strong></p>
              
              <div className="grid grid-cols-2 gap-3 sm:flex sm:flex-wrap">
                <a href="mailto:m774545471@gmail.com" className="flex items-center gap-2 p-2 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                  <span className="text-emerald-500">📧</span>
                  <span>البريد الإلكتروني</span>
                </a>
                <a href="https://wa.me/message/mr_mo515ed" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 p-2 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                  <span className="text-green-500">💬</span>
                  <span>واتساب</span>
                </a>
                <a href="https://instagram.com/mr_mo515ed" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 p-2 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                  <span className="text-rose-500">📸</span>
                  <span>إنستغرام</span>
                </a>
                <a href="https://t.me/mr_mo515ed" target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 p-2 rounded-xl bg-gray-50 dark:bg-gray-800 hover:bg-gray-100 dark:hover:bg-gray-700 transition">
                  <span className="text-blue-500">✈️</span>
                  <span>تليجرام</span>
                </a>
              </div>
            </div>
          </section>
        </div>

        {/* Footer */}
        <div className="p-4 bg-gray-50 dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800/80 text-center">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-gray-900 dark:bg-white text-white dark:text-gray-900 text-sm font-bold rounded-xl hover:bg-gray-800 dark:hover:bg-gray-100 transition shadow-sm"
          >
            إغلاق
          </button>
        </div>
      </div>
    </div>
  );
}
