import React from 'react';
import { Mail, Instagram, MessageCircle, Send } from 'lucide-react';
import { AdSlot } from '../ads/AdSlot';
import { SupportAdButton } from '../ads/SupportAdButton';

export function Footer() {
  const year = new Date().getFullYear();
  return (
    <footer className="w-full bg-white dark:bg-gray-900 border-t border-gray-100 dark:border-gray-800 mt-12 pb-24 sm:pb-8">
      {/* Support Ad Button to empower the platform freely */}
      <SupportAdButton />

      {/* Footer Top Banner */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-2">
        <AdSlot type="footer-banner" className="my-0" label="إعلان • إعلانات موثوقة" />
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 sm:py-10">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 items-center">
          
          {/* Copyright & Info */}
          <div className="flex flex-col items-center md:items-start text-center md:text-right space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg overflow-hidden border border-emerald-500/30 shadow-xs bg-gray-900 shrink-0">
                <img src="/icon-512.jpg" alt="شعار أدواتك السريعة" className="w-full h-full object-cover" />
              </div>
              <h3 className="text-xl font-black text-transparent bg-clip-text bg-gradient-to-l from-emerald-500 to-teal-600">
                أدواتك السريعة
              </h3>
            </div>
            <p className="text-sm text-gray-500 dark:text-gray-400 max-w-sm">
              مجموعة شاملة من الأدوات السريعة للعمل اليومي بالكامل داخل متصفحك. جميع الحقوق محفوظة &copy; {year}.
            </p>
          </div>

          {/* Contact & Socials */}
          <div className="flex flex-col items-center md:items-end space-y-4">
            <h4 className="font-bold text-gray-900 dark:text-white text-sm">تواصل معي (المطور)</h4>
            
            <div className="flex items-center gap-4">
              <a 
                href="mailto:m774545471@gmail.com" 
                className="w-10 h-10 rounded-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:text-emerald-500 hover:border-emerald-500 transition-colors"
                title="البريد الإلكتروني: m774545471@gmail.com"
              >
                <Mail className="w-4 h-4" />
              </a>
              <a 
                href="https://wa.me/message/mr_mo515ed" 
                target="_blank" rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:text-emerald-500 hover:border-emerald-500 transition-colors"
                title="واتساب: mr_mo515ed"
              >
                <MessageCircle className="w-4 h-4" />
              </a>
              <a 
                href="https://instagram.com/mr_mo515ed" 
                target="_blank" rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:text-emerald-500 hover:border-emerald-500 transition-colors"
                title="إنستغرام: @mr_mo515ed"
              >
                <Instagram className="w-4 h-4" />
              </a>
              <a 
                href="https://t.me/mr_mo515ed" 
                target="_blank" rel="noopener noreferrer" 
                className="w-10 h-10 rounded-full bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 flex items-center justify-center text-gray-600 dark:text-gray-400 hover:text-emerald-500 hover:border-emerald-500 transition-colors"
                title="تليجرام: @mr_mo515ed"
              >
                <Send className="w-4 h-4" />
              </a>
            </div>
            
            <p className="text-xs text-gray-500 dark:text-gray-400 font-mono mt-2">
              @mr_mo515ed
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
