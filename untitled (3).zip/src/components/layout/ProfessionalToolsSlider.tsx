import React, { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { ALL_TOOLS } from '../../data/toolsData';
import { 
  Sparkles, ArrowLeft, Star, ChevronRight, ChevronLeft
} from 'lucide-react';
import { getToolIcon } from '../../utils/iconMap';
import { motion, AnimatePresence } from 'motion/react';

const FEATURED_IDS = [
  'image-processing-suite',
  'pdf-tools-suite',
  'mega-converters-suite',
  'dev-design-hub',
  'security-data-suite',
  'medical-tools-suite',
  'data-tables-converter',
];

const GRADIENTS = [
  'from-indigo-600 via-purple-600 to-pink-600',
  'from-teal-600 via-cyan-600 to-blue-600',
  'from-emerald-600 via-teal-600 to-cyan-600',
  'from-rose-600 via-fuchsia-600 to-purple-600',
  'from-amber-600 via-orange-600 to-rose-600',
];

export function ProfessionalToolsSlider() {
  const navigate = useNavigate();
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);

  // Combine Featured (Professional) and New Tools
  let sliderTools = ALL_TOOLS.filter(t => t.isNew || FEATURED_IDS.includes(t.id));
  if (sliderTools.length === 0) {
    sliderTools = ALL_TOOLS.slice(0, 6);
  }

  useEffect(() => {
    if (isPaused) return;
    const timer = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % sliderTools.length);
    }, 5000);
    return () => clearInterval(timer);
  }, [sliderTools.length, isPaused]);

  if (sliderTools.length === 0) return null;

  const currentTool = sliderTools[currentIndex];
  const bgGradient = GRADIENTS[currentIndex % GRADIENTS.length];
  const IconComponent = getToolIcon(currentTool.icon);

  const handleNext = () => {
    setCurrentIndex((prev) => (prev + 1) % sliderTools.length);
  };

  const handlePrev = () => {
    setCurrentIndex((prev) => (prev - 1 + sliderTools.length) % sliderTools.length);
  };
  
  return (
    <div className="w-full mb-8" id="featured-slider-section">
      <div className="flex items-center justify-between mb-4 px-1">
        <div className="flex items-center gap-2.5">
          <div className="flex items-center justify-center w-7 h-7 rounded-xl bg-gradient-to-tr from-purple-500 to-pink-500 text-white shadow-md shadow-pink-500/20">
            <Star className="w-3.5 h-3.5 fill-white" />
          </div>
          <h2 className="text-lg sm:text-xl font-heading font-black text-gray-900 dark:text-white">
            الأدوات المميزة والحديثة
          </h2>
        </div>

        {/* Previous & Next arrows */}
        <div className="flex items-center gap-1.5">
          <button
            onClick={handleNext}
            className="p-1.5 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:text-emerald-600 dark:hover:text-emerald-400 hover:border-emerald-300 transition shadow-2xs"
            title="السابق"
          >
            <ChevronRight className="w-4 h-4" />
          </button>
          <button
            onClick={handlePrev}
            className="p-1.5 rounded-xl bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 text-gray-600 dark:text-gray-300 hover:text-emerald-600 dark:hover:text-emerald-400 hover:border-emerald-300 transition shadow-2xs"
            title="التالي"
          >
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
      </div>
      
      <div 
        onMouseEnter={() => setIsPaused(true)}
        onMouseLeave={() => setIsPaused(false)}
        className="relative min-h-[340px] sm:min-h-[260px] md:min-h-[240px] w-full rounded-[2rem] shadow-xl overflow-hidden group border border-white/10"
      >
        {/* Animated Background Base */}
        <div className="absolute inset-0 bg-gray-900 transition-colors duration-1000" />
        
        <AnimatePresence mode="wait">
          <motion.div
            key={currentIndex}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.7 }}
            className={`absolute inset-0 bg-gradient-to-br ${bgGradient} opacity-95`}
          />
        </AnimatePresence>

        {/* Floating Background Effects */}
        <div className="absolute inset-0 overflow-hidden opacity-25 mix-blend-overlay pointer-events-none">
           <motion.div 
             animate={{ rotate: 360, scale: [1, 1.2, 1] }} 
             transition={{ duration: 25, repeat: Infinity, ease: "linear" }}
             className="absolute -top-20 -right-20 w-72 h-72 bg-white rounded-full blur-3xl"
           />
           <motion.div 
             animate={{ rotate: -360, scale: [1, 1.3, 1] }} 
             transition={{ duration: 20, repeat: Infinity, ease: "linear" }}
             className="absolute -bottom-32 -left-20 w-80 h-80 bg-white rounded-full blur-3xl"
           />
        </div>

        {/* Main Content Layout */}
        <div className="relative z-10 h-full flex flex-col sm:flex-row items-center justify-between p-6 sm:p-8 md:p-10 gap-6">
          <AnimatePresence mode="wait">
            {/* Tool Icon */}
            <motion.div
              key={`icon-${currentIndex}`}
              initial={{ scale: 0.7, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              exit={{ scale: 0.7, opacity: 0 }}
              transition={{ type: "spring", stiffness: 260, damping: 25 }}
              className="relative w-18 h-18 sm:w-24 sm:h-24 md:w-28 md:h-28 shrink-0 rounded-2xl sm:rounded-3xl bg-white/20 backdrop-blur-md border border-white/30 flex items-center justify-center text-white shadow-xl"
            >
              <div className="absolute inset-0 rounded-2xl sm:rounded-3xl bg-gradient-to-br from-white/30 to-transparent opacity-60" />
              <IconComponent className="w-9 h-9 sm:w-12 sm:h-12 md:w-14 md:h-14 drop-shadow-md" />
            </motion.div>
          </AnimatePresence>

          <div className="flex-1 flex flex-col items-center sm:items-start text-center sm:text-right w-full min-w-0">
            <AnimatePresence mode="wait">
              <motion.div
                key={`info-${currentIndex}`}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -15 }}
                transition={{ duration: 0.4 }}
                className="flex flex-col items-center sm:items-start w-full"
              >
                {/* Badges */}
                <div className="flex flex-wrap items-center justify-center sm:justify-start gap-2 mb-2.5">
                  {currentTool.isNew ? (
                    <span className="px-3 py-0.5 rounded-full bg-rose-500 text-white text-[11px] font-black tracking-wider shadow-sm flex items-center gap-1">
                      <Sparkles className="w-3 h-3" /> أداة جديدة
                    </span>
                  ) : (
                    <span className="px-3 py-0.5 rounded-full bg-white/20 text-white text-[11px] font-black tracking-wider border border-white/30">
                      أداة احترافية
                    </span>
                  )}
                  {currentTool.badge && !currentTool.isNew && (
                    <span className="px-3 py-0.5 rounded-full bg-black/25 text-white text-[11px] font-bold">
                      {currentTool.badge}
                    </span>
                  )}
                  <span className="text-white/80 text-[11px] font-medium hidden md:inline">
                    • تعمل بالكامل في المتصفح
                  </span>
                </div>
                
                {/* Title */}
                <h3 className="text-xl sm:text-2xl md:text-3xl font-heading font-black text-white mb-2 leading-snug drop-shadow-xs">
                  {currentTool.titleAr}
                </h3>
                
                {/* Description */}
                <p className="text-xs sm:text-sm text-white/90 max-w-2xl line-clamp-2 leading-relaxed font-normal mb-4">
                  {currentTool.descriptionAr}
                </p>
                
                {/* Action CTA Button */}
                <button 
                  onClick={() => navigate(`/tool/${currentTool.id}`)}
                  className="flex items-center gap-2.5 px-6 py-2.5 sm:py-3 bg-white text-gray-900 rounded-xl text-xs sm:text-sm font-black transition-all hover:bg-gray-50 hover:scale-105 active:scale-95 shadow-lg group/btn"
                >
                  <span>استخدام الأداة الآن</span>
                  <ArrowLeft className="w-4 h-4 transform group-hover/btn:-translate-x-1 transition-transform text-emerald-600" />
                </button>
              </motion.div>
            </AnimatePresence>
          </div>
        </div>
        
        {/* Navigation Indicator Dots */}
        <div className="absolute bottom-3 left-0 right-0 flex justify-center items-center gap-1.5 z-20">
          {sliderTools.map((_, idx) => (
            <button
              key={idx}
              onClick={() => setCurrentIndex(idx)}
              className={`h-1.5 rounded-full transition-all duration-300 ${
                idx === currentIndex ? 'w-6 bg-white shadow-xs' : 'w-1.5 bg-white/40 hover:bg-white/70'
              }`}
              aria-label={`الشريحة ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
