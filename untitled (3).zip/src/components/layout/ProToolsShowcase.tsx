import React, { useState, useEffect, useRef, useCallback } from 'react';
import {
  Sparkles,
  ChevronRight,
  ChevronLeft,
  ArrowLeft,
  Image as ImageIcon,
  ShieldCheck,
  FileText,
  Code2,
  Palette,
  Share2,
  Calculator,
  Zap,
  CheckCircle2,
  Play
} from 'lucide-react';

interface ShowcaseItem {
  id: string;
  titleAr: string;
  titleEn: string;
  categoryNameAr: string;
  badge: string;
  descriptionAr: string;
  highlights: string[];
  icon: React.ElementType;
  gradientClass: string;
  badgeClass: string;
  glowClass: string;
  btnClass: string;
  tagline: string;
}

const SHOWCASE_ITEMS: ShowcaseItem[] = [
  {
    id: 'image-processing-suite',
    titleAr: 'حزمة معالجة وتعديل الصور الشاملة',
    titleEn: 'Advanced Image Studio',
    categoryNameAr: 'أدوات الصور',
    badge: 'الأكثر استخداماً 🔥',
    tagline: 'ضغط وتعديل فوري بدون رفع لسيرفر',
    descriptionAr: 'منظومة متكاملة لضغط الصور بنسبة تصل إلى 80%، تغيير المقاسات، تحويل الخلفيات إلى شفافة PNG، إزالة بيانات EXIF وصناعة الأيقونات في متصفحك.',
    highlights: ['ضغط ذكي بدون فقدان الجودة', 'تغيير أبعاد وتدوير', 'خلفية شفافة فورية', 'إزالة بيانات الموقع EXIF', 'صانع Favicon'],
    icon: ImageIcon,
    gradientClass: 'from-pink-600 via-rose-600 to-amber-600',
    badgeClass: 'bg-rose-500/20 text-rose-200 border-rose-400/30',
    glowClass: 'from-rose-500/20 via-pink-500/10 to-transparent',
    btnClass: 'bg-rose-500 hover:bg-rose-600 text-white shadow-rose-500/25',
  },
  {
    id: 'security-data-suite',
    titleAr: 'أدوات التشفير والبيانات والحماية',
    titleEn: 'Security & Crypto Suite',
    categoryNameAr: 'البرمجة والأمان',
    badge: 'حماية وأمان 100% 🔒',
    tagline: 'تشفير وتحليل فوري بدون اتصال خارجي',
    descriptionAr: 'توليد هاش MD5 و SHA-256، فك تشفير وفحص توكنات JWT، قراءة وتوليد رموز QR، محول YAML ↔ JSON، ومنسق أكواد XML للمطورين.',
    highlights: ['توليد هاش MD5 / SHA', 'فك وفحص JWT Token', 'قارئ وصانع QR Code', 'محول YAML ↔ JSON', 'توليد كلمات سر قوية'],
    icon: ShieldCheck,
    gradientClass: 'from-indigo-600 via-purple-600 to-sky-600',
    badgeClass: 'bg-indigo-500/20 text-indigo-200 border-indigo-400/30',
    glowClass: 'from-indigo-500/20 via-purple-500/10 to-transparent',
    btnClass: 'bg-indigo-500 hover:bg-indigo-600 text-white shadow-indigo-500/25',
  },
  {
    id: 'pdf-tools-suite',
    titleAr: 'حزمة أدوات PDF الاحترافية',
    titleEn: 'Advanced PDF Suite',
    categoryNameAr: 'أدوات PDF',
    badge: 'مستندات متكاملة 📄',
    tagline: 'دمج وتقسيم وحماية المستندات محلياً',
    descriptionAr: 'تجميع مستندات PDF في ملف موحد، استخراج وتقسيم الصفحات، إضافة علامات مائية مخصصة، تدوير الصفحات وتحويل صور JPG إلى PDF بسرعة فائقة.',
    highlights: ['دمج ملفات PDF متعددة', 'تقسيم واستخراج صفحات', 'علامة مائية مخصصة', 'تدوير صفحات المستند', 'تحويل JPG إلى PDF'],
    icon: FileText,
    gradientClass: 'from-red-600 via-rose-700 to-orange-600',
    badgeClass: 'bg-red-500/20 text-red-200 border-red-400/30',
    glowClass: 'from-red-500/20 via-rose-500/10 to-transparent',
    btnClass: 'bg-red-500 hover:bg-red-600 text-white shadow-red-500/25',
  },
  {
    id: 'text-processing-suite',
    titleAr: 'حزمة معالجة النصوص الذكية المتقدمة',
    titleEn: 'Smart Text Processing',
    categoryNameAr: 'معالجة النصوص',
    badge: 'فائقة السرعة ⚡',
    tagline: 'تنظيف وفرز واستخراج بضغطة واحدة',
    descriptionAr: 'إزالة الفراغات المزدوجة، حذف الأسطر المكررة، استخراج كافة الروابط والإيميلات، عكس النصوص، الفرز الأبجدي ومقارنة الفروقات بين نصين بدقة.',
    highlights: ['تنظيف المسافات الزائدة', 'استخراج الروابط والإيميلات', 'مقارنة نصين Diff', 'ترتيب وفرز الأسطر', 'حذف التكرار والعكس'],
    icon: Sparkles,
    gradientClass: 'from-blue-600 via-cyan-600 to-teal-600',
    badgeClass: 'bg-blue-500/20 text-blue-200 border-blue-400/30',
    glowClass: 'from-blue-500/20 via-cyan-500/10 to-transparent',
    btnClass: 'bg-blue-500 hover:bg-blue-600 text-white shadow-blue-500/25',
  },
  {
    id: 'web-dev-suite',
    titleAr: 'أدوات المطورين والويب المتقدمة',
    titleEn: 'Web & Dev Toolkit',
    categoryNameAr: 'تطوير الويب',
    badge: 'للمبرمجين 💻',
    tagline: 'محلل الروابط وضغط الأكواد ومولد Cron',
    descriptionAr: 'تفكيك الروابط URL واستخراج المعاملات، فحص ترويسات HTTP، كشف المتصفح والجهاز User-Agent، تقليص أكواد الويب، ومولد ومفسر مهام Cron بالعربية.',
    highlights: ['URL & Domain Parser', 'كاشف User-Agent', 'ضغط HTML / CSS / JS', 'فاحص ترويسات HTTP', 'مولد تعابير Cron'],
    icon: Code2,
    gradientClass: 'from-violet-600 via-indigo-700 to-purple-600',
    badgeClass: 'bg-violet-500/20 text-violet-200 border-violet-400/30',
    glowClass: 'from-violet-500/20 via-indigo-500/10 to-transparent',
    btnClass: 'bg-violet-500 hover:bg-violet-600 text-white shadow-violet-500/25',
  },
  {
    id: 'design-suite',
    titleAr: 'حزمة أدوات التصميم و CSS الاحترافية',
    titleEn: 'UI & Design Studio',
    categoryNameAr: 'التصميم و CSS',
    badge: 'لمصممي الواجهات 🎨',
    tagline: 'ألوان وظلال وحواف بمعايير عالمية',
    descriptionAr: 'فاحص تباين الألوان مع معايير WCAG لإمكانية الوصول، مولد ظلال CSS ثلاثية الأبعاد وناعمة، مولد انحناء الحواف Border Radius، وتوليد التدرجات.',
    highlights: ['فاحص التباين WCAG', 'مولد ظلال Box Shadow', 'مولد حواف Border Radius', 'مولد التدرجات والباليتات', 'معاينة حية وتصدير CSS'],
    icon: Palette,
    gradientClass: 'from-amber-600 via-orange-600 to-rose-600',
    badgeClass: 'bg-amber-500/20 text-amber-200 border-amber-400/30',
    glowClass: 'from-amber-500/20 via-orange-500/10 to-transparent',
    btnClass: 'bg-amber-500 hover:bg-amber-600 text-white shadow-amber-500/25',
  },
  {
    id: 'social-suite',
    titleAr: 'حزمة أدوات السوشيال ميديا وصناع المحتوى',
    titleEn: 'Social Media Studio',
    categoryNameAr: 'صناع المحتوى',
    badge: 'تفاعل ونمو 🚀',
    tagline: 'هاشتاقات وبايو ومقاسات لكافة الشبكات',
    descriptionAr: 'توليد حزم هاشتاقات تفاعلية، صانع البايو والسير الذاتية الجذابة، اقتراح أسماء المستخدمين واليوزرات، ودليل ومحول مقاسات الصور والقصص.',
    highlights: ['مولد الهاشتاقات الذكي', 'صانع ومولد البايو Bio', 'اقتراح يوزرات فريدة', 'مقاسات بوستات وستوري', 'أدوات انستغرام وتويتر'],
    icon: Share2,
    gradientClass: 'from-fuchsia-600 via-pink-600 to-rose-600',
    badgeClass: 'bg-fuchsia-500/20 text-fuchsia-200 border-fuchsia-400/30',
    glowClass: 'from-fuchsia-500/20 via-pink-500/10 to-transparent',
    btnClass: 'bg-fuchsia-500 hover:bg-fuchsia-600 text-white shadow-fuchsia-500/25',
  },
  {
    id: 'calculators-suite',
    titleAr: 'حزمة الحاسبات المالية والرياضية الشاملة',
    titleEn: 'Smart Calculators Suite',
    categoryNameAr: 'الحاسبات والمال',
    badge: 'دقة حسابية 100% 📊',
    tagline: 'ضرائب ونسب وهوامش ربح وكتلة الجسم',
    descriptionAr: 'حساب النسبة المئوية الدقيقة، حاسبة الخصومات والتخفيضات، ضريبة القيمة المضافة VAT 15%، هامش الربح والمارك اب للتجارة، ومؤشر كتلة الجسم BMI.',
    highlights: ['حاسبة النسبة المئوية', 'حاسبة التخفيضات والخصم', 'ضريبة القيمة المضافة VAT', 'حساب هامش وصافي الربح', 'مؤشر كتلة الجسم BMI'],
    icon: Calculator,
    gradientClass: 'from-emerald-600 via-teal-600 to-cyan-700',
    badgeClass: 'bg-emerald-500/20 text-emerald-200 border-emerald-400/30',
    glowClass: 'from-emerald-500/20 via-teal-500/10 to-transparent',
    btnClass: 'bg-emerald-500 hover:bg-emerald-600 text-white shadow-emerald-500/25',
  }
];

interface ProToolsShowcaseProps {
  onSelectTool: (toolId: string) => void;
}

export function ProToolsShowcase({ onSelectTool }: ProToolsShowcaseProps) {
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isPaused, setIsPaused] = useState(false);
  const timerRef = useRef<NodeJS.Timeout | null>(null);

  const nextSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev + 1) % SHOWCASE_ITEMS.length);
  }, []);

  const prevSlide = useCallback(() => {
    setCurrentIndex((prev) => (prev - 1 + SHOWCASE_ITEMS.length) % SHOWCASE_ITEMS.length);
  }, []);

  // Auto-scroll every 3 seconds (3000ms)
  useEffect(() => {
    if (isPaused) {
      if (timerRef.current) clearInterval(timerRef.current);
      return;
    }

    timerRef.current = setInterval(() => {
      nextSlide();
    }, 3000);

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isPaused, nextSlide]);

  const currentItem = SHOWCASE_ITEMS[currentIndex];
  const IconComponent = currentItem.icon;

  return (
    <div
      className="relative w-full rounded-3xl overflow-hidden shadow-xl border border-gray-200/80 dark:border-gray-800 bg-gray-950 text-white transition-all duration-500"
      onMouseEnter={() => setIsPaused(true)}
      onMouseLeave={() => setIsPaused(false)}
      id="pro-tools-showcase"
    >
      {/* Background Animated Gradient Layer */}
      <div
        className={`absolute inset-0 bg-gradient-to-r ${currentItem.gradientClass} opacity-85 transition-all duration-700`}
      />

      {/* Dark vignette & pattern overlay */}
      <div className="absolute inset-0 bg-gradient-to-t from-gray-950 via-gray-950/40 to-transparent opacity-90" />
      <div className="absolute -top-24 -right-24 w-96 h-96 rounded-full bg-white/10 blur-3xl pointer-events-none" />
      <div className="absolute -bottom-24 -left-24 w-96 h-96 rounded-full bg-black/40 blur-3xl pointer-events-none" />

      {/* Slide Content */}
      <div className="relative z-10 p-6 sm:p-8 md:p-10 flex flex-col justify-between min-h-[360px] sm:min-h-[380px]">
        {/* Top Bar: Category, Badge, and 3s Timer indicator */}
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <span className="px-3 py-1 rounded-full text-xs font-extrabold bg-white/20 backdrop-blur-md text-white border border-white/30 flex items-center gap-1.5 shadow-xs">
              <Zap className="w-3.5 h-3.5 text-yellow-300 fill-yellow-300" />
              <span>لوحة الأدوات الاحترافية الأكثر طلباً</span>
            </span>

            <span className={`px-3 py-1 rounded-full text-xs font-bold border backdrop-blur-md ${currentItem.badgeClass}`}>
              {currentItem.badge}
            </span>
          </div>

          {/* Auto slide status & slide counter */}
          <div className="flex items-center gap-2 text-xs text-white/80 bg-black/30 backdrop-blur-md px-3 py-1 rounded-full border border-white/10 font-mono">
            <span className="text-emerald-400 font-bold">{currentIndex + 1}</span>
            <span>/</span>
            <span>{SHOWCASE_ITEMS.length}</span>
            <span className="text-[10px] text-white/50 border-r border-white/20 pr-2 mr-1">
              {isPaused ? 'موقف مؤقتاً' : 'يتمرر كل 3 ثوانٍ'}
            </span>
          </div>
        </div>

        {/* Middle Main Info */}
        <div className="my-6 grid grid-cols-1 lg:grid-cols-12 gap-6 items-center">
          {/* Main text block */}
          <div className="lg:col-span-8 space-y-3">
            <div className="flex items-center gap-3">
              <div className="w-12 h-12 sm:w-14 sm:h-14 rounded-2xl bg-white/15 backdrop-blur-md border border-white/30 flex items-center justify-center shadow-lg shrink-0">
                <IconComponent className="w-6 h-6 sm:w-7 sm:h-7 text-white" />
              </div>
              <div>
                <span className="text-xs font-semibold text-white/70 tracking-wider">
                  {currentItem.categoryNameAr} • {currentItem.titleEn}
                </span>
                <h2 className="text-2xl sm:text-3xl font-heading font-black text-white leading-tight">
                  {currentItem.titleAr}
                </h2>
              </div>
            </div>

            <p className="text-sm sm:text-base text-white/90 leading-relaxed max-w-2xl">
              {currentItem.descriptionAr}
            </p>

            {/* Highlights pills */}
            <div className="flex flex-wrap gap-2 pt-2">
              {currentItem.highlights.map((h, i) => (
                <span
                  key={i}
                  className="inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium bg-white/10 hover:bg-white/20 backdrop-blur-md text-white border border-white/15 transition"
                >
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300" />
                  <span>{h}</span>
                </span>
              ))}
            </div>
          </div>

          {/* Action Box Callout */}
          <div className="lg:col-span-4 flex flex-col items-start lg:items-end justify-center">
            <button
              onClick={() => onSelectTool(currentItem.id)}
              className={`group w-full sm:w-auto px-6 py-3.5 rounded-2xl font-extrabold text-sm sm:text-base shadow-xl flex items-center justify-center gap-3 transition-all duration-300 hover:scale-[1.03] active:scale-[0.98] ${currentItem.btnClass}`}
            >
              <span>فتح وتشغيل الحزمة الآن</span>
              <ArrowLeft className="w-5 h-5 transform group-hover:-translate-x-1.5 transition-transform" />
            </button>
            <span className="text-[11px] text-white/60 mt-2 text-center lg:text-left">
              جاهزة للاستخدام الفوري بدون أي تحميل
            </span>
          </div>
        </div>

        {/* Bottom Bar: Progress timer line, dots and next/prev controls */}
        <div className="pt-4 border-t border-white/15 flex flex-col sm:flex-row items-center justify-between gap-4">
          {/* Navigation Dots */}
          <div className="flex items-center gap-2 overflow-x-auto py-1 max-w-full">
            {SHOWCASE_ITEMS.map((item, idx) => (
              <button
                key={item.id}
                onClick={() => setCurrentIndex(idx)}
                title={item.titleAr}
                className={`h-2.5 rounded-full transition-all duration-300 ${
                  currentIndex === idx
                    ? 'w-8 bg-white shadow-md'
                    : 'w-2.5 bg-white/30 hover:bg-white/60'
                }`}
              />
            ))}
          </div>

          {/* Controls */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              onClick={prevSlide}
              aria-label="الأداة السابقة"
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-white transition active:scale-95"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
            <button
              onClick={nextSlide}
              aria-label="الأداة التالية"
              className="p-2 rounded-xl bg-white/10 hover:bg-white/20 border border-white/15 text-white transition active:scale-95"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Visual 3-second Progress countdown line */}
        <div className="absolute bottom-0 left-0 right-0 h-1 bg-white/10 overflow-hidden">
          <div
            key={currentIndex}
            className={`h-full bg-white/80 ${isPaused ? 'w-full opacity-30' : 'animate-[progress_3s_linear]'}`}
            style={{
              animationDuration: '3000ms',
            }}
          />
        </div>
      </div>
    </div>
  );
}
