import React from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { Sun, Moon, Search, Star, Share2, Info } from 'lucide-react';
import { ToolCategory } from '../../types';

interface NavbarProps {
  darkMode: boolean;
  setDarkMode: (val: boolean | ((prev: boolean) => boolean)) => void;
  onOpenSearch: () => void;
  favoritesCount: number;
  onSelectCategory: (cat: ToolCategory) => void;
  activeCategory: ToolCategory;
  onHomeClick: () => void;
  onOpenAbout: () => void;
}

export function Navbar({
  darkMode,
  setDarkMode,
  onOpenSearch,
  favoritesCount,
  onSelectCategory,
  activeCategory,
  onHomeClick,
  onOpenAbout,
}: NavbarProps) {
  const navigate = useNavigate();
  const location = useLocation();

  const handleShare = async () => {
    if (navigator.share) {
      navigator.share({
        title: 'أدواتك السريعة | منصة الأدوات والمحولات المجانية',
        text: 'أدوات أونلاين مجانية وفائقة السرعة تعمل 100% في المتصفح بكل أمان وخصوصية.',
        url: 'https://adwatuk-alsariea.netlify.app',
      }).catch(() => {});
    } else {
      navigator.clipboard.writeText('https://adwatuk-alsariea.netlify.app');
      try {
        const confetti = (await import('canvas-confetti')).default;
        confetti({ particleCount: 30, spread: 45, origin: { y: 0.2 } });
      } catch {}
      alert('تم نسخ رابط المنصة إلى الحافظة!');
    }
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-white/80 dark:bg-gray-900/80 border-b border-gray-200/80 dark:border-gray-800 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-4">
        {/* Logo and Brand */}
        <div
          onClick={onHomeClick}
          className="flex items-center gap-2.5 cursor-pointer select-none group"
          id="navbar-brand-logo"
        >
          <div className="w-10 h-10 rounded-xl overflow-hidden border border-emerald-500/30 shadow-md shadow-emerald-500/20 group-hover:scale-105 transition-transform bg-gray-900 shrink-0 flex items-center justify-center">
            <img src="/icon-512.jpg" alt="أدواتك السريعة" className="w-full h-full object-cover" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-heading font-extrabold text-lg sm:text-xl text-gray-900 dark:text-white tracking-tight">
                أدواتك السريعة
              </span>
              <span className="px-1.5 py-0.5 text-[10px] font-bold bg-emerald-100 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 rounded-md">
                مجاني
              </span>
            </div>
            <span className="text-[10px] text-gray-500 dark:text-gray-400 hidden sm:block">
              أدوات ومحولات بدون رفع بيانات
            </span>
          </div>
        </div>

        {/* Center Search Trigger */}
        <div className="flex-1 max-w-md hidden md:block">
          <button
            onClick={onOpenSearch}
            id="navbar-search-btn"
            className="w-full flex items-center justify-between px-3.5 py-2 text-xs text-gray-400 bg-gray-100/90 dark:bg-gray-800/90 hover:bg-gray-200/80 dark:hover:bg-gray-700/80 border border-gray-200/70 dark:border-gray-700/60 rounded-xl transition-all shadow-2xs"
          >
            <div className="flex items-center gap-2">
              <Search className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              <span>ابحث عن أداة، محول، ضاغط، حاسبة...</span>
            </div>
            <kbd className="px-2 py-0.5 text-[10px] font-mono bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-md text-gray-500">
              Ctrl + K
            </kbd>
          </button>
        </div>

        {/* Right Actions */}
        <div className="flex items-center gap-2">
          {/* Mobile Search Button */}
          <button
            onClick={onOpenSearch}
            className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl md:hidden transition"
            title="بحث"
          >
            <Search className="w-5 h-5" />
          </button>

          {/* Favorites Filter */}
          <button
            onClick={() => onSelectCategory('favorites')}
            id="navbar-favorites-btn"
            className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 ${
              activeCategory === 'favorites'
                ? 'bg-amber-500 text-white shadow-xs'
                : 'bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-amber-50 dark:hover:bg-amber-950/40 hover:text-amber-600'
            }`}
            title="الأدوات المفضلة"
          >
            <Star className={`w-4 h-4 ${favoritesCount > 0 ? 'fill-current text-amber-500' : ''}`} />
            <span className="hidden sm:inline">المفضلة</span>
            {favoritesCount > 0 && (
              <span className="w-4 h-4 rounded-full bg-amber-500 text-white text-[10px] flex items-center justify-center font-bold">
                {favoritesCount}
              </span>
            )}
          </button>

          {/* About Button */}
          <button
            onClick={onOpenAbout}
            className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl transition"
            title="عن المنصة"
          >
            <Info className="w-5 h-5" />
          </button>

          {/* Share Button */}
          <button
            onClick={handleShare}
            id="navbar-share-btn"
            className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl transition"
            title="مشاركة المنصة"
          >
            <Share2 className="w-5 h-5" />
          </button>

          {/* Dark / Light Mode Toggle */}
          <button
            onClick={() => setDarkMode((prev) => !prev)}
            id="navbar-theme-toggle"
            className="p-2 text-gray-600 dark:text-gray-300 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-xl transition"
            title={darkMode ? 'التبديل إلى الوضع الفاتح' : 'التبديل إلى الوضع الليلي'}
          >
            {darkMode ? (
              <Sun className="w-5 h-5 text-amber-400" />
            ) : (
              <Moon className="w-5 h-5 text-gray-700" />
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
