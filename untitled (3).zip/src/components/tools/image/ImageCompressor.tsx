import React, { useState, useRef } from 'react';
import { Upload, Download, Image as ImageIcon, Sparkles, RefreshCw, ArrowDown, Check } from 'lucide-react';
import confetti from 'canvas-confetti';

export function ImageCompressor() {
  const [originalImage, setOriginalImage] = useState<string | null>(null);
  const [originalFile, setOriginalFile] = useState<File | null>(null);
  const [compressedImage, setCompressedImage] = useState<string | null>(null);
  const [compressedSize, setCompressedSize] = useState<number | null>(null);
  const [quality, setQuality] = useState<number>(75);
  const [maxWidth, setMaxWidth] = useState<number>(1920);
  const [format, setFormat] = useState<'image/jpeg' | 'image/webp' | 'image/png'>('image/jpeg');
  const [isProcessing, setIsProcessing] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (file: File) => {
    if (!file.type.startsWith('image/')) return;
    setOriginalFile(file);
    const reader = new FileReader();
    reader.onload = (e) => {
      const result = e.target?.result as string;
      setOriginalImage(result);
      compress(result, quality, maxWidth, format);
    };
    reader.readAsDataURL(file);
  };

  const compress = (imageSrc: string, q: number, maxW: number, fmt: string) => {
    setIsProcessing(true);
    const img = new Image();
    img.src = imageSrc;
    img.onload = () => {
      const canvas = document.createElement('canvas');
      let width = img.width;
      let height = img.height;

      if (width > maxW) {
        height = Math.round((height * maxW) / width);
        width = maxW;
      }

      canvas.width = width;
      canvas.height = height;
      const ctx = canvas.getContext('2d');
      if (!ctx) return;

      // Fill white for transparent JPG
      if (fmt === 'image/jpeg') {
        ctx.fillStyle = '#FFFFFF';
        ctx.fillRect(0, 0, width, height);
      }

      ctx.drawImage(img, 0, 0, width, height);

      const qualityFloat = q / 100;
      const dataUrl = canvas.toDataURL(fmt, qualityFloat);
      setCompressedImage(dataUrl);

      // Estimate byte size from dataUrl
      const base64Str = dataUrl.split(',')[1] || '';
      const bytesLength = window.atob(base64Str).length;
      setCompressedSize(bytesLength);
      setIsProcessing(false);
    };
  };

  const handleQualityChange = (newQuality: number) => {
    setQuality(newQuality);
    if (originalImage) {
      compress(originalImage, newQuality, maxWidth, format);
    }
  };

  const handleFormatChange = (newFormat: 'image/jpeg' | 'image/webp' | 'image/png') => {
    setFormat(newFormat);
    if (originalImage) {
      compress(originalImage, quality, maxWidth, newFormat);
    }
  };

  const handleDownload = () => {
    if (!compressedImage) return;
    const a = document.createElement('a');
    a.href = compressedImage;
    const ext = format === 'image/jpeg' ? 'jpg' : format === 'image/webp' ? 'webp' : 'png';
    const nameWithoutExt = originalFile?.name.substring(0, originalFile.name.lastIndexOf('.')) || 'compressed-image';
    a.download = `${nameWithoutExt}-compressed.${ext}`;
    a.click();
    confetti({ particleCount: 40, spread: 60, origin: { y: 0.8 } });
  };

  const formatFileSize = (bytes: number) => {
    if (bytes < 1024) return bytes + ' B';
    else if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + ' KB';
    return (bytes / (1024 * 1024)).toFixed(2) + ' MB';
  };

  const savedPercent =
    originalFile && compressedSize
      ? Math.max(0, Math.round(((originalFile.size - compressedSize) / originalFile.size) * 100))
      : 0;

  return (
    <div className="space-y-6" id="image-compressor-tool">
      {/* Upload Zone or Drag & Drop */}
      {!originalImage ? (
        <div
          onClick={() => fileInputRef.current?.click()}
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            if (e.dataTransfer.files?.[0]) handleFileChange(e.dataTransfer.files[0]);
          }}
          className="border-2 border-dashed border-emerald-300 dark:border-emerald-700/60 hover:border-emerald-500 rounded-2xl p-10 text-center cursor-pointer transition-all bg-emerald-50/20 dark:bg-emerald-950/10 flex flex-col items-center justify-center gap-3"
        >
          <div className="p-4 bg-emerald-100 dark:bg-emerald-900/40 text-emerald-600 dark:text-emerald-400 rounded-2xl">
            <Upload className="w-8 h-8" />
          </div>
          <div>
            <h3 className="text-base font-bold text-gray-800 dark:text-gray-200">
              اسحب وأفلت الصورة هنا أو انقر للاختيار
            </h3>
            <p className="text-xs text-gray-500 dark:text-gray-400 mt-1">
              يدعم JPG، PNG، WEBP (يتم الضغط بأمان كامل 100% داخل المتصفح)
            </p>
          </div>
          <input
            ref={fileInputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="hidden"
            onChange={(e) => e.target.files?.[0] && handleFileChange(e.target.files[0])}
          />
        </div>
      ) : (
        <div className="space-y-5">
          {/* Controls Bar */}
          <div className="p-4 bg-emerald-50/40 dark:bg-emerald-950/20 border border-emerald-100 dark:border-emerald-900/30 rounded-xl space-y-4">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">
                إعدادات الضغط والجودة:
              </span>
              <button
                onClick={() => {
                  setOriginalImage(null);
                  setCompressedImage(null);
                }}
                className="text-xs text-rose-500 hover:underline"
              >
                اختيار صورة أخرى
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <div className="flex justify-between text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1">
                  <span>نسبة الجودة:</span>
                  <span className="font-bold text-emerald-600 dark:text-emerald-400">{quality}%</span>
                </div>
                <input
                  type="range"
                  min={10}
                  max={95}
                  value={quality}
                  onChange={(e) => handleQualityChange(Number(e.target.value))}
                  className="w-full accent-emerald-600 cursor-pointer"
                />
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1">
                  الصيغة الناتجة:
                </label>
                <div className="flex rounded-lg border border-gray-200 dark:border-gray-700 overflow-hidden bg-white dark:bg-gray-800 text-xs">
                  <button
                    onClick={() => handleFormatChange('image/jpeg')}
                    className={`flex-1 py-1.5 font-semibold ${
                      format === 'image/jpeg' ? 'bg-emerald-600 text-white' : 'text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    JPG
                  </button>
                  <button
                    onClick={() => handleFormatChange('image/webp')}
                    className={`flex-1 py-1.5 font-semibold ${
                      format === 'image/webp' ? 'bg-emerald-600 text-white' : 'text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    WEBP
                  </button>
                  <button
                    onClick={() => handleFormatChange('image/png')}
                    className={`flex-1 py-1.5 font-semibold ${
                      format === 'image/png' ? 'bg-emerald-600 text-white' : 'text-gray-700 dark:text-gray-300'
                    }`}
                  >
                    PNG
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-semibold text-gray-600 dark:text-gray-300 mb-1">
                  الحد الأقصى للعرض (Max Width):
                </label>
                <select
                  value={maxWidth}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setMaxWidth(val);
                    if (originalImage) compress(originalImage, quality, val, format);
                  }}
                  className="w-full p-1.5 rounded-lg border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-900 text-gray-900 dark:text-gray-100 text-xs font-semibold"
                >
                  <option value={3840}>4K (3840px)</option>
                  <option value={1920}>Full HD (1920px)</option>
                  <option value={1280}>HD (1280px)</option>
                  <option value={800}>متوسط (800px)</option>
                  <option value={500}>صغير (500px)</option>
                </select>
              </div>
            </div>
          </div>

          {/* Stats Bar */}
          <div className="grid grid-cols-3 gap-3 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-xl text-center">
            <div>
              <div className="text-xs text-gray-500 dark:text-gray-400">الحجم الأصلي</div>
              <div className="text-sm sm:text-base font-bold text-gray-800 dark:text-gray-200">
                {originalFile ? formatFileSize(originalFile.size) : '-'}
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-500 dark:text-gray-400">الحجم بعد الضغط</div>
              <div className="text-sm sm:text-base font-bold text-emerald-600 dark:text-emerald-400">
                {compressedSize ? formatFileSize(compressedSize) : '-'}
              </div>
            </div>
            <div>
              <div className="text-xs text-gray-500 dark:text-gray-400">نسبة التوفير</div>
              <div className="text-sm sm:text-base font-extrabold text-emerald-600 dark:text-emerald-400 flex items-center justify-center gap-1">
                <ArrowDown className="w-4 h-4" />
                {savedPercent}%
              </div>
            </div>
          </div>

          {/* Previews */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">الصورة الأصلية</span>
              <div className="h-60 rounded-xl border border-gray-200 dark:border-gray-700 overflow-hidden bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                <img
                  src={originalImage}
                  alt="Original preview"
                  className="max-h-full max-w-full object-contain"
                />
              </div>
            </div>

            <div className="space-y-2">
              <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
                المعاينة بعد الضغط
              </span>
              <div className="h-60 rounded-xl border border-emerald-300 dark:border-emerald-700/60 overflow-hidden bg-gray-100 dark:bg-gray-800 flex items-center justify-center">
                {compressedImage && (
                  <img
                    src={compressedImage}
                    alt="Compressed preview"
                    className="max-h-full max-w-full object-contain"
                  />
                )}
              </div>
            </div>
          </div>

          {/* Download button */}
          <div className="flex justify-end gap-3 pt-2">
            <button
              onClick={handleDownload}
              id="btn-download-compressed-image"
              className="w-full sm:w-auto px-6 py-3 bg-emerald-600 hover:bg-emerald-700 text-white font-bold rounded-xl shadow-md hover:shadow-lg transition flex items-center justify-center gap-2"
            >
              <Download className="w-5 h-5" />
              تحميل الصورة المضغوطة الآن ({compressedSize ? formatFileSize(compressedSize) : ''})
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
