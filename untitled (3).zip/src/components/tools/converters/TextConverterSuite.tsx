import React, { useState } from 'react';
import Papa from 'papaparse';
import { marked } from 'marked';
import { Document, Packer, Paragraph, TextRun, AlignmentType } from 'docx';
import { convertHtmlToPdfBlob } from '../../../utils/pdfHelper';
import { ProcessingProgressBar } from '../../common/ProcessingProgressBar';
import {
  FileText,
  Download,
  Copy,
  Check,
  ArrowRightLeft,
  FileType,
  Sparkles,
  FileCode,
  FileSpreadsheet,
  RefreshCw,
  Trash2,
  CheckCircle2
} from 'lucide-react';
import confetti from 'canvas-confetti';

export type TextConvertMode =
  | 'text-to-pdf'
  | 'text-to-word'
  | 'text-to-txt'
  | 'text-to-html'
  | 'text-to-markdown'
  | 'text-to-json'
  | 'text-to-xml'
  | 'text-to-csv'
  | 'markdown-to-html'
  | 'html-to-markdown'
  | 'json-to-csv'
  | 'csv-to-json'
  | 'json-to-xml'
  | 'xml-to-json';

const MODES: { id: TextConvertMode; title: string; desc: string; icon: string; category: string }[] = [
  { id: 'text-to-pdf', title: 'نص → PDF', desc: 'تحويل أي نص أو مقال إلى مستند PDF قابل للطباعة', icon: 'FileText', category: 'مستندات' },
  { id: 'text-to-word', title: 'نص → Word (DOCX)', desc: 'تصدير النص بصيغة مايكروسوفت وورد Word DOCX', icon: 'FileType', category: 'مستندات' },
  { id: 'text-to-txt', title: 'نص → TXT', desc: 'حفظ وتنسيق النص في ملف نصي مجرد بترميز UTF-8', icon: 'FileText', category: 'نصوص' },
  { id: 'text-to-html', title: 'نص → HTML', desc: 'تحويل النص والفقرات إلى وسوم HTML مع معالجة الرموز', icon: 'FileCode', category: 'ويب وبرمجة' },
  { id: 'text-to-markdown', title: 'نص → Markdown', desc: 'تحويل النص إلى تنسيق ماركداون مع العناوين والقوائم', icon: 'FileText', category: 'ويب وبرمجة' },
  { id: 'text-to-json', title: 'نص → JSON', desc: 'تحويل الأسطر والبيانات إلى مصفوفة وكائنات JSON', icon: 'FileCode', category: 'بيانات' },
  { id: 'text-to-xml', title: 'نص → XML', desc: 'تحويل الأسطر إلى عقد XML منظمة وبنية هرمية', icon: 'FileCode', category: 'بيانات' },
  { id: 'text-to-csv', title: 'نص → CSV', desc: 'تحويل الأسطر والأسماء إلى صفوف وأعمدة جدول CSV', icon: 'FileSpreadsheet', category: 'بيانات' },
  { id: 'markdown-to-html', title: 'Markdown → HTML', desc: 'تحويل لغة ماركداون إلى صفحات ووسوم HTML نظيفة', icon: 'FileCode', category: 'ويب وبرمجة' },
  { id: 'html-to-markdown', title: 'HTML → Markdown', desc: 'استخراج نصوص Markdown من وسوم وشيفرة HTML', icon: 'FileText', category: 'ويب وبرمجة' },
  { id: 'json-to-csv', title: 'JSON → CSV', desc: 'تحويل كائنات ومصفوفات JSON إلى جدول CSV وجداول إكسل', icon: 'FileSpreadsheet', category: 'بيانات' },
  { id: 'csv-to-json', title: 'CSV → JSON', desc: 'تحويل ملفات وجداول CSV إلى كائنات JSON قياسية', icon: 'FileCode', category: 'بيانات' },
  { id: 'json-to-xml', title: 'JSON → XML', desc: 'تحويل كائنات JSON إلى عناصر وهيكل XML صالح', icon: 'FileCode', category: 'بيانات' },
  { id: 'xml-to-json', title: 'XML → JSON', desc: 'تحويل مستندات XML إلى كائنات JSON قابلة للاستخدام', icon: 'FileCode', category: 'بيانات' },
];

export function TextConverterSuite({ defaultMode }: { defaultMode?: TextConvertMode }) {
  const [currentMode, setCurrentMode] = useState<TextConvertMode>(defaultMode || 'text-to-pdf');
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [copied, setCopied] = useState(false);
  const [title, setTitle] = useState('مستند_جديد');
  const [fontSize, setFontSize] = useState(14);
  const [pageMargin, setPageMargin] = useState(15);
  const [statusMsg, setStatusMsg] = useState<{ text: string; isError?: boolean } | null>(null);

  // Auto convert on input or mode change
  const handleConvert = (input: string = inputText, mode: TextConvertMode = currentMode) => {
    if (!input.trim()) {
      setOutputText('');
      setStatusMsg(null);
      return;
    }

    try {
      setStatusMsg(null);
      switch (mode) {
        case 'text-to-html': {
          const paragraphs = input.split('\n\n').map(p => `<p>${p.replace(/\n/g, '<br/>')}</p>`).join('\n');
          const html = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <style>body { font-family: system-ui, sans-serif; line-height: 1.6; padding: 20px; }</style>
</head>
<body>
${paragraphs}
</body>
</html>`;
          setOutputText(html);
          break;
        }

        case 'text-to-markdown': {
          const lines = input.split('\n');
          const md = lines.map(line => {
            const trimmed = line.trim();
            if (!trimmed) return '';
            if (trimmed.startsWith('#')) return trimmed;
            return trimmed;
          }).join('\n\n');
          setOutputText(md);
          break;
        }

        case 'text-to-json': {
          const lines = input.split('\n').map(l => l.trim()).filter(Boolean);
          const obj = {
            title: title,
            generatedAt: new Date().toISOString(),
            totalLines: lines.length,
            items: lines.map((item, idx) => ({ id: idx + 1, content: item }))
          };
          setOutputText(JSON.stringify(obj, null, 2));
          break;
        }

        case 'text-to-xml': {
          const lines = input.split('\n').map(l => l.trim()).filter(Boolean);
          let xml = `<?xml version="1.0" encoding="UTF-8"?>\n<document title="${escapeXml(title)}">\n`;
          lines.forEach((line, i) => {
            xml += `  <item id="${i + 1}">${escapeXml(line)}</item>\n`;
          });
          xml += '</document>';
          setOutputText(xml);
          break;
        }

        case 'text-to-csv': {
          const lines = input.split('\n').map(l => l.trim()).filter(Boolean);
          const rows = lines.map((line, i) => [i + 1, line]);
          const csv = Papa.unparse({
            fields: ['الرقم', 'المحتوى'],
            data: rows
          });
          setOutputText(csv);
          break;
        }

        case 'markdown-to-html': {
          const rawHtml = marked.parse(input);
          const completeHtml = `<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>${title}</title>
  <style>body { font-family: system-ui, sans-serif; padding: 24px; line-height: 1.7; }</style>
</head>
<body>
${rawHtml}
</body>
</html>`;
          setOutputText(typeof rawHtml === 'string' ? completeHtml : String(rawHtml));
          break;
        }

        case 'html-to-markdown': {
          let md = input
            .replace(/<h1>(.*?)<\/h1>/gi, '# $1\n\n')
            .replace(/<h2>(.*?)<\/h2>/gi, '## $1\n\n')
            .replace(/<h3>(.*?)<\/h3>/gi, '### $1\n\n')
            .replace(/<p>(.*?)<\/p>/gi, '$1\n\n')
            .replace(/<strong>(.*?)<\/strong>/gi, '**$1**')
            .replace(/<b>(.*?)<\/b>/gi, '**$1**')
            .replace(/<em>(.*?)<\/em>/gi, '*$1*')
            .replace(/<i>(.*?)<\/i>/gi, '*$1*')
            .replace(/<br\s*\/?>/gi, '\n')
            .replace(/<li>(.*?)<\/li>/gi, '- $1\n')
            .replace(/<a\s+(?:[^>]*?\s+)?href="([^"]*)"[^>]*>(.*?)<\/a>/gi, '[$2]($1)')
            .replace(/<[^>]+>/g, '');
          setOutputText(md.trim());
          break;
        }

        case 'json-to-csv': {
          let parsed = JSON.parse(input);
          if (!Array.isArray(parsed)) {
            parsed = [parsed];
          }
          const csv = Papa.unparse(parsed);
          setOutputText(csv);
          break;
        }

        case 'csv-to-json': {
          const result = Papa.parse(input, { header: true, skipEmptyLines: true });
          setOutputText(JSON.stringify(result.data, null, 2));
          break;
        }

        case 'json-to-xml': {
          const parsed = JSON.parse(input);
          const xml = `<?xml version="1.0" encoding="UTF-8"?>\n<root>\n${jsonToXml(parsed, '  ')}</root>`;
          setOutputText(xml);
          break;
        }

        case 'xml-to-json': {
          const parser = new DOMParser();
          const xmlDoc = parser.parseFromString(input, 'text/xml');
          if (xmlDoc.getElementsByTagName('parsererror').length > 0) {
            throw new Error('ملف XML غير صالح');
          }
          const jsonObj = xmlToJson(xmlDoc);
          setOutputText(JSON.stringify(jsonObj, null, 2));
          break;
        }

        case 'text-to-txt':
        case 'text-to-pdf':
        case 'text-to-word':
          setOutputText(input);
          break;

        default:
          setOutputText(input);
      }
    } catch (err: any) {
      setStatusMsg({ text: `خطأ في التحويل: ${err?.message || 'تأكد من صحة التنسيق المدخل'}`, isError: true });
    }
  };

  const jsonToXml = (obj: any, indent = ''): string => {
    let xml = '';
    for (const prop in obj) {
      if (Array.isArray(obj[prop])) {
        for (const item of obj[prop]) {
          xml += `${indent}<${prop}>\n${typeof item === 'object' ? jsonToXml(item, indent + '  ') : indent + '  ' + escapeXml(String(item)) + '\n'}${indent}</${prop}>\n`;
        }
      } else if (typeof obj[prop] === 'object' && obj[prop] !== null) {
        xml += `${indent}<${prop}>\n${jsonToXml(obj[prop], indent + '  ')}${indent}</${prop}>\n`;
      } else {
        xml += `${indent}<${prop}>${escapeXml(String(obj[prop]))}</${prop}>\n`;
      }
    }
    return xml;
  };

  const xmlToJson = (xml: any): any => {
    let obj: any = {};
    if (xml.nodeType === 1) { // element
      if (xml.attributes.length > 0) {
        obj["@attributes"] = {};
        for (let j = 0; j < xml.attributes.length; j++) {
          const attribute = xml.attributes.item(j);
          obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
        }
      }
    } else if (xml.nodeType === 3) { // text
      obj = xml.nodeValue.trim();
    }

    if (xml.hasChildNodes()) {
      for (let i = 0; i < xml.childNodes.length; i++) {
        const item = xml.childNodes.item(i);
        const nodeName = item.nodeName;
        if (nodeName === '#text') {
          const val = item.nodeValue.trim();
          if (val) obj = val;
        } else if (typeof (obj[nodeName]) === "undefined") {
          obj[nodeName] = xmlToJson(item);
        } else {
          if (typeof (obj[nodeName].push) === "undefined") {
            const old = obj[nodeName];
            obj[nodeName] = [];
            obj[nodeName].push(old);
          }
          obj[nodeName].push(xmlToJson(item));
        }
      }
    }
    return obj;
  };

  const escapeXml = (unsafe: string) => {
    return unsafe.replace(/[<>&'"]/g, (c) => {
      switch (c) {
        case '<': return '&lt;';
        case '>': return '&gt;';
        case '&': return '&amp;';
        case '\'': return '&apos;';
        case '"': return '&quot;';
        default: return c;
      }
    });
  };

  const [isExporting, setIsExporting] = useState(false);
  const [exportProgress, setExportProgress] = useState(0);
  const [exportStatus, setExportStatus] = useState('');

  const handleDownload = async () => {
    if (!inputText.trim()) {
      alert('الرجاء إدخال النص أولاً');
      return;
    }

    const fileName = (title || 'document').replace(/\s+/g, '_');

    if (currentMode === 'text-to-pdf') {
      setIsExporting(true);
      setExportProgress(10);
      setExportStatus('جاري تنسيق النص والخطوط العربية...');

      try {
        const paragraphs = inputText
          .split('\n\n')
          .map(p => `<p style="font-size: ${fontSize}px; margin-bottom: 12px; line-height: 1.8;">${p.replace(/\n/g, '<br/>')}</p>`)
          .join('');

        const html = `
          <div dir="rtl" style="text-align: right; padding: ${pageMargin}px;">
            <h1 style="color: #065f46; font-size: ${fontSize + 8}px; margin-bottom: 20px; border-bottom: 2px solid #10b981; padding-bottom: 8px;">
              ${title || 'مستند بدون عنوان'}
            </h1>
            <div>${paragraphs}</div>
          </div>
        `;

        const { url } = await convertHtmlToPdfBlob(html, {
          filename: `${fileName}.pdf`,
          title: title,
          margin: pageMargin,
          onProgress: (pct, msg) => {
            setExportProgress(pct);
            setExportStatus(msg);
          }
        });

        const a = document.createElement('a');
        a.href = url;
        a.download = `${fileName}.pdf`;
        a.click();
        confetti({ particleCount: 35, spread: 60, origin: { y: 0.8 } });
      } catch (err: any) {
        alert('تعذر إنشاء ملف PDF: ' + err.message);
      } finally {
        setIsExporting(false);
      }
      return;
    }

    if (currentMode === 'text-to-word') {
      setIsExporting(true);
      setExportProgress(20);
      setExportStatus('جاري بناء مستند Word DOCX...');

      try {
        const paragraphs = inputText.split('\n\n').filter(Boolean).map(p => new Paragraph({
          alignment: AlignmentType.RIGHT,
          children: [new TextRun({ text: p, rightToLeft: true, font: 'Arial', size: fontSize * 2 })],
        }));

        setExportProgress(60);
        setExportStatus('جاري حزم وتصدير ملف Word...');

        const doc = new Document({
          sections: [{
            properties: {},
            children: paragraphs.length > 0 ? paragraphs : [new Paragraph({ children: [new TextRun({ text: inputText })] })],
          }],
        });

        const blob = await Packer.toBlob(doc);
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = `${fileName}.docx`;
        a.click();
        URL.revokeObjectURL(url);
        setExportProgress(100);
        confetti({ particleCount: 30, spread: 50 });
      } catch (err: any) {
        alert('تعذر إنشاء ملف Word: ' + err.message);
      } finally {
        setIsExporting(false);
      }
      return;
    }

    // Standard text download
    let extension = 'txt';
    let mimeType = 'text/plain;charset=utf-8';

    if (currentMode.includes('json')) {
      extension = 'json';
      mimeType = 'application/json;charset=utf-8';
    } else if (currentMode.includes('xml')) {
      extension = 'xml';
      mimeType = 'application/xml;charset=utf-8';
    } else if (currentMode.includes('csv')) {
      extension = 'csv';
      mimeType = 'text/csv;charset=utf-8';
    } else if (currentMode.includes('html')) {
      extension = 'html';
      mimeType = 'text/html;charset=utf-8';
    } else if (currentMode.includes('markdown')) {
      extension = 'md';
      mimeType = 'text/markdown;charset=utf-8';
    }

    const contentToDownload = outputText || inputText;
    const blob = new Blob([contentToDownload], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `${fileName}.${extension}`;
    a.click();
    URL.revokeObjectURL(url);
    confetti({ particleCount: 30, spread: 50 });
  };

  const handleCopy = () => {
    const textToCopy = outputText || inputText;
    if (!textToCopy) return;
    navigator.clipboard.writeText(textToCopy);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const selectedModeObj = MODES.find(m => m.id === currentMode);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Modes Grid / Selector */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-4 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-heading font-extrabold text-sm sm:text-base text-gray-900 dark:text-white">
              اختر نوع تحويل النصوص
            </h3>
          </div>
          <span className="text-xs px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-bold rounded-full border border-emerald-200/60 dark:border-emerald-800/60">
            {MODES.length} صيغ تحويل متوفرة
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-7 gap-2">
          {MODES.map((m) => {
            const isSelected = m.id === currentMode;
            return (
              <button
                key={m.id}
                onClick={() => {
                  setCurrentMode(m.id);
                  handleConvert(inputText, m.id);
                }}
                className={`p-2.5 rounded-2xl border text-right transition-all flex flex-col justify-between gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-900/10'
                    : 'bg-gray-50/50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-emerald-500/50'
                }`}
              >
                <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md self-start ${isSelected ? 'bg-white/20 text-white' : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300'}`}>
                  {m.category}
                </span>
                <span className="font-heading font-bold text-xs line-clamp-1" dir="ltr">
                  {m.title}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Conversion Workspace */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
        
        {/* Active Mode Banner */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800/60">
          <div>
            <h4 className="font-heading font-extrabold text-sm sm:text-base text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>{selectedModeObj?.title}</span>
            </h4>
            <p className="text-xs text-emerald-700 dark:text-emerald-300/80 mt-0.5">
              {selectedModeObj?.desc}
            </p>
          </div>

          <div className="flex items-center gap-2 shrink-0">
            <input
              type="text"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="اسم الملف التلقائي"
              className="px-3 py-1.5 text-xs font-semibold bg-white dark:bg-gray-800 border border-emerald-200 dark:border-emerald-700 rounded-xl outline-none"
            />
          </div>
        </div>

        {/* Options for PDF/Word */}
        {(currentMode === 'text-to-pdf' || currentMode === 'text-to-word') && (
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-gray-200 dark:border-gray-700">
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                حجم الخط (pt): {fontSize}
              </label>
              <input
                type="range"
                min="10"
                max="24"
                value={fontSize}
                onChange={(e) => setFontSize(Number(e.target.value))}
                className="w-full accent-emerald-600"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                الهوامش (مم): {pageMargin}
              </label>
              <input
                type="range"
                min="5"
                max="35"
                value={pageMargin}
                onChange={(e) => setPageMargin(Number(e.target.value))}
                className="w-full accent-emerald-600"
              />
            </div>
          </div>
        )}

        {/* Error message */}
        {statusMsg && (
          <div className={`p-3 rounded-xl text-xs font-bold ${statusMsg.isError ? 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-300 border border-rose-200 dark:border-rose-800' : 'bg-emerald-50 text-emerald-700'}`}>
            {statusMsg.text}
          </div>
        )}

        {/* Two-Pane Workspace */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
          
          {/* Input Pane */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-heading font-extrabold text-xs text-gray-700 dark:text-gray-300">
                النص أو الكود المدخل:
              </label>
              <div className="flex items-center gap-2">
                <button
                  onClick={() => {
                    setInputText('');
                    setOutputText('');
                  }}
                  className="text-[11px] font-bold text-gray-400 hover:text-rose-500 transition flex items-center gap-1"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                  مسح
                </button>
              </div>
            </div>

            <textarea
              value={inputText}
              onChange={(e) => {
                setInputText(e.target.value);
                handleConvert(e.target.value, currentMode);
              }}
              placeholder="اكتب أو الصق النص هنا ليتم تحويله فورياً..."
              rows={12}
              className="w-full p-4 text-xs font-mono bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl outline-none focus:border-emerald-500 transition leading-relaxed resize-y"
            />
          </div>

          {/* Output / Preview Pane */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="font-heading font-extrabold text-xs text-gray-700 dark:text-gray-300">
                النتيجة بعد التحويل:
              </label>
              <div className="flex items-center gap-2">
                <button
                  onClick={handleCopy}
                  className="text-[11px] font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
                >
                  {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                  {copied ? 'تم النسخ' : 'نسخ النتيجة'}
                </button>
              </div>
            </div>

            <textarea
              readOnly
              value={outputText || (inputText ? 'جاري التحويل...' : 'ستظهر النتيجة المحولة هنا مباشرة...')}
              rows={12}
              className="w-full p-4 text-xs font-mono bg-emerald-50/20 dark:bg-gray-800/80 border border-emerald-200/50 dark:border-gray-700 rounded-2xl outline-none transition leading-relaxed resize-y"
              dir="auto"
            />
          </div>
        </div>

        {/* Export Progress Bar */}
        {isExporting && (
          <ProcessingProgressBar
            progress={exportProgress}
            statusText={exportStatus}
            subText={title || 'مستند بدون عنوان'}
            color="emerald"
          />
        )}

        {/* Action Buttons */}
        <div className="flex flex-wrap items-center justify-between gap-4 pt-4 border-t border-gray-200 dark:border-gray-800">
          <div className="text-xs text-gray-500">
            الحجم: {new Blob([inputText]).size} بايت | الأسطر: {inputText.split('\n').filter(Boolean).length}
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={handleCopy}
              className="px-5 py-2.5 rounded-xl border border-gray-200 dark:border-gray-700 bg-white dark:bg-gray-800 text-gray-700 dark:text-gray-300 hover:bg-gray-50 font-bold text-xs flex items-center gap-2 shadow-xs transition"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-600" /> : <Copy className="w-4 h-4" />}
              <span>{copied ? 'تم النسخ' : 'نسخ الكود'}</span>
            </button>

            <button
              onClick={handleDownload}
              className="px-6 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs flex items-center gap-2 shadow-md shadow-emerald-900/10 transition transform hover:-translate-y-0.5"
            >
              <Download className="w-4 h-4" />
              <span>تحميل المستند ({selectedModeObj?.title.split('→')[1]?.trim() || 'ملف'})</span>
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
