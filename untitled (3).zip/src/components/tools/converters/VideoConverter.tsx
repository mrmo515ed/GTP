import React, { useState, useRef } from 'react';
import { FFmpeg } from '@ffmpeg/ffmpeg';
import { fetchFile, toBlobURL } from '@ffmpeg/util';
import {
  Film,
  Upload,
  Download,
  Play,
  Pause,
  RefreshCw,
  Sliders,
  Sparkles,
  Volume2,
  Check,
  Video,
  Music,
  Image as ImageIcon
} from 'lucide-react';
import confetti from 'canvas-confetti';

export type VideoConvertMode =
  | 'mp4-to-webm'
  | 'webm-to-mp4'
  | 'video-to-mp3'
  | 'video-to-gif'
  | 'gif-to-mp4'
  | 'mov-to-mp4'
  | 'mkv-to-mp4'
  | 'avi-to-mp4';

const VIDEO_MODES: { id: VideoConvertMode; title: string; desc: string; targetExt: string }[] = [
  { id: 'video-to-mp3', title: 'فيديو → MP3/صوت', desc: 'استخراج المسار الصوتي الصافي من الفيديو بجودة عالية', targetExt: 'mp3' },
  { id: 'video-to-gif', title: 'فيديو → GIF متحرك', desc: 'تحويل لقطات من الفيديو إلى صورة متحركة GIF خفيفة', targetExt: 'gif' },
  { id: 'mp4-to-webm', title: 'MP4 ↔ WebM', desc: 'تحويل فيديو MP4 إلى صيغة الويب الحديثة WebM فائقة السرعة', targetExt: 'webm' },
  { id: 'webm-to-mp4', title: 'WebM → MP4', desc: 'تحويل فيديوهات WebM إلى MP4 الأكثر توافقاً مع كل الأجهزة', targetExt: 'mp4' },
  { id: 'mov-to-mp4', title: 'MOV ↔ MP4', desc: 'تحويل مقاطع آيفون وماك QuickTime MOV إلى صيغة MP4', targetExt: 'mp4' },
  { id: 'mkv-to-mp4', title: 'MKV ↔ MP4', desc: 'تحويل حاويات ملفات ماتروشكا MKV عالية الدقة إلى MP4', targetExt: 'mp4' },
  { id: 'gif-to-mp4', title: 'GIF → MP4', desc: 'تحويل الصور المتحركة GIF إلى فيديو MP4 سريع وسلس', targetExt: 'mp4' },
];

let ffmpegGlobal: FFmpeg | null = null;
const loadFFmpeg = async () => {
  if (ffmpegGlobal) return ffmpegGlobal;
  const f = new FFmpeg();
  const baseURL = 'https://unpkg.com/@ffmpeg/core@0.12.10/dist/umd';
  await f.load({
    coreURL: await toBlobURL(`${baseURL}/ffmpeg-core.js`, 'text/javascript'),
    wasmURL: await toBlobURL(`${baseURL}/ffmpeg-core.wasm`, 'application/wasm'),
  });
  ffmpegGlobal = f;
  return f;
};

export function VideoConverter({ defaultMode }: { defaultMode?: VideoConvertMode }) {
  const selectedModeObj = VIDEO_MODES.find(m => m.id === (defaultMode || 'video-to-mp3')) || VIDEO_MODES[0];
  const [currentMode, setCurrentMode] = useState<VideoConvertMode>(defaultMode || 'video-to-mp3');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [videoUrl, setVideoUrl] = useState<string | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [duration, setDuration] = useState<number>(0);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [progress, setProgress] = useState<number>(0);
  const [convertedResultUrl, setConvertedResultUrl] = useState<string | null>(null);
  const [convertedResultName, setConvertedResultName] = useState<string>('');
  const [gifFps, setGifFps] = useState<number>(10);
  const [gifDuration, setGifDuration] = useState<number>(5);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<boolean>(false);

  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setVideoUrl(url);
    setIsPlaying(false);
    setError(null);
    setSuccess(false);
    setConvertedResultUrl(null);
  };

  const handleConvert = async () => {
    if (!selectedFile) {
      alert('الرجاء اختيار ملف فيديو أولاً');
      return;
    }

    setIsProcessing(true);
    setProgress(0);
    setConvertedResultUrl(null);
    setConvertedResultName('');
    setError(null);
    setSuccess(false);

    try {
      const baseName = selectedFile.name.split('.')[0] || 'video';

      // 1. Video to MP3 extraction using Web Audio (Fast route)
      if (currentMode === 'video-to-mp3') {
        const arrayBuffer = await selectedFile.arrayBuffer();
        const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
        const decoded = await audioCtx.decodeAudioData(arrayBuffer);

        // Simple WAV exporter
        const numChannels = decoded.numberOfChannels;
        const sampleRate = decoded.sampleRate;
        const left = decoded.getChannelData(0);
        const right = numChannels > 1 ? decoded.getChannelData(1) : left;
        const length = left.length * 2 * (numChannels === 2 ? 2 : 1);
        
        const buffer = new ArrayBuffer(44 + length);
        const view = new DataView(buffer);

        const writeString = (v: DataView, offset: number, str: string) => {
          for (let i = 0; i < str.length; i++) v.setUint8(offset + i, str.charCodeAt(i));
        };

        writeString(view, 0, 'RIFF');
        view.setUint32(4, 36 + length, true);
        writeString(view, 8, 'WAVE');
        writeString(view, 12, 'fmt ');
        view.setUint32(16, 16, true);
        view.setUint16(20, 1, true); // PCM
        view.setUint16(22, numChannels, true);
        view.setUint32(24, sampleRate, true);
        view.setUint32(28, sampleRate * numChannels * 2, true);
        view.setUint16(32, numChannels * 2, true);
        view.setUint16(34, 16, true);
        writeString(view, 36, 'data');
        view.setUint32(40, length, true);

        let offset = 44;
        for (let i = 0; i < left.length; i++) {
          let s = Math.max(-1, Math.min(1, left[i]));
          view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
          offset += 2;
          if (numChannels === 2) {
            s = Math.max(-1, Math.min(1, right[i]));
            view.setInt16(offset, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
            offset += 2;
          }
        }

        const blob = new Blob([view], { type: 'audio/mp3' });
        const dlUrl = URL.createObjectURL(blob);
        
        setConvertedResultUrl(dlUrl);
        setConvertedResultName(`${baseName}_audio.mp3`);
        setSuccess(true);
        confetti({ particleCount: 35, spread: 60 });
        setIsProcessing(false);
        return;
      }

      // 2. Real Video Format Conversion using FFmpeg.wasm
      setProgress(5); // Loading engine
      const f = await loadFFmpeg();
      
      f.on('progress', ({ progress: p }) => {
        setProgress(Math.round(p * 100));
      });

      const { name } = selectedFile;
      const targetExt = VIDEO_MODES.find(m => m.id === currentMode)?.targetExt || 'mp4';
      const outName = `output.${targetExt}`;
      
      await f.writeFile(name, await fetchFile(selectedFile));
      
      const command = ['-i', name];
      
      // Conversion profiles
      if (currentMode === 'video-to-gif') {
         // Convert video to GIF: max 15 fps, scale width to 480px keeping aspect ratio
         command.push('-t', gifDuration.toString(), '-vf', `fps=${gifFps},scale=320:-1:flags=lanczos,split[s0][s1];[s0]palettegen=stats_mode=diff[p];[s1][p]paletteuse=dither=bayer:bayer_scale=5`, '-loop', '0');
      } else if (currentMode === 'mp4-to-webm') {
         command.push('-c:v', 'libvpx-vp9', '-crf', '30', '-b:v', '0', '-b:a', '128k', '-c:a', 'libopus');
      } else {
         // General quick conversion to MP4 (h264)
         command.push('-c:v', 'libx264', '-preset', 'ultrafast', '-c:a', 'aac');
      }
      
      command.push(outName);
      
      await f.exec(command);
      const data = await f.readFile(outName);
      const blob = new Blob([data as Uint8Array], { type: targetExt === 'gif' ? 'image/gif' : `video/${targetExt}` });
      const url = URL.createObjectURL(blob);
      
      setConvertedResultUrl(url);
      setConvertedResultName(`${baseName}_converted.${targetExt}`);
      
      setSuccess(true);
      confetti({ particleCount: 35, spread: 60 });
    } catch (err: any) {
      console.error(err);
      setError(err.message || 'حدث خطأ أثناء معالجة الفيديو.');
    } finally {
      setIsProcessing(false);
      setProgress(0);
    }
  };

  const handleDownload = () => {
    if (convertedResultUrl && convertedResultName) {
      const a = document.createElement('a');
      a.href = convertedResultUrl;
      a.download = convertedResultName;
      a.click();
    }
  };

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Hidden Canvas */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Modes Grid */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-4 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Video className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-heading font-extrabold text-sm sm:text-base text-gray-900 dark:text-white">
              محولات ملفات الفيديو والوسائط
            </h3>
          </div>
          <span className="text-xs px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-bold rounded-full border border-emerald-200/60 dark:border-emerald-800/60">
            {VIDEO_MODES.length} محولات
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-7 gap-2">
          {VIDEO_MODES.map((m) => {
            const isSelected = m.id === currentMode;
            return (
              <button
                key={m.id}
                onClick={() => setCurrentMode(m.id)}
                className={`p-3 rounded-2xl border text-right transition-all flex flex-col justify-between gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-900/10'
                    : 'bg-gray-50/50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-emerald-500/50'
                }`}
              >
                <span className="font-heading font-bold text-xs" dir="ltr">
                  {m.title}
                </span>
                <span className={`text-[10px] line-clamp-1 ${isSelected ? 'text-emerald-100' : 'text-gray-400'}`}>
                  {m.desc}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Workspace */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
        
        {/* Banner */}
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 flex items-center justify-between">
          <div>
            <h4 className="font-heading font-extrabold text-sm sm:text-base text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>{selectedModeObj?.title}</span>
            </h4>
            <p className="text-xs text-emerald-700 dark:text-emerald-300/80 mt-0.5">
              {selectedModeObj?.desc}
            </p>
          </div>
        </div>

        {/* Upload Zone */}
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-gray-300 dark:border-gray-700 hover:border-emerald-500 rounded-3xl p-8 text-center cursor-pointer transition bg-gray-50/50 dark:bg-gray-800/30 group"
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept="video/*,.mp4,.webm,.mov,.avi,.mkv,.gif"
            className="hidden"
          />
          <div className="w-14 h-14 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition">
            <Film className="w-7 h-7" />
          </div>
          <p className="font-heading font-extrabold text-sm text-gray-800 dark:text-gray-200">
            انقر لاختيار مقطع الفيديو أو اسحبه هنا
          </p>
          <p className="text-xs text-gray-400 mt-1">
            يدعم MP4, WebM, MOV, AVI, MKV, GIF
          </p>
          {selectedFile && (
            <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200 rounded-lg text-xs font-bold">
              <Check className="w-3.5 h-3.5" />
              {selectedFile.name} ({(selectedFile.size / (1024 * 1024)).toFixed(2)} MB)
            </div>
          )}
        </div>

        {/* Video Player */}
        {videoUrl && (
          <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-gray-200 dark:border-gray-700 space-y-3">
            <video
              ref={videoRef}
              src={videoUrl}
              controls
              onLoadedMetadata={() => setDuration(videoRef.current?.duration || 0)}
              className="max-h-72 w-full object-contain rounded-xl bg-black"
            />
          </div>
        )}

        
        {/* Settings for GIF */}
        {currentMode === 'video-to-gif' && selectedFile && (
          <div className="flex gap-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-gray-200 dark:border-gray-700">
            <div className="flex-1">
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-2">مدة الـ GIF (ثواني) - أقصى حد يفضل 10 ثواني</label>
              <input type="range" min="1" max="15" value={gifDuration} onChange={(e) => setGifDuration(parseInt(e.target.value))} className="w-full accent-emerald-600" />
              <div className="text-center text-xs mt-1 text-emerald-600 font-bold">{gifDuration} ثانية</div>
            </div>
            <div className="flex-1">
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-2">عدد الإطارات (FPS) - الجودة</label>
              <input type="range" min="5" max="24" value={gifFps} onChange={(e) => setGifFps(parseInt(e.target.value))} className="w-full accent-emerald-600" />
              <div className="text-center text-xs mt-1 text-emerald-600 font-bold">{gifFps} إطار/ثانية</div>
            </div>
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-800 flex-wrap">
          
          {/* Status Messages */}
          {error && (
            <div className="mr-auto p-2.5 px-4 bg-red-50 dark:bg-red-900/30 text-red-700 dark:text-red-300 border border-red-200 dark:border-red-800 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></span>
              خطأ: {error}
            </div>
          )}
          
          {success && convertedResultUrl && (
            <div className="mr-auto p-2.5 px-4 bg-emerald-50 dark:bg-emerald-900/30 text-emerald-700 dark:text-emerald-300 border border-emerald-200 dark:border-emerald-800 rounded-xl text-xs sm:text-sm font-bold flex items-center gap-2">
              <Check className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
              تم التحويل بنجاح!
            </div>
          )}

          {isProcessing && progress > 0 && (
            <div className="flex-1 min-w-[120px] bg-gray-200 dark:bg-gray-700 rounded-full h-2.5 mx-4 overflow-hidden">
              <div className="bg-indigo-600 h-2.5 rounded-full transition-all duration-300" style={{ width: `${progress}%` }}></div>
            </div>
          )}
          <button
            onClick={handleConvert}
            disabled={!selectedFile || isProcessing}
            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-indigo-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5"
          >
            {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            <span>{isProcessing ? (progress > 0 ? `جاري التحويل ${progress}%...` : 'جاري التحميل...') : 'تحويل ومعالجة'}</span>
          </button>

          {convertedResultUrl && (
            <button
              onClick={handleDownload}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-emerald-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5 animate-in fade-in zoom-in"
            >
              <Download className="w-4 h-4" />
              <span>تحميل النتيجة</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
