import React, { useState, useRef } from 'react';
import { jsPDF } from 'jspdf';
import {
  Image as ImageIcon,
  Upload,
  Download,
  Copy,
  Check,
  RefreshCw,
  Sliders,
  FileImage,
  ArrowRightLeft,
  Sparkles,
  Layers,
  Eye,
  FileText
} from 'lucide-react';
import confetti from 'canvas-confetti';

export type ImageConvertMode =
  | 'jpg-png'
  | 'jpg-webp'
  | 'png-webp'
  | 'image-to-pdf'
  | 'pdf-to-image'
  | 'gif-to-image'
  | 'bmp-to-image'
  | 'svg-to-png'
  | 'ico-converter'
  | 'image-to-base64'
  | 'base64-to-image';

const MODES: { id: ImageConvertMode; title: string; desc: string; icon: string }[] = [
  { id: 'jpg-png', title: 'JPG ↔ PNG', desc: 'تحويل الصور بين JPG و PNG مع الحفاظ على الشفافية والجودة', icon: 'Image' },
  { id: 'jpg-webp', title: 'JPG ↔ WebP', desc: 'تحويل إلى صيغة WebP الحديثة فائقة الضغط والسرعة', icon: 'Sparkles' },
  { id: 'png-webp', title: 'PNG ↔ WebP', desc: 'تحويل PNG لـ WebP مع دعم ألفا الشفافية الكامل', icon: 'Image' },
  { id: 'image-to-pdf', title: 'JPG/PNG → PDF', desc: 'تجميع الصور وتحويلها إلى مستند PDF عالي الدقة', icon: 'FileText' },
  { id: 'svg-to-png', title: 'SVG → PNG', desc: 'تحويل رسومات الفيكتور SVG إلى صور نقطية PNG بدقة عالية', icon: 'FileCode' },
  { id: 'ico-converter', title: 'ICO ↔ PNG', desc: 'توليد أيقونات Favicon ومواقع بأحجام قياسية متعددة', icon: 'Layers' },
  { id: 'gif-to-image', title: 'GIF → JPG/PNG', desc: 'استخراج وتجميد إطارات الرسوم المتحركة GIF كصور ثابتة', icon: 'FileImage' },
  { id: 'bmp-to-image', title: 'BMP ↔ JPG/PNG', desc: 'تحويل الصور النقطية القديمة BMP إلى الصيغ الحديثة', icon: 'Image' },
  { id: 'image-to-base64', title: 'صورة → Base64', desc: 'تضمين الصورة ككود Base64 في الـ HTML و CSS مباشرة', icon: 'Code' },
  { id: 'base64-to-image', title: 'Base64 → صورة', desc: 'فك تشفير شفرة Base64 ومعاينتها وتنزيلها كملف صورة', icon: 'Eye' },
];

export function UniversalImageConverter({ defaultMode }: { defaultMode?: ImageConvertMode }) {
  const [currentMode, setCurrentMode] = useState<ImageConvertMode>(defaultMode || 'jpg-png');
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [targetFormat, setTargetFormat] = useState<'png' | 'jpeg' | 'webp' | 'ico'>('png');
  const [quality, setQuality] = useState(0.92);
  const [resizeWidth, setResizeWidth] = useState<number | ''>('');
  const [resizeHeight, setResizeHeight] = useState<number | ''>('');
  const [maintainAspect, setMaintainAspect] = useState(true);
  const [originalDimensions, setOriginalDimensions] = useState<{ width: number; height: number } | null>(null);
  
  // Base64 states
  const [base64Input, setBase64Input] = useState('');
  const [base64Output, setBase64Output] = useState('');
  const [copied, setCopied] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [convertedResultUrl, setConvertedResultUrl] = useState<string | null>(null);
  const [convertedResultName, setConvertedResultName] = useState<string>('');

  const fileInputRef = useRef<HTMLInputElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setSelectedFile(file);
    const url = URL.createObjectURL(file);
    setPreviewUrl(url);

    // Read dimensions
    const img = new Image();
    img.onload = () => {
      setOriginalDimensions({ width: img.naturalWidth, height: img.naturalHeight });
      setResizeWidth(img.naturalWidth);
      setResizeHeight(img.naturalHeight);
    };
    img.src = url;

    // Auto generate Base64 if in that mode
    const reader = new FileReader();
    reader.onloadend = () => {
      setBase64Output(reader.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleConvert = async () => {
    if (!previewUrl && !base64Input) {
      alert('الرجاء اختيار صورة أو إدخال كود Base64 أولاً');
      return;
    }

    setIsProcessing(true);
    setConvertedResultUrl(null);
    setConvertedResultName('');

    try {
      if (currentMode === 'image-to-pdf') {
        const doc = new jsPDF({
          orientation: 'portrait',
          unit: 'px',
          format: [originalDimensions?.width || 800, originalDimensions?.height || 600]
        });

        doc.addImage(
          previewUrl!,
          'JPEG',
          0,
          0,
          originalDimensions?.width || 800,
          originalDimensions?.height || 600
        );
        const blob = doc.output('blob');
        const url = URL.createObjectURL(blob);
        setConvertedResultUrl(url);
        setConvertedResultName(`${selectedFile?.name.split('.')[0] || 'converted'}.pdf`);
        confetti({ particleCount: 30, spread: 50 });
        setIsProcessing(false);
        return;
      }

      if (currentMode === 'base64-to-image') {
        setConvertedResultUrl(base64Input);
        setConvertedResultName(`decoded_image.${targetFormat}`);
        confetti({ particleCount: 30, spread: 50 });
        setIsProcessing(false);
        return;
      }

      // Convert using Canvas
      const img = new Image();
      img.crossOrigin = 'anonymous';
      img.onload = () => {
        const canvas = canvasRef.current || document.createElement('canvas');
        const targetW = Number(resizeWidth) || img.naturalWidth;
        const targetH = Number(resizeHeight) || img.naturalHeight;
        
        canvas.width = targetW;
        canvas.height = targetH;
        const ctx = canvas.getContext('2d');
        
        if (!ctx) {
          setIsProcessing(false);
          return;
        }

        // If target is JPEG, fill white background to avoid black transparency
        if (targetFormat === 'jpeg') {
          ctx.fillStyle = '#FFFFFF';
          ctx.fillRect(0, 0, targetW, targetH);
        }

        ctx.drawImage(img, 0, 0, targetW, targetH);
        
        const mime = targetFormat === 'jpeg' ? 'image/jpeg' : targetFormat === 'webp' ? 'image/webp' : 'image/png';
        const dataUrl = canvas.toDataURL(mime, quality);
        
        setConvertedResultUrl(dataUrl);
        const baseName = selectedFile?.name.split('.')[0] || 'converted_image';
        setConvertedResultName(`${baseName}.${targetFormat === 'jpeg' ? 'jpg' : targetFormat}`);
        
        confetti({ particleCount: 35, spread: 60, origin: { y: 0.8 } });
        setIsProcessing(false);
      };
      img.src = previewUrl!;
    } catch (err: any) {
      alert('حدث خطأ أثناء المعالجة: ' + err.message);
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (convertedResultUrl && convertedResultName) {
      const a = document.createElement('a');
      a.href = convertedResultUrl;
      a.download = convertedResultName;
      a.click();
    }
  };

  const handleWidthChange = (val: number) => {
    setResizeWidth(val);
    if (maintainAspect && originalDimensions && originalDimensions.width > 0) {
      const ratio = originalDimensions.height / originalDimensions.width;
      setResizeHeight(Math.round(val * ratio));
    }
  };

  const handleHeightChange = (val: number) => {
    setResizeHeight(val);
    if (maintainAspect && originalDimensions && originalDimensions.height > 0) {
      const ratio = originalDimensions.width / originalDimensions.height;
      setResizeWidth(Math.round(val * ratio));
    }
  };

  const selectedModeObj = MODES.find(m => m.id === currentMode);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Hidden Canvas */}
      <canvas ref={canvasRef} className="hidden" />

      {/* Modes Grid */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-4 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <ArrowRightLeft className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-heading font-extrabold text-sm sm:text-base text-gray-900 dark:text-white">
              محولات الصور وتغيير الصيغ
            </h3>
          </div>
          <span className="text-xs px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-bold rounded-full border border-emerald-200/60 dark:border-emerald-800/60">
            {MODES.length} محولات متاحة
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
          {MODES.map((m) => {
            const isSelected = m.id === currentMode;
            return (
              <button
                key={m.id}
                onClick={() => {
                  setCurrentMode(m.id);
                  if (m.id === 'jpg-png') setTargetFormat('png');
                  if (m.id === 'jpg-webp' || m.id === 'png-webp') setTargetFormat('webp');
                  if (m.id === 'svg-to-png') setTargetFormat('png');
                  if (m.id === 'ico-converter') {
                    setTargetFormat('png');
                    setResizeWidth(64);
                    setResizeHeight(64);
                  }
                }}
                className={`p-3 rounded-2xl border text-right transition-all flex flex-col justify-between gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-900/10'
                    : 'bg-gray-50/50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-emerald-500/50'
                }`}
              >
                <span className="font-heading font-bold text-xs" dir="ltr">
                  {m.title}
                </span>
                <span className={`text-[10px] line-clamp-1 ${isSelected ? 'text-emerald-100' : 'text-gray-400'}`}>
                  {m.desc}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Workspace */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
        
        {/* Banner */}
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 flex items-center justify-between">
          <div>
            <h4 className="font-heading font-extrabold text-sm sm:text-base text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>{selectedModeObj?.title}</span>
            </h4>
            <p className="text-xs text-emerald-700 dark:text-emerald-300/80 mt-0.5">
              {selectedModeObj?.desc}
            </p>
          </div>
        </div>

        {/* Base64 to Image Mode */}
        {currentMode === 'base64-to-image' ? (
          <div className="space-y-4">
            <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
              الصق كود الـ Base64 (يبدأ بـ data:image/png;base64,...):
            </label>
            <textarea
              value={base64Input}
              onChange={(e) => {
                setBase64Input(e.target.value);
                setPreviewUrl(e.target.value);
              }}
              rows={6}
              placeholder="data:image/jpeg;base64,/9j/4AAQSkZJRgABAQ..."
              className="w-full p-4 font-mono text-xs bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl outline-none focus:border-emerald-500"
            />
            {previewUrl && (
              <div className="p-4 bg-gray-50 dark:bg-gray-800 rounded-2xl text-center space-y-2">
                <p className="text-xs font-bold text-gray-500">معاينة الصورة المفكوكة:</p>
                <img src={previewUrl} alt="Preview" className="max-h-64 mx-auto rounded-xl shadow-xs" />
              </div>
            )}
          </div>
        ) : (
          /* File Upload Zone */
          <div
            onClick={() => fileInputRef.current?.click()}
            className="border-2 border-dashed border-gray-300 dark:border-gray-700 hover:border-emerald-500 dark:hover:border-emerald-500 rounded-3xl p-8 text-center cursor-pointer transition bg-gray-50/50 dark:bg-gray-800/30 group"
          >
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*,.svg,.ico,.bmp,.webp,.gif,.tif,.tiff"
              className="hidden"
            />
            <div className="w-14 h-14 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition">
              <Upload className="w-7 h-7" />
            </div>
            <p className="font-heading font-extrabold text-sm text-gray-800 dark:text-gray-200">
              اسحب وأفلت ملف الصورة هنا أو انقر للاختيار
            </p>
            <p className="text-xs text-gray-400 mt-1">
              يدعم JPG, PNG, WebP, SVG, GIF, BMP, ICO وجميع الصيغ بجودة كاملة
            </p>
            {selectedFile && (
              <div className="mt-3 inline-flex items-center gap-2 px-3 py-1 bg-emerald-100 dark:bg-emerald-900 text-emerald-800 dark:text-emerald-200 rounded-lg text-xs font-bold">
                <Check className="w-3.5 h-3.5" />
                {selectedFile.name} ({(selectedFile.size / 1024).toFixed(1)} KB)
              </div>
            )}
          </div>
        )}

        {/* Options & Settings */}
        {currentMode !== 'image-to-base64' && currentMode !== 'base64-to-image' && (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-gray-200 dark:border-gray-700">
            
            {/* Format Selection */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                الصيغة الناتجة المستهدفة:
              </label>
              <select
                value={targetFormat}
                onChange={(e) => setTargetFormat(e.target.value as any)}
                className="w-full px-3 py-2 text-xs font-bold bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
              >
                <option value="png">PNG (جودة كاملة مع الشفافية)</option>
                <option value="jpeg">JPG / JPEG (مناسب للصور الفوتوغرافية)</option>
                <option value="webp">WebP (ضغط متطور وخفيف جداً)</option>
                <option value="ico">ICO / Favicon (أيقونة للمواقع)</option>
              </select>
            </div>

            {/* Quality Slider */}
            <div>
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300 mb-1.5">
                جودة الضغط: {Math.round(quality * 100)}%
              </label>
              <input
                type="range"
                min="0.1"
                max="1.0"
                step="0.05"
                value={quality}
                onChange={(e) => setQuality(Number(e.target.value))}
                className="w-full accent-emerald-600"
              />
            </div>

            {/* Resizing */}
            <div className="space-y-1.5">
              <label className="block text-xs font-bold text-gray-700 dark:text-gray-300">
                تغيير الأبعاد (بكسل):
              </label>
              <div className="flex items-center gap-2">
                <input
                  type="number"
                  placeholder="العرض"
                  value={resizeWidth}
                  onChange={(e) => handleWidthChange(Number(e.target.value))}
                  className="w-1/2 px-2.5 py-1.5 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
                />
                <span className="text-xs text-gray-400">×</span>
                <input
                  type="number"
                  placeholder="الارتفاع"
                  value={resizeHeight}
                  onChange={(e) => handleHeightChange(Number(e.target.value))}
                  className="w-1/2 px-2.5 py-1.5 text-xs bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
                />
              </div>
            </div>
          </div>
        )}

        {/* Base64 Output Mode */}
        {currentMode === 'image-to-base64' && base64Output && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-gray-700 dark:text-gray-300">
                كود Base64 المولد:
              </label>
              <button
                onClick={() => {
                  navigator.clipboard.writeText(base64Output);
                  setCopied(true);
                  setTimeout(() => setCopied(false), 2000);
                }}
                className="text-xs font-bold text-emerald-600 dark:text-emerald-400 hover:underline flex items-center gap-1"
              >
                {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
                {copied ? 'تم النسخ' : 'نسخ كود Base64'}
              </button>
            </div>
            <textarea
              readOnly
              value={base64Output}
              rows={6}
              className="w-full p-4 font-mono text-xs bg-gray-50 dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl outline-none"
            />
          </div>
        )}

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
          <button
            onClick={handleConvert}
            disabled={(!previewUrl && !base64Input) || isProcessing}
            className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-indigo-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5"
          >
            {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
            <span>تحويل ومعالجة</span>
          </button>
          
          {convertedResultUrl && currentMode !== 'image-to-base64' && (
            <button
              onClick={handleDownload}
              className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-emerald-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5 animate-in fade-in zoom-in"
            >
              <Download className="w-4 h-4" />
              <span>تحميل النتيجة</span>
            </button>
          )}
        </div>

      </div>
    </div>
  );
}
