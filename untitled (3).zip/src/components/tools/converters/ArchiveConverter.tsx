import React, { useState, useRef } from 'react';
import JSZip from 'jszip';
import {
  Archive,
  Upload,
  Download,
  FolderArchive,
  FileText,
  FileCheck,
  Split,
  Layers,
  Sparkles,
  Trash2,
  Check,
  Eye,
  RefreshCw
} from 'lucide-react';
import confetti from 'canvas-confetti';

export type ArchiveConvertMode =
  | 'create-zip'
  | 'extract-zip'
  | 'merge-files'
  | 'split-files'
  | 'rename-files';

const ARCHIVE_MODES: { id: ArchiveConvertMode; title: string; desc: string; icon: string }[] = [
  { id: 'create-zip', title: 'إنشاء ملف ZIP', desc: 'تجميع وضغط عدة ملفات ومجلدات في أرشيف ZIP واحد', icon: 'Archive' },
  { id: 'extract-zip', title: 'فك ضغط ZIP', desc: 'استخراج واستعراض محتويات ملفات الأرشيف المضغوطة', icon: 'FolderArchive' },
  { id: 'merge-files', title: 'دمج عدة ملفات', desc: 'دمج ملفات نصية أو مستندات في ملف شامل متكامل', icon: 'Layers' },
  { id: 'split-files', title: 'تقسيم ملف كبير', desc: 'تجزئة الملفات الكبيرة إلى أجزاء بحجم محدد (MB / KB)', icon: 'Split' },
];

export function ArchiveConverter({ defaultMode }: { defaultMode?: ArchiveConvertMode }) {
  const [currentMode, setCurrentMode] = useState<ArchiveConvertMode>(defaultMode || 'create-zip');
  const [filesToZip, setFilesToZip] = useState<File[]>([]);
  const [extractedFiles, setExtractedFiles] = useState<{ name: string; size: number; contentBlob?: Blob }[]>([]);
  const [zipName, setZipName] = useState<string>('archive');
  const [chunkSizeMb, setChunkSizeMb] = useState<number>(5);
  const [isProcessing, setIsProcessing] = useState<boolean>(false);
  const [convertedResultUrl, setConvertedResultUrl] = useState<string | null>(null);
  const [convertedResultName, setConvertedResultName] = useState<string>('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFilesAdded = (e: React.ChangeEvent<HTMLInputElement>) => {
    const fileList = e.target.files;
    if (!fileList || fileList.length === 0) return;
    const files: File[] = Array.from(fileList);

    if (currentMode === 'extract-zip') {
      handleUnzip(files[0]);
    } else {
      setFilesToZip(prev => [...prev, ...files]);
    }
  };

  const handleUnzip = async (zipFile: File) => {
    setIsProcessing(true);
    try {
      const zip = new JSZip();
      const loaded = await zip.loadAsync(zipFile);
      const list: { name: string; size: number; contentBlob?: Blob }[] = [];

      for (const [filename, fileObj] of Object.entries(loaded.files)) {
        if (!fileObj.dir) {
          const blob = await fileObj.async('blob');
          list.push({ name: filename, size: blob.size, contentBlob: blob });
        }
      }

      setExtractedFiles(list);
      confetti({ particleCount: 25, spread: 40 });
    } catch (err: any) {
      alert('خطأ أثناء فك ضغط الملف: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleDownload = () => {
    if (convertedResultUrl) {
      const a = document.createElement('a');
      a.href = convertedResultUrl;
      a.download = convertedResultName || 'archive.zip';
      a.click();
    }
  };

  const handleCreateZip = async () => {
    if (filesToZip.length === 0) {
      alert('الرجاء إضافة ملفات لضغطها');
      return;
    }

    setIsProcessing(true);
    try {
      const zip = new JSZip();
      filesToZip.forEach(file => {
        zip.file(file.name, file);
      });

      const blob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(blob);
      setConvertedResultUrl(url);
      setConvertedResultName(`${zipName || 'archive'}.zip`);

      confetti({ particleCount: 35, spread: 60 });
    } catch (err: any) {
      alert('خطأ أثناء إنشاء ملف ZIP: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleMergeFiles = async () => {
    if (filesToZip.length === 0) {
      alert('الرجاء إضافة ملفات لدمجها');
      return;
    }

    setIsProcessing(true);
    try {
      let mergedText = '';
      for (const file of filesToZip) {
        const text = await file.text();
        mergedText += `\n/* ===== ${file.name} ===== */\n` + text + '\n';
      }

      const blob = new Blob([mergedText], { type: 'text/plain;charset=utf-8' });
      const url = URL.createObjectURL(blob);
      setConvertedResultUrl(url);
      setConvertedResultName(`${zipName || 'merged'}.txt`);

      confetti({ particleCount: 30, spread: 50 });
    } catch (err: any) {
      alert('خطأ أثناء دمج الملفات: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const handleSplitFile = async () => {
    if (filesToZip.length === 0) {
      alert('الرجاء اختيار ملف لتقسيمه');
      return;
    }

    const file = filesToZip[0];
    const chunkSize = chunkSizeMb * 1024 * 1024;
    const totalChunks = Math.ceil(file.size / chunkSize);

    setIsProcessing(true);
    try {
      const zip = new JSZip();
      for (let i = 0; i < totalChunks; i++) {
        const start = i * chunkSize;
        const end = Math.min(file.size, start + chunkSize);
        const chunkBlob = file.slice(start, end);
        zip.file(`${file.name}.part${i + 1}`, chunkBlob);
      }

      const zipBlob = await zip.generateAsync({ type: 'blob' });
      const url = URL.createObjectURL(zipBlob);
      setConvertedResultUrl(url);
      setConvertedResultName(`${file.name}_split_parts.zip`);

      confetti({ particleCount: 35, spread: 60 });
    } catch (err: any) {
      alert('خطأ أثناء تقسيم الملف: ' + err.message);
    } finally {
      setIsProcessing(false);
    }
  };

  const downloadExtractedFile = (item: { name: string; contentBlob?: Blob }) => {
    if (!item.contentBlob) return;
    const url = URL.createObjectURL(item.contentBlob);
    const a = document.createElement('a');
    a.href = url;
    a.download = item.name.split('/').pop() || item.name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const selectedModeObj = ARCHIVE_MODES.find(m => m.id === currentMode);

  return (
    <div className="space-y-6 animate-in fade-in duration-300">
      
      {/* Modes */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-4 sm:p-6 shadow-xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Archive className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />
            <h3 className="font-heading font-extrabold text-sm sm:text-base text-gray-900 dark:text-white">
              أدوات ضغط وفك وتقسيم الأرشيف والملفات
            </h3>
          </div>
          <span className="text-xs px-2.5 py-1 bg-emerald-50 dark:bg-emerald-950/60 text-emerald-700 dark:text-emerald-400 font-bold rounded-full border border-emerald-200/60 dark:border-emerald-800/60">
            {ARCHIVE_MODES.length} أدوات
          </span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
          {ARCHIVE_MODES.map((m) => {
            const isSelected = m.id === currentMode;
            return (
              <button
                key={m.id}
                onClick={() => {
                  setCurrentMode(m.id);
                  setFilesToZip([]);
                  setExtractedFiles([]);
                }}
                className={`p-3 rounded-2xl border text-right transition-all flex flex-col justify-between gap-1.5 ${
                  isSelected
                    ? 'bg-emerald-600 text-white border-emerald-600 shadow-md shadow-emerald-900/10'
                    : 'bg-gray-50/50 dark:bg-gray-800/50 border-gray-200 dark:border-gray-700 text-gray-700 dark:text-gray-300 hover:border-emerald-500/50'
                }`}
              >
                <span className="font-heading font-bold text-xs">
                  {m.title}
                </span>
                <span className={`text-[10px] line-clamp-1 ${isSelected ? 'text-emerald-100' : 'text-gray-400'}`}>
                  {m.desc}
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Main Workspace */}
      <div className="bg-white dark:bg-gray-900 border border-gray-200 dark:border-gray-800 rounded-3xl p-5 sm:p-7 shadow-xs space-y-6">
        
        {/* Banner */}
        <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 rounded-2xl border border-emerald-200 dark:border-emerald-800/60 flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div>
            <h4 className="font-heading font-extrabold text-sm sm:text-base text-emerald-900 dark:text-emerald-200 flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-emerald-600" />
              <span>{selectedModeObj?.title}</span>
            </h4>
            <p className="text-xs text-emerald-700 dark:text-emerald-300/80 mt-0.5">
              {selectedModeObj?.desc}
            </p>
          </div>

          <input
            type="text"
            value={zipName}
            onChange={(e) => setZipName(e.target.value)}
            placeholder="اسم الأرشيف / الملف"
            className="px-3 py-1.5 text-xs font-semibold bg-white dark:bg-gray-800 border border-emerald-200 dark:border-emerald-700 rounded-xl outline-none"
          />
        </div>

        {/* Upload Zone */}
        <div
          onClick={() => fileInputRef.current?.click()}
          className="border-2 border-dashed border-gray-300 dark:border-gray-700 hover:border-emerald-500 rounded-3xl p-8 text-center cursor-pointer transition bg-gray-50/50 dark:bg-gray-800/30 group"
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFilesAdded}
            multiple={currentMode !== 'extract-zip' && currentMode !== 'split-files'}
            accept={currentMode === 'extract-zip' ? '.zip' : '*'}
            className="hidden"
          />
          <div className="w-14 h-14 bg-emerald-100 dark:bg-emerald-900/50 text-emerald-600 dark:text-emerald-400 rounded-2xl flex items-center justify-center mx-auto mb-3 group-hover:scale-110 transition">
            <Upload className="w-7 h-7" />
          </div>
          <p className="font-heading font-extrabold text-sm text-gray-800 dark:text-gray-200">
            {currentMode === 'extract-zip' ? 'انقر لاختيار ملف ZIP لفك ضغطه' : 'انقر لاختيار الملفات أو اسحبها هنا'}
          </p>
          <p className="text-xs text-gray-400 mt-1">
            {currentMode === 'extract-zip' ? 'يدعم أرشيفات ZIP المتعددة' : 'يمكنك اختيار عدة ملفات دفعة واحدة'}
          </p>
        </div>

        {/* Selected files list */}
        {filesToZip.length > 0 && (
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-gray-700 dark:text-gray-300">
                الملفات المختارة ({filesToZip.length}):
              </span>
              <button
                onClick={() => setFilesToZip([])}
                className="text-xs text-rose-500 hover:underline flex items-center gap-1 font-bold"
              >
                <Trash2 className="w-3.5 h-3.5" />
                مسح الكل
              </button>
            </div>
            <div className="max-h-48 overflow-y-auto divide-y divide-gray-100 dark:divide-gray-800 border border-gray-200 dark:border-gray-700 rounded-2xl p-2 bg-gray-50/50 dark:bg-gray-800/50">
              {filesToZip.map((f, i) => (
                <div key={i} className="flex items-center justify-between py-2 px-2 text-xs">
                  <span className="font-medium text-gray-800 dark:text-gray-200 truncate">{f.name}</span>
                  <span className="text-gray-400">{(f.size / 1024).toFixed(1)} KB</span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Extracted zip files */}
        {extractedFiles.length > 0 && (
          <div className="space-y-2">
            <span className="text-xs font-bold text-emerald-600 dark:text-emerald-400">
              محتويات الأرشيف المفكوكة ({extractedFiles.length} ملف):
            </span>
            <div className="divide-y divide-gray-100 dark:divide-gray-800 border border-emerald-200 dark:border-gray-700 rounded-2xl p-2 bg-emerald-50/30 dark:bg-gray-800/50 max-h-56 overflow-y-auto">
              {extractedFiles.map((item, i) => (
                <div key={i} className="flex items-center justify-between py-2 px-3 text-xs">
                  <span className="font-bold text-gray-800 dark:text-gray-200 truncate">{item.name}</span>
                  <div className="flex items-center gap-3">
                    <span className="text-gray-400">{(item.size / 1024).toFixed(1)} KB</span>
                    <button
                      onClick={() => downloadExtractedFile(item)}
                      className="px-2 py-1 bg-emerald-600 hover:bg-emerald-700 text-white rounded-lg font-bold text-[11px] flex items-center gap-1"
                    >
                      <Download className="w-3 h-3" />
                      تنزيل
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Options for split */}
        {currentMode === 'split-files' && (
          <div className="p-4 bg-gray-50 dark:bg-gray-800/50 rounded-2xl border border-gray-200 dark:border-gray-700 flex items-center gap-4">
            <label className="text-xs font-bold text-gray-700 dark:text-gray-300">
              حجم كل جزء (ميغابايت MB):
            </label>
            <input
              type="number"
              min="1"
              max="100"
              value={chunkSizeMb}
              onChange={(e) => setChunkSizeMb(Number(e.target.value))}
              className="w-24 px-3 py-1.5 text-xs font-bold bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-xl outline-none"
            />
          </div>
        )}

        {/* Action Buttons */}
        {currentMode !== 'extract-zip' && (
          <div className="flex items-center justify-end gap-3 pt-4 border-t border-gray-200 dark:border-gray-800">
            <button
              onClick={() => {
                if (currentMode === 'create-zip') handleCreateZip();
                else if (currentMode === 'merge-files') handleMergeFiles();
                else if (currentMode === 'split-files') handleSplitFile();
              }}
              disabled={filesToZip.length === 0 || isProcessing}
              className="px-6 py-2.5 bg-indigo-600 hover:bg-indigo-700 disabled:opacity-50 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-indigo-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5"
            >
              {isProcessing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <RefreshCw className="w-4 h-4" />}
              <span>{currentMode === 'create-zip' ? 'معالجة وضغط' : currentMode === 'merge-files' ? 'دمج الملفات' : 'تقسيم الملف'}</span>
            </button>
            
            {convertedResultUrl && (
              <button
                onClick={handleDownload}
                className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs sm:text-sm rounded-2xl shadow-md shadow-emerald-900/10 flex items-center gap-2 transition transform hover:-translate-y-0.5 animate-in fade-in zoom-in"
              >
                <Download className="w-4 h-4" />
                <span>تحميل النتيجة ({convertedResultName})</span>
              </button>
            )}
          </div>
        )}

      </div>
    </div>
  );
}
