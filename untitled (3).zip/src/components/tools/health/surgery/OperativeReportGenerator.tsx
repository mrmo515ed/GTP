import React, { useState } from 'react';
import { FileText, Download, Printer, Check, Copy, User, Calendar, Clock } from 'lucide-react';
import { jsPDF } from 'jspdf';

export function OperativeReportGenerator() {
  const [patientName, setPatientName] = useState('أحمد محمد خالد');
  const [patientId, setPatientId] = useState('MED-2025-9842');
  const [surgeonName, setSurgeonName] = useState('د. عبد الرحمن الفضلي');
  const [anesthesiologistName, setAnesthesiologistName] = useState('د. مروان السعيد');
  const [procedureName, setProcedureName] = useState('استئصال الغضروف القطني المجهري (Microdiscectomy L4-L5)');
  const [preOpDiagnosis, setPreOpDiagnosis] = useState('انزلاق غضروفي قطني ضاغط على عصب عرق النسا الأيمن');
  const [postOpDiagnosis, setPostOpDiagnosis] = useState('نفس التشخيص مع تحرير كامل للجذر العصبي L5');
  const [anesthesiaType, setAnesthesiaType] = useState('تخدير عام مع تنبيب رغامي (General Anesthesia + ETT)');
  const [bloodLoss, setBloodLoss] = useState('50 مل (طبيعي)');
  const [findingsAndTechnique, setFindingsAndTechnique] = useState(
`1. تم تعقيم وتجهيز ظهر المريض بالبيتادين والكحول الجراحي في وضعية الانبطاح (Prone Position).
2. إجراء شق جلدي دقيق بطول 2.5 سم في المستوى L4-L5 تحت توجيه الأشعة التداخلية (C-Arm).
3. استخدام المجهر الجراحي المكبر لقص جزئي للصفيحة العظمية واستعراض القناة الشوكية.
4. إزاحة الجذر العصبي L5 بحذر واستئصال الفتق الغضروفي كاملاً دون أي تمزق في غشاء الأم الجافية.
5. التحقق من النبض الحر للعصب، وإيقاف النزيف بالكي ثنائي القطب Bipolar، وغسل الحقل بسالاين دافئ.
6. خياطة اللفافة بخيوط فيكريل 2-0 وخياطة الجلد تجميلياً بخيوط مونوكريل 3-0 ووضع ضماد معقم.`
  );

  const [downloadReady, setDownloadReady] = useState<{ url: string; name: string } | null>(null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [copied, setCopied] = useState(false);

  const handleGeneratePdf = () => {
    setIsGenerating(true);
    try {
      const doc = new jsPDF();
      doc.setFontSize(16);
      doc.text('OPERATIVE SURGICAL REPORT (تقرير العملية الجراحية)', 105, 20, { align: 'center' });

      doc.setFontSize(11);
      doc.text(`Patient Name: ${patientName}`, 20, 35);
      doc.text(`Medical ID: ${patientId}`, 130, 35);
      doc.text(`Lead Surgeon: ${surgeonName}`, 20, 45);
      doc.text(`Anesthesiologist: ${anesthesiologistName}`, 130, 45);
      doc.text(`Procedure: ${procedureName}`, 20, 55);
      doc.text(`Pre-Op Diagnosis: ${preOpDiagnosis}`, 20, 65);
      doc.text(`Post-Op Diagnosis: ${postOpDiagnosis}`, 20, 75);
      doc.text(`Anesthesia: ${anesthesiaType}`, 20, 85);
      doc.text(`Estimated Blood Loss (EBL): ${bloodLoss}`, 130, 85);

      doc.text('Operative Technique & Findings:', 20, 100);
      const splitText = doc.splitTextToSize(findingsAndTechnique, 170);
      doc.text(splitText, 20, 110);

      doc.text('Surgeon Signature: _______________________', 20, 270);
      doc.text('Date: ' + new Date().toLocaleDateString('ar-EG'), 130, 270);

      const blob = doc.output('blob');
      const url = URL.createObjectURL(blob);
      setDownloadReady({ url, name: `Surgical-Report-${patientId}.pdf` });
    } catch (e) {
      console.error(e);
    } finally {
      setIsGenerating(false);
    }
  };

  const handleCopyText = () => {
    const fullReport = `=== تقرير العملية الجراحية الرسمي ===
اسم المريض: ${patientName} | الرقم الطبي: ${patientId}
الجراح الرئيسي: ${surgeonName}
طبيب التخدير: ${anesthesiologistName}
اسم الإجراء الجراحي: ${procedureName}
التشخيص قبل الجراحة: ${preOpDiagnosis}
التشخيص بعد الجراحة: ${postOpDiagnosis}
نوع التخدير: ${anesthesiaType}
كمية الدم المفقودة: ${bloodLoss}

خطوات العملية وملاحظات الجراح:
${findingsAndTechnique}
`;
    navigator.clipboard.writeText(fullReport);
    setCopied(true);
    setTimeout(() => setCopied(false), 2500);
  };

  return (
    <div className="bg-slate-900 rounded-3xl p-6 border border-slate-800 text-slate-100 space-y-6 shadow-2xl">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-800 pb-4">
        <div className="flex items-center gap-3">
          <div className="p-3 bg-teal-500/20 text-teal-400 rounded-2xl border border-teal-500/30">
            <FileText className="w-6 h-6" />
          </div>
          <div>
            <h3 className="text-lg font-black text-white">محرر ومولد تقارير العمليات الجراحية (Operative Report Generator)</h3>
            <p className="text-xs text-slate-400">توثيق رسمي شامل للخطوات الجراحية، التخدير، فقدان الدم، والتصدير المباشر</p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleCopyText}
            className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold rounded-xl transition border border-slate-700 flex items-center gap-1.5"
          >
            {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
            <span>{copied ? 'تم النسخ' : 'نسخ التقرير'}</span>
          </button>
        </div>
      </div>

      {/* Form Fields */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
        <div className="space-y-1.5">
          <label className="font-bold text-slate-300">اسم المريض الكامل:</label>
          <input
            type="text"
            value={patientName}
            onChange={(e) => setPatientName(e.target.value)}
            className="w-full p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-slate-100 outline-none"
          />
        </div>

        <div className="space-y-1.5">
          <label className="font-bold text-slate-300">الرقم الطبي (Medical ID):</label>
          <input
            type="text"
            value={patientId}
            onChange={(e) => setPatientId(e.target.value)}
            className="w-full p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-slate-100 outline-none font-mono"
          />
        </div>

        <div className="space-y-1.5">
          <label className="font-bold text-slate-300">الجراح الرئيسي (Lead Surgeon):</label>
          <input
            type="text"
            value={surgeonName}
            onChange={(e) => setSurgeonName(e.target.value)}
            className="w-full p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-slate-100 outline-none"
          />
        </div>

        <div className="space-y-1.5">
          <label className="font-bold text-slate-300">طبيب التخدير (Anesthesiologist):</label>
          <input
            type="text"
            value={anesthesiologistName}
            onChange={(e) => setAnesthesiologistName(e.target.value)}
            className="w-full p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-slate-100 outline-none"
          />
        </div>

        <div className="md:col-span-2 space-y-1.5">
          <label className="font-bold text-slate-300">اسم الإجراء الجراحي المنفذ (Procedure):</label>
          <input
            type="text"
            value={procedureName}
            onChange={(e) => setProcedureName(e.target.value)}
            className="w-full p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-slate-100 outline-none font-bold text-teal-300"
          />
        </div>

        <div className="space-y-1.5">
          <label className="font-bold text-slate-300">التشخيص قبل الجراحة (Pre-Op Diagnosis):</label>
          <input
            type="text"
            value={preOpDiagnosis}
            onChange={(e) => setPreOpDiagnosis(e.target.value)}
            className="w-full p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-slate-100 outline-none"
          />
        </div>

        <div className="space-y-1.5">
          <label className="font-bold text-slate-300">التشخيص بعد الجراحة (Post-Op Diagnosis):</label>
          <input
            type="text"
            value={postOpDiagnosis}
            onChange={(e) => setPostOpDiagnosis(e.target.value)}
            className="w-full p-2.5 bg-slate-950 rounded-xl border border-slate-800 text-slate-100 outline-none"
          />
        </div>

        <div className="md:col-span-2 space-y-1.5">
          <label className="font-bold text-slate-300">تفاصيل وخطوات العملية الجراحية والمشاهدات التشريحية:</label>
          <textarea
            rows={6}
            value={findingsAndTechnique}
            onChange={(e) => setFindingsAndTechnique(e.target.value)}
            className="w-full p-3 bg-slate-950 rounded-xl border border-slate-800 text-slate-100 outline-none font-mono text-[11px] leading-relaxed"
          />
        </div>
      </div>

      {/* Action Buttons */}
      <div className="pt-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-4">
        <button
          onClick={handleGeneratePdf}
          disabled={isGenerating}
          className="w-full sm:w-auto px-6 py-2.5 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-2 shadow-md shadow-teal-950"
        >
          <FileText className="w-4 h-4" />
          <span>{isGenerating ? 'جارٍ توليد التقرير...' : 'توليد تقرير PDF رسمي'}</span>
        </button>

        {downloadReady && (
          <a
            href={downloadReady.url}
            download={downloadReady.name}
            className="w-full sm:w-auto px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl transition flex items-center justify-center gap-2 shadow-lg shadow-emerald-950 animate-in fade-in"
          >
            <Download className="w-4 h-4" />
            <span>تحميل تقرير الجراحة PDF ({downloadReady.name})</span>
          </a>
        )}
      </div>
    </div>
  );
}
