import React, { lazy, Suspense } from 'react';
import { lazyWithRetry } from '../../utils/lazyWithRetry';
import { ErrorBoundary } from '../common/ErrorBoundary';
import { LoadingFallback } from '../layout/LoadingFallback';

// Pages
const AssistantPage = lazyWithRetry(() => import('../pages/AssistantPage').then(m => ({ default: m.AssistantPage })));

// Text
const WordCounter = lazyWithRetry(() => import('./text/WordCounter').then(m => ({ default: m.WordCounter })));
const ArabicTextFormatter = lazyWithRetry(() => import('./text/ArabicTextFormatter').then(m => ({ default: m.ArabicTextFormatter })));
const CaseConverter = lazyWithRetry(() => import('./text/CaseConverter').then(m => ({ default: m.CaseConverter })));
const TextDiff = lazyWithRetry(() => import('./text/TextDiff').then(m => ({ default: m.TextDiff })));
const DuplicateRemover = lazyWithRetry(() => import('./text/DuplicateRemover').then(m => ({ default: m.DuplicateRemover })));
const LoremGenerator = lazyWithRetry(() => import('./text/LoremGenerator').then(m => ({ default: m.LoremGenerator })));
const HashEncoder = lazyWithRetry(() => import('./text/HashEncoder').then(m => ({ default: m.HashEncoder })));
const TextToSpeech = lazyWithRetry(() => import('./text/TextToSpeech').then(m => ({ default: m.TextToSpeech })));
const AITextDetector = lazyWithRetry(() => import('./text/AITextDetector').then(m => ({ default: m.AITextDetector })));
const TextProcessingSuite = lazyWithRetry(() => import('./text/TextProcessingSuite').then(m => ({ default: m.TextProcessingSuite })));

// Image
const ImageCompressor = lazyWithRetry(() => import('./image/ImageCompressor').then(m => ({ default: m.ImageCompressor })));
const ImageConverter = lazyWithRetry(() => import('./image/ImageConverter').then(m => ({ default: m.ImageConverter })));
const QRCodeGenerator = lazyWithRetry(() => import('./image/QRCodeGenerator').then(m => ({ default: m.QRCodeGenerator })));
const ColorPickerPalette = lazyWithRetry(() => import('./image/ColorPickerPalette').then(m => ({ default: m.ColorPickerPalette })));
const ImagePaletteExtractor = lazyWithRetry(() => import('./image/ImagePaletteExtractor').then(m => ({ default: m.ImagePaletteExtractor })));
const SvgToolsSuite = lazyWithRetry(() => import('./image/SvgToolsSuite').then(m => ({ default: m.SvgToolsSuite })));
const ImageProcessingSuite = lazyWithRetry(() => import('./image/ImageProcessingSuite').then(m => ({ default: m.ImageProcessingSuite })));

// Design
const GradientGenerator = lazyWithRetry(() => import('./design/GradientGenerator').then(m => ({ default: m.GradientGenerator })));
const DesignSuite = lazyWithRetry(() => import('./design/DesignSuite').then(m => ({ default: m.DesignSuite })));
const DiagramsDesignSuite = lazyWithRetry(() => import('./design/DiagramsDesignSuite').then(m => ({ default: m.DiagramsDesignSuite })));

// Calculators
const AgeCalculator = lazyWithRetry(() => import('./calculators/AgeCalculator').then(m => ({ default: m.AgeCalculator })));
const HealthCalculator = lazyWithRetry(() => import('./calculators/HealthCalculator').then(m => ({ default: m.HealthCalculator })));
const FinancialCalculator = lazyWithRetry(() => import('./calculators/FinancialCalculator').then(m => ({ default: m.FinancialCalculator })));
const DateCalculator = lazyWithRetry(() => import('./calculators/DateCalculator').then(m => ({ default: m.DateCalculator })));
const ZakatCalculator = lazyWithRetry(() => import('./calculators/ZakatCalculator').then(m => ({ default: m.ZakatCalculator })));
const StopwatchTimer = lazyWithRetry(() => import('./calculators/StopwatchTimer').then(m => ({ default: m.StopwatchTimer })));
const InstallmentCalculator = lazyWithRetry(() => import('./calculators/InstallmentCalculator').then(m => ({ default: m.InstallmentCalculator })));
const CalculatorsSuite = lazyWithRetry(() => import('./calculators/CalculatorsSuite').then(m => ({ default: m.CalculatorsSuite })));
const DailyCalculatorsHub = lazyWithRetry(() => import('./calculators/DailyCalculatorsHub').then(m => ({ default: m.DailyCalculatorsHub })));

// Health & Surgery
const PregnancyCalculator = lazyWithRetry(() => import('./health/PregnancyCalculator').then(m => ({ default: m.PregnancyCalculator })));
const BloodTypeCompatibility = lazyWithRetry(() => import('./health/BloodTypeCompatibility').then(m => ({ default: m.BloodTypeCompatibility })));
const MedicalToolsSuite = lazyWithRetry(() => import('./health/MedicalToolsSuite').then(m => ({ default: m.MedicalToolsSuite })));
const SurgicalAnatomy3DSuite = lazyWithRetry(() => import('./health/SurgicalAnatomy3DSuite').then(m => ({ default: m.SurgicalAnatomy3DSuite })));
const ChemicalReactionsLab = lazyWithRetry(() => import('./health/ChemicalReactionsLab').then(m => ({ default: m.ChemicalReactionsLab })));
const BiochemistryLabSuite = lazyWithRetry(() => import('./health/BiochemistryLabSuite').then(m => ({ default: m.BiochemistryLabSuite })));

// Student
const GpaCalculator = lazyWithRetry(() => import('./student/GpaCalculator').then(m => ({ default: m.GpaCalculator })));
const PomodoroTimer = lazyWithRetry(() => import('./student/PomodoroTimer').then(m => ({ default: m.PomodoroTimer })));
const NumbersToWords = lazyWithRetry(() => import('./student/NumbersToWords').then(m => ({ default: m.NumbersToWords })));
const ArabicNumerals = lazyWithRetry(() => import('./student/ArabicNumerals').then(m => ({ default: m.ArabicNumerals })));

// Discovery
const RandomPicker = lazyWithRetry(() => import('./discovery/RandomPicker').then(m => ({ default: m.RandomPicker })));
const IpInfo = lazyWithRetry(() => import('./discovery/IpInfo').then(m => ({ default: m.IpInfo })));

// Units
const UnitConverter = lazyWithRetry(() => import('./units/UnitConverter').then(m => ({ default: m.UnitConverter })));
const CurrencyCalculator = lazyWithRetry(() => import('./units/CurrencyCalculator').then(m => ({ default: m.CurrencyCalculator })));

// Dev & Security
const PasswordGenerator = lazyWithRetry(() => import('./dev/PasswordGenerator').then(m => ({ default: m.PasswordGenerator })));
const JsonFormatter = lazyWithRetry(() => import('./dev/JsonFormatter').then(m => ({ default: m.JsonFormatter })));
const SvgOptimizer = lazyWithRetry(() => import('./dev/SvgOptimizer').then(m => ({ default: m.SvgOptimizer })));
const SpeedTestSimulator = lazyWithRetry(() => import('./dev/SpeedTestSimulator').then(m => ({ default: m.SpeedTestSimulator })));
const BaseConverter = lazyWithRetry(() => import('./dev/BaseConverter').then(m => ({ default: m.BaseConverter })));
const Base64Converter = lazyWithRetry(() => import('./dev/Base64Converter').then(m => ({ default: m.Base64Converter })));
const UuidGenerator = lazyWithRetry(() => import('./dev/UuidGenerator').then(m => ({ default: m.UuidGenerator })));
const UnixTimestamp = lazyWithRetry(() => import('./dev/UnixTimestamp').then(m => ({ default: m.UnixTimestamp })));
const RegexTester = lazyWithRetry(() => import('./dev/RegexTester').then(m => ({ default: m.RegexTester })));
const CssFormatter = lazyWithRetry(() => import('./dev/CssFormatter').then(m => ({ default: m.CssFormatter })));
const ColorConverter = lazyWithRetry(() => import('./dev/ColorConverter').then(m => ({ default: m.ColorConverter })));
const JsonToolsSuite = lazyWithRetry(() => import('./dev/JsonToolsSuite').then(m => ({ default: m.JsonToolsSuite })));
const XmlToolsSuite = lazyWithRetry(() => import('./dev/XmlToolsSuite').then(m => ({ default: m.XmlToolsSuite })));
const SqlToolsSuite = lazyWithRetry(() => import('./dev/SqlToolsSuite').then(m => ({ default: m.SqlToolsSuite })));
const CodeToolsSuite = lazyWithRetry(() => import('./dev/CodeToolsSuite').then(m => ({ default: m.CodeToolsSuite })));
const EncodingSuite = lazyWithRetry(() => import('./dev/EncodingSuite').then(m => ({ default: m.EncodingSuite })));
const SecurityDataSuite = lazyWithRetry(() => import('./dev/SecurityDataSuite').then(m => ({ default: m.SecurityDataSuite })));
const WebDevSuite = lazyWithRetry(() => import('./dev/WebDevSuite').then(m => ({ default: m.WebDevSuite })));
const DevDesignHubSuite = lazyWithRetry(() => import('./dev/DevDesignHubSuite').then(m => ({ default: m.DevDesignHubSuite })));
const SecuritySuite = lazyWithRetry(() => import('./dev/SecuritySuite').then(m => ({ default: m.SecuritySuite })));

// Engineering
const TriangleSolver = lazyWithRetry(() => import('./engineering/TriangleSolver').then(m => ({ default: m.TriangleSolver })));
const EngineeringMathSuite = lazyWithRetry(() => import('./engineering/EngineeringMathSuite').then(m => ({ default: m.EngineeringMathSuite })));

// PDF
const PdfMerger = lazyWithRetry(() => import('./pdf/PdfMerger').then(m => ({ default: m.PdfMerger })));
const PdfToolsSuite = lazyWithRetry(() => import('./pdf/PdfToolsSuite').then(m => ({ default: m.PdfToolsSuite })));

// Social
const SocialSuite = lazyWithRetry(() => import('./social/SocialSuite').then(m => ({ default: m.SocialSuite })));

// Converters Suites
const TextConverterSuite = lazyWithRetry(() => import('./converters/TextConverterSuite').then(m => ({ default: m.TextConverterSuite })));
const UniversalImageConverter = lazyWithRetry(() => import('./converters/UniversalImageConverter').then(m => ({ default: m.UniversalImageConverter })));
const DocumentConverter = lazyWithRetry(() => import('./converters/DocumentConverter').then(m => ({ default: m.DocumentConverter })));
const DataTableConverter = lazyWithRetry(() => import('./converters/DataTableConverter').then(m => ({ default: m.DataTableConverter })));
const AudioConverter = lazyWithRetry(() => import('./converters/AudioConverter').then(m => ({ default: m.AudioConverter })));
const VideoConverter = lazyWithRetry(() => import('./converters/VideoConverter').then(m => ({ default: m.VideoConverter })));
const ArchiveConverter = lazyWithRetry(() => import('./converters/ArchiveConverter').then(m => ({ default: m.ArchiveConverter })));
const TimeDateConverter = lazyWithRetry(() => import('./converters/TimeDateConverter').then(m => ({ default: m.TimeDateConverter })));
const DevConverterSuite = lazyWithRetry(() => import('./converters/DevConverterSuite').then(m => ({ default: m.DevConverterSuite })));
const DataToolsSuite = lazyWithRetry(() => import('./converters/DataToolsSuite').then(m => ({ default: m.DataToolsSuite })));
const MegaConvertersSuite = lazyWithRetry(() => import('./converters/MegaConvertersSuite').then(m => ({ default: m.MegaConvertersSuite })));

function renderTool(toolId: string) {
  switch (toolId) {
    // 1. Text & Converters
    case 'ai-text-detector':
    case 'ai-detector':
    case 'ai-content-detector':
      return <AITextDetector />;
    case 'word-counter':
      return <WordCounter />;
    case 'arabic-text-formatter':
      return <ArabicTextFormatter />;
    case 'case-converter':
      return <CaseConverter />;
    case 'text-diff':
      return <TextDiff />;
    case 'duplicate-remover':
      return <DuplicateRemover />;
    case 'lorem-generator':
      return <LoremGenerator />;
    case 'hash-encoder':
      return <HashEncoder />;
    case 'text-to-speech':
      return <TextToSpeech />;
    case 'text-converter-suite':
      return <TextConverterSuite />;
    case 'text-to-pdf':
      return <TextConverterSuite defaultMode="text-to-pdf" />;
    case 'text-to-word':
      return <TextConverterSuite defaultMode="text-to-word" />;
    case 'text-to-txt':
      return <TextConverterSuite defaultMode="text-to-txt" />;
    case 'text-to-html':
      return <TextConverterSuite defaultMode="text-to-html" />;
    case 'text-to-markdown':
      return <TextConverterSuite defaultMode="text-to-markdown" />;
    case 'text-to-json':
      return <TextConverterSuite defaultMode="text-to-json" />;
    case 'text-to-xml':
      return <TextConverterSuite defaultMode="text-to-xml" />;
    case 'text-to-csv':
      return <TextConverterSuite defaultMode="text-to-csv" />;
    case 'markdown-to-html':
      return <TextConverterSuite defaultMode="markdown-to-html" />;
    case 'html-to-markdown':
      return <TextConverterSuite defaultMode="html-to-markdown" />;
    case 'csv-to-json':
      return <TextConverterSuite defaultMode="csv-to-json" />;

    // 2. Image Converters
    case 'image-compressor':
      return <ImageCompressor />;
    case 'image-converter':
    case 'image-converter-suite':
      return <UniversalImageConverter />;
    case 'universal-image-converter':
      return <UniversalImageConverter />;
    case 'png-to-jpg':
    case 'jpg-to-png':
      return <UniversalImageConverter defaultMode="jpg-png" />;
    case 'webp-to-png':
    case 'png-to-webp':
      return <UniversalImageConverter defaultMode="png-webp" />;
    case 'jpg-to-webp':
      return <UniversalImageConverter defaultMode="jpg-webp" />;
    case 'image-to-pdf':
      return <UniversalImageConverter defaultMode="image-to-pdf" />;
    case 'image-to-ico':
    case 'ico-converter':
      return <UniversalImageConverter defaultMode="ico-converter" />;
    case 'svg-to-png':
      return <UniversalImageConverter defaultMode="svg-to-png" />;
    case 'heic-to-jpg':
      return <UniversalImageConverter defaultMode="jpg-png" />;
    case 'qr-generator':
    case 'qr-code':
      return <QRCodeGenerator />;
    case 'color-picker':
    case 'color-picker-palette':
      return <ColorPickerPalette />;
    case 'image-palette':
    case 'image-palette-extractor':
      return <ImagePaletteExtractor />;
    case 'gradient-generator':
      return <GradientGenerator />;

    // 3. Document & PDF Converters
    case 'pdf-merger':
      return <PdfMerger />;
    case 'document-converter':
      return <DocumentConverter />;
    case 'pdf-to-word':
      return <DocumentConverter defaultMode="pdf-to-word" />;
    case 'word-to-pdf':
      return <DocumentConverter defaultMode="word-to-pdf" />;
    case 'pdf-to-excel':
      return <DocumentConverter defaultMode="excel-to-pdf" />;
    case 'excel-to-pdf':
      return <DocumentConverter defaultMode="excel-to-pdf" />;
    case 'pdf-to-ppt':
      return <DocumentConverter defaultMode="ppt-to-pdf" />;
    case 'ppt-to-pdf':
      return <DocumentConverter defaultMode="ppt-to-pdf" />;
    case 'pdf-to-text':
      return <DocumentConverter defaultMode="pdf-to-txt" />;
    case 'pdf-compress':
      return <PdfToolsSuite defaultTab="compress" />;
    case 'pdf-split':
      return <PdfToolsSuite defaultTab="split" />;
    case 'pdf-protect':
      return <PdfToolsSuite defaultTab="protect" />;

    // 4. Data Table Converters
    case 'data-table-converter':
      return <DataTableConverter />;
    case 'excel-to-json':
      return <DataTableConverter defaultMode="excel-to-json" />;
    case 'excel-to-csv':
      return <DataTableConverter defaultMode="excel-to-csv" />;
    case 'csv-to-excel':
      return <DataTableConverter defaultMode="csv-to-excel" />;
    case 'csv-to-xml':
      return <DataTableConverter defaultMode="csv-to-sql" />;
    case 'excel-to-html':
      return <DataTableConverter defaultMode="excel-to-csv" />;
    case 'sql-to-json':
      return <DataTableConverter defaultMode="json-to-excel" />;
    case 'sql-to-csv':
      return <DataTableConverter defaultMode="tsv-to-csv" />;
    case 'json-to-sql':
      return <DataTableConverter defaultMode="csv-to-sql" />;
    case 'csv-to-sql':
      return <DataTableConverter defaultMode="csv-to-sql" />;

    // 5. Audio & Media Converters
    case 'audio-converter':
    case 'audio-converter-suite':
      return <AudioConverter />;
    case 'mp3-to-wav':
      return <AudioConverter defaultMode="mp3-to-wav" />;
    case 'wav-to-mp3':
      return <AudioConverter defaultMode="wav-to-mp3" />;
    case 'm4a-to-mp3':
      return <AudioConverter defaultMode="m4a-to-mp3" />;
    case 'audio-cutter':
      return <AudioConverter defaultMode="mp3-to-wav" />;

    // 6. Video Converters
    case 'video-converter':
    case 'video-converter-suite':
      return <VideoConverter />;
    case 'mp4-to-gif':
    case 'video-to-gif':
      return <VideoConverter defaultMode="video-to-gif" />;
    case 'video-to-mp3':
      return <VideoConverter defaultMode="video-to-mp3" />;
    case 'video-compressor':
      return <VideoConverter defaultMode="mp4-to-webm" />;

    // 7. Archive Converters
    case 'archive-converter':
    case 'archive-converter-suite':
      return <ArchiveConverter />;
    case 'create-zip':
      return <ArchiveConverter defaultMode="create-zip" />;
    case 'extract-zip':
      return <ArchiveConverter defaultMode="extract-zip" />;

    // 8. Time & Date Converters
    case 'time-date-converter':
    case 'time-date-suite':
      return <TimeDateConverter />;
    case 'hijri-to-gregorian':
      return <TimeDateConverter defaultMode="hijri-gregorian" />;
    case 'gregorian-to-hijri':
      return <TimeDateConverter defaultMode="hijri-gregorian" />;
    case 'time-diff-calc':
      return <TimeDateConverter defaultMode="time-units" />;
    case 'time-zone-converter':
    case 'timezone-converter':
      return <TimeDateConverter defaultMode="timezone-converter" />;

    // 9. Developer & Coding Converters
    case 'dev-converter-suite':
      return <DevConverterSuite />;
    case 'html-to-jsx':
      return <DevConverterSuite defaultMode="html-entities" />;
    case 'css-to-tailwind':
      return <DevConverterSuite defaultMode="color-converter" />;
    case 'json-to-typescript':
      return <DevConverterSuite defaultMode="json-formatter" />;
    case 'svg-to-jsx':
      return <DevConverterSuite defaultMode="html-entities" />;
    case 'sql-formatter':
      return <DevConverterSuite defaultMode="json-formatter" />;
    case 'graphql-formatter':
      return <DevConverterSuite defaultMode="json-formatter" />;
    case 'markdown-to-pdf':
      return <DevConverterSuite defaultMode="base64-text" />;
    case 'cron-generator':
      return <WebDevSuite defaultTab="cron-generator" />;
    case 'url-encoder-decoder':
      return <DevConverterSuite defaultMode="url-encoder" />;
    case 'curl-to-fetch':
      return <DevConverterSuite defaultMode="json-formatter" />;

    // Calculators
    case 'age-calculator':
      return <AgeCalculator />;
    case 'bmi-calculator':
    case 'bmi-calc':
    case 'body-fat':
    case 'bmr-calculator':
    case 'ideal-weight':
    case 'water-intake':
    case 'calorie-calculator':
    case 'health-calculator':
      return <HealthCalculator />;
    case 'salary-tax':
    case 'loan-calculator':
    case 'compound-interest':
    case 'discount-calculator':
    case 'vat-calculator':
    case 'percentage-calculator':
    case 'profit-margin':
    case 'financial-calculator':
      return <FinancialCalculator />;
    case 'date-difference':
    case 'add-days':
    case 'hijri-gregorian':
    case 'zodiac-sign':
    case 'working-days':
    case 'day-of-week':
    case 'date-calculator':
      return <DateCalculator />;
    case 'zakat-money':
    case 'zakat-gold':
    case 'zakat-silver':
    case 'zakat-shares':
    case 'zakat-trade':
    case 'zakat-calculator':
      return <ZakatCalculator />;
    case 'stopwatch':
    case 'countdown-timer':
    case 'lap-timer':
    case 'stopwatch-timer':
      return <StopwatchTimer />;
    case 'installment-calculator':
      return <InstallmentCalculator />;

    // Health
    case 'pregnancy-due-date':
    case 'pregnancy-calculator':
      return <PregnancyCalculator />;
    case 'blood-compatibility':
    case 'blood-type':
      return <BloodTypeCompatibility />;

    // Student
    case 'gpa-calculator':
      return <GpaCalculator />;
    case 'pomodoro-timer':
      return <PomodoroTimer />;
    case 'numbers-to-words':
      return <NumbersToWords />;
    case 'arabic-numerals':
      return <ArabicNumerals />;

    // Discovery
    case 'random-picker':
      return <RandomPicker />;
    case 'ip-info':
      return <IpInfo />;

    // Units
    case 'unit-converter':
    case 'length-converter':
    case 'weight-converter':
    case 'temp-converter':
    case 'data-converter':
    case 'speed-converter':
    case 'area-converter':
    case 'volume-converter':
    case 'pressure-converter':
    case 'energy-converter':
    case 'power-converter':
    case 'angle-converter':
    case 'fuel-converter':
    case 'time-converter':
    case 'storage-converter':
      return <UnitConverter />;
    case 'currency-converter':
    case 'currency-calculator':
      return <CurrencyCalculator />;

    // Dev
    case 'password-generator':
      return <PasswordGenerator />;
    case 'json-formatter':
      return <JsonFormatter />;
    case 'svg-optimizer':
      return <SvgOptimizer />;
    case 'speed-test':
    case 'speed-test-simulator':
      return <SpeedTestSimulator />;
    case 'base-converter':
      return <BaseConverter />;
    case 'base64-converter':
      return <Base64Converter />;
    case 'uuid-generator':
      return <UuidGenerator />;
    case 'unix-timestamp':
      return <UnixTimestamp />;
    case 'regex-tester':
      return <RegexTester />;
    case 'css-formatter':
      return <CssFormatter />;
    case 'color-converter':
      return <ColorConverter />;

    // Suites
    case 'json-suite':
    case 'json-tools-suite':
    case 'json-validator':
    case 'json-minifier':
    case 'json-to-xml':
    case 'json-to-csv':
    case 'json-to-yaml':
      return <JsonToolsSuite defaultTab={toolId.replace('json-', '')} />;

    case 'xml-suite':
    case 'xml-tools-suite':
    case 'xml-validator':
    case 'xml-minifier':
    case 'xml-to-json':
    case 'xml-to-csv':
    case 'xml-to-yaml':
    case 'xml-formatter':
      return <XmlToolsSuite defaultTab={toolId.replace('xml-', '')} />;

    case 'svg-suite':
    case 'svg-tools-suite':
    case 'svg-viewer':
    case 'svg-minifier':
    case 'svg-to-jpg':
    case 'svg-to-webp':
      return <SvgToolsSuite defaultTab={toolId.replace('svg-', '')} />;

    case 'sql-suite':
    case 'sql-tools-suite':
    case 'sql-minifier':
    case 'sql-validator':
      return <SqlToolsSuite defaultTab={toolId.replace('sql-', '')} />;

    case 'code-formatters':
    case 'code-tools-suite':
    case 'js-formatter':
    case 'html-formatter':
    case 'yaml-formatter':
    case 'code-diff':
      return <CodeToolsSuite defaultTab={toolId.replace('-formatter', '')} />;

    case 'encoding-suite':
    case 'url-encode-decode':
    case 'html-encode-decode':
    case 'hex-encode-decode':
    case 'binary-encode-decode':
    case 'jwt-debugger':
      return <EncodingSuite defaultTab={toolId.replace('-encode-decode', '')} />;

    case 'security-data-suite':
    case 'hash-generator':
    case 'advanced-hash-generator':
      return <SecurityDataSuite defaultTab="hash-crypto" />;
    case 'jwt-inspector':
    case 'jwt-decoder':
    case 'jwt-token-decoder':
      return <SecurityDataSuite defaultTab="jwt-decoder" />;
    case 'qr-reader':
      return <SecurityDataSuite defaultTab="qr-reader" />;
    case 'yaml-json-converter':
      return <SecurityDataSuite defaultTab="yaml-json" />;
    case 'password-analyzer':
    case 'password-strength-tester':
      return <SecurityDataSuite defaultTab="password-generator" />;
    case 'credit-card-validator':
    case 'iban-validator':
    case 'mac-lookup':
      return <SecurityDataSuite defaultTab="hash-crypto" />;

    case 'web-dev-suite':
    case 'http-status-codes':
    case 'http-headers':
      return <WebDevSuite defaultTab="http-headers" />;
    case 'url-parser':
      return <WebDevSuite defaultTab="url-parser" />;
    case 'user-agent-parser':
      return <WebDevSuite defaultTab="user-agent" />;
    case 'code-minifier':
      return <WebDevSuite defaultTab="code-minifier" />;
    case 'meta-tags-generator':
    case 'robots-txt-generator':
    case 'htaccess-generator':
    case 'mime-types-lookup':
    case 'markdown-editor':
      return <WebDevSuite defaultTab="url-parser" />;

    case 'text-processing-suite':
    case 'text-sorter':
      return <TextProcessingSuite defaultTab="sort-lines" />;
    case 'remove-spaces':
      return <TextProcessingSuite defaultTab="extra-spaces" />;
    case 'text-reverse':
      return <TextProcessingSuite defaultTab="reverse-text" />;
    case 'extract-urls':
      return <TextProcessingSuite defaultTab="extract-urls" />;
    case 'extract-emails':
      return <TextProcessingSuite defaultTab="extract-emails" />;
    case 'merge-lines':
      return <TextProcessingSuite defaultTab="merge-lines" />;
    case 'split-lines':
      return <TextProcessingSuite defaultTab="split-text" />;
    case 'slug-generator':
    case 'find-and-replace':
    case 'morse-code-converter':
      return <TextProcessingSuite defaultTab="extra-spaces" />;

    case 'image-processing-suite':
      return <ImageProcessingSuite defaultTab="compress" />;
    case 'image-resizer':
      return <ImageProcessingSuite defaultTab="resize" />;
    case 'image-cropper':
      return <ImageProcessingSuite defaultTab="crop" />;
    case 'image-filters':
    case 'transparent-bg':
      return <ImageProcessingSuite defaultTab="transparent-bg" />;
    case 'remove-exif':
      return <ImageProcessingSuite defaultTab="remove-exif" />;
    case 'meme-generator':
      return <ImageProcessingSuite defaultTab="image-to-pdf" />;
    case 'favicon-generator':
    case 'favicon-maker':
      return <ImageProcessingSuite defaultTab="favicon-maker" />;

    case 'pdf-tools-suite':
    case 'pdf-merge-adv':
      return <PdfToolsSuite defaultTab="merge" />;
    case 'pdf-split-adv':
      return <PdfToolsSuite defaultTab="split" />;
    case 'pdf-watermark':
      return <PdfToolsSuite defaultTab="watermark" />;
    case 'pdf-page-rotator':
    case 'pdf-page-number':
    case 'pdf-reorder':
      return <PdfToolsSuite defaultTab="organize" />;

    case 'design-suite':
      return <DesignSuite defaultTab="color-converter" />;
    case 'box-shadow-generator':
    case 'box-shadow-gen':
      return <DesignSuite defaultTab="box-shadow" />;
    case 'border-radius-generator':
    case 'border-radius-gen':
      return <DesignSuite defaultTab="border-radius" />;
    case 'glassmorphism-generator':
    case 'neumorphism-generator':
    case 'aspect-ratio-calc':
      return <DesignSuite defaultTab="palette-generator" />;
    case 'contrast-checker':
      return <DesignSuite defaultTab="contrast-checker" />;

    case 'social-suite':
    case 'hashtag-generator':
      return <SocialSuite defaultTab="hashtag-generator" />;
    case 'bio-generator':
    case 'bio-link-generator':
      return <SocialSuite defaultTab="bio-generator" />;
    case 'username-generator':
      return <SocialSuite defaultTab="username-generator" />;
    case 'social-resizer':
      return <SocialSuite defaultTab="social-resizer" />;
    case 'utm-builder':
    case 'link-shortener':
    case 'social-qr':
      return <SocialSuite defaultTab="social-qr" />;
    case 'tweet-generator':
      return <SocialSuite defaultTab="bio-generator" />;

    case 'calculators-suite':
    case 'percentage-calc':
      return <CalculatorsSuite defaultTab="percentage" />;
    case 'discount-calc':
      return <CalculatorsSuite defaultTab="discount" />;
    case 'vat-calc':
      return <CalculatorsSuite defaultTab="vat" />;
    case 'profit-margin-calc':
      return <CalculatorsSuite defaultTab="profit-margin" />;
    case 'tip-calculator':
    case 'fuel-cost-calculator':
    case 'gpa-advanced-calc':
    case 'inflation-calculator':
    case 'crypto-profit-calc':
      return <CalculatorsSuite defaultTab="percentage" />;

    // Health, Surgery & Biochemistry
    case 'medical-tools-suite':
    case 'fluid-balance-calculator':
    case 'abg-interpreter':
    case 'pediatric-dose-calc':
    case 'cardiac-risk-calc':
    case 'gfr-calculator':
    case 'map-calculator':
      return <MedicalToolsSuite defaultTab={toolId} />;

    case 'surgery-3d-suite':
    case 'surgical-anatomy-3d-suite':
    case '3d-surgery-simulator':
    case 'cardiac-bypass-surgery':
    case 'heart-surgery-3d':
      return <SurgicalAnatomy3DSuite defaultOrgan="heart" />;
    case 'brain-neurosurgery-3d':
    case 'brain-aneurysm-surgery':
      return <SurgicalAnatomy3DSuite defaultOrgan="brain" />;
    case 'lungs-surgery-3d':
      return <SurgicalAnatomy3DSuite defaultOrgan="lungs" />;
    case 'eye-surgery-3d':
      return <SurgicalAnatomy3DSuite defaultOrgan="eye" />;
    case 'knee-replacement-3d':
    case 'knee-arthroscopy-surgery':
      return <SurgicalAnatomy3DSuite defaultOrgan="knee" />;
    case 'laparoscopy-cholecystectomy-3d':
    case 'appendectomy-surgery':
      return <SurgicalAnatomy3DSuite defaultOrgan="laparoscopy" />;
    case 'spine-disc-surgery-3d':
      return <SurgicalAnatomy3DSuite defaultOrgan="spine" />;
    case 'organ-anatomy-3d':
    case 'surgical-risk-calculator':
    case 'operative-report-generator':
    case 'suture-instrument-guide':
    case 'surgical-safety-checklist':
      return <SurgicalAnatomy3DSuite defaultOrgan="heart" />;

    case 'chemical-reactions-lab':
    case 'human-body-reactions':
    case 'dilution-calculator':
    case 'stoichiometry-calc':
    case 'reaction-balancer':
    case 'periodic-table-interactive':
    case 'molar-mass-calc':
      return <ChemicalReactionsLab />;

    case 'biochemistry-lab-suite':
    case 'biochem-lab':
    case 'ph-blood-calculator':
    case 'enzyme-kinetics-calc':
    case 'buffer-ph-calculator':
    case 'dna-rna-transcriber':
    case 'protein-mw-calc':
    case 'electrophoresis-simulator':
      return <BiochemistryLabSuite />;

    // Engineering & Diagrams
    case 'triangle-solver':
      return <TriangleSolver />;

    case 'engineering-math-suite':
    case 'matrix-operations-calc':
    case 'beam-deflection-calc':
    case 'boolean-algebra-simplifier':
    case 'circuit-law-calc':
    case 'statistical-distribution-calc':
    case 'scientific-graphing-calc':
      return <EngineeringMathSuite defaultTab={toolId} />;

    case 'diagrams-design-suite':
    case 'flowchart-editor':
    case 'mindmap-creator':
    case 'database-erd-designer':
    case 'wireframe-sketcher':
    case 'network-topology-builder':
      return <DiagramsDesignSuite defaultTab={toolId} />;

    // Mega Converters Hub
    case 'mega-converters-suite':
      return <MegaConvertersSuite defaultTab="text-cases" />;
    case 'media-converters-hub':
    case 'media-image-converter':
      return <UniversalImageConverter />;
    case 'media-audio-converter':
      return <AudioConverter />;
    case 'media-video-converter':
      return <VideoConverter />;
    case 'media-archive-converter':
      return <ArchiveConverter />;
    case 'documents-converters-hub':
    case 'doc-word-to-pdf':
    case 'doc-pdf-to-word':
    case 'doc-excel-to-pdf':
    case 'doc-pdf-to-excel':
    case 'doc-ocr-extractor':
      return <DocumentConverter />;
    case 'data-converters-hub':
    case 'data-json-to-csv':
    case 'data-csv-to-json':
    case 'data-json-to-yaml':
    case 'data-yaml-to-json':
    case 'data-sql-to-json':
      return <DataTableConverter />;
    case 'dev-converters-hub':
    case 'dev-code-converters':
      return <DevConverterSuite defaultMode="json-formatter" />;
    case 'dev-color-converters':
      return <DevConverterSuite defaultMode="color-converter" />;
    case 'dev-units-converters':
      return <UnitConverter />;
    case 'dev-timestamp-converters':
      return <TimeDateConverter />;
    case 'finance-converters-hub':
    case 'fin-gold-metals-calc':
    case 'fin-crypto-converter':
      return <FinancialCalculator />;
    case 'fin-currency-exchange':
      return <CurrencyCalculator />;

    // Data Tools Suite
    case 'data-tools-suite':
      return <DataToolsSuite defaultTab="csv-editor" />;
    case 'csv-data-editor':
      return <DataToolsSuite defaultTab="csv-editor" />;
    case 'json-data-viewer':
      return <DataToolsSuite defaultTab="json-viewer" />;
    case 'excel-cleaner':
      return <DataToolsSuite defaultTab="excel-cleaner" />;
    case 'data-anonymizer':
      return <DataToolsSuite defaultTab="data-anonymizer" />;
    case 'column-filter-sorter':
      return <DataToolsSuite defaultTab="column-filter" />;
    case 'regex-data-extractor':
      return <DataToolsSuite defaultTab="regex-extractor" />;

    // Developer & Design Hub
    case 'dev-design-hub':
    case 'dev-design-hub-suite':
      return <DevDesignHubSuite defaultTab="html-tailwind" />;
    case 'html-to-tailwind-jsx':
      return <DevDesignHubSuite defaultTab="html-tailwind" />;
    case 'svg-shape-morpher':
      return <DevDesignHubSuite defaultTab="svg-morpher" />;
    case 'css-glass-clay-generator':
      return <DevDesignHubSuite defaultTab="css-glass" />;
    case 'api-mock-server-gen':
      return <DevDesignHubSuite defaultTab="api-mock" />;
    case 'font-pairing-previewer':
      return <DevDesignHubSuite defaultTab="font-pairing" />;
    case 'micro-interaction-builder':
      return <DevDesignHubSuite defaultTab="micro-interactions" />;

    // Security Suite
    case 'security-suite':
      return <SecuritySuite defaultTab="jwt-decoder" />;
    case 'jwt-token-decoder':
      return <SecuritySuite defaultTab="jwt-decoder" />;
    case 'advanced-hash-generator':
      return <SecuritySuite defaultTab="hash-gen" />;
    case 'password-strength-tester':
      return <SecuritySuite defaultTab="password-strength" />;
    case 'uuid-v4-generator':
      return <SecuritySuite defaultTab="uuid-gen" />;
    case 'random-string-generator':
      return <SecuritySuite defaultTab="random-string" />;
    case 'html-entities-encoder':
      return <SecuritySuite defaultTab="html-entities" />;

    // Daily Calculators Hub
    case 'daily-calculators-hub':
      return <DailyCalculatorsHub />;
    case 'date-diff-calculator':
      return <DailyCalculatorsHub defaultTab="date-diff" />;
    case 'add-subtract-days':
      return <DailyCalculatorsHub defaultTab="add-days" />;
    case 'random-number-lottery':
      return <DailyCalculatorsHub defaultTab="random-lottery" />;

    // AI Assistant & Chatbot
    case 'assistant':
    case 'ai-assistant':
    case 'smart-assistant':
    case 'chat-assistant':
    case 'chatbot':
      return <AssistantPage />;

    default:
      return (
        <div className="py-20 text-center space-y-3 bg-white dark:bg-gray-900 rounded-3xl border border-dashed border-gray-200 dark:border-gray-800 p-8">
          <h3 className="text-base font-bold text-gray-800 dark:text-gray-200">
            هذه الأداة قيد التطوير
          </h3>
          <p className="text-xs text-gray-500 max-w-sm mx-auto">
            عذراً، الأداة التي تحاول الوصول إليها سيتم إضافتها قريباً.
          </p>
        </div>
      );
  }
}

export function ToolRenderer({ toolId }: { toolId: string }) {
  return (
    <ErrorBoundary>
      <Suspense fallback={<LoadingFallback message="جاري تشغيل الأداة..." />}>
        {renderTool(toolId)}
      </Suspense>
    </ErrorBoundary>
  );

}
