import React, { useState } from 'react';
import { Code2, FileCode2, RefreshCw, Copy, Download, CheckCircle2, XCircle } from 'lucide-react';
import confetti from 'canvas-confetti';
import beautify from 'js-beautify';

type CodeTab = 'html-format' | 'html-minify' | 'css-format' | 'css-minify' | 'js-format' | 'js-minify';

export function CodeToolsSuite({ defaultTab = 'html-format' }: { defaultTab?: string }) {
  const [activeTab, setActiveTab] = useState<CodeTab>(defaultTab as CodeTab);
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const tabs: { id: CodeTab; label: string; icon: any }[] = [
    { id: 'html-format', label: 'HTML Formatter', icon: Code2 },
    { id: 'html-minify', label: 'HTML Minifier', icon: RefreshCw },
    { id: 'css-format', label: 'CSS Formatter', icon: FileCode2 },
    { id: 'css-minify', label: 'CSS Minifier', icon: RefreshCw },
    { id: 'js-format', label: 'JS Formatter', icon: Code2 },
    { id: 'js-minify', label: 'JS Minifier', icon: RefreshCw },
  ];

  const handleProcess = () => {
    setError(null);
    setSuccess(null);
    setOutput('');

    if (!input.trim()) {
      setError('الرجاء إدخال الكود أولاً');
      return;
    }

    try {
      if (activeTab === 'html-format') {
        setOutput(beautify.html(input, { indent_size: 2 }));
        setSuccess('تم تنسيق كود HTML بنجاح');
      } else if (activeTab === 'html-minify') {
        let minified = input.replace(/<!--[\s\S]*?-->/g, '').replace(/>\s+</g, '><').trim();
        setOutput(minified);
        setSuccess('تم ضغط كود HTML بنجاح');
      } else if (activeTab === 'css-format') {
        setOutput(beautify.css(input, { indent_size: 2 }));
        setSuccess('تم تنسيق كود CSS بنجاح');
      } else if (activeTab === 'css-minify') {
        let minified = input.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\s+/g, ' ').replace(/\s*([{}:;,])\s*/g, '$1').trim();
        setOutput(minified);
        setSuccess('تم ضغط كود CSS بنجاح');
      } else if (activeTab === 'js-format') {
        setOutput(beautify.js(input, { indent_size: 2 }));
        setSuccess('تم تنسيق كود JS بنجاح');
      } else if (activeTab === 'js-minify') {
        // Simple JS minification (removes comments and excess whitespace, not a full AST minifier)
        let minified = input.replace(/\/\*[\s\S]*?\*\//g, '').replace(/\/\/.*/g, '').replace(/\s+/g, ' ').trim();
        setOutput(minified);
        setSuccess('تم ضغط كود JS بشكل مبدئي بنجاح');
      }
      confetti({ particleCount: 30, spread: 50 });
    } catch (err: any) {
      setError('خطأ في معالجة الكود: ' + err.message);
    }
  };

  const handleCopy = () => {
    if (!output) return;
    navigator.clipboard.writeText(output);
    setSuccess('تم النسخ إلى الحافظة');
    setTimeout(() => setSuccess(null), 2000);
  };

  const handleDownload = () => {
    if (!output) return;
    const ext = activeTab.includes('html') ? 'html' : activeTab.includes('css') ? 'css' : 'js';
    const blob = new Blob([output], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `code.${ext}`;
    a.click();
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap gap-2 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => { setActiveTab(tab.id); setOutput(''); setError(null); setSuccess(null); }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-lg'
                : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-50'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span className="text-sm font-medium">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white">الإدخال</h3>
            <button onClick={() => setInput('')} className="text-sm text-red-500 hover:text-red-600">مسح</button>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full h-96 p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-left dir-ltr"
            placeholder="الصق الكود هنا..."
          />
          <button
            onClick={handleProcess}
            className="w-full mt-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-5 h-5" />
            <span>تنفيذ العملية</span>
          </button>
        </div>

        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white">النتيجة</h3>
            <div className="flex gap-2">
              <button onClick={handleCopy} className="p-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <Copy className="w-4 h-4" />
              </button>
              <button onClick={handleDownload} className="p-2 text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg">
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          {error && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg flex items-center gap-2 text-sm">
              <XCircle className="w-5 h-5" />
              {error}
            </div>
          )}
          
          {success && (
            <div className="mb-4 p-3 bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-lg flex items-center gap-2 text-sm">
              <CheckCircle2 className="w-5 h-5" />
              {success}
            </div>
          )}

          <textarea
            value={output}
            readOnly
            className="w-full h-96 p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-left dir-ltr"
            placeholder="ستظهر النتيجة هنا..."
          />
        </div>
      </div>
    </div>
  );
}
