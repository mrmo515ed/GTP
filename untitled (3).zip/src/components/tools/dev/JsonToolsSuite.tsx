import React, { useState } from 'react';
import { FileJson, CheckCircle2, XCircle, Copy, Download, RefreshCw, FileText, FileSpreadsheet, FileCode } from 'lucide-react';
import confetti from 'canvas-confetti';
import { parse as yamlParse, stringify as yamlStringify } from 'yaml';
import { js2xml } from 'xml-js';
import Papa from 'papaparse';

type JsonTab = 'format' | 'validate' | 'minify' | 'to-xml' | 'to-csv' | 'to-yaml';

export function JsonToolsSuite({ defaultTab = 'format' }: { defaultTab?: string }) {
  const [activeTab, setActiveTab] = useState<JsonTab>(defaultTab as JsonTab);
  const [input, setInput] = useState('');
  const [output, setOutput] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState<string | null>(null);

  const tabs: { id: JsonTab; label: string; icon: any }[] = [
    { id: 'format', label: 'JSON Formatter / Beautifier', icon: FileJson },
    { id: 'validate', label: 'JSON Validator', icon: CheckCircle2 },
    { id: 'minify', label: 'JSON Minifier', icon: RefreshCw },
    { id: 'to-xml', label: 'JSON to XML', icon: FileCode },
    { id: 'to-csv', label: 'JSON to CSV', icon: FileSpreadsheet },
    { id: 'to-yaml', label: 'JSON to YAML', icon: FileText },
  ];

  const handleProcess = () => {
    setError(null);
    setSuccess(null);
    setOutput('');

    if (!input.trim()) {
      setError('الرجاء إدخال كود JSON أولاً');
      return;
    }

    try {
      const parsed = JSON.parse(input);

      switch (activeTab) {
        case 'format':
          setOutput(JSON.stringify(parsed, null, 2));
          setSuccess('تم التنسيق بنجاح');
          break;
        case 'validate':
          setOutput(JSON.stringify(parsed, null, 2));
          setSuccess('كود JSON صالح وخالٍ من الأخطاء ✅');
          break;
        case 'minify':
          setOutput(JSON.stringify(parsed));
          setSuccess('تم تصغير الكود بنجاح');
          break;
        case 'to-xml':
          const xml = js2xml({ root: parsed }, { compact: true, spaces: 2 });
          setOutput(xml);
          setSuccess('تم التحويل إلى XML بنجاح');
          break;
        case 'to-csv':
          let dataToCsv = parsed;
          if (!Array.isArray(parsed)) {
            dataToCsv = [parsed];
          }
          const csv = Papa.unparse(dataToCsv);
          setOutput(csv);
          setSuccess('تم التحويل إلى CSV بنجاح');
          break;
        case 'to-yaml':
          const yaml = yamlStringify(parsed);
          setOutput(yaml);
          setSuccess('تم التحويل إلى YAML بنجاح');
          break;
      }
      confetti({ particleCount: 30, spread: 50 });
    } catch (err: any) {
      setError('خطأ في بناء جملة JSON: ' + err.message);
    }
  };

  const handleCopy = () => {
    if (!output && activeTab !== 'validate') return;
    navigator.clipboard.writeText(output);
    setSuccess('تم النسخ إلى الحافظة');
    setTimeout(() => setSuccess(null), 2000);
  };

  const handleDownload = () => {
    if (!output) return;
    const exts: Record<string, string> = {
      'format': 'json', 'validate': 'json', 'minify': 'json',
      'to-xml': 'xml', 'to-csv': 'csv', 'to-yaml': 'yaml'
    };
    const ext = exts[activeTab] || 'txt';
    const blob = new Blob([output], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `result.${ext}`;
    a.click();
  };

  return (
    <div className="space-y-6">
      {/* Tabs */}
      <div className="flex flex-wrap gap-2 mb-6">
        {tabs.map((tab) => (
          <button
            key={tab.id}
            onClick={() => { setActiveTab(tab.id); setOutput(''); setError(null); setSuccess(null); }}
            className={`flex items-center gap-2 px-4 py-2 rounded-xl transition-all ${
              activeTab === tab.id
                ? 'bg-indigo-600 text-white shadow-lg'
                : 'bg-white dark:bg-gray-800 text-gray-600 dark:text-gray-300 hover:bg-gray-50'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span className="text-sm font-medium">{tab.label}</span>
          </button>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Input */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white">الإدخال (JSON)</h3>
            <button onClick={() => setInput('')} className="text-sm text-red-500 hover:text-red-600">مسح</button>
          </div>
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            className="w-full h-96 p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-left dir-ltr"
            placeholder="الصق كود JSON هنا..."
          />
          <button
            onClick={handleProcess}
            className="w-full mt-4 bg-indigo-600 hover:bg-indigo-700 text-white font-bold py-3 px-4 rounded-xl transition-colors flex items-center justify-center gap-2"
          >
            <RefreshCw className="w-5 h-5" />
            <span>تنفيذ العملية</span>
          </button>
        </div>

        {/* Output */}
        <div className="bg-white dark:bg-gray-800 rounded-2xl p-6 shadow-sm border border-gray-100 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="text-lg font-bold text-gray-800 dark:text-white">النتيجة</h3>
            <div className="flex gap-2">
              <button onClick={handleCopy} className="p-2 text-gray-500 hover:bg-gray-100 dark:hover:bg-gray-700 rounded-lg">
                <Copy className="w-4 h-4" />
              </button>
              <button onClick={handleDownload} className="p-2 text-indigo-500 hover:bg-indigo-50 dark:hover:bg-indigo-900/30 rounded-lg">
                <Download className="w-4 h-4" />
              </button>
            </div>
          </div>
          
          {error && (
            <div className="mb-4 p-3 bg-red-50 dark:bg-red-900/30 text-red-600 dark:text-red-400 rounded-lg flex items-center gap-2 text-sm">
              <XCircle className="w-5 h-5" />
              {error}
            </div>
          )}
          
          {success && (
            <div className="mb-4 p-3 bg-green-50 dark:bg-green-900/30 text-green-600 dark:text-green-400 rounded-lg flex items-center gap-2 text-sm">
              <CheckCircle2 className="w-5 h-5" />
              {success}
            </div>
          )}

          <textarea
            value={output}
            readOnly
            className="w-full h-96 p-4 bg-gray-50 dark:bg-gray-900 border border-gray-200 dark:border-gray-700 rounded-xl focus:ring-2 focus:ring-indigo-500 font-mono text-left dir-ltr"
            placeholder="ستظهر النتيجة هنا..."
          />
        </div>
      </div>
    </div>
  );
}
